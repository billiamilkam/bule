# Panduan Lengkap Installasi Aplikasi Billing di VPS dengan MobaXterm

Panduan ini menjelaskan langkah demi langkah untuk mengunggah, menginstal, dan menjalankan aplikasi full-stack (React + Express + MySQL) ini di VPS Linux (Ubuntu 20.04 / 22.04) menggunakan aplikasi **MobaXterm**.

---

## 📋 Daftar Isi
1. [Persiapan Awal](#1-persiapan-awal)
2. [Langkah 1: Menghubungkan VPS di MobaXterm](#langkah-1-menghubungkan-vps-di-mobaxterm)
3. [Langkah 2: Menginstal Node.js dan PM2 di VPS](#langkah-2-menginstal-nodejs-dan-pm2-di-vps)
4. [Langkah 3: Menginstal dan Menyiapkan Database MySQL](#langkah-3-menginstal-dan-menyiapkan-database-mysql)
5. [Langkah 4: Mengunggah Kode Aplikasi ke VPS](#langkah-4-mengunggah-kode-aplikasi-ke-vps)
6. [Langkah 5: Konfigurasi Environment (`.env`)](#langkah-5-konfigurasi-environment-env)
7. [Langkah 6: Membangun (Build) dan Menjalankan Aplikasi](#langkah-6-membangun-build-dan-menjalankan-aplikasi)
8. [Langkah 7: Mengonfigurasi Nginx sebagai Reverse Proxy (Opsional)](#langkah-7-mengonfigurasi-nginx-sebagai-reverse-proxy-opsional)
9. [Tips Tambahan Keterbacaan Mikrotik](#tips-tambahan-keterbacaan-mikrotik)

---

## 1. Persiapan Awal
Sebelum memulai, pastikan Anda memiliki:
1. **IP Address VPS**, **Username** (biasanya `root`), dan **Password** atau **SSH Key**.
2. **MobaXterm** terinstal di komputer lokal Anda (Unduh gratis dari situs resminya).
3. File proyek ini sudah bersih dari folder `node_modules` (folder ini nantinya akan di-install langsung di VPS demi mempercepat proses upload).

---

## Langkah 1: Menghubungkan VPS di MobaXterm
1. Buka aplikasi **MobaXterm**.
2. Di pojok kiri atas, klik tombol **Session**, kemudian pilih **SSH**.
3. Isi kolom sebagai berikut:
   - **Remote host**: Masukkan **IP Address VPS** Anda.
   - **Specify username**: Centang kotak ini lalu ketik `root` (atau username non-root Anda).
   - **Port**: `22` (default port SSH, ubah jika VPS Anda menggunakan port kustom).
4. Klik **OK**.
5. Jendela terminal hitam akan muncul dan meminta password:
   - Ketik password VPS Anda (Kursor tidak akan bergeser saat mengetik password untuk alasan keamanan).
   - Tekan **Enter**.
   - Jika ditanya *"Do you want to save password?"*, klik **Yes** jika Anda ingin login otomatis di kemudian hari.
6. Sekarang Anda telah berhasil masuk ke terminal SSH VPS Anda!

---

## Langkah 2: Menginstal Node.js dan PM2 di VPS
Jalankan perintah-perintah berikut di terminal MobaXterm secara berurutan untuk memperbarui sistem dan menginstal Node.js versi LTS (v20):

1. **Perbarui package list sistem:**
   ```bash
   sudo apt update && sudo apt upgrade -y
   ```

2. **Instal Node.js v20 LTS menggunakan NodeSource Node LTS:**
   ```bash
   curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
   sudo apt-get install -y nodejs
   ```

3. **Verifikasi instalasi Node.js dan npm:**
   ```bash
   node -v
   npm -v
   ```
   *(Kedua perintah ini harus memunculkan versi Node.js v20.x dan npm v10.x).*

4. **Instal PM2 secara global:**
   PM2 adalah process manager yang bertugas menjaga aplikasi Node.js tetap menyala jika terjadi error, reboot server, atau ketika terminal MobaXterm ditutup.
   ```bash
   sudo npm install -y -g pm2
   ```

---

## Langkah 3: Menginstal dan Menyiapkan Database MySQL
Jika VPS Anda belum memiliki database MySQL, jalankan perintah ini untuk menginstalnya:

1. **Pasang MySQL Server:**
   ```bash
   sudo apt install mysql-server -y
   ```

2. **Masuk ke MySQL Command Line:**
   ```bash
   sudo mysql
   ```

3. **Buat Database dan User Baru secara Aman:**
   Jalankan query SQL berikut (ganti kata sandi `gagah1313` jika Anda ingin mengubahnya):
   ```sql
   CREATE DATABASE bule_apk;
   CREATE USER 'bule_apk'@'localhost' IDENTIFIED BY 'gagah1313';
   GRANT ALL PRIVILEGES ON bule_apk.* TO 'bule_apk'@'localhost';
   FLUSH PRIVILEGES;
   EXIT;
   ```

---

## Langkah 4: Mengunggah Kode Aplikasi ke VPS
MobaXterm mempermudah pengunggahan file karena menyertakan panel **SFTP (file explorer)** di sebelah kiri layar terminal.

1. **Buat folder aplikasi di VPS:**
   Ketik perintah berikut di terminal untuk membuat folder `/var/www/billing-app` dan masuk ke dalamnya:
   ```bash
   mkdir -p /var/www/billing-app
   cd /var/www/billing-app
   ```

2. **Gunakan Panel SFTP MobaXterm:**
   - Di panel kiri MobaXterm, arahkan folder explorer-nya ke: `/var/www/billing-app` (Anda bisa mengetik jalur ini di bilah navigasi atas panel kiri atau mengkliknya secara visual).
   - Di komputer lokal Anda, lakukan **ZIP/Compress** pada seluruh folder proyek Anda **KECUALI** folder `node_modules` dan folder `.git` (jika ada). Beri nama file compress tersebut misalnya `billing-app.zip`.
   - **Drag and Drop / Tarik** file `billing-app.zip` dari komputer lokal Anda, lalu lepaskan di panel SFTP kiri MobaXterm.
   - Tunggu proses unggahan selesai (indikator bar hijau di bagian bawah panel kiri).

3. **Ekstrak File ZIP di VPS:**
   Instal tool unzip di VPS dan ekstrak filenya:
   ```bash
   sudo apt install unzip -y
   unzip billing-app.zip
   # Hapus file zip setelah diekstrak agar hemat ruang penyimpanan
   rm billing-app.zip
   ```

---

## Langkah 5: Konfigurasi Environment (`.env`)
Double-click file bernama `.env` langsung di panel SFTP kiri MobaXterm untuk mengeditnya menggunakan editor teks bawaan MobaXterm. Jika file tidak ada, Anda dapat membuatnya:

1. Di terminal VPS, buat file `.env`:
   ```bash
   nano .env
   ```

2. Salin dan tempel konfigurasi ini (sesuaikan dengan credential MySQL Anda):
   ```env
   PORT=3000
   MYSQL_DB_HOST=127.0.0.1
   MYSQL_DB_PORT=3306
   MYSQL_DB_USER=bule_apk
   MYSQL_DB_PASSWORD=gagah1313
   MYSQL_DB_DATABASE=bule_apk
   MYSQL_DB_ACTIVE=true
   GEMINI_API_KEY=AIzaSy... (Sediakan jika Anda menggunakan fitur asisten kecerdasan buatan)
   ```

3. Tekan `Ctrl + O` kemudian `Enter` untuk menyimpan, lalu `Ctrl + X` untuk keluar dari editor nano.

---

## Langkah 6: Membangun (Build) dan Menjalankan Aplikasi
Sekarang saatnya menginstal library yang diperlukan dan mengompilasi kode TypeScript Anda untuk produksi.

1. **Pasang dependencies:**
   ```bash
   npm install
   ```

2. **Jalankan kompilasi produksi:**
   Perintah ini akan menjalankan Vite build untuk client-side dan esbuild bundler untuk server-side TypeScript agar di-bundle ke file tunggal `/dist/server.cjs`:
   ```bash
   npm run build
   ```

3. **Jalankan aplikasi menggunakan PM2 (Background Process):**
   ```bash
   pm2 start npm --name "billing-panel" -- start
   ```

4. **Simpan konfigurasi PM2 agar otomatis berjalan saat VPS reboot:**
   ```bash
   pm2 save
   pm2 startup
   ```
   *(PM2 startup akan menghasilkan perintah konfigurasi berupa script, silakan salin dan jalankan perintah tersebut jika diminta)*.

5. **Periksa status aplikasi:**
   ```bash
   pm2 list
   ```
   Pastikan status aplikasi `"billing-panel"` adalah `online`.

---

## Langkah 7: Mengonfigurasi Nginx sebagai Reverse Proxy (Opsional)
Saat ini aplikasi berjalan di port `3000`. Agar user bisa membukanya melalui alamat IP standar (Port 80) atau memakai Domain Name tanpa mengetik `:3000`, jalankan reverse proxy Nginx.

1. **Instal Nginx:**
   ```bash
   sudo apt install nginx -y
   ```

2. **Buat file konfigurasi baru:**
   ```bash
   sudo nano /etc/nginx/sites-available/billing
   ```

3. **Salin konfigurasi proxy berikut:**
   ```nginx
   server {
       listen 80;
       server_name domain_anda_atau_ip_vps; # contoh: billing.com atau 103.xxx.xxx.xxx

       location / {
           proxy_pass http://127.0.0.1:3000;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_cache_bypass $http_upgrade;
       }
   }
   ```

4. **Aktifkan konfigurasi dan restart Nginx:**
   ```bash
   sudo ln -s /etc/nginx/sites-available/billing /etc/nginx/sites-enabled/
   # Hapus konfigurasi default Nginx agar tidak konflik
   sudo rm /etc/nginx/sites-enabled/default
   # Uji konfigurasi Nginx
   sudo nginx -t
   # Restart Nginx
   sudo systemctl restart nginx
   ```

Sekarang jalankan browser Anda dan buka alamat IP VPS Anda atau domain yang terhubung!

---

## Tips Tambahan Keterbacaan Mikrotik
Jika Anda mengalami masalah tidak bisa terhubung dengan Mikrotik API:
1. Pastikan port API Mikrotik (`8728` atau SSL `8729`) tidak diblokir oleh firewall VPS. Anda bisa mencoba mem-allow koneksi keluar di VPS dengan perintah:
   ```bash
   sudo ufw allow out 8728/tcp
   sudo ufw allow out 8729/tcp
   ```
2. Di sisi Winbox RouterBOARD Mikrotik, pastikan layanan API aktif pada menu **IP -> Services**, dan set kolom `Available From` jika Anda ingin membatasi agar hanya IP VPS Anda yang diizinkan memanggil command API ini demi keamanan jaringan.
