import { Pelanggan, Paket, Tagihan } from './types';

export function formatRupiah(amount: number): string {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0
  }).format(amount);
}

export function getNamaBulanIndo(monthNum: string): string {
  const months: { [key: string]: string } = {
    '01': 'Januari',
    '02': 'Februari',
    '03': 'Maret',
    '04': 'April',
    '05': 'Mei',
    '06': 'Juni',
    '07': 'Juli',
    '08': 'Agustus',
    '09': 'September',
    '10': 'Oktober',
    '11': 'November',
    '12': 'Desember'
  };
  return months[monthNum] || monthNum;
}

export function formatBulanIndo(bulanStr: string): string {
  if (!bulanStr || !bulanStr.includes('-')) return bulanStr;
  const [year, month] = bulanStr.split('-');
  return `${getNamaBulanIndo(month)} ${year}`;
}

export function formatTanggalIndo(dateStr: any): string {
  if (!dateStr) return '';
  const str = typeof dateStr === 'string' ? dateStr : String(dateStr);
  
  let datePart = '';
  let timePart = '';
  
  if (str.includes('T')) {
    const parts = str.split('T');
    datePart = parts[0];
    timePart = parts[1] ? ` pukul ${parts[1].substring(0, 5)}` : '';
  } else {
    const parts = str.split(' ');
    datePart = parts[0];
    timePart = parts[1] ? ` pukul ${parts[1].substring(0, 5)}` : '';
  }
  
  const dateSplit = datePart.split('-');
  if (dateSplit.length < 3) return str;
  
  const [year, month, day] = dateSplit;
  return `${parseInt(day)} ${getNamaBulanIndo(month)} ${year}${timePart}`;
}

export function generateInvoiceId(pelangganId: string, bulan: string): string {
  const cleanBulan = bulan.replace('-', '');
  const cleanPlg = pelangganId.replace('plg-', '');
  return `INV-${cleanBulan}-${cleanPlg}-${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`;
}

interface TemplateVars {
  Nama: string;
  NamaLayanan: string;
  Alamat: string;
  Bulan: string;
  Tarif: string;
  JatuhTempo: string;
  TanggalBayar?: string;
  MetodeBayar?: string;
  NamaBank: string;
  NoRek: string;
  AtasNama: string;
  NamaPenyedia: string;
}

export function replaceTemplates(template: string, vars: TemplateVars): string {
  let text = template;
  text = text.replace(/\[Nama\]/g, vars.Nama);
  text = text.replace(/\[NamaLayanan\]/g, vars.NamaLayanan);
  text = text.replace(/\[Alamat\]/g, vars.Alamat);
  text = text.replace(/\[Bulan\]/g, vars.Bulan);
  text = text.replace(/\[Tarif\]/g, vars.Tarif);
  text = text.replace(/\[JatuhTempo\]/g, vars.JatuhTempo);
  text = text.replace(/\[TanggalBayar\]/g, vars.TanggalBayar || '-');
  text = text.replace(/\[MetodeBayar\]/g, vars.MetodeBayar || '-');
  text = text.replace(/\[NamaBank\]/g, vars.NamaBank);
  text = text.replace(/\[NoRek\]/g, vars.NoRek);
  text = text.replace(/\[AtasNama\]/g, vars.AtasNama);
  text = text.replace(/\[NamaPenyedia\]/g, vars.NamaPenyedia);
  return text;
}

export function isPastDue(tanggalJatuhTempo: string, currentTanggalStr: string = '2026-06-14'): boolean {
  return new Date(tanggalJatuhTempo) < new Date(currentTanggalStr);
}
