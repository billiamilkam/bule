import { 
  Pelanggan, Paket, Tagihan, WhatsAppLog, AppSettings, 
  MikrotikServer, TukangTagih, Reseller, HotspotVoucher, PppoeUser, PesananAgen, Teknisi,
  PortalActivityLog
} from './types';

export const DEFAULT_PAKET: Paket[] = [
  {
    id: 'pkt-1',
    nama: 'Paket Hemat',
    kecepatan: '5 Mbps',
    harga: 100000,
    deskripsi: 'Cocok untuk kebutuhan chatting, browsing ringan, dan sosial media 1-2 perangkat.',
    mikrotikProfile: 'hs-hemat-5M'
  },
  {
    id: 'pkt-2',
    nama: 'Paket Keluarga',
    kecepatan: '10 Mbps',
    harga: 150000,
    deskripsi: 'Recomended! Streaming video HD lancar untuk 3-4 perangkat dirumah.',
    mikrotikProfile: 'hs-keluarga-10M'
  },
  {
    id: 'pkt-3',
    nama: 'Paket Premium',
    kecepatan: '20 Mbps',
    harga: 250000,
    deskripsi: 'Sangat cocok untuk gaming online, work from home, dan streaming 4K secara bersamaan.',
    mikrotikProfile: 'hs-premium-20M'
  },
  {
    id: 'pkt-4',
    nama: 'Paket Bisnis',
    kecepatan: '50 Mbps',
    harga: 450000,
    deskripsi: 'Sempurna untuk usaha mini-market, warkop, kos-kosan, atau penggunaan intensif.',
    mikrotikProfile: 'hs-bisnis-50M'
  }
];

export const DEFAULT_TUKANG_TAGIH: TukangTagih[] = [
  {
    id: 'tagih-1',
    nama: 'Andri Hermawan',
    alamat: 'Blok C No. 4, Perum Harmoni Kartika',
    noHp: '081290001111',
    username: 'andri',
    password: '123',
    statusAktif: true
  },
  {
    id: 'tagih-2',
    nama: 'Maman Setiawan',
    alamat: 'Dusun Sukamaju RT 03/RW 01',
    noHp: '085710002222',
    username: 'maman',
    password: '123',
    statusAktif: true
  },
  {
    id: 'tagih-3',
    nama: 'Rizky Pratama',
    alamat: 'Gang Damai No. 8',
    noHp: '089855556666',
    username: 'rizky',
    password: '123',
    statusAktif: false
  }
];

export const DEFAULT_PELANGGAN: Pelanggan[] = [
  {
    id: 'plg-1',
    nama: 'Budi Santoso',
    noHp: '081234567890',
    alamat: 'RT 001 / RW 004, No. 12',
    paketId: 'pkt-2',
    tarif: 150000,
    statusAktif: true,
    tanggalDaftar: '2025-10-15',
    jatuhTempo: '2026-06-10',
    kategoriLangganan: 'Rumahan',
    tukangTagihId: 'tagih-1'
  },
  {
    id: 'plg-2',
    nama: 'Siti Rahmawati',
    noHp: '085799887766',
    alamat: 'RT 001 / RW 004, No. 15B',
    paketId: 'pkt-1',
    tarif: 100000,
    statusAktif: true,
    tanggalDaftar: '2026-01-10',
    jatuhTempo: '2026-06-05',
    kategoriLangganan: 'Rumahan',
    tukangTagihId: 'tagih-2'
  },
  {
    id: 'plg-3',
    nama: 'Hendry Wijaya',
    noHp: '087811223344',
    alamat: 'RT 002 / RW 004, No. 04',
    paketId: 'pkt-3',
    tarif: 250000,
    statusAktif: true,
    tanggalDaftar: '2025-12-01',
    jatuhTempo: '2026-06-10',
    kategoriLangganan: 'Rumahan',
    tukangTagihId: 'tagih-1'
  },
  {
    id: 'plg-4',
    nama: 'Dewi Lestari',
    noHp: '089912345678',
    alamat: 'RT 003 / RW 004, No. 08',
    paketId: 'pkt-2',
    tarif: 150000,
    statusAktif: true,
    tanggalDaftar: '2026-03-20',
    jatuhTempo: '2026-06-15',
    kategoriLangganan: 'Hotspot',
    tukangTagihId: 'none' // Admin yang menagih sendiri
  },
  {
    id: 'plg-5',
    nama: 'Agus Setiawan',
    noHp: '081122334455',
    alamat: 'RT 002 / RW 004, No. 22',
    paketId: 'pkt-4',
    tarif: 450000,
    statusAktif: false,
    tanggalDaftar: '2025-08-05',
    jatuhTempo: '2026-06-05',
    kategoriLangganan: 'Rumahan',
    tukangTagihId: 'none'
  },
  {
    id: 'plg-6',
    nama: 'Eko Prasetyo',
    noHp: '081398765432',
    alamat: 'RT 003 / RW 004, No. 34',
    paketId: 'pkt-2',
    tarif: 150000,
    statusAktif: true,
    tanggalDaftar: '2026-04-02',
    jatuhTempo: '2026-06-10',
    kategoriLangganan: 'Hotspot',
    tukangTagihId: 'tagih-2'
  }
];

export const DEFAULT_TAGIHAN: Tagihan[] = [
  // May 2026 (Semua Lunas / Terbayar)
  {
    id: 'inv-202605-1',
    pelangganId: 'plg-1',
    pelangganNama: 'Budi Santoso',
    pelangganNoHp: '081234567890',
    bulan: '2026-05',
    jumlah: 150000,
    tanggalJatuhTempo: '2026-05-10',
    status: 'LUNAS',
    tanggalBayar: '2026-05-08',
    metodeBayar: 'Transfer BCA',
    waSent: true,
    waSentAt: '2026-05-02 09:30:12',
    catatan: 'Lunas tepat waktu'
  },
  {
    id: 'inv-202605-2',
    pelangganId: 'plg-2',
    pelangganNama: 'Siti Rahmawati',
    pelangganNoHp: '085799887766',
    bulan: '2026-05',
    jumlah: 100000,
    tanggalJatuhTempo: '2026-05-05',
    status: 'LUNAS',
    tanggalBayar: '2026-05-05',
    metodeBayar: 'Cash / Tunai',
    waSent: true,
    waSentAt: '2026-05-01 10:15:00',
    catatan: 'Diterima tunai oleh Pak RT'
  },
  {
    id: 'inv-202605-3',
    pelangganId: 'plg-3',
    pelangganNama: 'Hendry Wijaya',
    pelangganNoHp: '087811223344',
    bulan: '2026-05',
    jumlah: 250000,
    tanggalJatuhTempo: '2026-05-10',
    status: 'LUNAS',
    tanggalBayar: '2026-05-11',
    metodeBayar: 'Transfer BCA',
    waSent: true,
    waSentAt: '2026-05-02 09:32:00'
  },

  // June 2026 (Bulan Berjalan)
  {
    id: 'inv-202606-1',
    pelangganId: 'plg-1',
    pelangganNama: 'Budi Santoso',
    pelangganNoHp: '081234567890',
    bulan: '2026-06',
    jumlah: 150000,
    tanggalJatuhTempo: '2026-06-10',
    status: 'BELUM_BAYAR',
    waSent: true,
    waSentAt: '2026-06-02 08:30:00'
  },
  {
    id: 'inv-202606-2',
    pelangganId: 'plg-2',
    pelangganNama: 'Siti Rahmawati',
    pelangganNoHp: '085799887766',
    bulan: '2026-06',
    jumlah: 100000,
    tanggalJatuhTempo: '2026-06-05',
    status: 'LUNAS',
    tanggalBayar: '2026-06-04',
    metodeBayar: 'Cash / Tunai',
    waSent: true,
    waSentAt: '2026-06-02 08:31:00'
  },
  {
    id: 'inv-202606-3',
    pelangganId: 'plg-3',
    pelangganNama: 'Hendry Wijaya',
    pelangganNoHp: '087811223344',
    bulan: '2026-06',
    jumlah: 250000,
    tanggalJatuhTempo: '2026-06-10',
    status: 'LUNAS',
    tanggalBayar: '2026-06-09',
    metodeBayar: 'Transfer BCA',
    waSent: true,
    waSentAt: '2026-06-02 08:33:00'
  },
  {
    id: 'inv-202606-4',
    pelangganId: 'plg-4',
    pelangganNama: 'Dewi Lestari',
    pelangganNoHp: '089912345678',
    bulan: '2026-06',
    jumlah: 150000,
    tanggalJatuhTempo: '2026-06-15',
    status: 'BELUM_BAYAR',
    waSent: false
  },
  {
    id: 'inv-202606-6',
    pelangganId: 'plg-6',
    pelangganNama: 'Eko Prasetyo',
    pelangganNoHp: '081398765432',
    bulan: '2026-06',
    jumlah: 150000,
    tanggalJatuhTempo: '2026-06-10',
    status: 'BELUM_BAYAR',
    waSent: true,
    waSentAt: '2026-06-02 08:35:00'
  }
];

export const DEFAULT_WA_LOGS: WhatsAppLog[] = [
  {
    id: 'log-1',
    tagihanId: 'inv-202606-1',
    pelangganNama: 'Budi Santoso',
    noHp: '081234567890',
    pesan: 'Halo Bpk/Ibu Budi Santoso, Mengingatkan tagihan internet RT RW NET Anda bulan Juni 2026 sebesar Rp 150.000 dengan jatuh tempo 2026-06-10 belum dibayar. Mohon melakukan transfer ke REK BCA 456-789-012 a/n RT RW Net Mandiri. Terima kasih.',
    status: 'SUKSES',
    sentAt: '2026-06-02 08:30:15'
  }
];

export const DEFAULT_MIKROTIK: MikrotikServer[] = [
  {
    id: 'srv-1',
    nama: 'Mikrotik Pusat Kamal',
    ipAddress: '192.168.10.1',
    username: 'admin',
    port: 8728,
    status: 'TERHUBUNG',
    uptime: '15d 4h 23m',
    cpuLoad: 12
  },
  {
    id: 'srv-2',
    nama: 'Mikrotik OLT RT-04',
    ipAddress: '192.168.22.5',
    username: 'api_billing',
    port: 8728,
    status: 'TERHUBUNG',
    uptime: '2d 11h 5m',
    cpuLoad: 4
  },
  {
    id: 'srv-3',
    nama: 'Mikrotik Sektor Barat',
    ipAddress: '10.200.0.1',
    username: 'admin',
    port: 8728,
    status: 'TERPUTUS',
    uptime: '0s',
    cpuLoad: 0
  }
];

export const DEFAULT_RESELLER: Reseller[] = [
  {
    id: 'rsl-1',
    nama: 'Warung Bu Sri (Voucher Hotspot)',
    wilayah: 'Sektor RT 02 (Selatan)',
    noHp: '081233334444',
    saldo: 350005,
    komisiPercent: 10,
    statusAktif: true,
    username: 'sri',
    password: '123'
  },
  {
    id: 'rsl-2',
    nama: 'Koperasi Warga Mandiri',
    wilayah: 'Sektor RT 01 (Utara)',
    noHp: '085344445555',
    saldo: 1200000,
    komisiPercent: 12,
    statusAktif: true,
    username: 'koperasi',
    password: '123'
  },
  {
    id: 'rsl-3',
    nama: 'Agen Pulsa Toko Doni',
    wilayah: 'Dusun Sukarame',
    noHp: '089677778888',
    saldo: 15000,
    komisiPercent: 8,
    statusAktif: false,
    username: 'doni',
    password: '123'
  }
];

export const DEFAULT_VOUCHERS: HotspotVoucher[] = [
  {
    id: 'voc-1',
    code: '772182',
    paketId: 'pkt-1',
    harga: 5000,
    durasi: '1 Hari (FUP 2GB)',
    serverName: 'Mikrotik Pusat Kamal',
    status: 'AKTIF'
  },
  {
    id: 'voc-2',
    code: 'NET-X218A',
    paketId: 'pkt-2',
    harga: 15000,
    durasi: '7 Hari Unlimited',
    serverName: 'Mikrotik Pusat Kamal',
    status: 'DIGUNAKAN'
  },
  {
    id: 'voc-3',
    code: '445210',
    paketId: 'pkt-1',
    harga: 5000,
    durasi: '1 Hari (FUP 2GB)',
    serverName: 'Mikrotik OLT RT-04',
    status: 'EXPIRED'
  }
];

export const DEFAULT_PPPOE: PppoeUser[] = [
  {
    id: 'ppp-1',
    username: 'budi_rumahan_olt',
    profileName: 'Paket Keluarga 10M',
    localAddress: '10.10.10.1',
    remoteAddress: '10.10.10.101',
    status: 'ONLINE',
    serverName: 'Mikrotik OLT RT-04'
  },
  {
    id: 'ppp-2',
    username: 'siti_rahma_ppp',
    profileName: 'Paket Hemat 5M',
    localAddress: '10.10.10.1',
    remoteAddress: '10.10.10.102',
    status: 'ONLINE',
    serverName: 'Mikrotik Pusat Kamal'
  },
  {
    id: 'ppp-3',
    username: 'hendry_prem_west',
    profileName: 'Paket Premium 20M',
    localAddress: '10.10.20.1',
    remoteAddress: '10.10.20.55',
    status: 'OFFLINE',
    serverName: 'Mikrotik Sektor Barat'
  }
];

export const DEFAULT_SETTINGS: AppSettings = {
  billingNamaPenyedia: 'NET-KITA Mandiri',
  pjNama: 'Subhan Arifin',
  dueDayDefault: 10,
  bankNama: 'Bank BCA',
  bankNomorRekening: '4560983210',
  bankAtasNama: 'SUBHAN ARIFIN',
  waTemplateTagihanDefault: `Halo Kak *[Nama]*, 

Meningatkan tagihan layanan internet *[NamaLayanan]* d/a *[Alamat]* untuk periode bulan *[Bulan]* sebesar *[Tarif]* belum dilunasi. 
Jatuh tempo pembayaran pada tanggal *[JatuhTempo]*.

Mohon lakukan pembayaran via transfer ke:
🏦 *[NamaBank]*
💳 Rekenig: *[NoRek]*
👤 A/N: *[AtasNama]*

Jika sudah melakukan pembayaran, mohon kirimkan struk/bukti transfer ke nomor ini. Abaikan pesan ini jika Kakak sudah membayar.

Terima kasih atas kepercayaannya 🙏
_[Dapatkan pelayanan internet lancar tanpa batas!]_`,
  waTemplateLunasDefault: `Halo Kak *[Nama]*,

Terima kasih! Kami telah menerima pembayaran tagihan internet periode *[Bulan]* sebesar *[Tarif]*.

Transaksi Anda telah tercatat dengan bukti pembayaran lunas pada *[TanggalBayar]* melalui *[MetodeBayar]*.

Layanan internet Anda tetap aktif dengan lancar. Tetap nikmati koneksi internet terbaik dari kami! 🚀🚀

Hormat kami,
*[NamaPenyedia]*`,
  waGatewayToken: 'rtrwnet_token_prod_8f328a99db3288fbc',
  waStatusKoneksi: true,
  
  // Payment Gateway Config
  paymentGatewayActive: true,
  merchantCode: 'MID-78891002',
  apiKey: 'SB-Mid-server-xXyY881902Kk',
  clientKey: 'SB-Mid-client-zZwa1a902Lp',
  provider: 'Midtrans',

  // Voucher Buy Look & Customizer settings
  voucherPage: {
    title: 'Portal Pembelian Voucher NET-KITA',
    greetingText: 'Selamat Datang di Hotspot NET-KITA. Nikmati koneksi internet ultra cepat & stabil secara langsung tanpa kontrak!',
    themeColor: '#4f46e5', // Indigo-600
    showPrice: true,
    contactSupport: '081290001111',
    enableMikrotikApi: true,
    customLogoUrl: '',
    selectedServerId: 'srv-1',
    voucherOffers: [
      {
        id: 'off-1',
        name: 'Voucher Hemat 1 Hari',
        price: 5000,
        duration: '24 Jam',
        speedLimit: '5 Mbps',
        fup: 'FUP 2GB',
        serverId: 'srv-1',
        status: 'AKTIF'
      },
      {
        id: 'off-2',
        name: 'Voucher Unlimited 7 Hari',
        price: 15000,
        duration: '7 Hari',
        speedLimit: '10 Mbps',
        fup: 'Tanpa FUP',
        serverId: 'srv-1',
        status: 'AKTIF'
      },
      {
        id: 'off-3',
        name: 'Voucher Game & Streaming 30 Hari',
        price: 50000,
        duration: '30 Hari',
        speedLimit: '15 Mbps',
        fup: 'FUP 100GB',
        serverId: 'srv-1',
        status: 'AKTIF'
      },
      {
        id: 'off-4',
        name: 'Voucher OLT Super Cepat',
        price: 25000,
        duration: '10 Hari',
        speedLimit: '20 Mbps',
        fup: 'Tanpa Batas',
        serverId: 'srv-2',
        status: 'AKTIF'
      }
    ],
    qrisDanaBisnisNama: 'KITA NET DANA BISNIS',
    qrisDanaBisnisWAGateway: '081290001111',
    qrisDanaBisnisImage: '',
    qrisDanaBisnisEnabled: true
  },
  showQuickMenus: ['pelanggan', 'hotspot', 'tagihan', 'pppoe', 'reseller', 'teknisi'],
  geminiApiKey: ''
};

export const DEFAULT_PESANAN_AGEN: PesananAgen[] = [
  {
    id: 'psn-1',
    resellerId: 'rsl-1',
    resellerNama: 'Warung Bu Sri (Voucher Hotspot)',
    resellerWilayah: 'Sektor RT 02 (Selatan)',
    resellerNoHp: '081233334444',
    voucherCode: 'SRI_VOUCHER_5G',
    paketId: 'pkt-2',
    paketNama: 'Paket Keluarga',
    jumlahTagihan: 15000,
    status: 'BELUM BAYAR',
    tanggalPesan: '2026-06-12',
    bulan: '2026-06',
    catatan: 'Pesanan diambil langsung di tempat'
  },
  {
    id: 'psn-2',
    resellerId: 'rsl-2',
    resellerNama: 'Koperasi Warga Mandiri',
    resellerWilayah: 'Sektor RT 01 (Utara)',
    resellerNoHp: '085344445555',
    voucherCode: 'KOP_TURBO_WIFI',
    paketId: 'pkt-3',
    paketNama: 'Paket Premium',
    jumlahTagihan: 25000,
    status: 'LUNAS (TRANSFER)',
    tanggalPesan: '2026-06-10',
    bulan: '2026-06',
    catatan: 'Dibayar via transfer Bank Mandiri'
  }
];

export const DEFAULT_TEKNISI: Teknisi[] = [
  {
    id: 'tek-1',
    nama: 'Budi Utomo (Teknisi Lapangan)',
    noHp: '085811112222',
    username: 'budi',
    password: '123',
    statusAktif: true,
    allowedServerIds: ['srv-1'], // Only allowed to manage/filter Mikrotik Pusat Kamal
    allowedPaketIds: ['pkt-1', 'pkt-2']
  },
  {
    id: 'tek-2',
    nama: 'Andi Hermawan (Senior Teknisi)',
    noHp: '085833334444',
    username: 'andi',
    password: '123',
    statusAktif: true,
    allowedServerIds: ['srv-1', 'srv-2', 'srv-3'], // Multi-Mikrotik access
    allowedPaketIds: ['pkt-1', 'pkt-2', 'pkt-3']
  }
];

export const DEFAULT_PORTAL_LOGS: PortalActivityLog[] = [
  {
    id: 'plog-1',
    portalType: 'AGEN/RESELLER',
    operatorNama: 'Warung Bu Sri (Voucher Hotspot)',
    operatorId: 'rsl-1',
    aktifitasType: 'CETAK_VOUCHER',
    fiturLabel: 'Cetak Massal (Bulk)',
    detail: 'Berhasil mencetak 10 lembar voucher paket Keluarga (10 Mbps) di server Mikrotik Pusat Kamal.',
    timestamp: '2026-06-15T10:14:00.000Z',
    status: 'SUKSES',
    amount: 135000
  },
  {
    id: 'plog-2',
    portalType: 'AGEN/RESELLER',
    operatorNama: 'Warung Bu Sri (Voucher Hotspot)',
    operatorId: 'rsl-1',
    aktifitasType: 'TOPUP',
    fiturLabel: 'Deposit Topup Mandiri',
    detail: 'Top Up saldo otomatis sukses via QRIS senilai Rp 100.000',
    timestamp: '2026-06-15T09:30:00.000Z',
    status: 'SUKSES',
    amount: 100000
  },
  {
    id: 'plog-3',
    portalType: 'AGEN/RESELLER',
    operatorNama: 'Warung Bu Sri (Voucher Hotspot)',
    operatorId: 'rsl-1',
    aktifitasType: 'LOGIN',
    fiturLabel: 'Autentikasi Portal',
    detail: 'Login berhasil dari perangkat Chrome Mobile - IP: 192.168.10.125',
    timestamp: '2026-06-15T08:00:00.000Z',
    status: 'INFO'
  },
  {
    id: 'plog-4',
    portalType: 'TUKANG_TAGIH',
    operatorNama: 'Andi Hermawan',
    operatorId: 'tagih-1',
    aktifitasType: 'TRANSAKSI_BAYAR',
    fiturLabel: 'Terima Kas Lapangan',
    detail: 'Menerima pembayaran tunai tagihan bulanan pelanggan Budi Santoso senilai Rp 150.000',
    timestamp: '2026-06-14T15:20:00.000Z',
    status: 'SUKSES',
    amount: 150000
  },
  {
    id: 'plog-5',
    portalType: 'TUKANG_TAGIH',
    operatorNama: 'Andi Hermawan',
    operatorId: 'tagih-1',
    aktifitasType: 'LOGIN',
    fiturLabel: 'Autentikasi Portal',
    detail: 'Petugas Andri Hermawan berhasil masuk ke portal tagihan lapangan.',
    timestamp: '2026-06-14T07:45:00.000Z',
    status: 'INFO'
  },
  {
    id: 'plog-6',
    portalType: 'TEKNISI',
    operatorNama: 'Budi Utomo (Teknisi Lapangan)',
    operatorId: 'tek-1',
    aktifitasType: 'CETAK_VOUCHER',
    fiturLabel: 'MikroTik Hotspot API',
    detail: 'Mendaftarkan voucher manual baru USER: "BUDI_SUPER_SPEED" di router Mikrotik Pusat Kamal.',
    timestamp: '2026-06-13T11:15:00.000Z',
    status: 'SUKSES'
  },
  {
    id: 'plog-7',
    portalType: 'TEKNISI',
    operatorNama: 'Budi Utomo (Teknisi Lapangan)',
    operatorId: 'tek-1',
    aktifitasType: 'LOGIN',
    fiturLabel: 'Autentikasi Portal',
    detail: 'Masuk ke portal teknisi untuk sinkronisasi router dan pendaftaran hotspot.',
    timestamp: '2026-06-13T08:00:00.000Z',
    status: 'INFO'
  },
  {
    id: 'plog-8',
    portalType: 'AGEN/RESELLER',
    operatorNama: 'Koperasi Warga Mandiri',
    operatorId: 'rsl-2',
    aktifitasType: 'TOPUP',
    fiturLabel: 'Topup Setoran Tunai',
    detail: 'Penerimaan top-up saldo kemitraan oleh Admin senilai Rp 500.000',
    timestamp: '2026-06-12T14:00:00.000Z',
    status: 'SUKSES',
    amount: 500000
  }
];


