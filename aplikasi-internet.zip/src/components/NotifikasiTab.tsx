import React, { useState, useEffect } from 'react';
import { WhatsAppLog, AppSettings, Tagihan, Pelanggan, Paket } from '../types';
import { replaceTemplates, formatRupiah, formatTanggalIndo } from '../utils';
import { 
  QrCode, Save, RefreshCw, Smartphone, 
  HelpCircle, MessageSquareText, Search, Play, 
  Check, X, ShieldAlert, Cpu, CheckCircle2 
} from 'lucide-react';

interface NotifikasiTabProps {
  logs: WhatsAppLog[];
  settings: AppSettings;
  paket: Paket[];
  pelanggan: Pelanggan[];
  tagihan: Tagihan[];
  onSaveSettings: (settings: AppSettings) => void;
  // Broadcasting states for real-time sending animation
  isBroadcasting: boolean;
  setIsBroadcasting: (b: boolean) => void;
  broadcastQueue: Tagihan[];
  onFinishBroadcast: (sentLogs: WhatsAppLog[]) => void;
}

export default function NotifikasiTab({
  logs,
  settings,
  paket,
  pelanggan,
  tagihan,
  onSaveSettings,
  isBroadcasting,
  setIsBroadcasting,
  broadcastQueue,
  onFinishBroadcast
}: NotifikasiTabProps) {
  const [activeSubTab, setActiveSubTab] = useState<'GATEWAY' | 'TEMPLAT' | 'LOGS'>('GATEWAY');
  
  // Settings copy
  const [formSettings, setFormSettings] = useState<AppSettings>({ ...settings });
  
  // States
  const [isQrLoading, setIsQrLoading] = useState(false);
  const [showQrSim, setShowQrSim] = useState(false);
  const [logSearch, setLogSearch] = useState('');

  // Bulk Sender Simulation states
  const [currentSendIndex, setCurrentSendIndex] = useState(0);
  const [simulatedLogs, setSimulatedLogs] = useState<WhatsAppLog[]>([]);

  // Reset form copy on change
  useEffect(() => {
    setFormSettings({ ...settings });
  }, [settings]);

  // Save Config
  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings(formSettings);
    alert('Konfigurasi Pengaturan berhasil diperbarui!');
  };

  // QR Gateway Generator trigger
  const handleScanQr = () => {
    setIsQrLoading(true);
    setTimeout(() => {
      setIsQrLoading(false);
      setShowQrSim(true);
    }, 1500);
  };

  // Confirm QR Scanner Link (simulated)
  const confirmQrLink = () => {
    setShowQrSim(false);
    onSaveSettings({
      ...settings,
      waStatusKoneksi: true
    });
    alert('WhatsApp Gateway Terhubung Sukses! Device Anda siap mengirim pesan otomatis.');
  };

  // Disconnect Gateway
  const handleDisconnect = () => {
    if (confirm('Yakin ingin memisahkan perangkat Anda dari Gateway WA?')) {
      onSaveSettings({
        ...settings,
        waStatusKoneksi: false
      });
    }
  };

  // Simulation of Broadcaster
  useEffect(() => {
    if (isBroadcasting && broadcastQueue.length > 0) {
      if (currentSendIndex < broadcastQueue.length) {
        const timer = setTimeout(() => {
          const currentBill = broadcastQueue[currentSendIndex];
          const cust = pelanggan.find(p => p.id === currentBill.pelangganId);
          const pLayer = cust ? paket.find(p => p.id === cust.paketId) : null;
          
          // Generate message
          const rawTemplate = currentBill.status === 'LUNAS' 
            ? formSettings.waTemplateLunasDefault 
            : formSettings.waTemplateTagihanDefault;
            
          const variables = {
            Nama: currentBill.pelangganNama,
            NamaLayanan: pLayer ? pLayer.nama : 'Internet',
            Alamat: cust ? cust.alamat : '',
            Bulan: currentBill.bulan,
            Tarif: formatRupiah(currentBill.jumlah),
            JatuhTempo: currentBill.tanggalJatuhTempo,
            NamaBank: formSettings.bankNama,
            NoRek: formSettings.bankNomorRekening,
            AtasNama: formSettings.bankAtasNama,
            NamaPenyedia: formSettings.billingNamaPenyedia,
            TanggalBayar: currentBill.tanggalBayar,
            MetodeBayar: currentBill.metodeBayar
          };

          const pesanFinal = replaceTemplates(rawTemplate, variables);

          // Add simulated log
          const newLog: WhatsAppLog = {
            id: `log-${Date.now()}-${currentSendIndex}`,
            tagihanId: currentBill.id,
            pelangganNama: currentBill.pelangganNama,
            noHp: currentBill.pelangganNoHp,
            pesan: pesanFinal,
            status: 'SUKSES',
            sentAt: new Date().toISOString().substring(0, 19).replace('T', ' ')
          };

          setSimulatedLogs(prev => [...prev, newLog]);
          setCurrentSendIndex(idx => idx + 1);
        }, 1200); // 1.2s per message sending delay for ultra-realistic feeling
        return () => clearTimeout(timer);
      } else {
        // Broadbasting complete!
        setTimeout(() => {
          onFinishBroadcast(simulatedLogs);
          setIsBroadcasting(false);
          setCurrentSendIndex(0);
          setSimulatedLogs([]);
          alert(`Selesai! Berhasil membroadcast ${broadcastQueue.length} notifikasi WhatsApp kepada pelanggan.`);
        }, 800);
      }
    }
  }, [isBroadcasting, currentSendIndex, broadcastQueue]);

  // Filter logs
  const filteredLogs = logs.filter(l => 
    l.pelangganNama.toLowerCase().includes(logSearch.toLowerCase()) || 
    l.noHp.includes(logSearch) ||
    l.pesan.toLowerCase().includes(logSearch.toLowerCase())
  );

  return (
    <div className="space-y-6">
      
      {/* Sub Tabs Selection */}
      <div className="flex bg-slate-100 p-1.5 rounded-xl border border-slate-200 w-full sm:w-fit text-xs font-semibold select-none">
        <button
          onClick={() => setActiveSubTab('GATEWAY')}
          className={`flex-1 sm:flex-initial px-4 py-2 rounded-lg transition cursor-pointer flex items-center justify-center gap-1.5 ${
            activeSubTab === 'GATEWAY' ? 'bg-white text-slate-800 shadow-xs' : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Smartphone size={14} /> Gateway WA
        </button>
        <button
          onClick={() => setActiveSubTab('TEMPLAT')}
          className={`flex-1 sm:flex-initial px-4 py-2 rounded-lg transition cursor-pointer flex items-center justify-center gap-1.5 ${
            activeSubTab === 'TEMPLAT' ? 'bg-white text-slate-800 shadow-xs' : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <MessageSquareText size={14} /> Templat Pesan
        </button>
        <button
          onClick={() => setActiveSubTab('LOGS')}
          className={`flex-1 sm:flex-initial px-4 py-2 rounded-lg transition cursor-pointer flex items-center justify-center gap-1.5 ${
            activeSubTab === 'LOGS' ? 'bg-white text-slate-800 shadow-xs' : 'text-slate-500 hover:text-slate-800'
          }`}
        >
          <Search size={14} /> Log Pesan Terkirim ({logs.length})
        </button>
      </div>

      {/* SUB-TAB 1: GATEWAY CONFIG & QR CODE SIM */}
      {activeSubTab === 'GATEWAY' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Settings Left Column */}
          <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm lg:col-span-2 space-y-6">
            <div>
              <h3 className="text-base font-bold text-slate-800">🔌 Integrasi WhatsApp API Gateway</h3>
              <p className="text-xs text-slate-500 mt-1">
                Gunakan layanan Gateway (misal Fonnte/Wablas) untuk menyemburkan pesan masal, atau kirim langsung menggunakan kaitan direct-link tanpa gateway.
              </p>
            </div>

            <form onSubmit={handleSaveConfig} className="space-y-4 text-xs text-slate-600">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="font-semibold text-slate-700">Nama Penyedia Layanan RT-RW Net *</label>
                  <input
                    type="text"
                    required
                    className="w-full bg-slate-50 px-3 py-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-medium"
                    value={formSettings.billingNamaPenyedia}
                    onChange={(e) => setFormSettings({ ...formSettings, billingNamaPenyedia: e.target.value })}
                  />
                </div>
                
                <div className="space-y-1">
                  <label className="font-semibold text-slate-700">Nama Penanggung Jawab (Kasir) *</label>
                  <input
                    type="text"
                    required
                    className="w-full bg-slate-50 px-3 py-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-medium"
                    value={formSettings.pjNama}
                    onChange={(e) => setFormSettings({ ...formSettings, pjNama: e.target.value })}
                  />
                </div>

                <div className="space-y-1 col-span-1 sm:col-span-2 bg-slate-50/50 p-4 rounded-xl border border-slate-150/60 mt-1">
                  <p className="font-bold text-slate-700 mb-2">🏦 Rekening Tujuan Pembayaran Pelanggan</p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div className="space-y-1 text-[11px]">
                      <label className="font-semibold text-slate-500">Nama Bank (e.g. BCA, MANDIRI)*</label>
                      <input
                        type="text"
                        required
                        className="w-full bg-white px-2.5 py-2 border border-slate-200 rounded-lg focus:outline-hidden"
                        value={formSettings.bankNama}
                        onChange={(e) => setFormSettings({ ...formSettings, bankNama: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1 text-[11px]">
                      <label className="font-semibold text-slate-500">Nomor Rekening Bank *</label>
                      <input
                        type="text"
                        required
                        className="w-full bg-white px-2.5 py-2 border border-slate-200 rounded-lg focus:outline-hidden font-mono"
                        value={formSettings.bankNomorRekening}
                        onChange={(e) => setFormSettings({ ...formSettings, bankNomorRekening: e.target.value })}
                      />
                    </div>
                    <div className="space-y-1 text-[11px]">
                      <label className="font-semibold text-slate-500">Atas Nama Rekening *</label>
                      <input
                        type="text"
                        required
                        className="w-full bg-white px-2.5 py-2 border border-slate-200 rounded-lg focus:outline-hidden"
                        value={formSettings.bankAtasNama}
                        onChange={(e) => setFormSettings({ ...formSettings, bankAtasNama: e.target.value })}
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-slate-700">URL Gateway WhatsApp Server</label>
                  <input
                    type="text"
                    placeholder="https://api.fonnte.com/send"
                    className="w-full bg-slate-50 px-3 py-2.5 rounded-lg border border-slate-250/70 focus:outline-hidden text-slate-400 font-mono"
                    readOnly
                  />
                  <p className="text-[10px] text-slate-400 italic">Disetel automatis ke sandboxed server virtual kami.</p>
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-slate-700">Token Credential Gateway (ApiKey)</label>
                  <input
                    type="password"
                    required
                    className="w-full bg-slate-50 px-3 py-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-mono font-bold"
                    value={formSettings.waGatewayToken}
                    onChange={(e) => setFormSettings({ ...formSettings, waGatewayToken: e.target.value })}
                  />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-2 text-slate-500">
                  <Cpu size={14} className="text-slate-400" />
                  <span>Virtual Mode Terkonfigurasi</span>
                </div>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition flex items-center gap-1.5 cursor-pointer shadow-sm"
                >
                  <Save size={14} /> Simpan Profil & API Token
                </button>
              </div>
            </form>
          </div>

          {/* Connection Status Right Column */}
          <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm space-y-6">
            <div>
              <h3 className="text-base font-bold text-slate-800">🔮 Status Koneksi Device</h3>
              <p className="text-xs text-slate-500 mt-1">Informasi status sambungan nomor WhatsApp dengan server pemancar API.</p>
            </div>

            {settings.waStatusKoneksi ? (
              <div className="bg-emerald-50 rounded-2xl border border-emerald-100 p-5 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-emerald-500 text-white rounded-full">
                    <Check size={16} />
                  </div>
                  <div>
                    <p className="text-xs text-emerald-800 font-black">TERHUBUNG & AKTIF</p>
                    <p className="text-slate-500 text-[10px] mt-0.5">Device siap menyemburkan notifikasi</p>
                  </div>
                </div>

                <div className="text-[11px] text-slate-600 space-y-1.5 border-t border-emerald-200/50 pt-3">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Device ID:</span>
                    <span className="font-mono font-bold">RT-RW-NET-GW-01</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Kecepatan API:</span>
                    <span className="font-mono text-emerald-700 font-semibold">&lt; 150ms / Send</span>
                  </div>
                </div>

                <button
                  onClick={handleDisconnect}
                  className="w-full py-2 bg-white text-rose-600 border border-rose-200 rounded-xl font-bold text-xs hover:bg-rose-50 hover:border-rose-300 transition cursor-pointer"
                >
                  Putuskan Sambungan
                </button>
              </div>
            ) : (
              <div className="bg-rose-50/60 rounded-2xl border border-rose-100 p-5 space-y-4 text-center">
                <div className="p-3 bg-rose-100 text-rose-600 rounded-full w-fit mx-auto">
                  <ShieldAlert size={22} />
                </div>
                <div>
                  <p className="text-xs font-black text-rose-800">KONEKSI WA TERPUTUS</p>
                  <p className="text-[10px] text-slate-400 mt-1 leading-normal">
                    Nomor WhatsApp pengirim belum didaftarkan di server gateway API.
                  </p>
                </div>

                {isQrLoading ? (
                  <div className="py-4 flex flex-col items-center justify-center gap-2">
                    <RefreshCw size={24} className="text-indigo-600 animate-spin" />
                    <span className="text-[10px] text-slate-500 font-semibold">Generasi QR-Key...</span>
                  </div>
                ) : (
                  <button
                    onClick={handleScanQr}
                    className="w-full py-2.5 bg-indigo-600 text-white rounded-xl font-bold text-xs hover:bg-indigo-700 transition flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                  >
                    <QrCode size={14} /> Hubungkan Perangkat (Scan QR)
                  </button>
                )}
              </div>
            )}

            {/* Simulated QR Code modal */}
            {showQrSim && (
              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex flex-col items-center justify-center gap-3">
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider text-center">Scan QR WA Web Anda</p>
                <div className="p-3 bg-white border border-slate-200 rounded-lg shadow-inner relative group">
                  {/* Real procedural QR placeholder */}
                  <div className="w-40 h-40 bg-slate-900 flex items-center justify-center text-white font-mono p-4 font-bold text-center text-xs relative">
                    <div className="absolute inset-0 border-[8px] border-white bg-[radial-gradient(#ddd_1px,transparent_1px)] bg-[size:10px_10px] m-4" />
                    {/* Fake anchors */}
                    <div className="absolute left-2 top-2 w-8 h-8 border-4 border-slate-900 bg-white" />
                    <div className="absolute right-2 top-2 w-8 h-8 border-4 border-slate-900 bg-white" />
                    <div className="absolute left-2 bottom-2 w-8 h-8 border-4 border-slate-900 bg-white" />
                    <span className="z-10 bg-white text-slate-800 p-1.5 rounded-md border border-slate-300 relative font-bold text-[10px]">
                      WA WEB KEY
                    </span>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={confirmQrLink}
                  className="px-4 py-1.5 bg-emerald-600 text-white font-bold text-[10px] rounded-lg hover:bg-emerald-700 transition cursor-pointer"
                >
                  Simulasikan Scan Berhasil &rarr;
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SUB-TAB 2: MESSAGE TEMPLATES EDITOR */}
      {activeSubTab === 'TEMPLAT' && (
        <form onSubmit={handleSaveConfig} className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm space-y-6">
          <div className="flex flex-col md:flex-row gap-6">
            
            {/* Editor Boxes */}
            <div className="flex-1 space-y-4 text-xs text-slate-600">
              <div className="space-y-1.5">
                <div className="flex justify-between items-center">
                  <label className="font-bold text-slate-700">💬 Pesan Tagihan Belum Bayar (Default)</label>
                  <span className="text-[10px] bg-amber-50 text-amber-700 rounded-md px-2 py-0.5 border border-amber-100 font-bold">Variabel Aktif</span>
                </div>
                <textarea
                  required
                  rows={8}
                  className="w-full bg-slate-50 p-3 rounded-xl border border-slate-200 focus:outline-hidden font-mono text-[11px] leading-relaxed text-slate-700"
                  value={formSettings.waTemplateTagihanDefault}
                  onChange={(e) => setFormSettings({ ...formSettings, waTemplateTagihanDefault: e.target.value })}
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex justify-between items-center">
                  <label className="font-bold text-slate-700">✔ Pesan Konfirmasi Lunas Pembayaran</label>
                  <span className="text-[10px] bg-emerald-50 text-emerald-700 rounded-md px-2 py-0.5 border border-emerald-100 font-bold">Variabel Aktif</span>
                </div>
                <textarea
                  required
                  rows={8}
                  className="w-full bg-slate-50 p-3 rounded-xl border border-slate-200 focus:outline-hidden font-mono text-[11px] leading-relaxed text-slate-700"
                  value={formSettings.waTemplateLunasDefault}
                  onChange={(e) => setFormSettings({ ...formSettings, waTemplateLunasDefault: e.target.value })}
                />
              </div>
            </div>

            {/* Sidebar Variables Instructions */}
            <div className="w-full md:w-60 bg-indigo-50/40 p-5 rounded-2xl border border-indigo-100/50 space-y-4 text-xs">
              <h4 className="font-bold text-slate-800 flex items-center gap-1">
                <HelpCircle size={15} className="text-indigo-600" /> Placeholders Templat
              </h4>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                Anda dapat menyisipkan kata kunci unik berikut. Sistem akan menggantinya otomatis per baris data tagihan:
              </p>

              <div className="space-y-2.5 font-mono text-[10px] text-slate-700">
                <div className="p-1.5 bg-white border border-slate-100 rounded-md">
                  <p className="font-bold text-indigo-700">[Nama]</p>
                  <p className="text-[9px] text-slate-400 mt-0.5">Nama asli Pelanggan</p>
                </div>
                <div className="p-1.5 bg-white border border-slate-100 rounded-md">
                  <p className="font-bold text-indigo-700">[NamaLayanan]</p>
                  <p className="text-[9px] text-slate-400 mt-0.5">Misal: Paket Jaringan 10M</p>
                </div>
                <div className="p-1.5 bg-white border border-slate-100 rounded-md">
                  <p className="font-bold text-indigo-700">[Alamat]</p>
                  <p className="text-[9px] text-slate-400 mt-0.5">Alamat rumah pelanggan</p>
                </div>
                <div className="p-1.5 bg-white border border-slate-100 rounded-md">
                  <p className="font-bold text-indigo-700">[Bulan]</p>
                  <p className="text-[9px] text-slate-400 mt-0.5">Bulan tagihan (Juni 2026)</p>
                </div>
                <div className="p-1.5 bg-white border border-slate-100 rounded-md">
                  <p className="font-bold text-indigo-700">[Tarif]</p>
                  <p className="text-[9px] text-slate-400 mt-0.5">Jumlah biaya dlm Rupiah</p>
                </div>
                <div className="p-1.5 bg-white border border-slate-100 rounded-md">
                  <p className="font-bold text-indigo-700">[JatuhTempo]</p>
                  <p className="text-[9px] text-slate-400 mt-0.5">Batas pembayaran resmi</p>
                </div>
                <div className="p-1.5 bg-white border border-slate-100 rounded-md">
                  <p className="font-bold text-indigo-700">[NamaBank], [NoRek]</p>
                  <p className="text-[9px] text-slate-400 mt-0.5">Detail rekening transfer</p>
                </div>
              </div>
            </div>

          </div>

          <div className="pt-4 border-t border-slate-100 text-right">
            <button
              type="submit"
              className="px-5 py-2.5 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition flex items-center gap-1 hover:underline cursor-pointer ml-auto"
            >
              <Save size={14} /> Simpan Seluruh Templat
            </button>
          </div>
        </form>
      )}

      {/* SUB-TAB 3: LOGS HISTORY TABLE */}
      {activeSubTab === 'LOGS' && (
        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
            <div>
              <h3 className="font-bold text-slate-800">📋 Histori Pengiriman Pesan</h3>
              <p className="text-[11px] text-slate-400 mt-0.5">Semua pesan tagihan & receipt yang berhasil dilontarkan oleh API.</p>
            </div>
            
            <div className="relative w-full sm:w-64">
              <Search size={14} className="absolute left-3 top-2 text-slate-400" />
              <input
                type="text"
                placeholder="Cari log nama / isi pesan..."
                className="w-full bg-slate-50 text-[11px] pl-8 pr-3 py-1.5 border border-slate-200 rounded-lg focus:outline-hidden"
                value={logSearch}
                onChange={(e) => setLogSearch(e.target.value)}
              />
            </div>
          </div>

          <div className="overflow-x-auto rounded-xl border border-slate-100">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-100">
                  <th className="p-4">Tanggal Pengiriman</th>
                  <th className="p-4">Nama Pelanggan</th>
                  <th className="p-4">No. HP</th>
                  <th className="p-4">Isi Pesan WhatsApp</th>
                  <th className="p-4 text-center">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700 font-sans">
                {[...filteredLogs].reverse().map((log) => (
                  <tr key={log.id} className="hover:bg-slate-55/65 transition hover:bg-slate-50 duration-200">
                    <td className="p-4 font-mono text-[10px] whitespace-nowrap text-slate-400">{log.sentAt}</td>
                    <td className="p-4 font-bold text-slate-800 whitespace-nowrap">{log.pelangganNama}</td>
                    <td className="p-4 font-mono text-[11px] whitespace-nowrap">{log.noHp}</td>
                    <td className="p-4 max-w-sm truncate text-slate-500 italic" title={log.pesan}>{log.pesan}</td>
                    <td className="p-4 text-center whitespace-nowrap">
                      {log.status === 'SUKSES' ? (
                        <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 border border-emerald-250/30 rounded-md font-bold text-[9px]">
                          ✔ SUKSES
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 bg-rose-100 text-rose-800 border border-rose-250/30 rounded-md font-bold text-[9px]">
                          ❌ GAGAL
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
                {filteredLogs.length === 0 && (
                  <tr>
                    <td colSpan={5} className="p-8 text-center text-slate-400">
                      Tidak ada log pengiriman yang ditemukan.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* BULK SENT QUEUE SIMULATOR MODAL */}
      {isBroadcasting && broadcastQueue.length > 0 && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl border border-slate-100 shadow-2xl w-full max-w-md overflow-hidden animate-zoomIn p-6">
            
            <div className="text-center space-y-2 mb-4">
              <div className="p-3 bg-emerald-50 text-emerald-600 rounded-full w-fit mx-auto border border-emerald-100">
                <Play size={20} className="animate-pulse" />
              </div>
              <h3 className="font-extrabold text-slate-800 text-base">🚀 WhatsApp Broadcast Engine</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Sandboxed server virtual sedang memproses gundukan pengiriman antrean. Jangan tutup layar ini.
              </p>
            </div>

            {/* Calculations progress */}
            {(() => {
              const total = broadcastQueue.length;
              const sent = currentSendIndex;
              const pct = Math.round((sent / total) * 100);
              const currentItem = broadcastQueue[currentSendIndex];

              return (
                <div className="space-y-4 text-xs font-sans">
                  {/* Progress info */}
                  <div className="flex justify-between font-bold text-slate-500 text-[11px]">
                    <span>Status Pengiriman: {sent} / {total} Antrean</span>
                    <span className="text-indigo-600 font-extrabold">{pct}% Selesai</span>
                  </div>

                  {/* Progress bar */}
                  <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden border border-slate-200">
                    <div 
                      className="bg-emerald-500 h-full rounded-full transition-all duration-300"
                      style={{ width: `${pct}%` }}
                    />
                  </div>

                  {/* Current Active Processing item indicator */}
                  {currentItem ? (
                    <div className="bg-slate-50 p-4 rounded-xl border border-slate-150/60 flex items-center gap-3">
                      <div className="w-2 h-2 rounded-full bg-indigo-500 animate-ping shrink-0" />
                      <div className="flex-1">
                        <p className="font-bold text-slate-700">Mengirim ke: {currentItem.pelangganNama}</p>
                        <p className="text-[10px] text-slate-400 font-mono mt-0.5">{currentItem.pelangganNoHp} &bull; Tagihan: {formatRupiah(currentItem.jumlah)}</p>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-emerald-50 p-4 rounded-xl border border-emerald-100 flex items-center justify-center gap-2">
                      <CheckCircle2 size={16} className="text-emerald-600" />
                      <span className="font-bold text-emerald-800">Menyelesaikan kompilasi log...</span>
                    </div>
                  )}

                  {/* Live Mini Console logger */}
                  <div className="bg-slate-900 text-slate-300 p-3 rounded-lg font-mono text-[9px] h-32 overflow-y-auto space-y-1 scrollbar-thin">
                    <p className="text-emerald-400 font-bold">&gt; Broadcaster Engine Initialized.</p>
                    <p className="text-slate-500">&gt; Authenticating gateway credentials...</p>
                    {simulatedLogs.map((sl, index) => (
                      <p key={index} className="text-slate-400">
                        <span className="text-emerald-500 font-semibold">[SUKSES]</span> &gt; Notifikasi terkirim ke {sl.pelangganNama} ({sl.noHp})
                      </p>
                    ))}
                    {currentItem && (
                      <p className="text-amber-400 animate-pulse">&gt; Processing: Connection payload {currentItem.id}...</p>
                    )}
                  </div>
                </div>
              );
            })()}

          </div>
        </div>
      )}

    </div>
  );
}
