import React, { useState } from 'react';
import { CreditCard, Save, CheckCircle, Smartphone, Key, Settings, HelpCircle, Shield, Globe } from 'lucide-react';

interface PaymentGatewayTabProps {
  appSettings: {
    paymentGatewayActive: boolean;
    merchantCode: string;
    apiKey: string;
    clientKey: string;
    provider: 'Midtrans' | 'Xendit' | 'Tripay';
  };
  onSavePaymentSettings: (payload: { paymentGatewayActive: boolean; merchantCode: string; apiKey: string; clientKey: string; provider: 'Midtrans' | 'Xendit' | 'Tripay' }) => void;
}

export default function PaymentGatewayTab({
  appSettings,
  onSavePaymentSettings
}: PaymentGatewayTabProps) {
  const [formData, setFormData] = useState({ ...appSettings });
  const [isSaved, setIsSaved] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSavePaymentSettings(formData);
    setIsSaved(true);
    setTimeout(() => {
      setIsSaved(false);
    }, 2500);
  };

  return (
    <div id="payment-gateway-tab" className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-slate-800">Payment Gateway Integrasi</h2>
        <p className="text-xs text-slate-500">Otomatiskan pembayaran iuran tagihan bulanan & pembelian voucher online dengan Payment Gateway nasional.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Gateway Setup form */}
        <div className="md:col-span-2 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <Settings size={18} className="text-indigo-600" />
            <h3 className="font-extrabold text-slate-800 text-sm">Konfigurasi API Merchant</h3>
          </div>

          {isSaved && (
            <div className="bg-emerald-50 border border-emerald-250 text-emerald-800 text-xs p-3 rounded-lg flex items-center gap-2">
              <CheckCircle size={15} />
              <span>Konfigurasi Payment Gateway sukses disimpan & diaktifkan!</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4 text-xs font-semibold text-slate-705">
            <div className="flex items-center justify-between p-4 bg-slate-50 rounded-xl border border-slate-150">
              <div className="space-y-0.5">
                <p className="text-sm font-extrabold text-slate-800">Aktifkan Payment Gateway Otomatis</p>
                <p className="text-[10px] text-slate-400 font-normal">Izinkan pembayaran mandiri virtual account, e-wallet, bank transfer lunas real-time.</p>
              </div>
              <input
                type="checkbox"
                id="activeGateway"
                className="w-4 h-4 text-indigo-650 cursor-pointer"
                checked={formData.paymentGatewayActive}
                onChange={(e) => setFormData({ ...formData, paymentGatewayActive: e.target.checked })}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label>Pilih Provider Gerbang Pembayaran *</label>
                <select
                  className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden"
                  value={formData.provider}
                  onChange={(e) => setFormData({ ...formData, provider: e.target.value as any })}
                >
                  <option value="Midtrans">Midtrans (Sangat Direkomendasikan)</option>
                  <option value="Xendit">Xendit (Koneksi Cepat & Handal)</option>
                  <option value="Tripay">Tripay (Biaya Admin Rendah)</option>
                </select>
              </div>

              <div className="space-y-1">
                <label>Merchant Client ID / ID Toko *</label>
                <input
                  type="text"
                  required
                  placeholder="ID Toko Anda"
                  className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-mono"
                  value={formData.merchantCode}
                  onChange={(e) => setFormData({ ...formData, merchantCode: e.target.value })}
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="flex items-center gap-1 text-slate-700 font-extrabold">
                  <Key size={13} className="text-rose-500" /> Server API Key (Secret / Private Key) *
                </label>
                <input
                  type="password"
                  required
                  placeholder="Ex. SB-Mid-server-xxxxxxxxxxxx"
                  className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-mono text-slate-705 text-xs"
                  value={formData.apiKey}
                  onChange={(e) => setFormData({ ...formData, apiKey: e.target.value })}
                />
                <p className="text-[10px] text-slate-400 font-normal leading-normal">Digunakan privat di sisi server untuk verifikasi & otentikasi transaksi aman.</p>
              </div>

              <div className="space-y-1">
                <label className="flex items-center gap-1 text-slate-700 font-extrabold">
                  <Key size={13} className="text-indigo-500" /> Client Key (Public Key / Client API Key) *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex. SB-Mid-client-xxxxxxxxxxxx"
                  className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-mono text-slate-705 text-xs"
                  value={formData.clientKey || ''}
                  onChange={(e) => setFormData({ ...formData, clientKey: e.target.value })}
                />
                <p className="text-[10px] text-slate-400 font-normal leading-normal">Digunakan publik di sisi browser/client untuk memuat form checkout (Snap JS).</p>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-50 flex justify-end">
              <button
                type="submit"
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition flex items-center gap-1 cursor-pointer"
              >
                <Save size={14} /> Simpan Sandi & Kunci API
              </button>
            </div>
          </form>
        </div>

        {/* Info panel */}
        <div className="bg-indigo-50/50 p-5 rounded-2xl border border-indigo-100 flex flex-col justify-between text-xs text-indigo-950 font-sans leading-relaxed">
          <div className="space-y-4">
            <h4 className="font-bold flex items-center gap-1 text-sm text-indigo-900 border-b border-indigo-100 pb-2">
              <Shield size={16} /> Keamanan Transaksi
            </h4>
            <p>Setiap transaksi online diproses menggunakan enkripsi standar industri AES-256. Notifikasi webhook (Callback) dari provider akan memicu pelunasan invoice tagihan secara otomatis dlm hitungan detik tanpa campur tangan admin.</p>
            
            <div className="space-y-1 bg-white p-3 rounded-xl border border-indigo-100 font-mono text-[9px] text-indigo-700">
              <p className="font-bold flex items-center gap-1"><Globe size={11} /> URL Callback (Menerima):</p>
              <span className="break-all font-semibold select-all">https://netkita.com/api/callback/payment</span>
            </div>
          </div>

          <div className="bg-indigo-900 text-white p-3 rounded-xl mt-4 space-y-1 border border-indigo-700">
            <p className="font-bold text-[10px]">💡 Tips Hemat Biaya:</p>
            <p className="text-[9px] leading-tight opacity-90">Gunakan Tripay jika Anda menargetkan penjualan voucher kecil karena struktur biayanya sangat hemat untuk transaksi mikro.</p>
          </div>
        </div>

      </div>
    </div>
  );
}
