import React, { useState } from 'react';
import { Teknisi, MikrotikServer, Paket } from '../types';
import { ShieldAlert, Plus, Trash2, Edit3, Search, UserCheck, Server, AlertCircle, X, CheckSquare, Square, Save, Smartphone, Key } from 'lucide-react';

interface TeknisiTabProps {
  teknisiList: Teknisi[];
  servers: MikrotikServer[];
  paket: Paket[];
  onAddTeknisi: (t: Omit<Teknisi, 'id'>) => void;
  onUpdateTeknisi: (t: Teknisi) => void;
  onDeleteTeknisi: (id: string) => void;
  onLoginAsTeknisi?: (t: Teknisi) => void;
}

export default function TeknisiTab({
  teknisiList,
  servers,
  paket,
  onAddTeknisi,
  onUpdateTeknisi,
  onDeleteTeknisi,
  onLoginAsTeknisi
}: TeknisiTabProps) {
  const [search, setSearch] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTeknisi, setEditingTeknisi] = useState<Teknisi | null>(null);
  const [teknisiToDelete, setTeknisiToDelete] = useState<Teknisi | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    nama: '',
    noHp: '',
    username: '',
    password: '',
    statusAktif: true,
    allowedServerIds: [] as string[],
    allowedPaketIds: [] as string[],
    allowedMenus: [] as string[]
  });

  const handleOpenAddModal = () => {
    setEditingTeknisi(null);
    setFormData({
      nama: '',
      noHp: '',
      username: '',
      password: '',
      statusAktif: true,
      allowedServerIds: servers.map(s => s.id), // default allow all
      allowedPaketIds: paket.map(p => p.id), // default allow all
      allowedMenus: ['create_manual', 'create_bulk'] // default allow all
    });
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (t: Teknisi) => {
    setEditingTeknisi(t);
    setFormData({
      nama: t.nama,
      noHp: t.noHp,
      username: t.username,
      password: t.password || '',
      statusAktif: t.statusAktif,
      allowedServerIds: t.allowedServerIds || [],
      allowedPaketIds: t.allowedPaketIds || [],
      allowedMenus: t.allowedMenus || ['create_manual', 'create_bulk']
    });
    setIsModalOpen(true);
  };

  const handleToggleServer = (serverId: string) => {
    setFormData(prev => {
      const allowed = [...prev.allowedServerIds];
      if (allowed.includes(serverId)) {
        return { ...prev, allowedServerIds: allowed.filter(id => id !== serverId) };
      } else {
        return { ...prev, allowedServerIds: [...allowed, serverId] };
      }
    });
  };

  const handleTogglePaket = (paketId: string) => {
    setFormData(prev => {
      const allowed = [...prev.allowedPaketIds];
      if (allowed.includes(paketId)) {
        return { ...prev, allowedPaketIds: allowed.filter(id => id !== paketId) };
      } else {
        return { ...prev, allowedPaketIds: [...allowed, paketId] };
      }
    });
  };

  const handleToggleAllServers = () => {
    setFormData(prev => {
      const allIds = servers.map(s => s.id);
      const isAllChecked = prev.allowedServerIds.length === allIds.length;
      return {
        ...prev,
        allowedServerIds: isAllChecked ? [] : allIds
      };
    });
  };

  const handleToggleAllPakets = () => {
    setFormData(prev => {
      const allIds = paket.map(p => p.id);
      const isAllChecked = prev.allowedPaketIds.length === allIds.length;
      return {
        ...prev,
        allowedPaketIds: isAllChecked ? [] : allIds
      };
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.nama.trim() || !formData.username.trim() || !formData.password.trim()) {
      alert('Mohon isi semua data yang wajib bintang (*)');
      return;
    }

    if (formData.allowedServerIds.length === 0) {
      alert('Pilih minimal satu server MikroTik yang diizinkan untuk teknisi ini!');
      return;
    }

    if (editingTeknisi) {
      onUpdateTeknisi({
        ...editingTeknisi,
        nama: formData.nama,
        noHp: formData.noHp,
        username: formData.username,
        password: formData.password,
        statusAktif: formData.statusAktif,
        allowedServerIds: formData.allowedServerIds,
        allowedPaketIds: formData.allowedPaketIds,
        allowedMenus: formData.allowedMenus
      });
    } else {
      onAddTeknisi({
        nama: formData.nama,
        noHp: formData.noHp,
        username: formData.username,
        password: formData.password,
        statusAktif: formData.statusAktif,
        allowedServerIds: formData.allowedServerIds,
        allowedPaketIds: formData.allowedPaketIds,
        allowedMenus: formData.allowedMenus
      });
    }

    setIsModalOpen(false);
  };

  const filteredList = teknisiList.filter(t =>
    t.nama.toLowerCase().includes(search.toLowerCase()) ||
    t.username.toLowerCase().includes(search.toLowerCase()) ||
    t.noHp.includes(search)
  );

  return (
    <div id="teknisi-tab-container" className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
            <UserCheck className="text-indigo-600" />
            Manajemen & Akses Teknisi
          </h2>
          <p className="text-xs text-slate-500">
            Atur autentikasi login teknisi, filter multirouter (multi-mikrotik) dan profil paket yang diizinkan dikelola lapangan.
          </p>
        </div>
        <button
          onClick={handleOpenAddModal}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-indigo-600 text-white rounded-xl font-bold text-xs hover:bg-indigo-700 transition shadow-sm cursor-pointer"
        >
          <Plus size={16} /> Tambah Teknisi Baru
        </button>
      </div>

      {/* Info Alert */}
      <div className="bg-indigo-50 border border-indigo-150 rounded-2xl p-4 text-xs text-indigo-900 leading-relaxed flex items-start gap-2.5">
        <Server size={18} className="text-indigo-600 shrink-0 mt-0.5" />
        <div>
          <strong className="font-bold">Fitur Kunci Multi-MikroTik & Filter Cerdas:</strong>
          <span className="ml-1">
            Teknisi yang didaftarkan di sini dapat login ke <strong>"Portal Teknisi"</strong> menggunakan kredensial username dan password mereka sendiri. Mereka hanya dapat menyambung, menyaring data, dan membuat voucher hotspot baru di router-router MikroTik yang sudah Anda centang dan izinkan saja.
          </span>
        </div>
      </div>

      {/* Search Bar */}
      <div className="bg-slate-50 p-4 rounded-2xl border border-slate-150 relative max-w-md">
        <Search size={16} className="absolute left-7 top-7 text-slate-400" />
        <input
          type="text"
          placeholder="Cari teknisi berdasarkan nama / HP / username..."
          className="w-full bg-white text-xs pl-9 pr-3 py-2.5 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-medium placeholder:text-slate-400 text-slate-850"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      {/* Grid of Technicians */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredList.map((t) => {
          const allowedServersCount = t.allowedServerIds?.length || 0;
          return (
            <div key={t.id} className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between hover:border-indigo-200 transition">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-extrabold border ${
                    t.statusAktif 
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-700' 
                      : 'bg-rose-50 border-rose-200 text-rose-700'
                  }`}>
                    {t.statusAktif ? '● AKTIF' : '○ NONAKTIF'}
                  </span>
                  
                  {onLoginAsTeknisi && t.statusAktif && (
                    <button
                      onClick={() => onLoginAsTeknisi(t)}
                      className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-50 hover:bg-indigo-100 border border-indigo-200 text-indigo-700 rounded-lg text-[10px] font-black cursor-pointer uppercase tracking-wider"
                    >
                      <Key size={11} /> Login Portal
                    </button>
                  )}
                </div>

                <h3 className="font-black text-slate-800 text-base">{t.nama}</h3>
                <p className="text-[11px] text-slate-400 font-mono mt-0.5 flex items-center gap-1">
                  <Smartphone size={10} /> {t.noHp || 'Tidak ada HP'}
                </p>

                <div className="mt-4 pt-3 border-t border-slate-100 space-y-2">
                  <div className="flex justify-between text-[11px] font-medium text-slate-500">
                    <span>Username Login:</span>
                    <strong className="font-mono text-slate-800 font-bold bg-slate-100 px-1.5 py-0.5 rounded text-[10px]">{t.username}</strong>
                  </div>
                  <div className="flex justify-between text-[11px] font-medium text-slate-500">
                    <span>Keamanan Sandi:</span>
                    <strong className="font-mono text-slate-800 font-bold">•••••••</strong>
                  </div>
                  
                  {/* Authorized MikroTik Status */}
                  <div className="pt-2 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                    MikroTik Terkoneksi ({allowedServersCount})
                  </div>
                  <div className="flex flex-wrap gap-1 mt-1">
                    {t.allowedServerIds && t.allowedServerIds.map(sid => {
                      const srv = servers.find(s => s.id === sid);
                      return (
                        <span key={sid} className="px-2 py-0.5 bg-slate-50 border border-slate-200 text-[10px] text-slate-650 rounded-md font-sans">
                          📡 {srv ? srv.nama : 'Unknown Server'}
                        </span>
                      );
                    })}
                    {allowedServersCount === 0 && (
                      <span className="text-[10px] text-amber-600 font-bold italic flex items-center gap-1">
                        <AlertCircle size={11} /> Belum ada hak akses server
                      </span>
                    )}
                  </div>
                </div>
              </div>

              <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
                <button
                  onClick={() => handleOpenEditModal(t)}
                  className="inline-flex items-center gap-1 px-3 py-1.5 bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-650 rounded-lg text-[10px] font-bold transition cursor-pointer"
                >
                  <Edit3 size={12} /> Edit Hak Akses
                </button>
                <button
                  onClick={() => setTeknisiToDelete(t)}
                  className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                  title="Hapus teknisi"
                >
                  <Trash2 size={13} />
                </button>
              </div>
            </div>
          );
        })}

        {filteredList.length === 0 && (
          <div className="col-span-full text-center py-16 text-slate-400 bg-slate-50/50 rounded-2xl border border-dashed border-slate-200">
            <ShieldAlert size={36} className="mx-auto text-slate-350 mb-2" />
            <p className="text-sm font-bold text-slate-500">Data Teknisi Tidak Ditemukan</p>
            <p className="text-xs text-slate-400 mt-1">Tambahkan akun lapangan teknisi terlebih dahulu dengan mengklik tombol Tambah di atas.</p>
          </div>
        )}
      </div>

      {/* MODAL ADD / EDIT */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-3xl shadow-xl w-full max-w-lg overflow-hidden border border-slate-100 my-8">
            <div className="flex justify-between items-center bg-slate-50 px-6 py-4 border-b border-slate-150">
              <h4 className="font-extrabold text-slate-800 flex items-center gap-2 text-sm uppercase">
                <UserCheck size={18} className="text-indigo-600" />
                {editingTeknisi ? `Edit Teknisi: ${editingTeknisi.nama}` : 'Tambah Teknisi Baru'}
              </h4>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 hover:bg-slate-200 rounded-lg text-slate-400 transition"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs font-semibold text-slate-700">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-slate-600 font-bold">Nama Lengkap Teknisi *</label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: Budi Susanto"
                    className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-bold text-slate-800 focus:border-indigo-400 text-xs"
                    value={formData.nama}
                    onChange={(e) => setFormData({ ...formData, nama: e.target.value })}
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-600 font-bold">Nomor Handphone (WhatsApp) *</label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: 0812XXXXXXXX"
                    className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-bold text-slate-800 focus:border-indigo-400 text-xs"
                    value={formData.noHp}
                    onChange={(e) => setFormData({ ...formData, noHp: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-slate-600 font-bold">Username Login Portal *</label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: budi_teknisi"
                    className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-bold font-mono text-slate-800 focus:border-indigo-400 text-xs"
                    value={formData.username}
                    onChange={(e) => setFormData({ ...formData, username: e.target.value.toLowerCase().replace(/\s+/g, '') })}
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-600 font-bold">Password Login Portal *</label>
                  <input
                    type="password"
                    required
                    placeholder="Sandi Rahasia"
                    className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-bold font-mono text-slate-800 focus:border-indigo-400 text-xs"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-1 bg-slate-55 border border-slate-150 p-2.5 rounded-xl flex items-center justify-between">
                <div>
                  <label className="text-slate-700 font-extrabold text-[11px] block">Status Kerja Aktif</label>
                  <span className="text-[10px] text-slate-400 font-normal">Teknisi nonaktif tidak dapat mengakses portal.</span>
                </div>
                <button
                  type="button"
                  onClick={() => setFormData({ ...formData, statusAktif: !formData.statusAktif })}
                  className={`px-3 py-1 rounded-lg font-black text-[10px] tracking-wider uppercase transition cursor-pointer border ${
                    formData.statusAktif 
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-700' 
                      : 'bg-rose-50 border-rose-200 text-rose-700'
                  }`}
                >
                  {formData.statusAktif ? 'AKTIF' : 'NONAKTIF'}
                </button>
              </div>

              {/* Multi-Mikrotik checkboxes with Select All */}
              <div className="space-y-1 pt-2 border-t border-slate-100">
                <div className="flex justify-between items-center mb-1.5 text-xs">
                  <label className="text-slate-800 font-black flex items-center gap-1">
                    <Server size={14} className="text-indigo-500" />
                    Otorisasi Multi-MikroTik (Penyaringan Akses) *
                  </label>
                  <button
                    type="button"
                    onClick={handleToggleAllServers}
                    className="text-[10px] text-indigo-600 hover:underline font-bold"
                  >
                    {formData.allowedServerIds.length === servers.length ? 'Bersihkan Semua' : 'Pilih Semua'}
                  </button>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-32 overflow-y-auto p-1 border border-slate-150 rounded-xl bg-slate-50">
                  {servers.map((s) => {
                    const isChecked = formData.allowedServerIds.includes(s.id);
                    return (
                      <button
                        key={s.id}
                        type="button"
                        onClick={() => handleToggleServer(s.id)}
                        className={`inline-flex items-center gap-2 p-2 rounded-lg text-left border text-xs font-semibold select-none transition cursor-pointer ${
                          isChecked 
                            ? 'bg-indigo-50/50 border-indigo-200 text-indigo-900 font-bold' 
                            : 'bg-white border-slate-200 text-slate-600'
                        }`}
                      >
                        <span className="shrink-0">{isChecked ? <CheckSquare size={14} className="text-indigo-600" /> : <Square size={14} className="text-slate-400" />}</span>
                        <div className="truncate">
                          <div className="truncate text-[11px] font-bold">{s.nama}</div>
                          <div className="text-[9px] font-mono font-medium text-slate-400">{s.ipAddress}</div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Profil Paket user speed profile checkboxes with Select All */}
              <div className="space-y-1 pt-2 border-t border-slate-100">
                <div className="flex justify-between items-center mb-1.5 text-xs">
                  <label className="text-slate-800 font-black flex items-center gap-1">
                    <CheckSquare size={14} className="text-indigo-500" />
                    Profil Layanan Yang Boleh Dibuat (Hak Cetak) *
                  </label>
                  <button
                    type="button"
                    onClick={handleToggleAllPakets}
                    className="text-[10px] text-indigo-600 hover:underline font-bold"
                  >
                    {formData.allowedPaketIds.length === paket.length ? 'Bersihkan Semua' : 'Pilih Semua'}
                  </button>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-32 overflow-y-auto p-1 border border-slate-150 rounded-xl bg-slate-50">
                  {paket.map((p) => {
                    const isChecked = formData.allowedPaketIds.includes(p.id);
                    return (
                      <button
                        key={p.id}
                        type="button"
                        onClick={() => handleTogglePaket(p.id)}
                        className={`inline-flex items-center gap-2 p-2 rounded-lg text-left border text-xs font-semibold select-none transition cursor-pointer ${
                          isChecked 
                            ? 'bg-indigo-50/50 border-indigo-200 text-indigo-900 font-bold' 
                            : 'bg-white border-slate-200 text-slate-600'
                        }`}
                      >
                        <span className="shrink-0">{isChecked ? <CheckSquare size={14} className="text-indigo-600" /> : <Square size={14} className="text-slate-400" />}</span>
                        <div className="truncate">
                          <div className="truncate text-[11px] font-bold">{p.nama}</div>
                          <div className="text-[9px] font-mono font-medium text-slate-400">{p.kecepatan}</div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Otorisasi Cetak Voucher Options */}
              <div className="space-y-1 pt-2 border-t border-slate-100">
                <div className="flex justify-between items-center mb-1.5 text-xs">
                  <label className="text-slate-800 font-black flex items-center gap-1">
                    <Key size={14} className="text-indigo-500" />
                    Otorisasi Akses Cetak Voucher (Teknisi) *
                  </label>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 p-1.5 border border-slate-150 rounded-xl bg-slate-50">
                  <button
                    type="button"
                    onClick={() => {
                      const isChecked = formData.allowedMenus.includes('create_manual');
                      const updated = isChecked
                        ? formData.allowedMenus.filter(m => m !== 'create_manual')
                        : [...formData.allowedMenus, 'create_manual'];
                      setFormData(prev => ({ ...prev, allowedMenus: updated }));
                    }}
                    className={`inline-flex items-center gap-2 p-2.5 rounded-lg text-left border text-xs font-semibold select-none transition cursor-pointer ${
                      formData.allowedMenus.includes('create_manual')
                        ? 'bg-indigo-50/50 border-indigo-200 text-indigo-900 font-bold'
                        : 'bg-white border-slate-200 text-slate-600'
                    }`}
                  >
                    <span className="shrink-0">
                      {formData.allowedMenus.includes('create_manual') ? (
                        <CheckSquare size={14} className="text-indigo-600" />
                      ) : (
                        <Square size={14} className="text-slate-400" />
                      )}
                    </span>
                    <div>
                      <div className="text-[11px] font-bold">Cetak Manual (Tunggal)</div>
                      <div className="text-[9px] text-slate-400">Izinkan input manual kode voucher khusus</div>
                    </div>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      const isChecked = formData.allowedMenus.includes('create_bulk');
                      const updated = isChecked
                        ? formData.allowedMenus.filter(m => m !== 'create_bulk')
                        : [...formData.allowedMenus, 'create_bulk'];
                      setFormData(prev => ({ ...prev, allowedMenus: updated }));
                    }}
                    className={`inline-flex items-center gap-2 p-2.5 rounded-lg text-left border text-xs font-semibold select-none transition cursor-pointer ${
                      formData.allowedMenus.includes('create_bulk')
                        ? 'bg-indigo-50/50 border-indigo-200 text-indigo-900 font-bold'
                        : 'bg-white border-slate-200 text-slate-600'
                    }`}
                  >
                    <span className="shrink-0">
                      {formData.allowedMenus.includes('create_bulk') ? (
                        <CheckSquare size={14} className="text-indigo-600" />
                      ) : (
                        <Square size={14} className="text-slate-400" />
                      )}
                    </span>
                    <div>
                      <div className="text-[11px] font-bold">Cetak Voucher Massal</div>
                      <div className="text-[9px] text-slate-400">Izinkan membuat banyak voucher otomatis</div>
                    </div>
                  </button>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-150">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl font-bold transition cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition shadow-sm cursor-pointer flex items-center gap-1"
                >
                  <Save size={13} /> {editingTeknisi ? 'Simpan Perubahan' : 'Daftarkan Teknisi'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CUSTOM CONFIRMATION MODAL FOR DELETING TECHNICIAN */}
      {teknisiToDelete && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xl w-full max-w-sm overflow-hidden p-6 space-y-4">
            <div className="flex items-center gap-3 text-rose-650">
              <div className="p-2 bg-rose-50 rounded-full text-rose-600">
                <AlertCircle size={20} />
              </div>
              <h4 className="font-bold text-slate-800 text-sm">Konfirmasi Hapus Teknisi</h4>
            </div>
            
            <p className="text-xs text-slate-500 leading-relaxed">
              Apakah Anda yakin ingin menghapus data teknisi <strong className="text-slate-800 font-bold">{teknisiToDelete.nama}</strong>?
              <br className="mb-1" />
              Tindakan ini tidak dapat dibatalkan. Hak akses login ke portal teknisi akan dicabut sepenuhnya secara instan.
            </p>

            <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setTeknisiToDelete(null)}
                className="px-3.5 py-2 hover:bg-slate-100 text-slate-500 hover:text-slate-700 rounded-xl font-semibold text-xs transition cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteTeknisi(teknisiToDelete.id);
                  setTeknisiToDelete(null);
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold text-xs transition cursor-pointer shadow-xs font-sans"
              >
                Ya, Hapus
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
