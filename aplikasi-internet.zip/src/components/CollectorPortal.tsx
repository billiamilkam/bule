import React, { useState } from 'react';
import { Pelanggan, Tagihan, TukangTagih, Paket, PortalActivityLog } from '../types';
import { formatRupiah, formatBulanIndo, formatTanggalIndo } from '../utils';
import { ShieldAlert, LogOut, CheckCircle, Search, CreditCard, Users, Landmark, DollarSign, Wallet, ShieldCheck, Plus, X, UserCheck, ClipboardList } from 'lucide-react';

interface CollectorPortalProps {
  collector: TukangTagih;
  pelanggan: Pelanggan[];
  tagihan: Tagihan[];
  paket: Paket[];
  selectedBulan: string;
  onLogout: () => void;
  onRegisterPayment: (tagihanId: string, payload: { tanggalBayar: string; metodeBayar: string; catatan: string }) => void;
  onAddPelanggan?: (p: Omit<Pelanggan, 'id' | 'tanggalDaftar'>) => void;
  portalLogs: PortalActivityLog[];
  onAddPortalLog: (log: Omit<PortalActivityLog, 'id' | 'timestamp'>) => void;
}

export default function CollectorPortal({
  collector,
  pelanggan,
  tagihan,
  paket,
  selectedBulan,
  onLogout,
  onRegisterPayment,
  onAddPelanggan,
  portalLogs,
  onAddPortalLog
}: CollectorPortalProps) {
  const allowedMenus = collector.allowedMenus || ['beranda', 'tagihan', 'pelanggan', 'tambah_pelanggan'];
  const hasBeranda = allowedMenus.includes('beranda');
  const hasTagihan = allowedMenus.includes('tagihan');
  const hasPelanggan = allowedMenus.includes('pelanggan');
  const hasTambahPelanggan = allowedMenus.includes('tambah_pelanggan');

  const [activeSubTab, setActiveSubTab] = useState<'beranda' | 'tagihan' | 'pelanggan' | 'logs'>(() => {
    if (hasBeranda) return 'beranda';
    if (hasTagihan) return 'tagihan';
    if (hasPelanggan) return 'pelanggan';
    return 'beranda';
  });

  const [search, setSearch] = useState('');
  
  // Log filter child states
  const [logSearch, setLogSearch] = useState('');
  const [logTypeFilter, setLogTypeFilter] = useState<'ALL' | 'LOGIN' | 'TRANSAKSI_BAYAR'>('ALL');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  // 1. Filter customers allocated specifically to this collector
  const myCustomers = pelanggan.filter(p => p.tukangTagihId === collector.id);
  const myCustomerIds = myCustomers.map(p => p.id);

  // 2. Filter historical matching invoices for these customers
  const myInvoices = tagihan.filter(t => myCustomerIds.includes(t.pelangganId));

  // Current month's invoices for these customers
  const myCurrentInvoices = myInvoices.filter(t => t.bulan === selectedBulan);

  // Stats calculate
  const totalMyClients = myCustomers.length;
  const unpaidInvoices = myCurrentInvoices.filter(t => t.status !== 'LUNAS');
  const paidInvoices = myCurrentInvoices.filter(t => t.status === 'LUNAS');

  const totalToCollect = unpaidInvoices.reduce((sum, item) => sum + item.jumlah, 0);
  const totalCollected = paidInvoices.reduce((sum, item) => sum + item.jumlah, 0);

  // Filter allowed packages
  const myAllowedPakets = paket.filter(p => !collector.allowedPaketIds || collector.allowedPaketIds.length === 0 || collector.allowedPaketIds.includes(p.id));

  // Create Customer Form State
  const [newCust, setNewCust] = useState({
    nama: '',
    noHp: '08',
    alamat: '',
    paketId: myAllowedPakets[0]?.id || paket[0]?.id || '',
    tarif: myAllowedPakets[0]?.harga || paket[0]?.harga || 50000,
    kategoriLangganan: 'Rumahan' as 'Rumahan' | 'Hotspot',
    jatuhTempo: '10' // Hari jatuh tempo standard
  });

  // Handle active package selection change to auto update rates
  const handlePaketChange = (paketId: string) => {
    const p = paket.find(item => item.id === paketId);
    setNewCust({
      ...newCust,
      paketId,
      tarif: p ? p.harga : 50000
    });
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCust.nama.trim()) {
      alert('Nama pelanggan harus diisi!');
      return;
    }
    if (onAddPelanggan) {
      onAddPelanggan({
        nama: newCust.nama,
        noHp: newCust.noHp,
        alamat: newCust.alamat,
        paketId: newCust.paketId,
        tarif: newCust.tarif,
        statusAktif: true,
        jatuhTempo: newCust.jatuhTempo,
        kategoriLangganan: newCust.kategoriLangganan,
        tukangTagihId: collector.id
      });
      setIsAddModalOpen(false);
      setNewCust({
        nama: '',
        noHp: '08',
        alamat: '',
        paketId: myAllowedPakets[0]?.id || paket[0]?.id || '',
        statusAktif: true,
        tarif: myAllowedPakets[0]?.harga || paket[0]?.harga || 50000,
        kategoriLangganan: 'Rumahan',
        jatuhTempo: '10'
      } as any);
      alert('Pelanggan Baru Berhasil Terdaftar!');
    } else {
      alert('Aksi pendaftaran gagal dihubungkan ke server.');
    }
  };

  // Handle confirming cash collection on the spot
  const handleCollectCash = (invoiceId: string, pelangganNama: string) => {
    const confirmPay = confirm(`Konfirmasi Pembayaran LAPANGAN: Apakah Anda benar-benar telah menerima uang tunai dari pelanggan ${pelangganNama}?`);
    if (confirmPay) {
      onRegisterPayment(invoiceId, {
        tanggalBayar: new Date().toISOString().substring(0, 10),
        metodeBayar: 'Cash / Tunai via Kopel',
        catatan: `Diterima langsung di lapangan oleh petugas: ${collector.nama}`
      });
      alert(`Berhasil! Tagihan ${pelangganNama} ditandai sebagai LUNAS. Resit otomatis dikompilasi.`);
    }
  };

  // Filter customers for table search
  const filteredMyCustomers = myCustomers.filter(p => {
    const q = search.toLowerCase();
    return p.nama.toLowerCase().includes(q) || p.noHp.includes(q) || p.alamat.toLowerCase().includes(q);
  });

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 font-sans select-none antialiased flex flex-col">
      
      {/* Collector Portal Header */}
      <header className="bg-slate-950 border-b border-slate-800 py-3.5 px-5 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-indigo-600 text-white rounded-lg shadow-lg font-black tracking-widest text-[11px] flex items-center gap-1.5 shrink-0">
            <Landmark size={14} /> PORTAL LAPANGAN
          </div>
          <div>
            <h1 className="text-xs font-bold text-slate-100 flex items-center gap-1">
              Petugas: <span className="text-indigo-400 font-extrabold">{collector.nama}</span>
            </h1>
            <p className="text-[10px] text-slate-500 mt-0.5">Sistem Billing Terbatas Kolektor</p>
          </div>
        </div>

        <button
          onClick={onLogout}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-rose-950/45 text-rose-300 hover:bg-rose-900 border border-rose-900/50 rounded-xl text-[11px] font-bold transition cursor-pointer shrink-0"
        >
          <LogOut size={13} /> Keluar (Logout)
        </button>
      </header>

      {/* Navigation Sub-Tabs */}
      <div className="bg-slate-950 border-b border-slate-800 scroll-smooth">
        <div className="max-w-7xl mx-auto px-4 flex gap-1 overflow-x-auto">
          {hasBeranda && (
            <button
              onClick={() => setActiveSubTab('beranda')}
               className={`px-4 py-3 text-xs font-bold transition border-b-2 shrink-0 ${
                activeSubTab === 'beranda' ? 'border-indigo-500 text-indigo-400 font-black' : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Beranda Petugas
            </button>
          )}
          {hasTagihan && (
            <button
              onClick={() => setActiveSubTab('tagihan')}
               className={`px-4 py-3 text-xs font-bold transition border-b-2 shrink-0 ${
                activeSubTab === 'tagihan' ? 'border-indigo-500 text-indigo-400 font-black' : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Daftar Tagihan ({unpaidInvoices.length})
            </button>
          )}
          {hasPelanggan && (
            <button
              onClick={() => setActiveSubTab('pelanggan')}
               className={`px-4 py-3 text-xs font-bold transition border-b-2 shrink-0 ${
                activeSubTab === 'pelanggan' ? 'border-indigo-500 text-indigo-400 font-black' : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Anggota Saya ({totalMyClients})
            </button>
          )}
          <button
            onClick={() => setActiveSubTab('logs')}
             className={`px-4 py-3 text-xs font-bold transition border-b-2 shrink-0 ${
              activeSubTab === 'logs' ? 'border-indigo-500 text-indigo-400 font-black' : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Log Kas Lapangan ({portalLogs ? portalLogs.filter(log => log.portalType === 'TUKANG_TAGIH' && log.operatorId === collector.id).length : 0})
          </button>
        </div>
      </div>

      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 space-y-6">

        {/* ACCESS DENIED STATE IF ADMIN REVOKED ALL MENUS */}
        {!hasBeranda && !hasTagihan && !hasPelanggan && (
          <div className="p-12 text-center bg-slate-950 border border-slate-800 rounded-3xl max-w-md mx-auto my-12">
            <ShieldAlert size={48} className="text-rose-500 mx-auto mb-4" />
            <h4 className="font-extrabold text-slate-100 text-base">Hak Akses Dinonaktifkan</h4>
            <p className="text-xs text-slate-400 mt-2 leading-relaxed">Administrator telah menonaktifkan semua akses layar pabean untuk akun petugas Anda sementara waktu.</p>
          </div>
        )}

        {/* --- 1. BERANDA SUBTAB --- */}
        {activeSubTab === 'beranda' && hasBeranda && (
          <div className="space-y-6">
            <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 leading-normal">
              <h3 className="font-extrabold text-indigo-400 text-sm">Selamat Bekerja, {collector.nama}!</h3>
              <p className="text-slate-400 text-xs mt-1">Anda masuk dengan akses terbatas penagihan lapangan. Berikut ringkasan tugas penagihan periode <strong className="text-white">{formatBulanIndo(selectedBulan)}</strong>:</p>
            </div>

            {/* Field statistical summary cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 flex items-center justify-between">
                <div>
                  <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Total Pelanggan Saya</p>
                  <h3 className="text-2xl font-black text-slate-100 mt-1">{totalMyClients}</h3>
                </div>
                <div className="p-3 bg-slate-900 border text-indigo-400 border-slate-800 rounded-xl">
                  <Users size={20} />
                </div>
              </div>

              <div className="bg-slate-950 p-5 rounded-2xl border border-emerald-950/60 flex items-center justify-between">
                <div>
                  <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Berhasil Tertagih (Lunas)</p>
                  <h3 className="text-2xl font-black text-emerald-400 mt-1">{formatRupiah(totalCollected)}</h3>
                  <p className="text-[9px] text-slate-500 mt-1">{paidInvoices.length} Pelanggan Lunas</p>
                </div>
                <div className="p-3 bg-slate-900 border text-emerald-400 border-slate-800 rounded-xl">
                  <DollarSign size={20} />
                </div>
              </div>

              <div className="bg-slate-950 p-5 rounded-2xl border border-rose-950/60 flex items-center justify-between">
                <div>
                  <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Sisa Tunggakan Lapangan</p>
                  <h3 className="text-2xl font-black text-rose-400 mt-1">{formatRupiah(totalToCollect)}</h3>
                  <p className="text-[9px] text-slate-500 mt-1">{unpaidInvoices.length} Pelanggan Belum Bayar</p>
                </div>
                <div className="p-3 bg-slate-900 border text-rose-550 border-slate-800 rounded-xl">
                  <CreditCard size={20} />
                </div>
              </div>
            </div>

            {/* Restricted warning statement */}
            <div className="p-4 bg-indigo-950/30 border border-slate-800 rounded-2xl text-xs text-slate-300 flex gap-3">
              <ShieldAlert size={16} className="text-indigo-450 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-white">Menu & Profil Tersinkronisasi</p>
                <p className="opacity-80 mt-0.5">Sesuai kebijakan administrator, menu navigasi Anda dibatasi {allowedMenus.length} akses resmi, dan hanya diperkenankan menggunakan {myAllowedPakets.length} paket / user profile MikroTik yang diizinkan.</p>
              </div>
            </div>
          </div>
        )}

        {/* --- 2. TAGIHAN LAPANGAN SUBTAB --- */}
        {activeSubTab === 'tagihan' && hasTagihan && (
          <div className="space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-slate-200">Daftar Tagihan Jatuh Tempo</h3>
                <p className="text-[11px] text-slate-500">Menampilkan tagihan berjalan Anda untuk ditagih ke rumah warga.</p>
              </div>
              <p className="text-xs bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800 text-indigo-400 font-bold self-start md:self-auto">
                Periode: {formatBulanIndo(selectedBulan)}
              </p>
            </div>

            {unpaidInvoices.length === 0 ? (
              <div className="p-12 text-center bg-slate-950 border border-slate-800 rounded-3xl">
                <CheckCircle size={36} className="text-emerald-500 mx-auto mb-2" />
                <h4 className="font-bold text-slate-200">Berhasil! Hari Ini Bersih</h4>
                <p className="text-xs text-slate-500 mt-1">Semua iuran asuhan yang didelegasikan ke Anda lunas terbayar.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {unpaidInvoices.map((inv) => {
                  const client = myCustomers.find(p => p.id === inv.pelangganId);
                  return (
                    <div 
                      key={inv.id} 
                      className="bg-slate-950 rounded-2xl border border-slate-800 p-5 space-y-4 shadow-md hover:border-slate-700 transition"
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <span className="text-[10px] bg-rose-950/60 border border-rose-900 text-rose-300 font-black px-2 py-0.5 rounded-md">
                            BELUM BAYAR
                          </span>
                          <h4 className="font-extrabold text-slate-100 text-sm mt-2">{inv.pelangganNama}</h4>
                          <p className="text-[10px] text-slate-400 mt-1 font-mono">{inv.pelangganNoHp}</p>
                        </div>
                        <span className="font-mono font-black text-indigo-455 text-sm">{formatRupiah(inv.jumlah)}</span>
                      </div>

                      <div className="text-[11px] text-slate-400 space-y-1 bg-slate-900/60 p-3 rounded-xl border border-slate-800/50 leading-relaxed font-sans mt-2">
                        <p><strong>Alamat:</strong> {client?.alamat || '-'}</p>
                        <p><strong>Jatuh Tempo:</strong> {formatTanggalIndo(inv.tanggalJatuhTempo)}</p>
                      </div>

                      <button
                        onClick={() => handleCollectCash(inv.id, inv.pelangganNama)}
                        className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
                      >
                        <CheckCircle size={14} /> Setorkan Lapangan (Tunai)
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* --- 3. MEMBERS SUBTAB --- */}
        {activeSubTab === 'pelanggan' && hasPelanggan && (
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-slate-200">Daftar Anggota / Pelanggan Anda</h3>
                <p className="text-[11px] text-slate-500">Database lengkap warga asuhan wilayah Anda yang ditugaskan resmi kepada Anda.</p>
              </div>
              {hasTambahPelanggan && (
                <button
                  onClick={() => setIsAddModalOpen(true)}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-md shadow-indigo-500/10"
                >
                  <Plus size={14} /> Registrasikan Warga Baru
                </button>
              )}
            </div>

            {/* Real-time Search Box inside list */}
            <div className="max-w-md bg-slate-950 p-2.5 rounded-xl border border-slate-800">
              <div className="relative">
                <Search size={14} className="absolute left-3 top-3 text-slate-500" />
                <input
                  type="text"
                  placeholder="Cari nama atau No. WA anggota saya..."
                  className="w-full bg-slate-900 text-xs pl-8 pr-3 py-2 rounded-lg border border-slate-800 focus:outline-hidden focus:border-indigo-500 font-medium text-slate-200"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
            </div>

            <div className="bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden text-xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse min-w-[600px]">
                  <thead className="bg-slate-900 text-slate-500 font-bold uppercase text-[10px] tracking-wider border-b border-slate-800">
                    <tr>
                      <th className="p-4">Nama Pelanggan</th>
                      <th className="p-4">No. HP / WA</th>
                      <th className="p-4">Kategori Rumah</th>
                      <th className="p-4">Alamat Lengkap</th>
                      <th className="p-4 text-center">Status Tarif</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 text-slate-400 font-medium">
                    {filteredMyCustomers.map((p) => (
                      <tr key={p.id} className="hover:bg-slate-900/50">
                        <td className="p-4 font-bold text-slate-100">{p.nama}</td>
                        <td className="p-4 font-mono select-all text-slate-350">{p.noHp}</td>
                        <td className="p-4">
                          <span className={`inline-block px-2 py-0.5 rounded text-[9px] font-bold ${
                            p.kategoriLangganan === 'Hotspot' ? 'bg-amber-950/60 border border-amber-900 text-amber-300' : 'bg-sky-950/60 border border-sky-900 text-sky-300'
                          }`}>
                            {p.kategoriLangganan || 'Rumahan'}
                          </span>
                        </td>
                        <td className="p-3.5 max-w-sm truncate">{p.alamat}</td>
                        <td className="p-4 text-center font-bold text-indigo-400 font-mono">{formatRupiah(p.tarif)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {filteredMyCustomers.length === 0 && (
                <div className="text-center py-10 text-slate-500 text-xs">
                  <p>Tidak ada warga ditemukan dalam asuhan penugasan Anda.</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* SUBTAB CONTENT: LOGS AUDIT */}
        {activeSubTab === 'logs' && (
          <div className="bg-slate-950/80 border border-slate-800 p-5 rounded-3xl space-y-4">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pt-1">
              <div>
                <h3 className="font-bold text-sm text-slate-200">Log Kas Lapangan</h3>
                <p className="text-[10px] text-slate-500 mt-0.5">Audit log penagihan lunas manual, setoran cash, dan sesi login Anda.</p>
              </div>

              <div className="flex items-center gap-2">
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Saring keterangan..."
                    className="bg-slate-900 text-xs border border-slate-800 focus:outline-hidden pl-8 pr-3 py-1.5 rounded-xl text-slate-200 placeholder-slate-600 focus:border-indigo-500 font-sans"
                    value={logSearch}
                    onChange={(e) => setLogSearch(e.target.value)}
                  />
                  <Search size={13} className="absolute left-2.5 top-2.5 text-slate-600" />
                </div>

                <select
                  value={logTypeFilter}
                  onChange={(e: any) => setLogTypeFilter(e.target.value)}
                  className="bg-slate-900 border border-slate-800 text-slate-300 text-[11px] py-1.5 px-2.5 rounded-xl font-sans"
                >
                  <option value="ALL">Semua Tipe</option>
                  <option value="LOGIN">Masuk Portal</option>
                  <option value="TRANSAKSI_BAYAR">Terbayar (Lunas)</option>
                </select>
              </div>
            </div>

            {/* Log Table View */}
            <div className="border border-slate-800 rounded-2xl overflow-hidden font-sans">
              <div className="overflow-y-auto max-h-[400px]">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="bg-slate-900/80 text-slate-400 uppercase tracking-wider font-extrabold text-[10px] border-b border-slate-850 sticky top-0 z-10">
                    <tr>
                      <th className="p-3">Waktu</th>
                      <th className="p-3">Kegiatan</th>
                      <th className="p-3">Detail Aktivitas</th>
                      <th className="p-3 text-right">Setoran Kas</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-850 font-semibold text-slate-300">
                    {(portalLogs || [])
                      .filter(log => log.portalType === 'TUKANG_TAGIH' && log.operatorId === collector.id)
                      .filter(log => logTypeFilter === 'ALL' || log.aktifitasType === logTypeFilter)
                      .filter(log => logSearch === '' || log.detail.toLowerCase().includes(logSearch.toLowerCase()) || log.fiturLabel.toLowerCase().includes(logSearch.toLowerCase()))
                      .length === 0 ? (
                      <tr>
                        <td colSpan={4} className="p-8 text-center text-slate-500 font-normal italic">
                          Belum ada baris log yang cocok dengan filter atau kriteria pencarian Anda.
                        </td>
                      </tr>
                    ) : (
                      (portalLogs || [])
                        .filter(log => log.portalType === 'TUKANG_TAGIH' && log.operatorId === collector.id)
                        .filter(log => logTypeFilter === 'ALL' || log.aktifitasType === logTypeFilter)
                        .filter(log => logSearch === '' || log.detail.toLowerCase().includes(logSearch.toLowerCase()) || log.fiturLabel.toLowerCase().includes(logSearch.toLowerCase()))
                        .map(log => (
                          <tr key={log.id} className="hover:bg-slate-900/40 transition">
                            <td className="p-3 text-slate-500 text-[10px] font-mono whitespace-nowrap">
                              {log.timestamp.substring(0, 10)} {log.timestamp.substring(11, 16)}
                            </td>
                            <td className="p-3">
                              <div className="flex items-center gap-1.5">
                                <span className={`px-2 py-0.5 rounded text-[9px] uppercase tracking-wider font-black ${
                                  log.aktifitasType === 'LOGIN' ? 'bg-blue-950 text-blue-400 border border-blue-900' :
                                  log.aktifitasType === 'TRANSAKSI_BAYAR' ? 'bg-emerald-950 text-emerald-400 border border-emerald-900' :
                                  'bg-slate-905 text-slate-400 border border-slate-800'
                                }`}>
                                  {log.aktifitasType.replace('_', ' ')}
                                </span>
                                <span className="text-white text-[11px] block">{log.fiturLabel}</span>
                              </div>
                            </td>
                            <td className="p-3 text-slate-400 text-[11px] max-w-xs md:max-w-md font-sans leading-relaxed">
                              {log.detail}
                            </td>
                            <td className="p-3 text-right font-mono text-emerald-400 font-black text-[11px]">
                              {log.amount ? formatRupiah(log.amount) : <span className="text-slate-600">-</span>}
                            </td>
                          </tr>
                        ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

      </main>

      {/* REGISTRATION MODAL FOR FIELD TO ADD NEW MEMBER */}
      {isAddModalOpen && hasTambahPelanggan && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-md overflow-hidden shadow-xl">
            <div className="flex justify-between items-center bg-slate-950 px-5 py-4 border-b border-slate-800">
              <h4 className="font-bold text-slate-200 flex items-center gap-1.5 text-xs uppercase tracking-wider">
                <UserCheck size={16} className="text-indigo-400" />
                Registrasikan Pelanggan Baru
              </h4>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 hover:bg-slate-800 rounded-lg text-slate-400 transition cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="p-5 space-y-4 text-xs text-slate-300">
              <div className="space-y-1">
                <label className="text-slate-450 font-bold">Nama Lengkap Warga / Pelanggan *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Bapak Sukirno"
                  className="w-full bg-slate-950 px-3 pl-3.5 py-2.5 rounded-xl border border-slate-800 focus:outline-hidden focus:border-indigo-500 text-slate-200 font-medium"
                  value={newCust.nama}
                  onChange={(e) => setNewCust({ ...newCust, nama: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-slate-450 font-bold">No. HP / WhatsApp *</label>
                  <input
                    type="tel"
                    required
                    placeholder="08..."
                    className="w-full bg-slate-950 px-3 py-2.5 rounded-xl border border-slate-800 focus:outline-hidden focus:border-indigo-500 text-slate-200 font-mono"
                    value={newCust.noHp}
                    onChange={(e) => setNewCust({ ...newCust, noHp: e.target.value })}
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-450 font-bold">Kategori Layanan *</label>
                  <select
                    className="w-full bg-slate-950 px-3 py-2.5 rounded-xl border border-slate-800 focus:outline-hidden text-slate-200 font-medium"
                    value={newCust.kategoriLangganan}
                    onChange={(e) => setNewCust({ ...newCust, kategoriLangganan: e.target.value as any })}
                  >
                    <option value="Rumahan">Rumahan (PPPoE)</option>
                    <option value="Hotspot">Hotspot (Voucher)</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-450 font-bold">Pilih User Profile MikroTik (Allowed) *</label>
                <select
                  className="w-full bg-slate-950 p-2.5 rounded-xl border border-slate-800 focus:outline-hidden text-slate-200 focus:border-indigo-500 font-semibold"
                  value={newCust.paketId}
                  onChange={(e) => handlePaketChange(e.target.value)}
                >
                  {myAllowedPakets.map(p => (
                    <option key={p.id} value={p.id}>📶 {p.nama} - {formatRupiah(p.harga)} ({p.kecepatan})</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3 bg-slate-950/70 p-3 rounded-2xl border border-slate-800/80">
                <div>
                  <span className="text-[10px] text-slate-500 font-bold block uppercase">Tarif Iuran Bulanan</span>
                  <span className="text-sm font-black text-indigo-400 font-mono block mt-1">{formatRupiah(newCust.tarif)}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 font-bold block uppercase">Hari Jatuh Tempo</span>
                  <input
                    type="number"
                    min={1}
                    max={28}
                    className="w-16 bg-slate-900 border border-slate-800 text-center text-xs font-mono font-bold text-slate-200 rounded p-1 mt-1 shrink-0"
                    value={newCust.jatuhTempo}
                    onChange={(e) => setNewCust({ ...newCust, jatuhTempo: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-450 font-bold">Alamat Rumah Pelanggan *</label>
                <textarea
                  required
                  rows={2}
                  placeholder="Contoh: JL. Melati NO.12 RT 04 RW 02"
                  className="w-full bg-slate-950 px-3 py-2 rounded-xl border border-slate-800 focus:outline-hidden focus:border-indigo-500 text-slate-200 font-medium"
                  value={newCust.alamat}
                  onChange={(e) => setNewCust({ ...newCust, alamat: e.target.value })}
                />
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold transition cursor-pointer shadow-sm shadow-indigo-500/10"
                >
                  Daftarkan Anggota
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <footer className="p-4 bg-slate-950 border-t border-slate-850 text-center text-slate-600 text-[10px] shrink-0">
        <p>&copy; {new Date().getFullYear()} {collector.nama}. Semua hak akses terikat kepatuhan keamanan server.</p>
      </footer>
    </div>
  );
}
