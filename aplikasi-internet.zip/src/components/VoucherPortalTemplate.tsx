import React, { useState, useEffect } from 'react';
import { VoucherPageSettings, MikrotikServer, VoucherOffer, HotspotVoucher } from '../types';
import { formatRupiah } from '../utils';
import { 
  Laptop, Phone, Smartphone, MessageCircle, Settings, HelpCircle, 
  Save, CheckCircle, ShieldAlert, Sparkles, Wifi, Upload, Trash2, 
  Edit3, Plus, Link, Copy, ArrowUpRight, RefreshCw, Image, X, Globe, Eye,
  QrCode, Send
} from 'lucide-react';

interface VoucherPortalTemplateProps {
  voucherPageSettings: VoucherPageSettings;
  servers: MikrotikServer[];
  onSaveSettings: (settings: VoucherPageSettings) => void;
  onAddVoucher?: (v: Omit<HotspotVoucher, 'id'>) => void;
}

export default function VoucherPortalTemplate({
  voucherPageSettings,
  servers,
  onSaveSettings,
  onAddVoucher
}: VoucherPortalTemplateProps) {
  // Initialize with fallback for lists
  const [formData, setFormData] = useState<VoucherPageSettings>(() => {
    const v = (voucherPageSettings || {}) as Partial<VoucherPageSettings>;
    return {
      title: v.title || 'Portal Pembelian Voucher NET-KITA',
      greetingText: v.greetingText || 'Selamat Datang di Hotspot NET-KITA. Nikmati internet cepat instan!',
      themeColor: v.themeColor || '#4f46e5',
      showPrice: v.showPrice !== false,
      contactSupport: v.contactSupport || '081290001111',
      enableMikrotikApi: v.enableMikrotikApi !== false,
      customLogoUrl: v.customLogoUrl || '',
      selectedServerId: v.selectedServerId || servers[0]?.id || '',
      voucherOffers: v.voucherOffers || [
        {
          id: 'off-1',
          name: 'Voucher Hemat 1 Hari',
          price: 5000,
          duration: '24 Jam',
          speedLimit: '5 Mbps',
          fup: 'FUP 2GB',
          serverId: 'srv-1',
          status: 'AKTIF'
        },
        {
          id: 'off-2',
          name: 'Voucher Unlimited 7 Hari',
          price: 15000,
          duration: '7 Hari',
          speedLimit: '10 Mbps',
          fup: 'Tanpa FUP',
          serverId: 'srv-1',
          status: 'AKTIF'
        },
        {
          id: 'off-3',
          name: 'Voucher OLT Super Cepat',
          price: 25000,
          duration: '10 Hari',
          speedLimit: '20 Mbps',
          fup: 'Tanpa Batas',
          serverId: 'srv-2',
          status: 'AKTIF'
        }
      ],
      qrisDanaBisnisNama: v.qrisDanaBisnisNama || 'KITA NET DANA BISNIS',
      qrisDanaBisnisWAGateway: v.qrisDanaBisnisWAGateway || '081290001111',
      qrisDanaBisnisImage: v.qrisDanaBisnisImage || '',
      qrisDanaBisnisEnabled: v.qrisDanaBisnisEnabled !== false
    };
  });

  const [activeMenuSection, setActiveMenuSection] = useState<'settings' | 'offers' | 'qris' | 'integration'>('settings');
  const [isSavedAlert, setIsSavedAlert] = useState(false);
  const [isCopied, setIsCopied] = useState<string | null>(null);

  // States for interactive static QRIS DANA Bisnis customer simulator
  const [selectedOffer, setSelectedOffer] = useState<VoucherOffer | null>(null);
  const [buyerWhatsApp, setBuyerWhatsApp] = useState('');
  const [simulationScreen, setSimulationScreen] = useState<'list' | 'checkout' | 'success'>('list');
  const [generatedVoucher, setGeneratedVoucher] = useState<{ id: string; code: string; pass: string } | null>(null);
  const [isPayingSim, setIsPayingSim] = useState(false);
  const [showWaLog, setShowWaLog] = useState(false);
  const [waMessageBody, setWaMessageBody] = useState('');

  // Voucher Offer Creator / Editor Form State
  const [isEditingOffer, setIsEditingOffer] = useState<boolean>(false);
  const [selectedOfferId, setSelectedOfferId] = useState<string | null>(null);
  const [offerForm, setOfferForm] = useState({
    name: '',
    price: 3000,
    duration: '1 Hari',
    speedLimit: '5 Mbps',
    fup: 'Unlimited',
    serverId: servers[0]?.id || 'srv-1',
    status: 'AKTIF' as 'AKTIF' | 'NONAKTIF'
  });

  const colors = [
    { name: 'Indigo Premium', class: '#4f46e5', bg: 'bg-indigo-600' },
    { name: 'Emerald Green', class: '#10b981', bg: 'bg-emerald-500' },
    { name: 'Sky Blue', class: '#0ea5e9', bg: 'bg-sky-500' },
    { name: 'Rose Red', class: '#f43f5e', bg: 'bg-rose-500' },
    { name: 'Orange Amber', class: '#f59e0b', bg: 'bg-amber-500' },
    { name: 'Slate Dark', class: '#334155', bg: 'bg-slate-700' },
  ];

  // Build the self service web portal URL
  const appOrigin = typeof window !== 'undefined' ? window.location.origin : 'https://ais-pre-thayaedb56firtdla37ief.run.app';
  const targetServerObj = servers.find(s => s.id === formData.selectedServerId) || servers[0];
  const portalUrl = `${appOrigin}/portal?router=${formData.selectedServerId || 'all'}`;
  
  // HTML embed code snippet for MikroTik Hotspot login.html
  const embedCodeSnippet = `<!-- Tombol Bayar Voucher Otomatis NET-KITA (Sempurnakan di login.html) -->
<div style="margin: 15px 0; text-align: center;">
  <a href="${portalUrl}" target="_blank" style="display: inline-block; background-color: ${formData.themeColor}; color: white; padding: 12px 20px; font-family: 'Helvetica Neue', Arial, sans-serif; font-size: 13px; font-weight: bold; border-radius: 8px; text-decoration: none; box-shadow: 0 4px 6px rgba(0,0,0,0.1); transition: all 0.2s ease;">
    ⚡ BELI VOUCHER ONLINE DISINI (BAYAR QRIS)
  </a>
  <p style="font-size: 10px; color: #777; margin-top: 5px;">Menerima GoPay, OVO, Dana, LinkAja & QRIS Bank Mandiri/BCA</p>
</div>`;

  const handleSave = (nextData: VoucherPageSettings) => {
    onSaveSettings(nextData);
    setIsSavedAlert(true);
    setTimeout(() => {
      setIsSavedAlert(false);
    }, 3500);
  };

  // 1. PNG LOGO UPLOAD COMPONENT HANDLER
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.type !== 'image/png') {
      alert('Format file tidak didukung! Mohon upload file gambar berformat PNG saja.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        const updated = {
          ...formData,
          customLogoUrl: reader.result
        };
        setFormData(updated);
        handleSave(updated);
        alert('PNG Logo sukses diunggah dan disimpan ke database lokal!');
      }
    };
    reader.onerror = () => {
      alert('Gagal membaca fail gambar.');
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveLogo = () => {
    const updated = {
      ...formData,
      customLogoUrl: ''
    };
    setFormData(updated);
    handleSave(updated);
    alert('Custom logo dihapus. Portal akan kembali menampilkan icon WiFi default.');
  };

  // Clipboard Copier
  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setIsCopied(label);
    setTimeout(() => {
      setIsCopied(null);
    }, 2000);
  };

  // 2. VOUCHER OFFER CREATOR & UPDATER HANDLERS
  const handleOpenAddOffer = () => {
    setOfferForm({
      name: '',
      price: 5000,
      duration: '1 Hari',
      speedLimit: '5 Mbps',
      fup: 'Unlimited',
      serverId: formData.selectedServerId || servers[0]?.id || 'srv-1',
      status: 'AKTIF'
    });
    setSelectedOfferId(null);
    setIsEditingOffer(true);
  };

  const handleOpenEditOffer = (offer: VoucherOffer) => {
    setOfferForm({
      name: offer.name,
      price: offer.price,
      duration: offer.duration,
      speedLimit: offer.speedLimit,
      fup: offer.fup || 'Unlimited',
      serverId: offer.serverId,
      status: offer.status
    });
    setSelectedOfferId(offer.id);
    setIsEditingOffer(true);
  };

  const handleSaveOffer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!offerForm.name.trim()) {
      alert('Nama paket voucher wajib diisi!');
      return;
    }

    let updatedOffers = [...(formData.voucherOffers || [])];

    if (selectedOfferId) {
      // Edit mode
      updatedOffers = updatedOffers.map(o => 
        o.id === selectedOfferId 
          ? { ...o, ...offerForm }
          : o
      );
    } else {
      // Create mode
      const newOffer: VoucherOffer = {
        id: `off-${Date.now()}`,
        ...offerForm
      };
      updatedOffers.push(newOffer);
    }

    const updatedData = {
      ...formData,
      voucherOffers: updatedOffers
    };

    setFormData(updatedData);
    handleSave(updatedData);
    setIsEditingOffer(false);
    setSelectedOfferId(null);
  };

  const handleDeleteOffer = (id: string) => {
    if (!confirm('Apakah Anda yakin ingin menghapus paket voucher ini dari menu tampilan portal?')) return;
    
    const updatedOffers = (formData.voucherOffers || []).filter(o => o.id !== id);
    const updatedData = {
      ...formData,
      voucherOffers: updatedOffers
    };
    setFormData(updatedData);
    handleSave(updatedData);
  };

  // Filter voucher offers matching the currently targeted router server
  const filteredOffersForPreview = (formData.voucherOffers || []).filter(
    o => o.serverId === formData.selectedServerId && o.status === 'AKTIF'
  );

  return (
    <div id="voucher-portal-template" className="space-y-6">
      {/* Top Description */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-5">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Tampilan & Portal Pembelian Voucher Online</h2>
          <p className="text-xs text-slate-500">
            Unggah logo PNG kustom, kelola item menu voucher prabayar untuk pelanggan, saring rute tiap router MikroTik, dan tempelkan sirkuit tautan di MikroTik Hotspot login.html Anda.
          </p>
        </div>

        {/* Tab configuration switcher */}
        <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200">
          <button
            onClick={() => setActiveMenuSection('settings')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer select-none ${
              activeMenuSection === 'settings' 
                ? 'bg-indigo-600 text-white shadow-xs' 
                : 'text-slate-600 hover:text-indigo-600 hover:bg-slate-50'
            }`}
          >
            <Settings size={13} /> 🎨 Desain Portal
          </button>
          <button
            onClick={() => setActiveMenuSection('offers')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer select-none ${
              activeMenuSection === 'offers' 
                ? 'bg-indigo-600 text-white shadow-xs' 
                : 'text-slate-600 hover:text-indigo-600 hover:bg-slate-50'
            }`}
          >
            <Plus size={13} /> 🎫 Menu Voucher
          </button>
          <button
            onClick={() => setActiveMenuSection('qris')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer select-none ${
              activeMenuSection === 'qris' 
                ? 'bg-indigo-600 text-white shadow-xs' 
                : 'text-slate-600 hover:text-indigo-600 hover:bg-slate-50'
            }`}
          >
            <QrCode size={13} /> 📱 QRIS DANA Bisnis
          </button>
          <button
            onClick={() => setActiveMenuSection('integration')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer select-none ${
              activeMenuSection === 'integration' 
                ? 'bg-indigo-600 text-white shadow-xs' 
                : 'text-slate-600 hover:text-indigo-600 hover:bg-slate-50'
            }`}
          >
            <Link size={13} /> 🔗 Link & Integrasi HTML
          </button>
        </div>
      </div>

      {/* Main Form Alert notification */}
      {isSavedAlert && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs px-4 py-3 rounded-xl flex items-center justify-between animate-fadeIn">
          <div className="flex items-center gap-2">
            <CheckCircle size={15} className="text-emerald-600" />
            <span className="font-bold">Perubahan portal berhasil disimpan & dikoordinasikan secara instan!</span>
          </div>
          <span className="text-[10px] font-mono text-emerald-600">Terintegrasi MikroTik Web API</span>
        </div>
      )}

      {/* CONTENT COLUMNS */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* LEFT COLUMN: Editor Panels depends on activeMenuSection */}
        <div className="lg:col-span-7 space-y-6">
          
          {/* SECTION A: PORTAL LAYOUT SETTINGS */}
          {activeMenuSection === 'settings' && (
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-5">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2">
                  <Settings size={18} className="text-indigo-600" />
                  <h3 className="font-extrabold text-slate-800 text-sm">Pengaturan Desain & Logo Portal</h3>
                </div>
                <span className="text-[10px] text-slate-400 font-mono">Langkah 1 dari 3</span>
              </div>

              {/* PNG IMAGE LOGO UPLOADER BOX */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-700 block">Logo Portal Mandiri (Khusus Format .PNG) *</label>
                
                <div className="flex items-start gap-4">
                  {formData.customLogoUrl ? (
                    <div className="relative group">
                      <img 
                        src={formData.customLogoUrl} 
                        alt="Custom Logo" 
                        referrerPolicy="no-referrer"
                        className="w-16 h-16 rounded-xl border border-slate-200 p-1 object-contain bg-slate-50 flex-shrink-0"
                      />
                      <button
                        type="button"
                        onClick={handleRemoveLogo}
                        className="absolute -top-1.5 -right-1.5 bg-rose-500 hover:bg-rose-600 text-white rounded-full p-0.5 shadow-sm transition"
                        title="Hapus Logo"
                      >
                        <X size={11} />
                      </button>
                    </div>
                  ) : (
                    <div className="w-16 h-16 rounded-xl border-2 border-dashed border-slate-300 flex items-center justify-center bg-slate-50 text-slate-400 flex-shrink-0">
                      <Image size={22} />
                    </div>
                  )}

                  <div className="flex-1">
                    <div className="relative align-middle block">
                      <input
                        type="file"
                        id="logo-png-file"
                        accept="image/png"
                        className="hidden"
                        onChange={handleLogoUpload}
                      />
                      <label 
                        htmlFor="logo-png-file"
                        className="inline-flex items-center gap-1.5 px-3 py-2 border border-slate-250 bg-white hover:bg-slate-50 text-slate-705 rounded-lg text-xs font-bold transition cursor-pointer shadow-3xs"
                      >
                        <Upload size={13} /> Pilih Gambar PNG
                      </label>
                    </div>
                    <p className="text-[10px] text-slate-450 mt-1.5 leading-normal">
                      PENTING: Logo akan ditampilkan di bagian atas visual portal HP pelanggan. Disarankan mengunggah gambar PNG transparan agar warna latar selaras dengan tema.
                    </p>
                  </div>
                </div>
              </div>

              <form onSubmit={(e) => { e.preventDefault(); handleSave(formData); }} className="space-y-4 text-xs font-semibold text-slate-700 pt-2">
                {/* Router selection: Di router mana portal ini akan ditampilkan */}
                <div className="space-y-1.5">
                  <label className="text-slate-600 font-bold block">Pilih Router MikroTik Utama Aplikasi *</label>
                  <select
                    className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden text-slate-800 font-bold"
                    value={formData.selectedServerId}
                    onChange={(e) => {
                      const updated = { ...formData, selectedServerId: e.target.value };
                      setFormData(updated);
                      handleSave(updated);
                    }}
                  >
                    {servers.map((s) => (
                      <option key={s.id} value={s.id}>
                        🖥️ {s.nama} ({s.ipAddress})
                      </option>
                    ))}
                  </select>
                  <p className="text-[10px] text-slate-450 font-normal">
                    Pilih target router server MikroTik bawaan yang akan melayani otentikasi user & voucher untuk portal ini. Pelanggan akan dialihkan ke Router ini.
                  </p>
                </div>

                <div className="space-y-1.5">
                  <label>Judul Brand Portal WiFi *</label>
                  <input
                    type="text"
                    required
                    className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-bold text-slate-800 text-xs"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  />
                </div>

                <div className="space-y-1.5">
                  <label>Teks Selamat Datang / Aturan Cara Beli *</label>
                  <textarea
                    required
                    rows={3}
                    className="w-full bg-slate-50 p-2 rounded-lg border border-slate-200 focus:outline-hidden leading-snug"
                    value={formData.greetingText}
                    onChange={(e) => setFormData({ ...formData, greetingText: e.target.value })}
                  />
                </div>

                {/* Color Accent Picker */}
                <div className="space-y-2">
                  <label>Pilih Warna Tema Utama Visual Portal</label>
                  <div className="flex flex-wrap gap-2">
                    {colors.map((col, i) => (
                      <button
                        type="button"
                        key={i}
                        onClick={() => setFormData({ ...formData, themeColor: col.class })}
                        className={`px-3 py-1.5 rounded-lg text-[10px] font-bold border transition flex items-center gap-1.5 ${
                          formData.themeColor === col.class 
                            ? 'border-indigo-600 bg-indigo-50/50 text-indigo-700' 
                            : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-650'
                        }`}
                      >
                        <span className={`w-3 h-3 rounded-full ${col.bg} inline-block`} />
                        {col.name}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label>Nomor WA Hubungi CS Bantuan *</label>
                    <input
                      type="text"
                      required
                      placeholder="Contoh: 0812XXXXXXXX"
                      className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-mono"
                      value={formData.contactSupport}
                      onChange={(e) => setFormData({ ...formData, contactSupport: e.target.value })}
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label>Daftar Harga Jual</label>
                    <select
                      className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden"
                      value={formData.showPrice ? 'true' : 'false'}
                      onChange={(e) => setFormData({ ...formData, showPrice: e.target.value === 'true' })}
                    >
                      <option value="true">Tampilkan List Menu Voucher</option>
                      <option value="false">Sembunyikan List Menu Voucher</option>
                    </select>
                  </div>
                </div>

                {/* Mikrotik API Toggle Integration */}
                <div className="p-4 bg-indigo-50/60 rounded-xl border border-indigo-150 flex items-center justify-between mt-4">
                  <div className="space-y-0.5 pr-2">
                    <p className="text-xs font-extrabold text-slate-800 flex items-center gap-1">
                      🌐 Integrasi RouterOS API Server
                    </p>
                    <p className="text-[10px] text-slate-500 leading-normal font-normal">
                      Sinkronkan secara aman voucher yang dibuat langsung ke memori RouterOS MikroTik yang dipilih saat ini.
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      id="enableApiConnect"
                      className="w-4 h-4 text-indigo-650 focus:ring-indigo-500 rounded cursor-pointer"
                      checked={formData.enableMikrotikApi}
                      onChange={(e) => setFormData({ ...formData, enableMikrotikApi: e.target.checked })}
                    />
                    <label htmlFor="enableApiConnect" className="text-xs font-black cursor-pointer text-indigo-700">ACTIVE</label>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-6 rounded-xl transition flex items-center justify-center gap-2 shadow-xs cursor-pointer"
                >
                  <Save size={14} /> Update & Sinkronisasikan Live Desain Portal
                </button>
              </form>
            </div>
          )}

          {/* SECTION B: MENU VOUCHER CREATOR CRUD (EDIT / KELOLA MENU VOUCHER) */}
          {activeMenuSection === 'offers' && (
            <div className="space-y-6">
              
              {/* VOUCHER FORM DIALOG DRAWER (INLINE EDITOR) */}
              {isEditingOffer ? (
                <div className="bg-slate-55 shadow-xs border-2 border-indigo-200 rounded-2xl p-6 bg-slate-50/50 space-y-4 animate-fadeIn">
                  <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                    <h4 className="font-extrabold text-slate-800 text-xs uppercase tracking-wider flex items-center gap-1.5">
                      <Edit3 size={14} className="text-indigo-600" />
                      {selectedOfferId ? 'Edit Item Menu Voucher' : 'Buat Item Menu Voucher Baru'}
                    </h4>
                    <button 
                      onClick={() => setIsEditingOffer(false)} 
                      className="text-slate-400 hover:text-slate-600 p-1"
                    >
                      <X size={16} />
                    </button>
                  </div>

                  <form onSubmit={handleSaveOffer} className="space-y-4 text-xs font-semibold text-slate-700">
                    <div className="grid grid-cols-2 gap-4">
                      
                      <div className="space-y-1">
                        <label className="text-slate-600">Nama Paket Voucher *</label>
                        <input
                          type="text"
                          required
                          placeholder="Misal: Paket Cepat 1 Hari"
                          className="w-full bg-white p-2.5 rounded-lg border border-slate-200 focus:outline-hidden text-slate-800 font-bold"
                          value={offerForm.name}
                          onChange={(e) => setOfferForm({ ...offerForm, name: e.target.value })}
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-slate-600">Harga Jual (Rupiah) *</label>
                        <input
                          type="number"
                          required
                          placeholder="5000"
                          className="w-full bg-white p-2.5 rounded-lg border border-slate-200 focus:outline-hidden text-slate-800 font-mono"
                          value={offerForm.price}
                          onChange={(e) => setOfferForm({ ...offerForm, price: parseInt(e.target.value) || 0 })}
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-slate-600">Masa Aktif Durasi *</label>
                        <input
                          type="text"
                          required
                          placeholder="Misal: 24 Jam atau 7 Hari"
                          className="w-full bg-white p-2.5 rounded-lg border border-slate-200 focus:outline-hidden text-slate-800"
                          value={offerForm.duration}
                          onChange={(e) => setOfferForm({ ...offerForm, duration: e.target.value })}
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-slate-600">Batas Kecepatan (Speed Limit) *</label>
                        <input
                          type="text"
                          required
                          placeholder="Misal: Up to 5 Mbps"
                          className="w-full bg-white p-2.5 rounded-lg border border-slate-200 focus:outline-hidden text-slate-800"
                          value={offerForm.speedLimit}
                          onChange={(e) => setOfferForm({ ...offerForm, speedLimit: e.target.value })}
                        />
                      </div>

                      <div className="space-y-1">
                        <label className="text-slate-600">Kapasitas Kuota (FUP) / Deskripsi</label>
                        <input
                          type="text"
                          placeholder="Misal: FUP 2GB ATAU Unlimited"
                          className="w-full bg-white p-2.5 rounded-lg border border-slate-200 focus:outline-hidden text-slate-800"
                          value={offerForm.fup}
                          onChange={(e) => setOfferForm({ ...offerForm, fup: e.target.value })}
                        />
                      </div>

                      {/* DI ROUTER MANA AKAN TAMPILKAN */}
                      <div className="space-y-1">
                        <label className="text-indigo-700 font-extrabold block">Tampilkan Di Router Mana? *</label>
                        <select
                          className="w-full bg-white p-2.5 rounded-lg border border-indigo-200 focus:outline-hidden text-indigo-900 font-bold"
                          value={offerForm.serverId}
                          onChange={(e) => setOfferForm({ ...offerForm, serverId: e.target.value })}
                        >
                          {servers.map((s) => (
                            <option key={s.id} value={s.id}>
                              🖥️ {s.nama} ({s.ipAddress})
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="space-y-1 col-span-2">
                        <label className="text-slate-600">Status Menu Paket</label>
                        <div className="flex gap-4 pt-1.5">
                          <label className="flex items-center gap-1.5 cursor-pointer font-bold">
                            <input
                              type="radio"
                              name="offer-status"
                              checked={offerForm.status === 'AKTIF'}
                              onChange={() => setOfferForm({ ...offerForm, status: 'AKTIF' })}
                              className="w-4 h-4 text-indigo-600"
                            />
                            AKTIF (Tampilkan)
                          </label>
                          <label className="flex items-center gap-1.5 cursor-pointer font-bold">
                            <input
                              type="radio"
                              name="offer-status"
                              checked={offerForm.status === 'NONAKTIF'}
                              onChange={() => setOfferForm({ ...offerForm, status: 'NONAKTIF' })}
                              className="w-4 h-4 text-rose-600"
                            />
                            NONAKTIF (Sembunyikan)
                          </label>
                        </div>
                      </div>

                    </div>

                    <div className="flex justify-end gap-2.5 pt-3 border-t border-slate-200 mt-4">
                      <button
                        type="button"
                        onClick={() => setIsEditingOffer(false)}
                        className="px-4 py-2 border border-slate-200 bg-white hover:bg-slate-50 text-slate-600 font-bold rounded-lg transition"
                      >
                        Batal
                      </button>
                      <button
                        type="submit"
                        className="px-4.5 py-2 bg-indigo-650 hover:bg-indigo-750 text-white font-bold rounded-lg transition"
                      >
                        Simpan Paket Menu
                      </button>
                    </div>
                  </form>
                </div>
              ) : (
                <div className="flex justify-between items-center bg-slate-50 p-4 rounded-xl border border-slate-200/60 shadow-3xs">
                  <div>
                    <h3 className="font-extrabold text-slate-700 text-xs tracking-wider uppercase">Menu Paket List Pembelian</h3>
                    <p className="text-[10px] text-slate-400">Atur paket-paket wifi voucher prabayar yang bisa dibeli mandiri oleh klien.</p>
                  </div>
                  <button
                    onClick={handleOpenAddOffer}
                    className="inline-flex items-center gap-1.5 px-3 py-2 bg-indigo-600 text-white rounded-lg font-bold text-xs hover:bg-indigo-700 transition cursor-pointer shadow-xs"
                  >
                    <Plus size={13} /> Tambah Menu Voucher
                  </button>
                </div>
              )}

              {/* LIST OF DEFINED VOUCHER OFFERS */}
              <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="bg-slate-50/80 border-b border-slate-100 text-slate-400 font-extrabold uppercase tracking-wider text-[10px]">
                        <th className="p-3.5">Nama Voucher Menu</th>
                        <th className="p-3.5">Target Router (Ditampilkan di)</th>
                        <th className="p-3.5 text-right">Harga Jual</th>
                        <th className="p-3.5">Speed & Kuota</th>
                        <th className="p-3.5 text-center">Status</th>
                        <th className="p-3.5 text-center">Tindakan</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-medium text-slate-750">
                      {(!formData.voucherOffers || formData.voucherOffers.length === 0) ? (
                        <tr>
                          <td colSpan={6} className="p-12 text-center text-slate-450 italic">
                            Belum ada program menu voucher kustom yang dibuat. Silakan tambahkan program baru.
                          </td>
                        </tr>
                      ) : (
                        formData.voucherOffers.map((o) => {
                          const targetRouter = servers.find(s => s.id === o.serverId);
                          return (
                            <tr key={o.id} className="hover:bg-slate-50/40 transition">
                              <td className="p-3.5">
                                <div className="font-bold text-slate-800">{o.name}</div>
                                <div className="text-[10px] text-slate-400 font-normal mt-0.5">Masa Aktif: {o.duration}</div>
                              </td>
                              <td className="p-3.5">
                                <span className="inline-flex items-center gap-1 py-0.5 px-2 rounded-md bg-indigo-50 text-indigo-700 text-[10px] font-bold border border-indigo-100">
                                  🖥️ {targetRouter ? targetRouter.nama : 'Unknown Router'}
                                </span>
                              </td>
                              <td className="p-3.5 text-right font-black font-mono text-emerald-600">
                                {formatRupiah(o.price)}
                              </td>
                              <td className="p-3.5">
                                <div className="font-semibold text-slate-700">{o.speedLimit}</div>
                                <div className="text-[10px] text-slate-400 font-mono">{o.fup || 'Unlimited'}</div>
                              </td>
                              <td className="p-3.5 text-center">
                                <span className={`inline-block px-2 py-0.5 text-[9px] font-black rounded-sm border ${
                                  o.status === 'AKTIF' 
                                    ? 'bg-emerald-50 text-emerald-700 border-emerald-150'
                                    : 'bg-rose-50 text-rose-600 border-rose-150'
                                }`}>
                                  {o.status}
                                </span>
                              </td>
                              <td className="p-3.5 text-center">
                                <div className="flex items-center justify-center gap-1.5">
                                  <button
                                    onClick={() => handleOpenEditOffer(o)}
                                    className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-slate-50 rounded transition"
                                    title="Edit Paket"
                                  >
                                    <Edit3 size={13} />
                                  </button>
                                  <button
                                    onClick={() => handleDeleteOffer(o.id)}
                                    className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-slate-50 rounded transition"
                                    title="Hapus"
                                  >
                                    <Trash2 size={13} />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* SECTION D: QRIS DANA BISNIS STATIC SETTINGS */}
          {activeMenuSection === 'qris' && (
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-5">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <div className="flex items-center gap-2">
                  <QrCode size={18} className="text-indigo-600" />
                  <h3 className="font-extrabold text-slate-800 text-sm">Pengaturan QRIS Statis DANA Bisnis</h3>
                </div>
                <span className="text-[10px] text-indigo-600 font-mono font-bold bg-indigo-50 px-2.5 py-1 rounded-full">DANA Bisnis Otomatis</span>
              </div>

              <div className="bg-blue-50/50 border border-blue-200 text-blue-800 text-xs p-4 rounded-xl space-y-1.5 leading-relaxed">
                <p className="font-bold flex items-center gap-1.5 text-blue-900">
                  <Sparkles size={14} className="text-blue-600 animate-pulse" /> Cara Kerja Otomatisasi Voucher:
                </p>
                <ol className="list-decimal list-inside text-[11px] font-semibold text-slate-650 space-y-1">
                  <li>Pelanggan memilih paket voucher di HP mereka dan menginput <strong>Nomor WhatsApp</strong>.</li>
                  <li>Sistem menampilkan lembar tagihan <strong>QRIS Statis DANA Bisnis</strong> Anda beserta nominal pembayaran yang presisi.</li>
                  <li>Setelah pelanggan mentransfer/membayar, transaksi divalidasi dan sistem secara <strong>otomatis menggenerasi rincian kode voucher baru</strong> di router MikroTik terpilih.</li>
                  <li>Informasi akun dan link voucher langsung terkirim secara instan ke nomor <strong>WhatsApp Pelanggan</strong> menggunakan gateway center Anda!</li>
                </ol>
              </div>

              {/* QRIS DANA BISNIS FORM */}
              <form onSubmit={(e) => { e.preventDefault(); handleSave(formData); }} className="space-y-4 text-xs font-semibold text-slate-700">
                {/* STATUS ENABLE/DISABLE SWITCH */}
                <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl flex items-center justify-between">
                  <div className="space-y-0.5 animate-fadeIn">
                    <p className="font-extrabold text-slate-800 text-xs">Status Layanan QRIS Statis DANA Bisnis</p>
                    <p className="text-[10px] text-slate-500 font-normal">Aktifkan atau nonaktifkan fitur transaksi pembelian voucher hotspot QRIS DANA Bisnis secara otomatis.</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full ${
                      formData.qrisDanaBisnisEnabled !== false 
                        ? 'bg-emerald-100 text-emerald-700 border border-emerald-200' 
                        : 'bg-rose-100 text-rose-700 border border-rose-200'
                    }`}>
                      {formData.qrisDanaBisnisEnabled !== false ? 'AKTIF/ENABLED' : 'NONAKTIF/DISABLED'}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        const updatedStatus = formData.qrisDanaBisnisEnabled === false ? true : false;
                        setFormData({ ...formData, qrisDanaBisnisEnabled: updatedStatus });
                      }}
                      className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-hidden ${
                        formData.qrisDanaBisnisEnabled !== false ? 'bg-indigo-600' : 'bg-slate-300'
                      }`}
                    >
                      <span
                        className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-md ring-0 transition duration-200 ease-in-out ${
                          formData.qrisDanaBisnisEnabled !== false ? 'translate-x-5' : 'translate-x-0'
                        }`}
                      />
                    </button>
                  </div>
                </div>

                <div className={`grid grid-cols-1 md:grid-cols-2 gap-4 transition-opacity ${formData.qrisDanaBisnisEnabled === false ? 'opacity-40 select-none' : 'opacity-100'}`}>
                  <div className="space-y-1.5">
                    <label className="text-slate-600 font-bold block">Nama Toko / Merchant DANA Bisnis *</label>
                    <input
                      type="text"
                      required={formData.qrisDanaBisnisEnabled !== false}
                      disabled={formData.qrisDanaBisnisEnabled === false}
                      placeholder="Contoh: NET-KITA WI-FI"
                      className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-bold text-slate-800 disabled:bg-slate-100 disabled:text-slate-400"
                      value={formData.qrisDanaBisnisNama || ''}
                      onChange={(e) => setFormData({ ...formData, qrisDanaBisnisNama: e.target.value })}
                    />
                    <p className="text-[10px] text-slate-400 font-normal mt-0.5">
                      Nama yang akan tercetak di bagian atas lembar QRIS Statis Anda agar pelanggan yakin tidak salah transfer.
                    </p>
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-slate-600 font-bold block">No WhatsApp Gateway Center *</label>
                    <input
                      type="text"
                      required={formData.qrisDanaBisnisEnabled !== false}
                      disabled={formData.qrisDanaBisnisEnabled === false}
                      placeholder="Contoh: 0812XXXXXXXX"
                      className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-mono disabled:bg-slate-100 disabled:text-slate-400"
                      value={formData.qrisDanaBisnisWAGateway || ''}
                      onChange={(e) => setFormData({ ...formData, qrisDanaBisnisWAGateway: e.target.value })}
                    />
                    <p className="text-[10px] text-slate-400 font-normal mt-0.5">
                      Nomor WA Server atau nomor resmi Anda untuk mengirim bukti notifikasi otomatisasi rincian akun voucher.
                    </p>
                  </div>
                </div>

                {/* QRIS IMAGE UPLOADER */}
                <div className={`space-y-2 border-t border-slate-100 pt-3 transition-opacity ${formData.qrisDanaBisnisEnabled === false ? 'opacity-40 select-none pointer-events-none' : 'opacity-100'}`}>
                  <label className="text-xs font-bold text-slate-700 block">Gambar Kode QRIS Statis DANA Bisnis Anda (Pilihan)</label>
                  
                  <div className="flex items-start gap-4">
                    {formData.qrisDanaBisnisImage ? (
                      <div className="relative group">
                        <img 
                          src={formData.qrisDanaBisnisImage} 
                          alt="QRIS Statis" 
                          referrerPolicy="no-referrer"
                          className="w-24 h-24 rounded-xl border border-slate-200 p-1 object-contain bg-slate-50 flex-shrink-0"
                        />
                        <button
                          type="button"
                          disabled={formData.qrisDanaBisnisEnabled === false}
                          onClick={() => {
                            const updated = { ...formData, qrisDanaBisnisImage: '' };
                            setFormData(updated);
                            handleSave(updated);
                            alert('QRIS kustom dihapus. Portal akan menampilkan visual kode QRIS dinamis/otomatis.');
                          }}
                          className="absolute -top-1.5 -right-1.5 bg-rose-500 hover:bg-rose-600 text-white rounded-full p-0.5 shadow-sm transition disabled:hidden"
                          title="Hapus QRIS"
                        >
                          <X size={11} />
                        </button>
                      </div>
                    ) : (
                      <div className="w-24 h-24 rounded-xl border-2 border-dashed border-slate-300 flex flex-col items-center justify-center bg-slate-50 text-slate-400 flex-shrink-0 p-2 text-center text-[9px] font-bold">
                        <QrCode size={24} className="mb-1 text-slate-400" />
                        Default QRIS Generator
                      </div>
                    )}

                    <div className="flex-1">
                      <div className="relative align-middle block">
                        <input
                          type="file"
                          id="qris-image-file"
                          disabled={formData.qrisDanaBisnisEnabled === false}
                          accept="image/*"
                          className="hidden"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (!file) return;
                            const reader = new FileReader();
                            reader.onload = () => {
                              if (typeof reader.result === 'string') {
                                const updated = { ...formData, qrisDanaBisnisImage: reader.result };
                                setFormData(updated);
                                handleSave(updated);
                                alert('Gambar QRIS Statis berhasil dikoordinasikan!');
                              }
                            };
                            reader.readAsDataURL(file);
                          }}
                        />
                        <label 
                          htmlFor="qris-image-file"
                          className={`inline-flex items-center gap-1.5 px-3 py-2 border border-slate-250 bg-white text-slate-705 rounded-lg text-xs font-bold transition shadow-3xs ${formData.qrisDanaBisnisEnabled === false ? 'cursor-not-allowed bg-slate-100 text-slate-400' : 'cursor-pointer hover:bg-slate-50'}`}
                        >
                          <Upload size={13} /> Unggah Gambar QRIS (.PNG/.JPG)
                        </label>
                      </div>
                      <p className="text-[10px] text-slate-455 mt-1.5 leading-normal">
                        Unggah kode QR yang Anda peroleh dari aplikasi DANA Bisnis Anda. Jika dikosongkan, simulator portal pelanggan akan menggenerasikan kode QR mandiri yang dinamis secara otomatis.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="border-t border-slate-100 pt-3">
                  <button
                    type="submit"
                    className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2.5 px-5 rounded-xl transition flex items-center justify-center gap-2 shadow-xs cursor-pointer"
                  >
                    <Save size={14} /> Simpan Pengaturan QRIS & DANA Bisnis
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* SECTION C: LOGINPAGE INTEGRATION LINK CODE & SCRIPT GENERATOR */}
          {activeMenuSection === 'integration' && (
            <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
              <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
                <Globe size={18} className="text-indigo-600" />
                <h3 className="font-extrabold text-slate-800 text-sm">Integrasi Login-Page MikroTik</h3>
              </div>

              {/* URL LINK VIEW */}
              <div className="space-y-2 bg-slate-50 p-4 rounded-xl border border-slate-200">
                <div className="flex justify-between items-center">
                  <span className="text-[10px] text-slate-450 font-black tracking-wider uppercase">Tautan Penjualan Online Portal (Link URL)</span>
                  <button
                    onClick={() => handleCopy(portalUrl, 'portal_link')}
                    className="inline-flex items-center gap-1 text-[10px] font-bold text-indigo-600 hover:text-indigo-800 transition cursor-pointer"
                  >
                    <Copy size={11} /> {isCopied === 'portal_link' ? 'Tersalin!' : 'Salin Link'}
                  </button>
                </div>
                <div className="flex items-center gap-2 mt-1.5">
                  <input
                    type="text"
                    readOnly
                    className="flex-1 bg-white p-2.5 rounded-lg border border-slate-250 font-mono text-[10px] text-slate-600 focus:outline-hidden"
                    value={portalUrl}
                  />
                  <a
                    href={portalUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="p-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition"
                    title="Buka Portal Mandiri"
                  >
                    <ArrowUpRight size={14} />
                  </a>
                </div>
                <p className="text-[9px] text-slate-400 leading-normal font-sans">
                  Pelanggan yang terhubung ke WiFi Hotspot MikroTik Anda dapat membuka URL link di atas untuk bertransaksi membeli voucher secara otomatis memakai QRIS se-Indonesia.
                </p>
              </div>

              {/* MIKROTIK HTML EMBED CODE BLOCK */}
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <div>
                    <label className="text-[11px] font-extrabold text-slate-700 block">HTML Script Redirect (Embed dalam WinBox login.html)</label>
                    <span className="text-[9px] text-slate-450">Sisipkan kode tombol di bawah form login hotspot MikroTik</span>
                  </div>
                  <button
                    onClick={() => handleCopy(embedCodeSnippet, 'html_code')}
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 border border-slate-200 rounded-lg text-[10px] font-bold text-slate-600 bg-slate-50 hover:bg-slate-100 transition cursor-pointer"
                  >
                    <Copy size={12} /> {isCopied === 'html_code' ? 'Disalin ke Clipboard!' : 'Salin Semua Kode HTML'}
                  </button>
                </div>

                <div className="relative">
                  <pre className="p-4 bg-slate-900 text-teal-400 font-mono text-[10px] rounded-xl overflow-x-auto border border-slate-800 max-h-56 leading-relaxed">
                    {embedCodeSnippet}
                  </pre>
                </div>
              </div>

              <div className="p-4 bg-amber-50/80 border border-amber-200 rounded-xl flex gap-3 text-xs text-amber-805 leading-relaxed">
                <ShieldAlert size={16} className="text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <p className="font-extrabold">Cara Integrasi di MikroTik Winbox:</p>
                  <ol className="list-decimal list-inside text-[11px] mt-1 space-y-1 font-semibold text-slate-650">
                    <li>Gunakan software FTP Client (seperti FileZilla) atau gunakan File Browser WinBox.</li>
                    <li>Unduh folder <code className="bg-amber-100/60 px-1 font-mono rounded">hotspot</code> dari memori Mikrotik Anda ke PC komputer.</li>
                    <li>Buka file <code className="bg-amber-100/60 px-1 font-mono rounded">login.html</code> menggunakan text editor (Notepad++ / VS Code).</li>
                    <li>Tempelkan kode HTML di atas tepat di bagian bawah box form login hotspot Anda.</li>
                    <li>Unggah kembali berkas <code className="bg-amber-100/60 px-1 font-mono rounded">login.html</code> yang sudah diisi ke router MikroTik Anda. Selesai!</li>
                  </ol>
                </div>
              </div>

            </div>
          )}

        </div>

        {/* RIGHT COLUMN: Phone Smartphone screen view simulator with custom logo render & customized offerings */}
        <div className="lg:col-span-5 flex flex-col items-center justify-start pt-2">
          <div className="text-center mb-3">
            <p className="text-[10px] uppercase font-bold tracking-wider text-slate-450 flex items-center justify-center gap-1.5">
              <Smartphone size={13} className="text-slate-400" /> Pratinjau Tampilan di HP Pelanggan
            </p>
            <span className="text-[9px] text-indigo-600 font-mono font-bold bg-indigo-50 px-2 py-0.5 rounded-full mt-1 inline-block">
              🖥️ Saringan Router: {targetServerObj?.nama || 'Multi-Router'}
            </span>
          </div>

          {/* Smartphone Frame Container */}
          <div className="w-[285px] h-[550px] bg-slate-900 rounded-[40px] p-3 shadow-xl border-4 border-slate-800 relative ring-8 ring-slate-100 flex flex-col overflow-hidden">
            {/* Top Speaker Notch */}
            <div className="absolute top-0 left-1/2 transform -translate-x-1/2 w-28 h-4 bg-slate-900 rounded-b-xl z-20 flex items-center justify-center">
              <div className="w-10 h-1 bg-slate-800 rounded-full" />
            </div>

            {/* Screen Wrapper */}
            <div className="flex-1 bg-slate-50 rounded-[28px] overflow-hidden flex flex-col justify-between font-sans relative z-10 text-slate-650 text-[10px] select-none">
              
              {/* Dynamic Portal Header with Color & Logo PNG support */}
              <div 
                className="p-5 pt-8 text-white text-center rounded-b-3xl space-y-1.5 border-b shadow-md transition-all duration-300 relative z-10"
                style={{ backgroundColor: formData.themeColor }}
              >
                {/* Dynamically render PNG Logo or Default Wifi Icon */}
                {formData.customLogoUrl ? (
                  <div className="w-11 h-11 rounded-xl bg-white p-1.5 flex items-center justify-center mx-auto mb-1 animate-fadeIn border-2 border-white/60 shadow-xs">
                    <img 
                      src={formData.customLogoUrl} 
                      alt="Portal Logo" 
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-contain"
                    />
                  </div>
                ) : (
                  <div className="w-9 h-9 rounded-full bg-white/20 flex items-center justify-center mx-auto mb-1">
                    <Wifi size={17} className="text-white" />
                  </div>
                )}
                
                <h4 className="font-extrabold text-[11px] uppercase leading-tight tracking-wide">{formData.title || 'PORTAL WIFI'}</h4>
                <p className="text-[7.5px] text-white/80">Koneksi Internet Prabayar Instan</p>
              </div>

              {/* Portal Body Scroll Area */}
              {simulationScreen === 'list' && (
                <div className="flex-1 overflow-y-auto p-4 space-y-3.5 pt-3">
                  <div className="bg-white p-3 rounded-xl border border-slate-200/60 shadow-xxs">
                    <p className="text-slate-600 leading-normal text-center font-medium font-sans">
                      {formData.greetingText || 'Kustomisasi selamat datang Anda di sini.'}
                    </p>
                  </div>

                  {/* Voucher Price Card Simulator - dynamically populated from custom voucher offers */}
                  {formData.showPrice && (
                    <div className="space-y-2">
                      <div className="flex justify-between items-center px-1">
                        <p className="font-black text-slate-700 border-l-2 pl-1.5 text-[8.5px] uppercase tracking-wide" style={{ borderColor: formData.themeColor }}>
                          Pilih Menu Paket Tersedia:
                        </p>
                        <span className="text-[7.5px] font-mono text-slate-400 font-bold">
                          Total: {filteredOffersForPreview.length} Menu
                        </span>
                      </div>
                      
                      <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                        {filteredOffersForPreview.length === 0 ? (
                          <div className="bg-white border border-slate-100 p-3 rounded-lg text-center text-slate-450 italic text-[8px]">
                            Tidak ada paket wifi aktif di router ini. Tambahkan menu baru di bagian "Menu Voucher".
                          </div>
                        ) : (
                          filteredOffersForPreview.map((offer, idx) => {
                            const isSelected = selectedOffer?.id === offer.id;
                            return (
                              <div 
                                key={offer.id}
                                onClick={() => setSelectedOffer(offer)}
                                className={`bg-white border p-2 rounded-lg flex items-center justify-between hover:border-slate-300 transition-all cursor-pointer ${
                                  isSelected 
                                    ? 'border-2 ring-2 ring-indigo-100' 
                                    : 'border-slate-150'
                                }`}
                                style={isSelected ? { borderColor: formData.themeColor } : undefined}
                              >
                                <div>
                                  <p className="font-bold text-slate-800 text-[9px] flex items-center gap-1">
                                    {isSelected && <span className="w-1.5 h-1.5 rounded-full inline-block animate-pulse" style={{ backgroundColor: formData.themeColor }} />}
                                    {offer.name}
                                  </p>
                                  <p className="text-[7px] text-slate-400 mt-0.5">{offer.speedLimit} &bull; {offer.fup || 'Unlimited'}</p>
                                </div>
                                <div className="text-right">
                                  <span 
                                    className={`font-mono font-black text-[8.5px] px-1.5 py-0.5 rounded-md ${
                                      isSelected ? 'text-white font-bold' : 'bg-slate-100 text-slate-700'
                                    }`}
                                    style={isSelected ? { backgroundColor: formData.themeColor } : undefined}
                                  >
                                    {formatRupiah(offer.price)}
                                  </span>
                                  <p className="text-[6.5px] text-slate-400 font-mono mt-0.5">Aktif: {offer.duration}</p>
                                </div>
                              </div>
                            );
                          })
                        )}
                      </div>
                    </div>
                  )}

                  {/* WhatsApp input for customers */}
                  {selectedOffer && (
                    <div className="bg-indigo-50/50 border border-indigo-150 p-2.5 rounded-xl space-y-1.5 animate-fadeIn">
                      <label className="text-[8px] font-extrabold text-slate-700 block">
                        📲 Nomor WhatsApp Anda (Untuk Kirim Voucher):
                      </label>
                      <input
                        type="tel"
                        required
                        placeholder="Contoh: 081234567890"
                        className="w-full bg-white p-2 rounded-lg border border-slate-205 text-[9px] font-mono focus:outline-hidden"
                        value={buyerWhatsApp}
                        onChange={(e) => setBuyerWhatsApp(e.target.value)}
                      />
                      <p className="text-[6.5px] text-slate-400 font-normal">
                        Rincian voucher hotspot akan otomatis terkirim via WhatsApp Gateway setetelah pembayaran terverifikasi.
                      </p>
                    </div>
                  )}

                  {/* Payment Option mockup */}
                  <div className="space-y-1.5">
                    <p className="font-bold text-slate-500 text-[7px] uppercase tracking-wider text-center">Bayar Instan pakai QRIS / E-Money</p>
                    {formData.qrisDanaBisnisEnabled === false ? (
                      <div className="bg-rose-50 border border-rose-200 p-2 rounded-xl text-center shadow-3xs">
                        <span className="text-[8px] font-black text-rose-600 block">⚠️ LAYANAN QRIS NONAKTIF</span>
                        <p className="text-[7.5px] text-slate-500 mt-0.5 leading-tight">Pembelian voucher otomatis via QRIS sedang dinonaktifkan sementara oleh Administrator.</p>
                      </div>
                    ) : (
                      <button 
                        type="button"
                        disabled={!selectedOffer || buyerWhatsApp.trim().length < 8}
                        onClick={() => {
                          if (selectedOffer && buyerWhatsApp.trim().length >= 8) {
                            setSimulationScreen('checkout');
                          }
                        }}
                        className={`w-full text-white font-black text-[9.5px] py-2 rounded-xl text-center shadow-xs flex items-center justify-center gap-1 transition ${
                          (selectedOffer && buyerWhatsApp.trim().length >= 8)
                            ? 'cursor-pointer hover:opacity-95' 
                            : 'cursor-not-allowed opacity-45'
                        }`}
                        style={{ backgroundColor: formData.themeColor }}
                      >
                        <Sparkles size={11} className="animate-pulse" /> 
                        {selectedOffer 
                          ? `Bayar Paket ${selectedOffer.name}`
                          : 'Bayar Sekarang (Instan)'
                        }
                      </button>
                    )}
                  </div>
                </div>
              )}

              {/* SCREEN B: QRIS SCANNER SIMULATION */}
              {simulationScreen === 'checkout' && selectedOffer && (
                <div className="flex-1 overflow-y-auto p-4 space-y-3.5 pt-3.5 flex flex-col justify-between">
                  <div>
                    {/* Header Back */}
                    <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                      <button 
                        type="button"
                        onClick={() => setSimulationScreen('list')}
                        className="text-slate-500 hover:text-slate-850 font-bold text-[8px] flex items-center gap-0.5 cursor-pointer"
                      >
                        &larr; Pilih Paket
                      </button>
                      <span className="text-[8px] font-bold text-slate-400 font-mono">Invoice #{Math.floor(1000 + Math.random() * 9000)}</span>
                    </div>

                    {/* Summary Card */}
                    <div className="bg-slate-100 p-2 rounded-xl border border-slate-200/80 mt-2 space-y-1">
                      <div className="flex justify-between items-center text-[8.5px]">
                        <span className="font-semibold text-slate-500">Paket Voucher</span>
                        <span className="font-black text-slate-800">{selectedOffer.name}</span>
                      </div>
                      <div className="flex justify-between items-center text-[9.5px] border-t border-slate-200/40 pt-1">
                        <span className="font-extrabold text-slate-500">Total Nominal</span>
                        <span className="font-black text-rose-600 font-mono">{formatRupiah(selectedOffer.price)}</span>
                      </div>
                    </div>

                    {/* QRIS DANA BISNIS STATIC BOX */}
                    <div className="bg-white border-2 border-slate-200 rounded-2xl p-3 mt-2.5 space-y-2 shadow-xxs">
                      {/* Logo and Brand row */}
                      <div className="flex items-center justify-between p-0.5 border-b border-slate-100 pb-1.5">
                        <div className="flex items-center gap-0.5">
                          <span className="font-extrabold text-blue-600 text-[8.5px] tracking-tight">QR</span>
                          <span className="font-extrabold text-[#f43f5e] text-[8.5px] tracking-tight">IS</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <span className="text-[6px] font-extrabold text-indigo-700">DANA BISNIS</span>
                          <div className="bg-[#0ea5e9] text-white rounded-xs px-1 text-[6px] font-black">DANA</div>
                        </div>
                      </div>

                      {/* Code Image / SVG Pattern fallback */}
                      <div className="mx-auto w-32 h-32 bg-white border border-slate-150 p-1.5 rounded-xl flex items-center justify-center">
                        {formData.qrisDanaBisnisImage ? (
                          <img 
                            src={formData.qrisDanaBisnisImage || undefined} 
                            alt="QRIS Statis" 
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-contain"
                          />
                        ) : (
                          <div className="relative w-full h-full bg-slate-50 rounded-lg p-1 flex flex-col items-center justify-center border border-dashed border-slate-200">
                            {/* SVG mockup QR code dots */}
                            <svg className="w-20 h-20 text-slate-900" viewBox="0 0 100 100" fill="currentColor">
                              <rect x="0" y="0" width="22" height="22" />
                              <rect x="4" y="4" width="14" height="14" fill="white" />
                              <rect x="7" y="7" width="8" height="8" />

                              <rect x="78" y="0" width="22" height="22" />
                              <rect x="82" y="4" width="14" height="14" fill="white" />
                              <rect x="85" y="7" width="8" height="8" />

                              <rect x="0" y="78" width="22" height="22" />
                              <rect x="4" y="82" width="14" height="14" fill="white" />
                              <rect x="7" y="85" width="8" height="8" />

                              <rect x="42" y="42" width="16" height="16" fill="#000000" />
                              <circle cx="50" cy="50" r="4" fill="white" />

                              {/* Randomized pixel bars */}
                              <rect x="30" y="5" width="12" height="4" />
                              <rect x="50" y="6" width="4" height="14" />
                              <rect x="32" y="22" width="6" height="8" />
                              <rect x="62" y="18" width="12" height="4" />

                              <rect x="5" y="32" width="16" height="4" />
                              <rect x="15" y="42" width="4" height="12" />
                              <rect x="25" y="52" width="12" height="4" />

                              <rect x="78" y="32" width="16" height="4" />
                              <rect x="82" y="42" width="4" height="12" />
                              <rect x="70" y="52" width="12" height="4" />

                              <rect x="30" y="78" width="6" height="8" />
                              <rect x="42" y="82" width="12" height="4" />
                              <rect x="32" y="90" width="22" height="4" />
                              <rect x="62" y="78" width="4" height="14" />
                              <rect x="68" y="85" width="12" height="4" />
                            </svg>
                            <div className="absolute bg-[#0ea5e9] text-white px-1 rounded-[1px] border border-white text-[4px] font-black tracking-wider shadow-xxs">DANA</div>
                          </div>
                        )}
                      </div>

                      {/* Store detail label */}
                      <div className="space-y-0.5 text-center">
                        <p className="font-extrabold text-[8.5px] uppercase text-indigo-950 tracking-wide">
                          {formData.qrisDanaBisnisNama || 'KITA NET DANA BISNIS'}
                        </p>
                        <p className="text-[5.5px] font-mono text-slate-400">NMID: ID2029339485 &bull; DANA BISNIS QRIS STATIC</p>
                      </div>
                    </div>

                    <p className="text-[7.5px] text-slate-500 text-center leading-normal mt-2">
                      Pindai / Screenshot QRIS DANA Bisnis di atas. Pembayaran sukses akan memicu sistem menggenerasi voucher secara instan.
                    </p>
                  </div>

                  {/* Simulate verification trigger */}
                  <div className="space-y-1.5 pt-2">
                    <button
                      type="button"
                      disabled={isPayingSim}
                      onClick={() => {
                        setIsPayingSim(true);
                        setTimeout(() => {
                          const suffix = Math.random().toString(36).substring(2, 7).toUpperCase();
                          const vocCode = `DANA-${suffix}`;
                          const vocPass = `NET-${Math.floor(100 + Math.random() * 900)}`;

                          if (onAddVoucher) {
                            onAddVoucher({
                              code: vocCode,
                              password: vocPass,
                              paketId: selectedOffer.id,
                              harga: selectedOffer.price,
                              durasi: selectedOffer.duration,
                              serverName: targetServerObj?.nama || 'Server Utama',
                              status: 'AKTIF',
                              agentPaymentStatus: 'LUNAS' // Auto-lunas paid online
                            });
                          }

                          // Formulate Simulated WA
                          const msg = `*TRANSAKSI QRIS SUKSES (DANA BISNIS)* ✅

Halo Kak! Terima kasih, pembayaran Rp ${selectedOffer.price.toLocaleString('id-ID')} via QRIS *${formData.qrisDanaBisnisNama || 'KITA NET DANA BISNIS'}* terdeteksi SUKSES.

Berikut rincian *WIFI HOTSPOT VOUCHER* Anda:
----------------------------------------
📶 Router Server : *${targetServerObj?.nama || 'Server Utama'}*
🎫 KODE VOUCHER  : *${vocCode}*
🔑 PASSWORD VOUCHER : *${vocPass}*
💰 TOTAL BAYAR   : *Rp ${selectedOffer.price.toLocaleString('id-ID')}*
⌛ DURASI AKTIF  : *${selectedOffer.duration}*
⚡ BATAS SPEED   : *${selectedOffer.speedLimit}*
----------------------------------------
Sistem: Otomatis generate & sinkronisasi MikroTik API Sukses!

*PETUNJUK KONEKSI:*
1. Cari & hubungkan WiFi Anda ke Hotspot: *${targetServerObj?.nama || 'Server Utama'}*.
2. Browser halaman login MikroTik akan otomatis terbuka.
3. Masukkan Kode Voucher di atas di kolom kode voucher, tekan tombol Hubungkan/Login.

Butuh bantuan? WA CS: ${formData.contactSupport}`;

                          setGeneratedVoucher({ id: `voc-${Date.now()}`, code: vocCode, pass: vocPass });
                          setWaMessageBody(msg);
                          setShowWaLog(true);
                          setSimulationScreen('success');
                          setIsPayingSim(false);
                        }, 1200);
                      }}
                      className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-2 rounded-xl text-center text-[9px] flex items-center justify-center gap-1 cursor-pointer transition shadow-xs"
                    >
                      {isPayingSim ? (
                        <>
                          <RefreshCw size={10} className="animate-spin shrink-0" />
                          Memverifikasi Pembayaran...
                        </>
                      ) : (
                        <>
                          <CheckCircle size={10} className="shrink-0 animate-bounce" />
                          Simulasi Bayar / Konfirmasi Lunas
                        </>
                      )}
                    </button>
                  </div>
                </div>
              )}

              {/* SCREEN C: SUCCESS SPLASH VIEW */}
              {simulationScreen === 'success' && selectedOffer && generatedVoucher && (
                <div className="flex-1 overflow-y-auto p-4 space-y-4 pt-4 flex flex-col justify-between text-center animate-fadeIn">
                  <div className="space-y-3">
                    <div className="w-10 h-10 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto border border-emerald-150 shadow-xxs">
                      <CheckCircle size={20} className="animate-bounce" />
                    </div>

                    <div className="space-y-0.5">
                      <h4 className="font-extrabold text-[11px] text-slate-800 leading-none">Pembayaran Berhasil!</h4>
                      <p className="text-[6.5px] text-emerald-600 font-bold">Otomatisasi Voucher Berhasil</p>
                    </div>

                    {/* VOUCHER ticket */}
                    <div className="bg-white border-2 border-dashed border-emerald-250 rounded-2xl p-3 relative overflow-hidden space-y-2 text-center">
                      <div className="absolute -left-1.5 top-11 w-2.5 h-2.5 bg-slate-50 border border-emerald-250 rounded-full" />
                      <div className="absolute -right-1.5 top-11 w-2.5 h-2.5 bg-slate-50 border border-emerald-250 rounded-full" />

                      <p className="text-[6px] font-black text-slate-400 font-mono tracking-widest uppercase">KODE WIFI VOUCHER</p>
                      
                      <div className="bg-slate-50 py-2 px-1 rounded-xl border border-slate-205">
                        <p className="text-[13px] font-black text-indigo-700 font-mono tracking-wider">{generatedVoucher.code}</p>
                        <p className="text-[7px] text-slate-400 mt-0.5">Password: <strong className="font-mono text-slate-700">{generatedVoucher.pass}</strong></p>
                      </div>

                      <div className="grid grid-cols-2 gap-1 text-[7px] pt-1.5 border-t border-slate-100 font-semibold text-slate-500 text-left">
                        <div>Durasi: <strong className="text-slate-700 text-[7px]">{selectedOffer.duration}</strong></div>
                        <div>Speed: <strong className="text-slate-700 text-[7px]">{selectedOffer.speedLimit}</strong></div>
                      </div>
                    </div>

                    <div className="bg-sky-50 border border-sky-100 p-2 rounded-xl text-left flex gap-1.5 items-start">
                      <MessageCircle size={13} className="text-sky-600 shrink-0 mt-0.5 animate-pulse" />
                      <div className="space-y-0.5">
                        <p className="text-[7.5px] font-black text-sky-850">WhatsApp Sukses Terkirim</p>
                        <p className="text-[6.5px] text-sky-600 leading-tight">Detail voucher & petunjuk cara mendaftar telah otomatis dikirim ke nomor <strong>{buyerWhatsApp}</strong>.</p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <button
                      type="button"
                      onClick={() => handleCopy(generatedVoucher.code, 'sim_voucher')}
                      className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold py-1.5 rounded-lg text-[8px] transition cursor-pointer flex items-center justify-center gap-1"
                    >
                      <Copy size={9} /> 
                      {isCopied === 'sim_voucher' ? 'Tersalin' : 'Salin Voucher'}
                    </button>
                    
                    <button
                      type="button"
                      onClick={() => {
                        setSimulationScreen('list');
                        setSelectedOffer(null);
                        setGeneratedVoucher(null);
                      }}
                      className="w-full text-white py-1.5 rounded-lg text-center text-[9px] font-extrabold cursor-pointer transition hover:opacity-95"
                      style={{ backgroundColor: formData.themeColor }}
                    >
                      Beli Voucher Baru &larr;
                    </button>
                  </div>
                </div>
              )}


              {/* Portal Footer banner */}
              <div className="p-3 bg-slate-100 border-t border-slate-200 text-center text-[7.5px] text-slate-400">
                <p>Bantuan CS (WhatsApp): <strong className="text-slate-650 font-mono">{formData.contactSupport}</strong></p>
                <span className="mt-1 block opacity-85">MikroTik self-service portal disinkronkan</span>
              </div>

            </div>

            {/* Smart Home Indicator bar */}
            <div className="absolute bottom-1.5 left-1/2 transform -translate-x-1/2 w-24 h-1 bg-slate-700 rounded-full z-20" />
          </div>

          {/* Simulated WhatsApp Webhook message logger */}
          {showWaLog && (
            <div className="mt-4 w-[285px] bg-[#e5ddd5] rounded-2xl border border-slate-200 overflow-hidden shadow-lg animate-fadeIn text-xs flex flex-col font-sans">
              {/* WhatsApp header */}
              <div className="bg-[#075e54] text-white p-2.5 flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-[#128c7e] text-white flex items-center justify-center font-bold text-[10px]">WA</div>
                <div className="flex-1">
                  <h5 className="font-extrabold text-[9.5px] leading-tight">WA Gateway Center</h5>
                  <p className="text-[7.5px] text-white/70">Online &bull; Pengiriman Otomatis</p>
                </div>
                <button 
                  type="button"
                  onClick={() => setShowWaLog(false)} 
                  className="text-white/80 hover:text-white font-bold p-1 text-[9px] cursor-pointer"
                  title="Sembunyikan Log WA"
                >
                  <X size={12} />
                </button>
              </div>

              {/* Chat bubble body */}
              <div className="p-3 space-y-2 max-h-56 overflow-y-auto leading-relaxed text-slate-800">
                <p className="text-[7px] text-center text-slate-500 bg-amber-100/75 py-1 px-2 rounded-md self-center font-bold uppercase">
                  ⚡ SINKRONISASI WA GATEWAY SUKSES TERKIRIM KE {buyerWhatsApp}
                </p>

                <div className="bg-white p-2.5 rounded-lg rounded-tl-none shadow-3xs max-w-[95%] relative mx-auto border border-slate-100">
                  <pre className="whitespace-pre-wrap font-mono text-[7px] leading-snug break-words font-semibold text-slate-700">
                    {waMessageBody}
                  </pre>
                  <div className="text-right text-[6px] text-slate-400 mt-1 font-mono">
                    {new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })} &bull; Terkirim & Aktivasi MikroTik Sukses
                  </div>
                </div>
              </div>

              {/* Chat Footer */}
              <div className="bg-slate-50 p-2 flex gap-1.5 justify-end border-t border-slate-150">
                <button
                  type="button"
                  onClick={() => handleCopy(waMessageBody, 'wa_copy')}
                  className="px-2 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-lg font-bold text-[8px] flex items-center gap-1 cursor-pointer transition shadow-3xs"
                >
                  <Copy size={9} />
                  {isCopied === 'wa_copy' ? 'Tersalin!' : 'Salin Pesan WA'}
                </button>
              </div>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
