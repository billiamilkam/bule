import React, { useState, useEffect } from 'react';
import { 
  Settings, Save, CheckCircle, Shield, Briefcase, CreditCard, 
  MessageSquare, Database, Download, Upload, Trash2, HelpCircle,
  Server, RefreshCw, AlertCircle, Check, Users, Wifi, Store,
  ClipboardList, UserCheck, LayoutGrid, Sparkles, Eye, EyeOff, Cpu, Key
} from 'lucide-react';
import { AppSettings } from '../types';

const AVAILABLE_QUICK_MENUS = [
  { id: 'mikrotik', label: 'Router Mikrotik', desc: 'Kelola server & interfaces Mikrotik', icon: Server, color: 'text-sky-500 bg-sky-50' },
  { id: 'pelanggan', label: 'Data Pelanggan', desc: 'Atur data & status isolir pelanggan bulanan', icon: Users, color: 'text-indigo-500 bg-indigo-50' },
  { id: 'hotspot', label: 'Hotspot Voucher', desc: 'Generate & manajemen akun voucher', icon: Wifi, color: 'text-amber-500 bg-amber-50' },
  { id: 'pppoe', label: 'PPPoE/Rumahan', desc: 'Monitor pelanggan kabel PPPoE', icon: RefreshCw, color: 'text-purple-500 bg-purple-50' },
  { id: 'reseller', label: 'Agen / Reseller', desc: 'Manajemen agen voucher & limit saldo', icon: Store, color: 'text-emerald-500 bg-emerald-50' },
  { id: 'pesanan_agen', label: 'Pesanan Agen', desc: 'Approval pembelian voucher agen', icon: ClipboardList, color: 'text-rose-500 bg-rose-50' },
  { id: 'tukang_tagih', label: 'Tukang Tagih', desc: 'Staf penagihan & setor iuran lapangan', icon: UserCheck, color: 'text-cyan-500 bg-cyan-50' },
  { id: 'teknisi', label: 'Akses Teknisi', desc: 'Tiket & status troubleshooting lapangan', icon: UserCheck, color: 'text-blue-500 bg-blue-50' },
  { id: 'tagihan', label: 'Tagihan Bulanan', desc: 'Kelola laporan billing & pelunasan iuran', icon: CreditCard, color: 'text-indigo-600 bg-indigo-50 font-bold' },
  { id: 'notifikasi', label: 'WA Gateway API', desc: 'Setting template & status broadcast WA', icon: MessageSquare, color: 'text-emerald-600 bg-emerald-50' },
  { id: 'payment_gateway', label: 'Payment Gateway', desc: 'Integrasi transfer otomatis online', icon: CreditCard, color: 'text-indigo-500 bg-indigo-50 font-semibold' },
  { id: 'voucher_look', label: 'Portal Voucher Look', desc: 'Desain visual portal beli ecer voucher', icon: Settings, color: 'text-teal-500 bg-teal-50' }
];

interface PengaturanTabProps {
  appSettings: AppSettings;
  onSaveSettings: (settings: AppSettings) => void;
  onExportDatabase: () => void;
  onImportDatabase: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onResetDatabase: () => void;
  mysqlStatus?: 'connected' | 'offline';
  isSyncing?: boolean;
  onSyncNow?: () => void;
}

export default function PengaturanTab({
  appSettings,
  onSaveSettings,
  onExportDatabase,
  onImportDatabase,
  onResetDatabase,
  mysqlStatus = 'offline',
  isSyncing = false,
  onSyncNow
}: PengaturanTabProps) {
  const [formData, setFormData] = useState<AppSettings>({ ...appSettings });
  const [isSaved, setIsSaved] = useState(false);
  const [activeSubTab, setActiveSubTab] = useState<'profil_billing' | 'whatsapp_template' | 'system_db' | 'mysql_config' | 'gemini_api'>('profil_billing');

  // Gemini API form toggles and test states
  const [showGeminiKey, setShowGeminiKey] = useState(false);
  const [isTestingGemini, setIsTestingGemini] = useState(false);
  const [geminiTestResult, setGeminiTestResult] = useState<{ success?: boolean; message?: string } | null>(null);

  // MySQL form states
  const [mysqlHost, setMysqlHost] = useState('');
  const [mysqlPort, setMysqlPort] = useState('3306');
  const [mysqlUser, setMysqlUser] = useState('');
  const [mysqlPassword, setMysqlPassword] = useState('');
  const [mysqlDatabase, setMysqlDatabase] = useState('');
  const [mysqlActive, setMysqlActive] = useState(false);

  // Connection testing states
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success?: boolean; message?: string } | null>(null);
  const [isSavingConfig, setIsSavingConfig] = useState(false);
  const [saveSuccessMessage, setSaveSuccessMessage] = useState('');

  // Raw Database JSON Editor states for Shared Hosting files
  const [rawDbJson, setRawDbJson] = useState('');
  const [isRawDbLoading, setIsRawDbLoading] = useState(false);
  const [rawDbSaveStatus, setRawDbSaveStatus] = useState('');

  const fetchRawDbJson = async () => {
    setIsRawDbLoading(true);
    setRawDbSaveStatus('');
    try {
      const res = await fetch('/api/db/raw-json');
      const data = await res.json();
      if (data && data.success) {
        setRawDbJson(data.jsonText);
      }
    } catch (err: any) {
      console.error('Failed to load raw JSON fallback:', err);
    } finally {
      setIsRawDbLoading(false);
    }
  };

  useEffect(() => {
    if (activeSubTab === 'system_db') {
      fetchRawDbJson();
    }
  }, [activeSubTab]);

  const handleSaveRawDbJson = async () => {
    if (!confirm('Apakah Anda yakin ingin langsung menimpa file database_fallback.json di server? Tindakan salah input JSON dapat merusak data.')) {
      return;
    }
    setRawDbSaveStatus('menyimpan');
    try {
      const res = await fetch('/api/db/raw-json-save', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ jsonText: rawDbJson })
      });
      const data = await res.json();
      if (data.success) {
        setRawDbSaveStatus('sukses');
        alert(data.message);
        setTimeout(() => {
          window.location.reload();
        }, 800);
      } else {
        setRawDbSaveStatus('gagal');
        alert('Gagal: ' + data.message);
      }
    } catch (err: any) {
      setRawDbSaveStatus('gagal');
      alert('Error: ' + err.message);
    }
  };

  // Pull initial config from back-end server
  useEffect(() => {
    const fetchMysqlConfig = async () => {
      try {
        const res = await fetch('/api/db/mysql-config');
        const data = await res.json();
        if (data) {
          setMysqlHost(data.host || '');
          setMysqlPort(String(data.port || '3306'));
          setMysqlUser(data.user || '');
          setMysqlPassword(data.password || '');
          setMysqlDatabase(data.database || '');
          setMysqlActive(!!data.active);
        }
      } catch (err) {
        console.error('Failed to load MySQL config from server:', err);
      }
    };
    fetchMysqlConfig();
  }, [activeSubTab]);

  useEffect(() => {
    setFormData({ ...appSettings });
  }, [appSettings]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings(formData);
    setIsSaved(true);
    setTimeout(() => {
      setIsSaved(false);
    }, 2500);
  };

  const handleResetWipeButton = () => {
    if (confirm('PERINGATAN: Tindakan ini akan mengembalikan seluruh database ke bawaan asli. Seluruh voucher, pelanggan, reseller, tagihan, dan teknisi akan terhapus. Apakah Anda benar-benar yakin?')) {
      onResetDatabase();
    }
  };

  const handleTestMySQL = async () => {
    setIsTesting(true);
    setTestResult(null);
    try {
      const res = await fetch('/api/db/mysql-test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          host: mysqlHost,
          port: parseInt(mysqlPort) || 3306,
          user: mysqlUser,
          password: mysqlPassword,
          database: mysqlDatabase,
          active: mysqlActive
        })
      });
      const data = await res.json();
      setTestResult({
        success: data.success,
        message: data.message
      });
    } catch (err: any) {
      setTestResult({
        success: false,
        message: `Gagal melakukan koneksi ke server Express: ${err?.message || 'Error Jaringan'}`
      });
    } finally {
      setIsTesting(false);
    }
  };

  const handleTestGemini = async () => {
    if (!formData.geminiApiKey) {
      setGeminiTestResult({
        success: false,
        message: 'Google Gemini API Key wajib diisi untuk melakukan tes.'
      });
      return;
    }
    setIsTestingGemini(true);
    setGeminiTestResult(null);
    try {
      const res = await fetch('/api/ai/test-key', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ apiKey: formData.geminiApiKey })
      });
      const data = await res.json();
      setGeminiTestResult({
        success: data.success,
        message: data.message
      });
    } catch (err: any) {
      setGeminiTestResult({
        success: false,
        message: err.message || 'Gagal terhubung dengan server Express.'
      });
    } finally {
      setIsTestingGemini(false);
    }
  };

  const handleSaveMySQLConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingConfig(true);
    setSaveSuccessMessage('');
    try {
      const res = await fetch('/api/db/mysql-save-config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          host: mysqlHost,
          port: parseInt(mysqlPort) || 3306,
          user: mysqlUser,
          password: mysqlPassword,
          database: mysqlDatabase,
          active: mysqlActive
        })
      });
      const data = await res.json();
      if (data.success) {
        setSaveSuccessMessage('Konfigurasi akses MySQL berhasil disimpan dan diterapkan ke sistem!');
        setTimeout(() => setSaveSuccessMessage(''), 4500);
        if (onSyncNow) {
          // Sync immediate state
          onSyncNow();
        }
      }
    } catch (err: any) {
      alert('Gagal menerapkan pengaturan MySQL: ' + err.message);
    } finally {
      setIsSavingConfig(false);
    }
  };

  return (
    <div id="pengaturan-tab" className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Menu Pengaturan Sistem</h2>
          <p className="text-xs text-slate-500">
            Ubah konfigurasi dasar nama penyedia wifi RT RW Net, template auto-respon billing, ekspor database, dan sinkronisasi MySQL.
          </p>
        </div>
        
        {/* Real-time server connection stats badge */}
        <div className="flex items-center gap-2 bg-white px-3.5 py-1.5 rounded-2xl border border-slate-200 shadow-2xs self-start">
          <span className="relative flex h-2 w-2">
            <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${mysqlStatus === 'connected' ? 'bg-emerald-400' : 'bg-slate-400'}`}></span>
            <span className={`relative inline-flex rounded-full h-2 w-2 ${mysqlStatus === 'connected' ? 'bg-emerald-500' : 'bg-slate-500'}`}></span>
          </span>
          <span className="text-[11px] font-extrabold text-slate-700">
            MySQL Cloud Status: {mysqlStatus === 'connected' ? (
              <span className="text-emerald-600">Terhubung (REALTIME)</span>
            ) : (
              <span className="text-slate-500">Mode Lokal Offline (.JSON)</span>
            )}
          </span>
        </div>
      </div>

      {/* Settings Navigation */}
      <div className="flex flex-wrap border-b border-slate-200">
        <button
          onClick={() => setActiveSubTab('profil_billing')}
          className={`px-4 py-2.5 font-bold text-xs border-b-2 transition flex items-center gap-2 cursor-pointer ${
            activeSubTab === 'profil_billing' 
              ? 'border-indigo-600 text-indigo-600' 
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Briefcase size={14} /> Profil & Info Rekening
        </button>
        <button
          onClick={() => setActiveSubTab('whatsapp_template')}
          className={`px-4 py-2.5 font-bold text-xs border-b-2 transition flex items-center gap-2 cursor-pointer ${
            activeSubTab === 'whatsapp_template' 
              ? 'border-indigo-600 text-indigo-600' 
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <MessageSquare size={14} /> Template Pesan WhatsApp
        </button>
        <button
          onClick={() => setActiveSubTab('system_db')}
          className={`px-4 py-2.5 font-bold text-xs border-b-2 transition flex items-center gap-2 cursor-pointer ${
            activeSubTab === 'system_db' 
              ? 'border-indigo-600 text-indigo-600' 
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Database size={14} /> Pemeliharaan Lokal & Impor JSON
        </button>
        <button
          onClick={() => setActiveSubTab('mysql_config')}
          className={`px-4 py-2.5 font-bold text-xs border-b-2 transition flex items-center gap-2 cursor-pointer ${
            activeSubTab === 'mysql_config' 
              ? 'border-rose-500 text-rose-500 border-rose-500' 
              : 'border-transparent text-rose-600 hover:text-rose-800'
          }`}
        >
          <Server size={14} /> Koneksi Database MySQL
        </button>
        <button
          onClick={() => {
            setActiveSubTab('gemini_api');
            setGeminiTestResult(null);
          }}
          className={`px-4 py-2.5 font-bold text-xs border-b-2 transition flex items-center gap-2 cursor-pointer ${
            activeSubTab === 'gemini_api' 
              ? 'border-indigo-600 text-indigo-600' 
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Sparkles size={14} className="text-violet-500" /> Integrasi Gemini API Key
        </button>
      </div>

      {isSaved && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs p-3 rounded-xl flex items-center gap-2">
          <CheckCircle size={15} />
          <span>Pengaturan dasar RT RW Net berhasil disimpan dengan aman!</span>
        </div>
      )}

      {saveSuccessMessage && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs p-3.5 rounded-xl flex items-center gap-2 animate-fadeIn shadow-xs font-semibold">
          <CheckCircle size={16} className="text-emerald-600 shrink-0" />
          <span>{saveSuccessMessage}</span>
        </div>
      )}

      {/* Sub Tab Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Form panel */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs">
          
          <form onSubmit={activeSubTab === 'mysql_config' ? handleSaveMySQLConfig : handleSubmit} className="space-y-5 text-xs font-semibold text-slate-700">
            
            {activeSubTab === 'profil_billing' && (
              <div className="space-y-4">
                <div className="flex items-center gap-2 border-b border-slate-100 pb-2 mb-3">
                  <Briefcase size={16} className="text-indigo-600" />
                  <h3 className="font-extrabold text-slate-800 text-xs">Identitas & Kebijakan Billing</h3>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label>Nama Penyedia Layanan (Brand WiFi) *</label>
                    <input
                      type="text"
                      className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-bold"
                      value={formData.billingNamaPenyedia}
                      onChange={(e) => setFormData({ ...formData, billingNamaPenyedia: e.target.value })}
                      required
                    />
                    <p className="text-[10px] text-slate-400 font-normal">Contoh: NET-KITA Mandiri, Jaya WiFi, IndoNet.</p>
                  </div>

                  <div className="space-y-1">
                    <label>Nama Penanggung Jawab (Owner) *</label>
                    <input
                      type="text"
                      className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-bold"
                      value={formData.pjNama}
                      required
                      onChange={(e) => setFormData({ ...formData, pjNama: e.target.value })}
                    />
                    <p className="text-[10px] text-slate-400 font-normal">Nama Anda sebagai penanggung jawab tagihan.</p>
                  </div>
                </div>

                <div className="space-y-1">
                  <label>Tanggal Default Jatuh Tempo Bulanan *</label>
                  <input
                    type="number"
                    min="1"
                    max="28"
                    className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-bold"
                    value={formData.dueDayDefault}
                    required
                    onChange={(e) => setFormData({ ...formData, dueDayDefault: parseInt(e.target.value) || 10 })}
                  />
                  <p className="text-[10px] text-slate-400 font-normal">Hari/Tanggal default iuran bulanan jatuh tempo dlm satu bulan (rekomendasi: 5, 10, atau 15).</p>
                </div>

                <div className="flex items-center gap-2 border-b border-slate-100 pb-2 pt-2 mb-2">
                  <CreditCard size={16} className="text-indigo-600" />
                  <h3 className="font-extrabold text-slate-800 text-xs">Informasi Rekening Pembayaran</h3>
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-1">
                    <label>Nama Bank Pembayaran *</label>
                    <input
                      type="text"
                      className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-bold"
                      value={formData.bankNama}
                      required
                      onChange={(e) => setFormData({ ...formData, bankNama: e.target.value })}
                    />
                    <p className="text-[10px] text-slate-400 font-normal">Ex. Bank BCA, Bank Mandiri, BRI.</p>
                  </div>

                  <div className="space-y-1">
                    <label>Nomor Rekening Penerima *</label>
                    <input
                      type="text"
                      className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-bold font-mono"
                      value={formData.bankNomorRekening}
                      required
                      onChange={(e) => setFormData({ ...formData, bankNomorRekening: e.target.value })}
                    />
                    <p className="text-[10px] text-slate-400 font-normal">Nomor rekening transfer pembayaran.</p>
                  </div>

                  <div className="space-y-1">
                    <label>Atas Nama Rekening (A/N) *</label>
                    <input
                      type="text"
                      className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-bold"
                      value={formData.bankAtasNama}
                      required
                      onChange={(e) => setFormData({ ...formData, bankAtasNama: e.target.value })}
                    />
                    <p className="text-[10px] text-slate-400 font-normal">Nama lengkap pemegang rekening bank.</p>
                  </div>
                </div>

                {/* PILIHAN MENU CEPAT HALAMAN UTAMA */}
                <div className="flex items-center gap-2 border-b border-slate-100 pb-2 pt-4 mb-2">
                  <LayoutGrid size={16} className="text-indigo-600" />
                  <h3 className="font-extrabold text-slate-800 text-xs">Menu Pintasan Halaman Utama (Dashboard)</h3>
                </div>
                <p className="text-[10px] text-slate-400 font-normal mb-3">Pilih menu/fitur sistem yang ingin ditampilkan sebagai tombol pintasan langsung di dashboard halaman utama Anda.</p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-72 overflow-y-auto pr-1 bg-slate-50 p-4 rounded-2xl border border-slate-200">
                  {AVAILABLE_QUICK_MENUS.map((m) => {
                    const isChecked = (formData.showQuickMenus || []).includes(m.id);
                    const IconComponent = m.icon;
                    return (
                      <div 
                        key={m.id} 
                        onClick={() => {
                          const currentList = formData.showQuickMenus || [];
                          let newList;
                          if (currentList.includes(m.id)) {
                            newList = currentList.filter(id => id !== m.id);
                          } else {
                            newList = [...currentList, m.id];
                          }
                          setFormData({ ...formData, showQuickMenus: newList });
                        }}
                        className={`flex items-start gap-3 p-3 rounded-xl border transition cursor-pointer select-none ${
                          isChecked 
                            ? 'bg-white border-indigo-500 shadow-xs ring-1 ring-indigo-500/10' 
                            : 'bg-white/80 hover:bg-white border-slate-200 opacity-60 hover:opacity-100'
                        }`}
                      >
                        <div className="flex items-center h-5 shrink-0">
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => {}} // fully controlled by outer parent onClick
                            className="h-4 w-4 rounded-sm border-slate-300 text-indigo-650 focus:ring-indigo-500 cursor-pointer"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5 font-bold text-slate-800 text-[11px]">
                            <div className={`p-1 rounded-md ${m.color} shrink-0`}>
                              <IconComponent size={12} />
                            </div>
                            <span className="truncate">{m.label}</span>
                          </div>
                          <p className="text-[9px] text-slate-400 font-normal mt-1 leading-snug">
                            {m.desc}
                          </p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {activeSubTab === 'whatsapp_template' && (
              <div className="space-y-4">
                <div className="flex items-center gap-2 border-b border-slate-100 pb-2 mb-3">
                  <MessageSquare size={16} className="text-indigo-600" />
                  <h3 className="font-extrabold text-slate-800 text-xs">Template Penagihan Otomatis</h3>
                </div>

                <div className="space-y-1">
                  <label>Template WhatsApp Penagihan Tagihan (Belum Bayar) *</label>
                  <textarea
                    rows={6}
                    className="w-full bg-slate-50 p-3 rounded-lg border border-slate-200 focus:outline-hidden font-mono text-xs text-slate-800 leading-normal"
                    value={formData.waTemplateTagihanDefault}
                    required
                    onChange={(e) => setFormData({ ...formData, waTemplateTagihanDefault: e.target.value })}
                  />
                  <div className="p-3 bg-indigo-50 border border-indigo-100 rounded-xl leading-normal text-[10px] text-slate-600 font-normal">
                    <span className="font-bold text-indigo-700">Tag Variabel yang didukung:</span> 
                    <p className="mt-1 font-mono text-[9px] bg-white border border-indigo-100 p-2 rounded-md">
                      [Nama] : Nama Pelanggan • [NamaLayanan] : Nama Paket • [Alamat] : Alamat • [Bulan] : Bulan Invoice • [Tarif] : Jumlah Rupiah • [JatuhTempo] : Tgl Jatuh Tempo • [NamaBank] : Nama Bank • [NoRek] : No Rekening • [AtasNama] : Pemegang Bank • [NamaPenyedia] : Nama Penyedia RT RW Net
                    </p>
                  </div>
                </div>

                <div className="space-y-1">
                  <label>Template WhatsApp Invoice Lunas (Kas Bukti Bayar) *</label>
                  <textarea
                    rows={6}
                    className="w-full bg-slate-50 p-3 rounded-lg border border-slate-200 focus:outline-hidden font-mono text-xs text-slate-800 leading-normal"
                    value={formData.waTemplateLunasDefault}
                    required
                    onChange={(e) => setFormData({ ...formData, waTemplateLunasDefault: e.target.value })}
                  />
                  <div className="p-3 bg-indigo-50 border border-indigo-100 rounded-xl leading-normal text-[10px] text-slate-600 font-normal">
                    <span className="font-bold text-indigo-700">Tag tambahan untuk Template Lunas:</span>
                    <p className="mt-1 font-mono text-[9px] bg-white border border-indigo-100 p-2 rounded-md">
                      [TanggalBayar] : Tanggal Bayar Terdaftar • [MetodeBayar] : Kasir / Midtrans / Manual
                    </p>
                  </div>
                </div>
              </div>
            )}

            {activeSubTab === 'system_db' && (
              <div className="space-y-5">
                <div className="flex items-center gap-2 border-b border-slate-100 pb-2 mb-3">
                  <Database size={16} className="text-indigo-600" />
                  <h3 className="font-extrabold text-slate-800 text-xs">Pemeliharaan & Cadangan Database Lokal (.JSON)</h3>
                </div>

                <div className="bg-amber-50 p-4 border border-amber-200 rounded-xl shadow-xs text-[11px] font-normal leading-normal text-amber-900 flex items-start gap-2.5">
                  <Shield size={16} className="text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">Penyimpanan Cadangan File:</span>
                    <p className="mt-0.5">Jika Anda tidak mengaktifkan MySQL, data tetap secara realtime tersimpan aman di browser Anda menggunakan local storage dan dicadangkan ke server server-side JSON.</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-bold text-center">
                  {/* Backup Card */}
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col justify-between hover:border-indigo-200 transition">
                    <div className="mb-4">
                      <Download size={24} className="mx-auto text-indigo-600 mb-2" />
                      <h4 className="text-slate-800 text-xs">Unduh Cadangan</h4>
                      <p className="text-[10px] text-slate-400 font-normal mt-1 leading-relaxed">Ekspor seluruh data sistem menjadi berkas file format JSON yang aman.</p>
                    </div>
                    <button
                      type="button"
                      onClick={onExportDatabase}
                      className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-1"
                    >
                      <Download size={12} /> Unduh (.JSON)
                    </button>
                  </div>

                  {/* Restore Card */}
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col justify-between hover:border-indigo-200 transition">
                    <div className="mb-4">
                      <Upload size={24} className="mx-auto text-emerald-600 mb-2" />
                      <h4 className="text-slate-800 text-xs">Pulihkan Database</h4>
                      <p className="text-[10px] text-slate-400 font-normal mt-1 leading-relaxed">Unggah file backup .JSON untuk memulihkan seluruh data Anda seketika.</p>
                    </div>
                    <label className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-100 rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-1 border border-slate-200">
                      <Upload size={12} /> Jalankan Impor
                      <input type="file" accept=".json" onChange={onImportDatabase} className="hidden" />
                    </label>
                  </div>

                  {/* Reset/Wipe Database Card */}
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col justify-between hover:border-rose-200 transition">
                    <div className="mb-4">
                      <Trash2 size={24} className="mx-auto text-rose-500 mb-2" />
                      <h4 className="text-slate-800 text-xs">Hapus Total Data</h4>
                      <p className="text-[10px] text-slate-400 font-normal mt-1 leading-relaxed">Wipe database kosong dan muat ulang seting bawaan pabrik (Default).</p>
                    </div>
                    <button
                      type="button"
                      onClick={handleResetWipeButton}
                      className="w-full py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs transition cursor-pointer flex items-center justify-center gap-1"
                    >
                      <Trash2 size={12} /> Hapus & Reset
                    </button>
                  </div>
                </div>

                {/* Live Server File Editor Section */}
                <div className="pt-5 border-t border-slate-150 space-y-3.5">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-extrabold text-slate-800 text-xs flex items-center gap-1.5">
                        📝 Editor File Database Lokal (Edit Raw JSON)
                      </h4>
                      <p className="text-[10px] text-slate-400 font-normal">
                        Edit data mentah berkas <code className="bg-slate-100 font-mono px-1">database_fallback.json</code> di root hosting secara manual.
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={fetchRawDbJson}
                      className="px-2.5 py-1 text-[10px] font-bold text-slate-650 bg-slate-100 hover:bg-slate-200 rounded-md transition cursor-pointer"
                    >
                      Segarkan Raw JSON
                    </button>
                  </div>

                  {isRawDbLoading ? (
                    <div className="text-center py-6 text-slate-400 italic text-xs">
                      Mengunduh berkas database dari server hosting...
                    </div>
                  ) : (
                    <div className="space-y-2">
                      <textarea
                        rows={10}
                        className="w-full bg-slate-900 text-teal-400 p-3.5 rounded-xl border border-slate-800 font-mono text-[10px] focus:outline-hidden leading-relaxed focus:ring-1 focus:ring-teal-500/30"
                        value={rawDbJson}
                        onChange={(e) => setRawDbJson(e.target.value)}
                        placeholder='{ "pelanggan": [], "paket": [] }'
                      />
                      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 bg-slate-50 p-3 rounded-xl border border-slate-200">
                        <span className="text-[9.5px] text-amber-600 font-semibold max-w-md">
                          ⚠️ Peringatan: Tulis format JSON yang valid. Menyimpan akan me-refresh aplikasi agar data termuat baru.
                        </span>
                        <button
                          type="button"
                          onClick={handleSaveRawDbJson}
                          className="w-full sm:w-auto px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-lg text-[10.5px] shadow-xs transition flex items-center justify-center gap-1.5 cursor-pointer hover:shadow-md"
                        >
                          <Save size={12} /> Simpan File ke Server Hosting
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeSubTab === 'mysql_config' && (
              <div className="space-y-4">
                <div className="flex items-center gap-2 border-b border-rose-100 pb-2 mb-3">
                  <Server size={16} className="text-rose-500" />
                  <h3 className="font-extrabold text-slate-800 text-xs">Hubungkan Database MySQL Cloud (Penyimpanan Utama)</h3>
                </div>

                <div className="bg-rose-50 border border-rose-150 p-4 rounded-xl leading-normal text-[11px] text-rose-950 font-normal flex items-start gap-2.5">
                  <Shield size={16} className="text-rose-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold">Keamanan Connection String:</span>
                    <p className="mt-0.5">Sistem ini memfasilitasi integrasi MySQL langsung. Ketika aktif, database lokal Anda akan disinkronisasikan ke tabel relasional MySQL secara berkala. Ideal untuk multi-device, backup otomatis, dan reliabilitas tinggi.</p>
                  </div>
                </div>

                {/* Form fields */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label>Host / IP Server MySQL *</label>
                    <input
                      type="text"
                      className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-bold"
                      value={mysqlHost}
                      onChange={(e) => setMysqlHost(e.target.value)}
                      placeholder="localhost atau IP database"
                      required
                    />
                  </div>
                  <div className="space-y-1">
                    <label>Username MySQL *</label>
                    <input
                      type="text"
                      className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-bold"
                      value={mysqlUser}
                      onChange={(e) => setMysqlUser(e.target.value)}
                      placeholder="root"
                      required
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label>Password Server MySQL *</label>
                    <input
                      type="password"
                      className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-mono"
                      value={mysqlPassword}
                      onChange={(e) => setMysqlPassword(e.target.value)}
                      placeholder="••••••••••••"
                    />
                  </div>
                  <div className="space-y-1">
                    <label>Nama Database MySQL *</label>
                    <input
                      type="text"
                      className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-bold"
                      value={mysqlDatabase}
                      onChange={(e) => setMysqlDatabase(e.target.value)}
                      placeholder="billing_rtrwnet"
                      required
                    />
                  </div>
                </div>

                <div className="p-3 bg-slate-50/70 border border-slate-150 rounded-xl flex items-center justify-between">
                  <div className="space-y-0.5">
                    <span className="font-bold text-slate-800 text-xs">Aktifkan Penyimpanan MySQL</span>
                    <p className="text-[10px] text-slate-400 font-normal">Alihkan seluruh penulisan & pembacaan data langsung ke MySQL.</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer select-none">
                    <input
                      type="checkbox"
                      className="sr-only peer"
                      checked={mysqlActive}
                      onChange={(e) => setMysqlActive(e.target.checked)}
                    />
                    <div className="w-10 h-6 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-350 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-rose-500"></div>
                  </label>
                </div>

                {/* DB Test results inside tabs */}
                {testResult && (
                  <div className={`p-4 rounded-xl border leading-normal animate-fadeIn text-[11px] flex gap-2.5 ${testResult.success ? 'bg-emerald-50 border-emerald-200 text-emerald-950' : 'bg-rose-50 border-rose-200 text-rose-950'}`}>
                    {testResult.success ? (
                      <>
                        <CheckCircle size={16} className="text-emerald-600 shrink-0 mt-0.5" />
                        <div>
                          <strong className="font-bold">Sukses Berhasil!</strong>
                          <p className="mt-0.5 font-normal">{testResult.message}</p>
                        </div>
                      </>
                    ) : (
                      <>
                        <AlertCircle size={16} className="text-rose-600 shrink-0 mt-0.5" />
                        <div>
                          <strong className="font-bold">Koneksi Gagal:</strong>
                          <p className="mt-0.5 font-normal">{testResult.message}</p>
                        </div>
                      </>
                    )}
                  </div>
                )}

                {/* Operations Action Bar */}
                <div className="pt-3 border-t border-slate-150 flex flex-wrap gap-3 justify-between items-center">
                  <button
                    type="button"
                    onClick={handleTestMySQL}
                    disabled={isTesting}
                    className="px-4 py-2 bg-slate-800 text-white rounded-xl font-bold flex items-center gap-1.5 transition disabled:opacity-50 hover:bg-slate-700 cursor-pointer"
                  >
                    {isTesting ? (
                      <RefreshCw size={13} className="animate-spin text-white" />
                    ) : (
                      <Server size={13} />
                    )}
                    <span>{isTesting ? 'Menguji Koneksi...' : 'Tes Koneksi & Migrasi Tabel'}</span>
                  </button>

                  <div className="flex gap-2">
                    {mysqlStatus === 'connected' && onSyncNow && (
                      <button
                        type="button"
                        onClick={onSyncNow}
                        disabled={isSyncing}
                        className="px-4 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl font-bold transition flex items-center gap-1 cursor-pointer"
                      >
                        {isSyncing ? (
                          <RefreshCw size={13} className="animate-spin" />
                        ) : (
                          <RefreshCw size={13} />
                        )}
                        <span>{isSyncing ? 'Sinkron Gagal...' : 'Sinkronkan Sekarang'}</span>
                      </button>
                    )}

                    <button
                      type="submit"
                      disabled={isSavingConfig}
                      className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold transition flex items-center gap-1.5 cursor-pointer hover:shadow-xs disabled:opacity-50"
                    >
                      {isSavingConfig ? (
                        <RefreshCw size={13} className="animate-spin text-white" />
                      ) : (
                        <Save size={13} />
                      )}
                      <span>Terapkan & Simpan</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {activeSubTab === 'gemini_api' && (
              <div className="space-y-5">
                <div className="flex items-center gap-2 border-b border-indigo-100 pb-2 mb-3">
                  <Sparkles size={16} className="text-violet-500" />
                  <h3 className="font-extrabold text-slate-800 text-xs text-indigo-950 uppercase tracking-widest font-mono">Integrasi Google Gemini AI</h3>
                </div>

                <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl leading-normal text-[11px] text-slate-200 font-normal flex items-start gap-2.5 shadow-sm">
                  <Cpu size={16} className="text-violet-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-violet-300">AI-Powered Co-Pilot (Gemini 3.5 Flash)</span>
                    <p className="mt-1 text-slate-350 leading-relaxed">
                      Dengan memasukkan Google Gemini API Key, Anda mengaktifkan kecerdasan buatan terintegrasi untuk membantu analisis paket hotspot router MikroTik, memberikan rekomendasi harga voucher, otomatisasi deskripsi gangguan, hingga penyusunan konten template penagihan tagihan pelanggan yang persuasif.
                    </p>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <label htmlFor="geminiApiKeyInput" className="block text-slate-700 font-extrabold text-xs flex items-center gap-1.5">
                    <Key size={13} className="text-slate-450" />
                    Google Gemini API Key
                  </label>
                  <p className="text-[10px] text-slate-400 font-normal leading-relaxed">API Key disimpan secara aman di database server Anda dan tidak pernah diekspos ke pihak luar.</p>
                  
                  <div className="relative mt-1">
                    <input
                      id="geminiApiKeyInput"
                      type={showGeminiKey ? "text" : "password"}
                      value={formData.geminiApiKey || ''}
                      onChange={(e) => setFormData({ ...formData, geminiApiKey: e.target.value })}
                      placeholder="Masukkan API Key Anda (misal: AIzaSy...)"
                      className="w-full pl-3 pr-10 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:border-indigo-500 focus:bg-white text-xs font-mono font-medium outline-none transition"
                    />
                    <button
                      type="button"
                      onClick={() => setShowGeminiKey(!showGeminiKey)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 cursor-pointer"
                    >
                      {showGeminiKey ? <EyeOff size={16} /> : <Eye size={16} />}
                    </button>
                  </div>
                </div>

                {geminiTestResult && (
                  <div className={`p-4 rounded-xl text-xs flex items-start gap-2.5 animate-fadeIn ${
                    geminiTestResult.success 
                      ? 'bg-emerald-50 border border-emerald-100 text-emerald-950 font-normal shadow-xs' 
                      : 'bg-rose-50 border border-rose-100 text-rose-950 font-normal shadow-xs'
                  }`}>
                    {geminiTestResult.success ? (
                      <CheckCircle size={16} className="text-emerald-600 shrink-0 mt-0.5" />
                    ) : (
                      <AlertCircle size={16} className="text-rose-600 shrink-0 mt-0.5" />
                    )}
                    <div>
                      <p className="font-bold">{geminiTestResult.success ? 'Koneksi Berhasil!' : 'Validasi Gagal'}</p>
                      <p className="mt-1 leading-relaxed opacity-90">{geminiTestResult.message}</p>
                    </div>
                  </div>
                )}

                <div className="pt-2">
                  <button
                    type="button"
                    onClick={handleTestGemini}
                    disabled={isTestingGemini}
                    className="px-4 py-2 bg-slate-800 text-white hover:bg-slate-750 font-bold rounded-xl flex items-center gap-1.5 transition disabled:opacity-50 cursor-pointer"
                  >
                    {isTestingGemini ? (
                      <RefreshCw size={13} className="animate-spin text-white" />
                    ) : (
                      <Cpu size={13} className="text-violet-400" />
                    )}
                    <span>{isTestingGemini ? 'Sedang Memvalidasi...' : 'Tes Validasi API Key'}</span>
                  </button>
                </div>
              </div>
            )}

            {false && (
              <div className="space-y-5 animate-fadeIn">
                <div className="flex items-center gap-2 border-b border-emerald-100 pb-2 mb-3">
                  <Database size={16} className="text-emerald-600" />
                  <h3 className="font-extrabold text-slate-800 text-xs text-emerald-950 uppercase tracking-widest font-mono">Migrasi Hosting Mandiri: PHP & MySQL (Tanpa Node.js)</h3>
                </div>

                <div className="bg-emerald-50 border border-emerald-150 p-4 rounded-xl leading-normal text-[11px] text-emerald-950 font-normal shadow-3xs">
                  <span className="font-extrabold text-emerald-900 flex items-center gap-1.5 mb-1 text-xs">
                    🚀 Server Bebas Node.js (PHP 7.4 - 8.x + MySQL / MariaDB)
                  </span>
                  <p className="leading-relaxed">
                    Aplikasi ini dirancang sebagai <strong>React Single Page App (SPA)</strong> yang digerakkan oleh <strong>Vite</strong>. Karena React berjalan sepenuhnya di dalam browser pelanggan Anda, Anda <strong>TIDAK memerlukan Node.js</strong> sama sekali pada server produksi hosting Anda! Hosting Anda hanya bertugas menyajikan berkas HTML/CSS statis, dan menerima query database dinamis lewat API berformat <strong>PHP & MySQL</strong> asli yang telah kami persiapkan di folder <code className="bg-white/80 font-mono px-1 rounded border border-emerald-200">/api/</code>.
                  </p>
                </div>

                {/* THE FOUR STEPS MAP */}
                <div className="space-y-4 pt-1">
                  
                  {/* STEP 1 */}
                  <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl space-y-2">
                    <p className="font-extrabold text-indigo-755 text-xs text-slate-800 flex items-center gap-1.5">
                      <span className="bg-indigo-600 text-white leading-none p-1 text-[9.5px] rounded-md font-mono font-black">Langkah 1</span>
                      Dapatkan File Build Statis React
                    </p>
                    <p className="text-[10px] text-slate-500 font-normal leading-relaxed">
                      Ekspor berkas zip repositori ini (melalui tombol <strong>Settings / Export ZIP</strong> di kanan atas) ke komputer lokal, lalu di vscode/terminal komputer Anda jalankan perintah: 
                      <code className="bg-slate-200 font-mono text-[9px] mx-1 px-1 rounded block mt-1.5 py-1 text-slate-700">npm run build</code>
                      Ini akan melahirkan direktori baru di komputer bernama <strong className="text-slate-800">/dist</strong> yang berisikan <code className="font-mono text-[9.5px]">index.html</code> dan folder <code className="font-mono text-[9.5px]">/assets/</code> super ringan. Berkas-berkas statis inilah yang akan diunggah ke folder <strong className="text-slate-800">public_html/</strong> hosting Anda.
                    </p>
                  </div>

                  {/* STEP 2 */}
                  <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl space-y-2">
                    <p className="font-extrabold text-slate-855 text-xs text-slate-800 flex items-center gap-1.5">
                      <span className="bg-indigo-600 text-white leading-none p-1 text-[9.5px] rounded-md font-mono font-black">Langkah 2</span>
                      Impor Skema SQL ke phpMyAdmin
                    </p>
                    <p className="text-[10px] text-slate-500 font-normal leading-relaxed">
                      Buat database MySQL baru di cPanel / Plesk shared hosting Anda. Buka <strong>phpMyAdmin</strong>, pilih nama database Anda, lalu masuk ke tab <strong>SQL</strong>. Copy & paste script struktur tabel di bawah ini lalu tekan tombol <strong>Kirim / Go</strong>.
                    </p>
                    
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="text-[9px] font-bold text-slate-450 font-mono">FILE: /api/database.sql</span>
                        <button
                          type="button"
                          onClick={() => {
                            const sqlContent = `-- STRUKTUR DATABASES\n` + 
                              `CREATE TABLE IF NOT EXISTS tbl_pelanggan (\n` +
                              `  id varchar(100) PRIMARY KEY,\n` +
                              `  nama varchar(255) NOT NULL,\n` +
                              `  alamat varchar(255),\n` +
                              `  noHp varchar(50),\n` +
                              `  paketId varchar(100),\n` +
                              `  tarif int DEFAULT 0,\n` +
                              `  statusAktif tinyint DEFAULT 1,\n` +
                              `  koordinat varchar(100),\n` +
                              `  dueDay int DEFAULT 10,\n` +
                              `  tanggalPasang varchar(50)\n` +
                              `);`; // condensed or simple snippet
                            navigator.clipboard.writeText(sqlContent);
                            alert('Struktur contoh SQL minimal di-copy! Berkas SQL lengkap Anda dapat diambil langsung dari direktori /api/database.sql setelah mengunduh file ZIP project.');
                          }}
                          className="px-2 py-0.5 bg-slate-200 hover:bg-slate-300 text-[9px] cursor-pointer rounded text-slate-650 font-extrabold transition"
                        >
                          Salin Snippet SQL
                        </button>
                      </div>
                      <textarea
                        readOnly
                        rows={5}
                        className="w-full bg-slate-900 border border-slate-800 p-2.5 rounded-lg text-[9px] font-mono text-emerald-400 focus:outline-hidden"
                        value={`-- UNDUH LENGKAP DI /api/database.sql SETELAH EKSPOR ZIP
CREATE TABLE IF NOT EXISTS tbl_pelanggan (
  id VARCHAR(100) PRIMARY KEY,
  nama VARCHAR(255) NOT NULL,
  alamat VARCHAR(255),
  noHp VARCHAR(50),
  paketId VARCHAR(100),
  tarif INT DEFAULT 0,
  statusAktif TINYINT DEFAULT 1,
  koordinat VARCHAR(100),
  dueDay INT DEFAULT 10,
  tanggalPasang VARCHAR(50)
);

CREATE TABLE IF NOT EXISTS tbl_paket (
  id VARCHAR(100) PRIMARY KEY,
  nama VARCHAR(255) NOT NULL,
  kecepatan VARCHAR(50),
  harga INT DEFAULT 0,
  tipe VARCHAR(50),
  deskripsi VARCHAR(255)
);

CREATE TABLE IF NOT EXISTS tbl_tagihan (
  id VARCHAR(100) PRIMARY KEY,
  nominal INT DEFAULT 0,
  bulan VARCHAR(20),
  status VARCHAR(50) DEFAULT 'BELUM_BAYAR'
);`}
                      />
                    </div>
                  </div>

                  {/* STEP 3 */}
                  <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl space-y-2">
                    <p className="font-extrabold text-slate-855 text-xs text-slate-800 flex items-center gap-1.5">
                      <span className="bg-indigo-600 text-white leading-none p-1 text-[9.5px] rounded-md font-mono font-black">Langkah 3</span>
                      Unggah File Hosting & Edit config.php
                    </p>
                    <p className="text-[10px] text-slate-500 font-normal leading-relaxed">
                      Simpan isi hasil folder build React <strong className="text-slate-800">/dist</strong> langsung ke dalam <strong className="text-slate-900">public_html/</strong> hosting Anda. Buat folder bernama <strong className="text-slate-800">api/</strong> di dalam <strong className="text-slate-900">public_html/</strong>, taruh berkas <code className="font-mono text-[9.5px]">config.php</code> dan <code className="font-mono text-[9.5px]">index.php</code> yang telah kami buat untuk Anda.
                    </p>
                    <p className="text-[10px] text-slate-500 font-normal leading-relaxed">
                      Silakan edit berkas <strong className="text-slate-800">api/config.php</strong> untuk mendaftarkan nama db_user, db_pass, dan db_nama sesuai akun database cPanel yang Anda buat pada Langkah 2.
                    </p>
                    
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="text-[9px] font-bold text-slate-450 font-mono">FILE: /api/config.php</span>
                        <button
                          type="button"
                          onClick={() => {
                            const configContent = `<?php\ndefine('DB_HOST', 'localhost');\ndefine('DB_USER', 'ganti_dengan_db_user');\ndefine('DB_PASS', 'ganti_dengan_db_pass');\ndefine('DB_NAME', 'ganti_dengan_db_nama');\n\nfunction getDbConnection() {\n    // Connect using PDO ...\n}`;
                            navigator.clipboard.writeText(configContent);
                            alert('Snippet config.php disalin! Berkas config.php lengkap sudah kami sisipkan di root direktori /api/config.php pada ekspor zip Anda.');
                          }}
                          className="px-2 py-0.5 bg-slate-200 hover:bg-slate-300 text-[9px] cursor-pointer rounded text-slate-650 font-extrabold transition"
                        >
                          Salin Snippet Config
                        </button>
                      </div>
                      <textarea
                        readOnly
                        rows={5}
                        className="w-full bg-slate-900 border border-slate-800 p-2.5 rounded-lg text-[9px] font-mono text-emerald-400 focus:outline-hidden"
                        value={`<?php // FILE /api/config.php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json; charset=UTF-8");

define('DB_HOST', 'localhost');  // Biasanya tetap localhost pada shared hosting
define('DB_USER', 'ganti_dengan_database_user');
define('DB_PASS', 'ganti_dengan_database_password');
define('DB_NAME', 'ganti_dengan_database_nama');`}
                      />
                    </div>
                  </div>

                  {/* STEP 4 */}
                  <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl space-y-2">
                    <p className="font-extrabold text-slate-855 text-xs text-slate-800 flex items-center gap-1.5">
                      <span className="bg-indigo-600 text-white leading-none p-1 text-[9.5px] rounded-md font-mono font-black">Langkah 4</span>
                      Atur Router Apache .htaccess
                    </p>
                    <p className="text-[10px] text-slate-500 font-normal leading-relaxed">
                      Agar reload browser tidak memicu error <strong>404 Not Found</strong> (ciri khas React Router virtual), dan agar request API secara otomatis diteruskan ke PHP controller, buat file bernama <strong className="text-slate-800">.htaccess</strong> di root folder <strong className="text-slate-900">public_html/</strong> Anda.
                    </p>
                    
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between">
                        <span className="text-[9px] font-bold text-slate-450 font-mono">FILE: /.htaccess</span>
                        <button
                          type="button"
                          onClick={() => {
                            const htContent = `RewriteEngine On\nRewriteBase /\nRewriteCond %{REQUEST_URI} ^/api/(.*)$\nRewriteRule ^api/(.*)$ api/index.php?endpoint=$1 [QSA,L]\nRewriteCond %{REQUEST_FILENAME} !-f\nRewriteCond %{REQUEST_FILENAME} !-d\nRewriteRule . /index.html [L]`;
                            navigator.clipboard.writeText(htContent);
                            alert('Rules .htaccess berhasil disalin dengan sukses!');
                          }}
                          className="px-2 py-0.5 bg-slate-200 hover:bg-slate-300 text-[9px] cursor-pointer rounded text-slate-650 font-extrabold transition"
                        >
                          Salin .htaccess
                        </button>
                      </div>
                      <textarea
                        readOnly
                        rows={6}
                        className="w-full bg-slate-900 border border-slate-800 p-2.5 rounded-lg text-[9px] font-mono text-emerald-400 focus:outline-hidden"
                        value={`RewriteEngine On
RewriteBase /

# 1. Alihkan seluruh API Call ke Controller PHP
RewriteCond %{REQUEST_URI} ^/api/(.*)$ [NC]
RewriteRule ^api/(.*)$ api/index.php?endpoint=$1 [QSA,L]

# 2. Tangani Routing SPA React agar reload tidak 404
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule . /index.html [L]`}
                      />
                    </div>
                  </div>

                </div>
              </div>
            )}

            {/* Footer control */}
            {activeSubTab !== 'system_db' && activeSubTab !== 'mysql_config' && (
              <div className="pt-3 border-t border-slate-100 flex justify-end">
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition flex items-center gap-1.5 cursor-pointer hover:shadow-xs"
                >
                  <Save size={14} /> Simpan Pengaturan
                </button>
              </div>
            )}

          </form>

        </div>

        {/* Info panel */}
        <div className="bg-indigo-50/50 p-5 rounded-2xl border border-indigo-100 flex flex-col justify-between text-xs text-indigo-950 font-sans leading-relaxed">
          <div className="space-y-4">
            <h4 className="font-bold flex items-center gap-1 text-sm text-indigo-900 border-b border-indigo-100 pb-2">
              <Settings size={16} /> Bantuan Konfigurasi
            </h4>
            <p className="text-slate-650">
              Pengaturan ini berlaku secara global pada sistem router billing RT RW Net Anda. Nama penyedia layanan akan muncul di bagian kop header cetak nota, invoice cetak PDF, lapor bayar, dan salam pembuka di pesan-pesan autoreply.
            </p>
            <div className="p-3 bg-white rounded-lg border border-indigo-100 space-y-1">
              <p className="font-bold text-indigo-800 text-[10px]">🏢 Info Aktif Saat Ini:</p>
              <div className="font-mono text-[9px] text-slate-500 leading-normal space-y-1">
                <p><strong>Brand:</strong> {appSettings.billingNamaPenyedia}</p>
                <p><strong>Owner:</strong> {appSettings.pjNama}</p>
                <p><strong>Rekening:</strong> {appSettings.bankNama} - {appSettings.bankNomorRekening}</p>
                <p><strong>Atas nama:</strong> {appSettings.bankAtasNama}</p>
                <p className="border-t border-dashed border-slate-200 pt-1 mt-1 font-bold text-rose-800">🛢️ Database:</p>
                <p><strong>Server Driver:</strong> MySQL 8.X / MariaDB Compatible</p>
                <p><strong>Sistem Sinkronisasi:</strong> {mysqlStatus === 'connected' ? '🟢 AKTIF (Relational)' : '🔴 NONAKTIF (Lokal)'}</p>
              </div>
            </div>
          </div>

          <div className="bg-indigo-900 text-white p-3 rounded-xl mt-4 space-y-1 border border-indigo-700 select-none">
            <p className="font-bold text-[10px]">📊 Tip Pelayanan Prima:</p>
            <p className="text-[9px] leading-tight opacity-90 font-normal">
              Gunakan tanggal jatuh tempo yang wajar (misal, tanggal 10 setelah gajian) dan sesuaikan template tagihan agar terdengar ramah dan sopan demi kenyamanan pelanggan WiFi hotspot Anda.
            </p>
          </div>
        </div>

      </div>
    </div>
  );
}
