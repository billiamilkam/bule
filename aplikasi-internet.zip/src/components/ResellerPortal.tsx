import React, { useState } from 'react';
import { Reseller, Paket, HotspotVoucher, MikrotikServer, PortalActivityLog } from '../types';
import { formatRupiah } from '../utils';
import { 
  Store, LogOut, Wallet, Plus, Wifi, Layers, 
  Tag, Printer, Trash2, History, Search, ArrowUpRight, 
  ShieldCheck, AlertCircle, RefreshCw, Key, ClipboardList
} from 'lucide-react';

interface ResellerPortalProps {
  reseller: Reseller;
  paket: Paket[];
  vouchers: HotspotVoucher[];
  servers: MikrotikServer[];
  onLogout: () => void;
  onUpdateReseller: (updated: Reseller) => void;
  onAddVoucher: (v: Omit<HotspotVoucher, 'id'>) => void;
  onBulkGenerate: (payload: { count: number; paketId: string; harga: number; durasi: string; serverName: string; resellerId?: string; prefix?: string; credMode?: 'UP' | 'U_P' }) => void;
  portalLogs: PortalActivityLog[];
  onAddPortalLog: (log: Omit<PortalActivityLog, 'id' | 'timestamp'>) => void;
}

export default function ResellerPortal({
  reseller,
  paket,
  vouchers,
  servers,
  onLogout,
  onUpdateReseller,
  onAddVoucher,
  onBulkGenerate,
  portalLogs,
  onAddPortalLog
}: ResellerPortalProps) {
  const allowedMenus = reseller.allowedMenus || ['create_manual', 'create_bulk', 'topup_simulation', 'vouchers_history'];
  const hasHistory = allowedMenus.includes('vouchers_history');
  const hasManual = allowedMenus.includes('create_manual');
  const hasBulk = allowedMenus.includes('create_bulk');
  const hasTopUp = allowedMenus.includes('topup_simulation');

  // Filter allowed packages
  const myAllowedPakets = paket.filter(p => !reseller.allowedPaketIds || reseller.allowedPaketIds.length === 0 || reseller.allowedPaketIds.includes(p.id));

  // Filter allowed servers
  const myAllowedServers = servers.filter(s => !reseller.allowedServerIds || reseller.allowedServerIds.length === 0 || reseller.allowedServerIds.includes(s.id));

  const [activeTab, setActiveTab] = useState<'create' | 'vouchers' | 'logs'>(() => {
    if (!hasManual && !hasBulk && hasHistory) {
      return 'vouchers';
    }
    return 'create';
  });
  const [createMode, setCreateMode] = useState<'manual' | 'bulk'>(() => {
    if (!hasManual && hasBulk) {
      return 'bulk';
    }
    return 'manual';
  });
  const [searchQuery, setSearchQuery] = useState('');
  
  // Log portal filter states
  const [logTypeFilter, setLogTypeFilter] = useState<'ALL' | 'LOGIN' | 'CETAK_VOUCHER' | 'TOPUP'>('ALL');
  const [logSearch, setLogSearch] = useState('');

  // Top-Up State
  const [showTopUp, setShowTopUp] = useState(false);
  const [topUpAmount, setTopUpAmount] = useState(50000);
  const [topUpMethod, setTopUpMethod] = useState<'BANK' | 'E_WALLET'>('E_WALLET');

  // Manual Form State
  const [manualCode, setManualCode] = useState('');
  const [manualPassword, setManualPassword] = useState('');
  const [manualPaketId, setManualPaketId] = useState(myAllowedPakets[0]?.id || paket[0]?.id || '');
  const [manualServer, setManualServer] = useState(myAllowedServers[0]?.nama || servers[0]?.nama || 'Mikrotik Pusat Kamal');
  const [manualDurasi, setManualDurasi] = useState('1 Hari (FUP 2GB)');

  // Bulk Form State
  const [bulkCount, setBulkCount] = useState(5);
  const [bulkPaketId, setBulkPaketId] = useState(myAllowedPakets[0]?.id || paket[0]?.id || '');
  const [bulkServer, setBulkServer] = useState(myAllowedServers[0]?.nama || servers[0]?.nama || 'Mikrotik Pusat Kamal');
  const [bulkDurasi, setBulkDurasi] = useState('1 Hari (FUP 2GB)');

  // Price Calculation Helpers
  const getPackagePriceAndCost = (paketId: string) => {
    const p = paket.find(item => item.id === paketId);
    if (!p) return { price: 5000, cost: 4500 };

    // Use custom pricing from reseller settings
    const custom = reseller.paketCustomPrices?.[paketId];
    if (custom) {
      return { price: custom.hargaJual, cost: custom.hargaModal };
    }

    // Voucher base public price (simulated smart retail price) fallback
    const publicPrice = p.harga > 50000 ? 5000 : p.harga / 10;
    const discount = (publicPrice * (reseller.komisiPercent || 10)) / 100;
    const agentCost = publicPrice - discount;
    return { price: Math.round(publicPrice), cost: Math.round(agentCost) };
  };

  // Reseller-specific vouchers
  const resellerVouchers = vouchers.filter(v => v.resellerId === reseller.id);

  const filteredVouchers = resellerVouchers.filter(v => {
    return v.code.toLowerCase().includes(searchQuery.toLowerCase()) || 
           v.durasi.toLowerCase().includes(searchQuery.toLowerCase());
  });

  // Handle Top-Up Submission
  const handleTopUp = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: Reseller = {
      ...reseller,
      saldo: reseller.saldo + topUpAmount
    };
    onUpdateReseller(updated);
    setShowTopUp(false);
    alert(`Top-Up Berhasil! Saldo sebesar ${formatRupiah(topUpAmount)} ditambahkan via ${topUpMethod === 'BANK' ? 'Transfer Bank' : 'Dompet Digital'}.`);
  };

  // Handle Single Manual Submission
  const handleCreateManual = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualCode.trim()) {
      alert('Isi username / kode hotspot terlebih dahulu!');
      return;
    }

    const { price, cost } = getPackagePriceAndCost(manualPaketId);

    if (reseller.saldo < cost) {
      alert(`⚠️ Gagal Membuat Voucher: Saldo tidak mencukupi!\nSaldo Anda: ${formatRupiah(reseller.saldo)}\nBiaya modal voucher: ${formatRupiah(cost)}`);
      return;
    }

    // Add voucher to shared pool
    onAddVoucher({
      code: manualCode.trim(),
      password: manualPassword.trim() || undefined,
      paketId: manualPaketId,
      harga: price,
      durasi: manualDurasi,
      serverName: manualServer,
      status: 'AKTIF',
      resellerId: reseller.id
    });

    // Deduct cost from reseller balance
    const updatedReseller: Reseller = {
      ...reseller,
      saldo: reseller.saldo - cost
    };
    onUpdateReseller(updatedReseller);

    setManualCode('');
    setManualPassword('');
    alert(`Sukses mendaftarkan user hotspot "${manualCode.trim()}"!\nSaldo terpotong: ${formatRupiah(cost)} (Terjual eceran Rp ${price})`);
  };

  // Handle Bulk Generator Submission
  const handleCreateBulk = (e: React.FormEvent) => {
    e.preventDefault();
    const { price, cost } = getPackagePriceAndCost(bulkPaketId);
    const totalCost = cost * bulkCount;

    if (reseller.saldo < totalCost) {
      alert(`⚠️ Gagal Membuat Massal: Saldo tidak mencukupi!\nJumlah Voucher: ${bulkCount} pcs\nTotal modal ditarik: ${formatRupiah(totalCost)}\nSaldo Anda: ${formatRupiah(reseller.saldo)}`);
      return;
    }

    // Call bulk generate and specify the reseller identification
    onBulkGenerate({
      count: bulkCount,
      paketId: bulkPaketId,
      harga: price,
      durasi: bulkDurasi,
      serverName: bulkServer,
      resellerId: reseller.id
    });

    // Deduct totalCost from reseller balance
    const updatedReseller: Reseller = {
      ...reseller,
      saldo: reseller.saldo - totalCost
    };
    onUpdateReseller(updatedReseller);

    alert(`Sukses mencetak ${bulkCount} voucher WiFi acak!\nSaldo terpotong: ${formatRupiah(totalCost)} (Retail: Rp ${price}/pcs)`);
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col font-sans select-none antialiased">
      {/* Reseller Header Portal */}
      <header className="bg-slate-950 border-b border-slate-800 shrink-0">
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="p-2.5 bg-indigo-600 text-white rounded-xl shadow-lg shadow-indigo-500/20">
              <Store size={22} />
            </span>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-base font-black tracking-tight text-white">{reseller.nama}</h1>
                <span className="bg-indigo-900/50 border border-indigo-700/50 text-indigo-400 font-extrabold text-[9px] px-2 py-0.5 rounded-full uppercase tracking-wider">
                  Agen Kemitraan
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">Sektor Distribusi Wifi: <span className="text-slate-200 font-semibold">{reseller.wilayah}</span></p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-slate-900 border border-slate-800 px-4 py-2 rounded-2xl flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-emerald-950/80 border border-emerald-800/80 flex items-center justify-center text-emerald-400">
                <Wallet size={16} />
              </div>
              <div>
                <p className="text-[9px] text-slate-400 uppercase font-bold tracking-wider">Saldo Deposit</p>
                <p className="text-sm font-black text-emerald-400 font-mono mt-0.5">{formatRupiah(reseller.saldo)}</p>
              </div>
            </div>

            {hasTopUp && (
              <button
                onClick={() => setShowTopUp(true)}
                className="px-3 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs rounded-xl flex items-center gap-1.5 transition shadow-md shadow-indigo-500/10 cursor-pointer"
              >
                <Plus size={14} /> Top Up
              </button>
            )}

            <button
              onClick={onLogout}
              className="p-2.5 bg-slate-800 hover:bg-rose-600 border border-slate-700 hover:border-rose-500 text-slate-400 hover:text-white rounded-xl transition"
              title="Keluar Akun"
            >
              <LogOut size={16} />
            </button>
          </div>
        </div>
      </header>

      {/* Main Container Area */}
      <main className="max-w-7xl mx-auto px-4 md:px-6 py-6 flex-1 w-full grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Side: Summary & Packages Info */}
        <div className="space-y-6">
          
          {/* Quick Reseller Status Card */}
          <div className="bg-slate-950/80 border border-slate-800 p-5 rounded-3xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-indigo-500/10 to-transparent blur-xl"></div>
            <h3 className="font-bold text-slate-200 text-xs uppercase tracking-wider mb-3">Informasi Kemitraan</h3>
            
            <div className="space-y-3 text-xs text-slate-400 font-sans">
              <div className="flex items-center justify-between pb-2 border-b border-slate-900">
                <span>ID Agen</span>
                <span className="font-mono font-bold text-slate-200 uppercase">{reseller.id}</span>
              </div>
              <div className="flex items-center justify-between pb-2 border-b border-slate-900">
                <span>No. Handphone (WA)</span>
                <span className="font-bold text-slate-200">{reseller.noHp}</span>
              </div>
              <div className="flex items-center justify-between pb-2 border-b border-slate-900">
                <span>Skema Pembelian</span>
                <span className="font-extrabold text-indigo-400 flex items-center gap-0.5 bg-indigo-900/40 px-2 py-0.5 rounded border border-indigo-800/40">
                  Wholesale Agen (Modal & Jual)
                </span>
              </div>
              <div className="flex items-center justify-between pb-1">
                <span>Voucher Dicetak Anda</span>
                <span className="font-bold text-emerald-400 font-mono">{resellerVouchers.length} Pcs</span>
              </div>
            </div>
          </div>

          {/* Speed Packages Catalog */}
          <div className="bg-slate-950/80 border border-slate-800 p-5 rounded-3xl space-y-4">
            <h3 className="font-bold text-slate-200 text-xs uppercase tracking-wider">Katalog Tarif & Harga Agen</h3>
            
            <div className="space-y-3">
              {myAllowedPakets.map(p => {
                const { price, cost } = getPackagePriceAndCost(p.id);
                return (
                  <div key={p.id} className="bg-slate-900 border border-slate-800 p-3 rounded-2xl flex items-center justify-between text-xs">
                    <div>
                      <h4 className="font-extrabold text-slate-200">{p.nama} ({p.kecepatan})</h4>
                      <p className="text-[10px] text-slate-500 mt-1">Eceran: <span className="font-semibold text-slate-400">{formatRupiah(price)}</span></p>
                    </div>
                    
                    <div className="text-right">
                      <p className="text-[10px] text-slate-400 uppercase font-black tracking-wide">Harga Modal Anda</p>
                      <p className="font-bold text-emerald-400 font-mono mt-0.5">{formatRupiah(cost)}</p>
                    </div>
                  </div>
                );
              })}
            </div>
            
            <div className="p-3 bg-indigo-950/40 border border-indigo-900/60 rounded-xl flex items-start gap-2.5 text-[10px] text-indigo-300 leading-normal">
              <ShieldCheck size={14} className="shrink-0 mt-0.5 text-indigo-400" />
              <span>Sistem otomatis mendiscount saldo Anda sebesar nominal harga modal tiap kali transaksi berhasil didaftarkan.</span>
            </div>
          </div>
        </div>

        {/* Right Side: Tab Controls & Main Forms Column */}
        <div className="lg:col-span-2 flex flex-col space-y-6">
          
          {/* Main Navigation Tabs */}
          <div className="flex p-1 bg-slate-950 border border-slate-800 rounded-2xl shrink-0">
            {(hasManual || hasBulk) && (
              <button
                onClick={() => setActiveTab('create')}
                className={`flex-1 py-3 text-center rounded-xl font-extrabold text-[11px] transition flex items-center justify-center gap-2.5 ${
                  activeTab === 'create' ? 'bg-slate-800 text-indigo-400' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Plus size={14} /> Buat & Cetak
              </button>
            )}
            {hasHistory && (
              <button
                onClick={() => setActiveTab('vouchers')}
                className={`flex-1 py-3 text-center rounded-xl font-extrabold text-[11px] transition flex items-center justify-center gap-2.5 ${
                  activeTab === 'vouchers' ? 'bg-slate-800 text-indigo-400' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <History size={14} /> Riwayat Voucher ({resellerVouchers.length})
              </button>
            )}
            <button
              onClick={() => setActiveTab('logs')}
              className={`flex-1 py-3 text-center rounded-xl font-extrabold text-[11px] transition flex items-center justify-center gap-2.5 ${
                activeTab === 'logs' ? 'bg-slate-800 text-indigo-400' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <ClipboardList size={14} /> Log & Audit ({portalLogs ? portalLogs.filter(log => log.portalType === 'AGEN/RESELLER' && log.operatorId === reseller.id).length : 0})
            </button>
          </div>

          {/* TAB CONTENT: FORMS */}
          {activeTab === 'create' && (
            <div className="bg-slate-950/80 border border-slate-800 p-6 rounded-3xl space-y-6">
              
              {/* Manual vs Bulk Sub-menu */}
              {hasManual && hasBulk && (
                <div className="grid grid-cols-2 gap-3 p-1.5 bg-slate-900 rounded-2xl border border-slate-800/80">
                  <button
                    onClick={() => setCreateMode('manual')}
                    className={`py-2.5 text-center rounded-xl font-bold text-xs transition flex items-center justify-center gap-1.5 ${
                      createMode === 'manual' ? 'bg-slate-800 text-white shadow-xs border border-indigo-500/20' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <Key size={14} /> Manual (Sandi Custom)
                  </button>
                  <button
                    onClick={() => setCreateMode('bulk')}
                    className={`py-2.5 text-center rounded-xl font-bold text-xs transition flex items-center justify-center gap-1.5 ${
                      createMode === 'bulk' ? 'bg-slate-800 text-white shadow-xs border border-indigo-500/20' : 'text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    <Layers size={14} /> Massal (Bulk Generator)
                  </button>
                </div>
              )}

              {!hasManual && !hasBulk && (
                <div className="p-8 text-center bg-slate-900 rounded-3xl border border-dashed border-slate-800 text-slate-400 leading-relaxed font-sans flex flex-col items-center">
                  <AlertCircle size={32} className="text-amber-500 mb-2" />
                  <h4 className="font-extrabold text-slate-200">Akses Pembuatan Voucher Dibatasi</h4>
                  <p className="text-xs text-slate-500 mt-1 max-w-sm">Administrator Anda telah menonaktifkan semua metode cetakan voucher baru untuk kemitraan Anda saat ini.</p>
                </div>
              )}

              {/* MANUAL SINGLE USER FORM */}
              {createMode === 'manual' && hasManual && (
                <form onSubmit={handleCreateManual} className="space-y-4 text-xs font-semibold text-slate-300">
                  <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl">
                    <h3 className="font-black text-slate-200 mb-1 leading-snug">Metode Manual</h3>
                    <p className="text-[10px] text-slate-500 leading-normal">Gunakan bila ingin mendaftarkan nama pembeli sebagai username dan melampirkan sandi kustom agar mudah login.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-slate-400">Username / Kode Hotspot *</label>
                      <input
                        type="text"
                        required
                        placeholder="Contoh: rudi_wifi"
                        className="w-full bg-slate-900 p-3 rounded-xl border border-slate-800 focus:outline-hidden focus:border-indigo-500 font-bold font-mono text-white"
                        value={manualCode}
                        onChange={(e) => setManualCode(e.target.value)}
                      />
                    </div>

                    <div className="space-y-1">
                      <label className="text-slate-400">Password Sandi Hotspot</label>
                      <input
                        type="text"
                        placeholder="Contoh: rudi123 (Kosongkan bila sama)"
                        className="w-full bg-slate-900 p-3 rounded-xl border border-slate-800 focus:outline-hidden focus:border-indigo-500 font-mono text-white"
                        value={manualPassword}
                        onChange={(e) => setManualPassword(e.target.value)}
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-slate-400">Pilih User Profile MikroTik</label>
                    <select
                      className="w-full bg-slate-900 p-3 rounded-xl border border-slate-800 focus:outline-hidden text-slate-200 focus:border-indigo-500 font-medium"
                      value={manualPaketId}
                      onChange={(e) => setManualPaketId(e.target.value)}
                    >
                      {myAllowedPakets.map(p => (
                        <option key={p.id} value={p.id}>{p.nama} ({p.kecepatan})</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-slate-400">Target Router Mikrotik Aktif</label>
                    <select
                      className="w-full bg-slate-900 p-3 rounded-xl border border-slate-800 focus:outline-hidden text-slate-200 focus:border-indigo-500 font-medium"
                      value={manualServer}
                      onChange={(e) => setManualServer(e.target.value)}
                    >
                      {myAllowedServers.map((s, idx) => (
                        <option key={idx} value={s.nama}>{s.nama} ({s.ipAddress})</option>
                      ))}
                    </select>
                  </div>

                  {/* Summary cost calculation card */}
                  <div className="bg-slate-900/60 p-4 rounded-2xl border border-slate-800 text-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
                    <div>
                      <p className="text-slate-400">Biaya Tarik Saldo Deposit (Harga Modal Agen)</p>
                      <p className="text-[10px] text-slate-500 mt-0.5">Membeli seharga: {formatRupiah(getPackagePriceAndCost(manualPaketId).cost)} | Dijual kembali: {formatRupiah(getPackagePriceAndCost(manualPaketId).price)}</p>
                    </div>

                    <p className="text-sm font-black text-emerald-400 font-mono text-right">{formatRupiah(getPackagePriceAndCost(manualPaketId).cost)}</p>
                  </div>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="submit"
                      className="w-full sm:w-auto px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold rounded-xl transition shadow-md shadow-indigo-500/10 cursor-pointer text-center text-xs"
                    >
                      Registrasikan & Kurangi Saldo
                    </button>
                  </div>
                </form>
              )}

              {/* AUTOMATIC BULK VOUCHERS FORM */}
              {createMode === 'bulk' && hasBulk && (
                <form onSubmit={handleCreateBulk} className="space-y-4 text-xs font-semibold text-slate-300">
                  <div className="p-4 bg-slate-900 border border-slate-800 rounded-2xl">
                    <h3 className="font-black text-slate-200 mb-1 leading-snug">Metode Bulk Massal</h3>
                    <p className="text-[10px] text-slate-500 leading-normal">Gunakan untuk mencetak sekumpulan kode login WiFI sekaligus. Sangat praktis untuk dicetak pada kertas label kecil dan dipajang di warung.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1">
                      <label className="text-slate-400">Jumlah Voucher Yang Dicetak</label>
                      <input
                        type="number"
                        min={1}
                        max={50}
                        required
                        className="w-full bg-slate-900 p-3 rounded-xl border border-slate-800 focus:outline-hidden focus:border-indigo-500 font-bold font-mono text-white text-base text-center"
                        value={bulkCount}
                        onChange={(e) => setBulkCount(parseInt(e.target.value) || 1)}
                      />
                      <p className="text-[9px] text-slate-400 font-normal">Maksimal 50 lembar voucher per sekali cetak.</p>
                    </div>

                    <div className="space-y-1 flex-1">
                      <label className="text-slate-400">Pilih User Profile MikroTik</label>
                      <select
                        className="w-full bg-slate-900 p-3.5 rounded-xl border border-slate-800 focus:outline-hidden text-slate-200 focus:border-indigo-500 font-medium"
                        value={bulkPaketId}
                        onChange={(e) => setBulkPaketId(e.target.value)}
                      >
                        {myAllowedPakets.map(p => (
                          <option key={p.id} value={p.id}>{p.nama} ({p.kecepatan})</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-slate-400">Target Router Mikrotik</label>
                    <select
                      className="w-full bg-slate-900 p-3 rounded-xl border border-slate-800 focus:outline-hidden text-slate-200 focus:border-indigo-500 font-medium"
                      value={bulkServer}
                      onChange={(e) => setBulkServer(e.target.value)}
                    >
                      {myAllowedServers.map((s, idx) => (
                        <option key={idx} value={s.nama}>{s.nama} ({s.ipAddress})</option>
                      ))}
                    </select>
                  </div>

                  {/* Summary cost calculation card */}
                  <div className="bg-slate-900/60 p-4 rounded-2xl border border-slate-800 text-xs space-y-2">
                    <div className="flex items-center justify-between text-slate-400">
                      <span>Harga Modal Modal Per Pcs:</span>
                      <span className="font-mono text-slate-100 font-bold">{formatRupiah(getPackagePriceAndCost(bulkPaketId).cost)}</span>
                    </div>
                    <div className="flex items-center justify-between text-slate-400">
                      <span>Kuantitas Voucher:</span>
                      <span className="font-extrabold text-indigo-400">{bulkCount} Lembar</span>
                    </div>
                    <div className="flex items-center justify-between pt-2 border-t border-slate-800 text-sm font-black text-emerald-400">
                      <span>Total Pemotongan Saldo:</span>
                      <span className="font-mono text-base">{formatRupiah(getPackagePriceAndCost(bulkPaketId).cost * bulkCount)}</span>
                    </div>
                  </div>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="submit"
                      className="w-full sm:w-auto px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-extrabold rounded-xl transition shadow-md shadow-indigo-500/10 cursor-pointer text-center text-xs flex items-center justify-center gap-1.5"
                    >
                      <Layers size={14} /> Kirim & Mass Generate WiFi Voucher
                    </button>
                  </div>
                </form>
              )}
            </div>
          )}

          {/* TAB CONTENT: HISTORY & VOUCHER PRINTING */}
          {activeTab === 'vouchers' && (
            <div className="bg-slate-950/80 border border-slate-800 p-5 rounded-3xl space-y-4">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pt-1">
                <div>
                  <h3 className="font-extrabold text-sm text-slate-200">Riwayat Cetakan Anda</h3>
                  <p className="text-[10px] text-slate-500 mt-0.5">Daftar file kode hotspot yang sukses ditarik dari saldo deposit Anda.</p>
                </div>
                
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Saring kode cetak..."
                    className="bg-slate-900 text-xs border border-slate-800 focus:outline-hidden pl-8 pr-3 py-2 rounded-xl text-slate-200 placeholder-slate-600 focus:border-indigo-500 font-sans"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                  <Search size={14} className="absolute left-2.5 top-2.5 text-slate-600" />
                </div>
              </div>

              {/* Table list */}
              <div className="border border-slate-800 rounded-2xl overflow-hidden font-sans">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead className="bg-slate-900/80 text-slate-400 uppercase tracking-wider font-extrabold text-[10px] border-b border-slate-850">
                      <tr>
                        <th className="p-3">Kode Hotspot / Sandi</th>
                        <th className="p-3 text-center">Durasi</th>
                        <th className="p-3 text-right">Harga Ret</th>
                        <th className="p-3 text-center">Aksi Slip</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-850 font-semibold text-slate-300">
                      {filteredVouchers.length === 0 ? (
                        <tr>
                          <td colSpan={4} className="p-8 text-center text-slate-500 font-normal italic">
                            Belum ada riwayat cetak voucher.
                          </td>
                        </tr>
                      ) : (
                        filteredVouchers.map(v => (
                          <tr key={v.id} className="hover:bg-slate-900/40 transition">
                            <td className="p-3">
                              <div className="flex flex-col gap-1.5 items-start">
                                <span className="bg-indigo-950 text-indigo-400 border border-indigo-900 px-2.5 py-1 rounded font-mono font-black text-[11px] uppercase tracking-wider">
                                  {v.code}
                                </span>
                                {v.password && (
                                  <span className="text-[10px] font-mono bg-slate-900 px-1.5 py-0.5 border border-slate-800 text-slate-400">
                                    Sandi: <span className="text-white font-bold">{v.password}</span>
                                  </span>
                                )}
                              </div>
                            </td>
                            <td className="p-3 text-center">
                              <span className="text-xs font-bold text-slate-400">{v.durasi}</span>
                              <p className="text-[9px] text-slate-500 mt-0.5">{v.serverName}</p>
                            </td>
                            <td className="p-3 text-right font-bold text-emerald-400 font-mono">
                              {formatRupiah(v.harga)}
                            </td>
                            <td className="p-3 text-center">
                              <div className="flex items-center justify-center gap-1.5">
                                <button
                                  onClick={() => alert(`Mencetak struk label voucher ${v.code} (Eceran: ${formatRupiah(v.harga)}). Terhubung ke printer thermal Bluetooth!`)}
                                  className="p-1 px-2 border border-slate-800 hover:border-slate-700 bg-slate-900 hover:bg-slate-850 text-slate-400 hover:text-white rounded flex items-center gap-1 text-[10px] transition"
                                  title="Cetak Slip Label"
                                >
                                  <Printer size={12} /> Cetak
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB CONTENT: LOG & AUDIT */}
          {activeTab === 'logs' && (
            <div className="bg-slate-950/80 border border-slate-800 p-5 rounded-3xl space-y-4">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pt-1">
                <div>
                  <h3 className="font-extrabold text-sm text-slate-200">Log Aktivitas Portal Agen</h3>
                  <p className="text-[10px] text-slate-500 mt-0.5">Audit log terperinci dari login, topup saldo, dan riwayat cetak voucher Anda.</p>
                </div>

                <div className="flex items-center gap-2">
                  <div className="relative">
                    <input
                      type="text"
                      placeholder="Cari kata kunci log..."
                      className="bg-slate-900 text-xs border border-slate-800 focus:outline-hidden pl-8 pr-3 py-1.5 rounded-xl text-slate-200 placeholder-slate-600 focus:border-indigo-500 font-sans"
                      value={logSearch}
                      onChange={(e) => setLogSearch(e.target.value)}
                    />
                    <Search size={13} className="absolute left-2.5 top-2.5 text-slate-600" />
                  </div>

                  <select
                    value={logTypeFilter}
                    onChange={(e: any) => setLogTypeFilter(e.target.value)}
                    className="bg-slate-900 border border-slate-800 text-slate-300 text-[11px] py-1.5 px-2.5 rounded-xl font-sans"
                  >
                    <option value="ALL">Semua Tipe</option>
                    <option value="LOGIN">Masuk Portal</option>
                    <option value="CETAK_VOUCHER">Cetak Voucher</option>
                    <option value="TOPUP">Simulasi Top-Up</option>
                  </select>
                </div>
              </div>

              {/* Log List View */}
              <div className="border border-slate-800 rounded-2xl overflow-hidden font-sans">
                <div className="overflow-y-auto max-h-[400px]">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead className="bg-slate-900/80 text-slate-400 uppercase tracking-wider font-extrabold text-[10px] border-b border-slate-850 sticky top-0 z-10">
                      <tr>
                        <th className="p-3">Waktu</th>
                        <th className="p-3">Kegiatan</th>
                        <th className="p-3">Detail Aktivitas</th>
                        <th className="p-3 text-right">Nilai</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-850 font-semibold text-slate-300">
                      {(portalLogs || [])
                        .filter(log => log.portalType === 'AGEN/RESELLER' && log.operatorId === reseller.id)
                        .filter(log => logTypeFilter === 'ALL' || log.aktifitasType === logTypeFilter)
                        .filter(log => logSearch === '' || log.detail.toLowerCase().includes(logSearch.toLowerCase()) || log.fiturLabel.toLowerCase().includes(logSearch.toLowerCase()))
                        .length === 0 ? (
                        <tr>
                          <td colSpan={4} className="p-8 text-center text-slate-500 font-normal italic">
                            Belum ada baris log yang cocok dengan filter atau kriteria pencarian Anda.
                          </td>
                        </tr>
                      ) : (
                        (portalLogs || [])
                          .filter(log => log.portalType === 'AGEN/RESELLER' && log.operatorId === reseller.id)
                          .filter(log => logTypeFilter === 'ALL' || log.aktifitasType === logTypeFilter)
                          .filter(log => logSearch === '' || log.detail.toLowerCase().includes(logSearch.toLowerCase()) || log.fiturLabel.toLowerCase().includes(logSearch.toLowerCase()))
                          .map(log => (
                            <tr key={log.id} className="hover:bg-slate-900/40 transition">
                              <td className="p-3 text-slate-500 text-[10px] font-mono whitespace-nowrap">
                                {log.timestamp.substring(0, 10)} {log.timestamp.substring(11, 16)}
                              </td>
                              <td className="p-3">
                                <div className="flex items-center gap-1.5">
                                  <span className={`px-2 py-0.5 rounded text-[9px] uppercase tracking-wider font-black ${
                                    log.aktifitasType === 'LOGIN' ? 'bg-blue-950 text-blue-400 border border-blue-900' :
                                    log.aktifitasType === 'CETAK_VOUCHER' ? 'bg-purple-950 text-purple-400 border border-purple-900' :
                                    log.aktifitasType === 'TOPUP' ? 'bg-emerald-950 text-emerald-400 border border-emerald-900' :
                                    'bg-slate-905 text-slate-400 border border-slate-800'
                                  }`}>
                                    {log.aktifitasType.replace('_', ' ')}
                                  </span>
                                  <span className="text-white text-[11px] block">{log.fiturLabel}</span>
                                </div>
                              </td>
                              <td className="p-3 text-slate-400 text-[11px] max-w-xs md:max-w-md font-sans leading-relaxed">
                                {log.detail}
                              </td>
                              <td className="p-3 text-right font-mono text-[11px]">
                                {log.amount ? (
                                  <span className={log.aktifitasType === 'TOPUP' ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                                    {log.aktifitasType === 'TOPUP' ? '+' : '-'}{formatRupiah(log.amount)}
                                  </span>
                                ) : (
                                  <span className="text-slate-600">-</span>
                                )}
                              </td>
                            </tr>
                          ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* MODAL: TOP-UP PRE-DEFINED LIST */}
      {showTopUp && (
        <div className="fixed inset-0 bg-slate-995/85 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-slate-950 border border-slate-800 rounded-3xl w-full max-w-sm overflow-hidden text-slate-300 font-sans">
            <div className="flex justify-between items-center bg-slate-900 px-5 py-4 border-b border-slate-800">
              <h4 className="font-extrabold text-white flex items-center gap-2 text-xs uppercase tracking-wider">
                <Wallet size={16} className="text-indigo-400" /> Top-Up Saldo Deposito Agen
              </h4>
              <button 
                onClick={() => setShowTopUp(false)}
                className="p-1 hover:bg-slate-800 text-slate-400 hover:text-white rounded-lg transition"
              >
                <Plus size={16} className="rotate-45" />
              </button>
            </div>

            <form onSubmit={handleTopUp} className="p-5 space-y-4 text-xs font-semibold">
              <div className="bg-slate-900/50 p-3.5 rounded-2xl border border-slate-800">
                <p className="text-[10px] text-slate-400 uppercase font-black">Deposit Saat Ini</p>
                <h4 className="text-emerald-400 font-black text-sm font-mono mt-0.5">{formatRupiah(reseller.saldo)}</h4>
              </div>

              <div className="space-y-1.5">
                <label className="text-slate-400">Nominal Isi Ulang *</label>
                <input
                  type="number"
                  required
                  min={10000}
                  className="w-full bg-slate-900 p-3.5 rounded-xl border border-slate-800 focus:outline-hidden focus:border-indigo-500 font-mono font-black text-emerald-400 text-base"
                  value={topUpAmount}
                  onChange={(e) => setTopUpAmount(parseInt(e.target.value) || 0)}
                />
              </div>

              {/* Predefined Amounts Grid */}
              <div className="grid grid-cols-2 gap-2 text-center text-[10px] font-bold">
                <button
                  type="button"
                  onClick={() => setTopUpAmount(50000)}
                  className="p-2 bg-slate-900 hover:bg-slate-850 border border-slate-800 rounded-lg text-slate-200 transition"
                >
                  + Rp 50.000
                </button>
                <button
                  type="button"
                  onClick={() => setTopUpAmount(100000)}
                  className="p-2 bg-slate-900 hover:bg-slate-850 border border-slate-800 rounded-lg text-slate-200 transition"
                >
                  + Rp 100.000
                </button>
                <button
                  type="button"
                  onClick={() => setTopUpAmount(250000)}
                  className="p-2 bg-slate-900 hover:bg-slate-850 border border-slate-800 rounded-lg text-slate-200 transition"
                >
                  + Rp 250.000
                </button>
                <button
                  type="button"
                  onClick={() => setTopUpAmount(500000)}
                  className="p-2 bg-slate-900 hover:bg-slate-850 border border-slate-800 rounded-lg text-slate-200 transition"
                >
                  + Rp 500.000
                </button>
              </div>

              {/* Top Up Methods */}
              <div className="space-y-1.5 pt-1.5">
                <label className="text-slate-400">Pilih Metode Pembayaran</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setTopUpMethod('E_WALLET')}
                    className={`p-2 rounded-lg border text-center font-bold text-[10px] transition ${
                      topUpMethod === 'E_WALLET' ? 'border-indigo-500 bg-indigo-950/20 text-white' : 'border-slate-800 bg-slate-900 text-slate-400'
                    }`}
                  >
                    🚀 QRIS / E-Wallet
                  </button>
                  <button
                    type="button"
                    onClick={() => setTopUpMethod('BANK')}
                    className={`p-2 rounded-lg border text-center font-bold text-[10px] transition ${
                      topUpMethod === 'BANK' ? 'border-indigo-500 bg-indigo-950/20 text-white' : 'border-slate-800 bg-slate-900 text-slate-400'
                    }`}
                  >
                    🏦 Transfer Bank
                  </button>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-850">
                <button
                  type="button"
                  onClick={() => setShowTopUp(false)}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-850 text-slate-400 hover:text-white rounded-xl transition text-[11px]"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold transition text-[11px] shadow-sm cursor-pointer shadow-emerald-500/10"
                >
                  Bayar & Selesaikan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
