import React, { useState } from 'react';
import { Pelanggan, Paket, TukangTagih } from '../types';
import { formatRupiah, formatTanggalIndo } from '../utils';
import { Search, Plus, UserPlus, ToggleLeft, ToggleRight, Edit2, Trash2, X, AlertCircle, Wifi, Home, UserCheck, Download, Upload, FileSpreadsheet } from 'lucide-react';

interface PelangganTabProps {
  pelanggan: Pelanggan[];
  paket: Paket[];
  collectors: TukangTagih[];
  onAddPelanggan: (p: Omit<Pelanggan, 'id' | 'tanggalDaftar'>) => void;
  onUpdatePelanggan: (p: Pelanggan) => void;
  onDeletePelanggan: (id: string) => void;
}

export default function PelangganTab({
  pelanggan,
  paket,
  collectors,
  onAddPelanggan,
  onUpdatePelanggan,
  onDeletePelanggan
}: PelangganTabProps) {
  // Filters and queries
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<'SEMUA' | 'AKTIF' | 'NON_AKTIF'>('SEMUA');
  const [filterPaket, setFilterPaket] = useState<string>('SEMUA');
  const [filterCategory, setFilterCategory] = useState<'SEMUA' | 'Rumahan' | 'Hotspot'>('SEMUA');

  // Modal forms
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPelanggan, setEditingPelanggan] = useState<Pelanggan | null>(null);
  const [customerToDelete, setCustomerToDelete] = useState<Pelanggan | null>(null);

  // Form Fields
  const [formData, setFormData] = useState({
    nama: '',
    noHp: '',
    alamat: '',
    paketId: 'manual',
    tarif: 0,
    statusAktif: true,
    jatuhTempo: '2026-06-10',
    kategoriLangganan: 'Rumahan' as 'Rumahan' | 'Hotspot',
    tukangTagihId: 'none'
  });

  const handleExportCSV = () => {
    const headers = ["Nama", "No HP / WhatsApp", "Alamat", "Paket ID (atau 'manual')", "Tarif Bulanan", "Status Aktif (true/false)", "Tanggal Jatuh Tempo (YYYY-MM-DD)", "Kategori Langganan (Rumahan/Hotspot/PPPoE)"];
    
    const rows = pelanggan.map(p => [
      p.nama,
      p.noHp,
      p.alamat,
      p.paketId,
      p.tarif,
      p.statusAktif ? "true" : "false",
      p.jatuhTempo,
      p.kategoriLangganan
    ]);
    
    // Add UTF-8 BOM so Excel opens indonesian special characters/spacing correctly
    const csvContent = "\uFEFF" + [headers.join(","), ...rows.map(e => e.map(val => `"${String(val).replace(/"/g, '""')}"`).join(","))].join("\n");
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `Data_Pelanggan_RTRWNet_${new Date().toISOString().substring(0,10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleImportCSV = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const lines = text.split(/\r?\n/);
        if (lines.length <= 1) {
          alert("File Excel/CSV kosong.");
          return;
        }
        
        // Skip header line
        let importCount = 0;
        for (let i = 1; i < lines.length; i++) {
          const line = lines[i].trim();
          if (!line) continue;
          
          const cols: string[] = [];
          let current = '';
          let inQuotes = false;
          for (let c = 0; c < line.length; c++) {
            const char = line[c];
            if (char === '"') {
              inQuotes = !inQuotes;
            } else if (char === ',' && !inQuotes) {
              cols.push(current.trim());
              current = '';
            } else {
              current += char;
            }
          }
          cols.push(current.trim());
          
          const cleanCols = cols.map(c => c.replace(/^"|"$/g, '').trim());
          if (cleanCols.length < 2 || !cleanCols[0]) continue;
          
          const nama = cleanCols[0];
          const noHp = cleanCols[1] || '08';
          const alamat = cleanCols[2] || '';
          const paketId = cleanCols[3] || 'manual';
          const tarif = Number(cleanCols[4]) || 0;
          const statusAktif = cleanCols[5] === 'false' ? false : true;
          const jatuhTempo = cleanCols[6] || '2026-06-10';
          const kategoriLangganan = (cleanCols[7] === 'Hotspot' || cleanCols[7] === 'PPPoE' ? cleanCols[7] : 'Rumahan') as any;
          
          onAddPelanggan({
            nama,
            noHp,
            alamat,
            paketId,
            tarif,
            statusAktif,
            jatuhTempo,
            kategoriLangganan,
            tukangTagihId: 'none'
          });
          importCount++;
        }
        
        alert(`Sukses mengimport ${importCount} data pelanggan dari Excel/CSV.`);
      } catch (err) {
        console.error(err);
        alert("Gagal membaca file. Pastikan format file sesuai.");
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Open modal for Adding
  const openAddModal = () => {
    setFormData({
      nama: '',
      noHp: '08',
      alamat: '',
      paketId: 'manual',
      tarif: 0,
      statusAktif: true,
      jatuhTempo: '2026-06-10',
      kategoriLangganan: 'Rumahan',
      tukangTagihId: 'none'
    });
    setEditingPelanggan(null);
    setIsModalOpen(true);
  };

  // Open modal for Editing
  const openEditModal = (p: Pelanggan) => {
    setEditingPelanggan(p);
    setFormData({
      nama: p.nama,
      noHp: p.noHp,
      alamat: p.alamat,
      paketId: p.paketId,
      tarif: p.tarif,
      statusAktif: p.statusAktif,
      jatuhTempo: p.jatuhTempo,
      kategoriLangganan: p.kategoriLangganan || 'Rumahan',
      tukangTagihId: p.tukangTagihId || 'none'
    });
    setIsModalOpen(true);
  };

  // Submission handler
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.nama.trim() || !formData.noHp.trim()) {
      alert('Nama dan No WhatsApp harus diisi!');
      return;
    }

    if (editingPelanggan) {
      onUpdatePelanggan({
        ...editingPelanggan,
        ...formData
      });
    } else {
      onAddPelanggan(formData);
    }
    
    setIsModalOpen(false);
  };

  // Quick toggle Customer Active State
  const handleToggleStatus = (p: Pelanggan) => {
    onUpdatePelanggan({
      ...p,
      statusAktif: !p.statusAktif
    });
  };

  // Filtering logic
  const filteredList = pelanggan.filter((p) => {
    const matchSearch = 
      p.nama.toLowerCase().includes(search.toLowerCase()) ||
      p.noHp.includes(search) ||
      p.alamat.toLowerCase().includes(search.toLowerCase());
    
    const matchStatus = 
      filterStatus === 'SEMUA' || 
      (filterStatus === 'AKTIF' && p.statusAktif) || 
      (filterStatus === 'NON_AKTIF' && !p.statusAktif);

    const matchPaket = 
      filterPaket === 'SEMUA' || 
      p.paketId === filterPaket;

    const matchCategory = 
      filterCategory === 'SEMUA' || 
      p.kategoriLangganan === filterCategory;

    return matchSearch && matchStatus && matchPaket && matchCategory;
  });

  const totalCount = pelanggan.length;
  const activeCount = pelanggan.filter(p => p.statusAktif).length;
  const inactiveCount = pelanggan.filter(p => !p.statusAktif).length;

  return (
    <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm space-y-6">
      
      {/* Tab Header Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h3 className="text-lg font-bold text-slate-800">📋 Database Pelanggan</h3>
          <p className="text-xs text-slate-500">Jumlah total terdaftar: {pelanggan.length} pelanggan</p>
        </div>
        <div className="flex flex-wrap items-center gap-2 self-start md:self-auto">
          {/* Export Excel Button */}
          <button
            onClick={handleExportCSV}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-emerald-50 text-emerald-700 hover:bg-emerald-600 hover:text-white border border-emerald-100 rounded-xl font-bold text-xs transition cursor-pointer shadow-3xs"
            title="Download data pelanggan ke dokumen excel / csv"
          >
            <Download size={15} /> Export Excel
          </button>

          {/* Import Excel Button */}
          <label
            className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-amber-50 text-amber-700 hover:bg-amber-600 hover:text-white border border-amber-100 rounded-xl font-bold text-xs transition cursor-pointer shadow-3xs"
            title="Import data pelanggan dari dokumen excel / csv"
          >
            <Upload size={15} /> Import Excel
            <input
              type="file"
              accept=".csv"
              onChange={handleImportCSV}
              className="hidden"
            />
          </label>

          {/* Add Customer Button */}
          <button
            onClick={openAddModal}
            className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-xl font-bold text-xs hover:bg-indigo-700 transition cursor-pointer shadow-sm"
          >
            <UserPlus size={15} /> Tambah Pelanggan
          </button>
        </div>
      </div>

      {/* Quick Statistics & Filter Tiles for Subscriptions */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <button
          type="button"
          onClick={() => setFilterStatus('SEMUA')}
          className={`p-3.5 rounded-xl border text-left transition-all relative overflow-hidden cursor-pointer group ${
            filterStatus === 'SEMUA'
              ? 'bg-indigo-50/75 border-indigo-200 shadow-xs ring-2 ring-indigo-500/20'
              : 'bg-white border-slate-100 hover:border-slate-200 hover:bg-slate-50/50'
          }`}
        >
          <div className="flex justify-between items-center">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest group-hover:text-slate-500 transition-colors">Semua Pelanggan</span>
            <span className="text-[10px] px-2 py-0.5 bg-slate-100 rounded-full font-bold text-slate-600 border border-slate-200">{totalCount}</span>
          </div>
          <p className="text-lg font-extrabold text-slate-800 mt-1.5 flex items-baseline gap-1">
            {totalCount} <span className="text-xs font-normal text-slate-400 font-sans">Total</span>
          </p>
          <div className="absolute right-3 -bottom-2 opacity-[0.04] text-5xl font-extrabold select-none pointer-events-none group-hover:scale-110 transition-transform">
            👥
          </div>
        </button>

        <button
          type="button"
          onClick={() => setFilterStatus('AKTIF')}
          className={`p-3.5 rounded-xl border text-left transition-all relative overflow-hidden cursor-pointer group ${
            filterStatus === 'AKTIF'
              ? 'bg-emerald-50/80 border-emerald-200 shadow-xs ring-2 ring-emerald-500/20'
              : 'bg-white border-slate-100 hover:border-slate-200 hover:bg-emerald-50/20'
          }`}
        >
          <div className="flex justify-between items-center">
            <span className={`text-[10px] font-bold uppercase tracking-widest transition-colors ${filterStatus === 'AKTIF' ? 'text-emerald-700' : 'text-slate-400 group-hover:text-emerald-600'}`}>Layanan Aktif</span>
            <span className="text-[10px] px-2 py-0.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-800 rounded-full font-bold border border-emerald-200/50">{activeCount}</span>
          </div>
          <p className={`text-lg font-extrabold mt-1.5 flex items-baseline gap-1 ${filterStatus === 'AKTIF' ? 'text-emerald-700' : 'text-slate-800 group-hover:text-emerald-700'}`}>
            {activeCount} <span className="text-xs font-normal text-slate-400 font-sans">Berlangganan</span>
          </p>
          <div className="absolute right-3 -bottom-2 opacity-[0.06] text-5xl font-extrabold select-none pointer-events-none group-hover:scale-110 transition-transform">
            🟢
          </div>
        </button>

        <button
          type="button"
          onClick={() => setFilterStatus('NON_AKTIF')}
          className={`p-3.5 rounded-xl border text-left transition-all relative overflow-hidden cursor-pointer group ${
            filterStatus === 'NON_AKTIF'
              ? 'bg-rose-50/80 border-rose-200 shadow-xs ring-2 ring-rose-500/20'
              : 'bg-white border-slate-100 hover:border-slate-200 hover:bg-rose-50/20'
          }`}
        >
          <div className="flex justify-between items-center">
            <span className={`text-[10px] font-bold uppercase tracking-widest transition-colors ${filterStatus === 'NON_AKTIF' ? 'text-rose-700' : 'text-slate-400 group-hover:text-rose-600'}`}>Layanan Non-Aktif / Isolir</span>
            <span className="text-[10px] px-2 py-0.5 bg-rose-100 text-rose-800 rounded-full font-bold border border-rose-200/50">{inactiveCount}</span>
          </div>
          <p className={`text-lg font-extrabold mt-1.5 flex items-baseline gap-1 ${filterStatus === 'NON_AKTIF' ? 'text-rose-700' : 'text-slate-800 group-hover:text-rose-700'}`}>
            {inactiveCount} <span className="text-xs font-normal text-slate-400 font-sans">Isolir</span>
          </p>
          <div className="absolute right-3 -bottom-2 opacity-[0.06] text-5xl font-extrabold select-none pointer-events-none group-hover:scale-110 transition-transform">
            🔴
          </div>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 bg-slate-50 p-4 rounded-xl border border-slate-100">
        <div className="relative">
          <Search size={16} className="absolute left-3 top-3 text-slate-400" />
          <input
            type="text"
            placeholder="Cari Nama/HP/Alamat..."
            className="w-full bg-white text-xs pl-9 pr-3 py-2.5 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 placeholder:text-slate-400 font-medium"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        
        <div>
          <select
            className="w-full bg-white text-xs px-3 py-2.5 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-bold text-slate-700"
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value as any)}
          >
            <option value="SEMUA">👤 Semua Status Layanan</option>
            <option value="AKTIF">🟢 Layanan Aktif</option>
            <option value="NON_AKTIF">🔴 Layanan Non-Aktif / Terisolir</option>
          </select>
        </div>

        <div>
          <select
            className="w-full bg-white text-xs px-3 py-2.5 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-bold text-slate-700"
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value as any)}
          >
            <option value="SEMUA">🌐 Semua Kategori Langganan</option>
            <option value="Rumahan">🏠 Rumahan (PPPoE / Kabel)</option>
            <option value="Hotspot">📶 WiFi Hotspot (Voucher)</option>
          </select>
        </div>

        <div>
          <select
            className="w-full bg-white text-xs px-3 py-2.5 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-bold text-slate-700"
            value={filterPaket}
            onChange={(e) => setFilterPaket(e.target.value)}
          >
            <option value="SEMUA">📦 Semua Paket Kecepatan</option>
            {paket.map((pkt) => (
              <option key={pkt.id} value={pkt.id}>
                📦 {pkt.nama} ({pkt.kecepatan})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Customer List Table */}
      <div className="overflow-x-auto rounded-xl border border-slate-100">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="bg-slate-50 text-xs font-semibold text-slate-500 border-b border-slate-100">
              <th className="p-4">ID / Pelanggan</th>
              <th className="p-4">No. HP (WhatsApp)</th>
              <th className="p-4">Alamat Rumah</th>
              <th className="p-4">Kategori & Paket</th>
              <th className="p-4">Tarif Bulanan</th>
              <th className="p-4 text-center">Jatuh Tempo</th>
              <th className="p-4 text-center">Petugas Tagih</th>
              <th className="p-4 text-center">Status</th>
              <th className="p-4 text-right">Aksi</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
            {filteredList.map((p) => {
              const customerPaket = paket.find((pkt) => pkt.id === p.paketId);
              const assignedCollector = collectors.find(c => c.id === p.tukangTagihId);
              return (
                <tr key={p.id} className="hover:bg-slate-50/60 font-sans transition">
                  <td className="p-4">
                    <div>
                      <p className="font-bold text-slate-800 text-sm">{p.nama}</p>
                      <p className="text-[10px] text-slate-400 font-mono mt-0.5">{p.id}</p>
                    </div>
                  </td>
                  <td className="p-4 font-mono">{p.noHp}</td>
                  <td className="p-4 max-w-xs truncate">{p.alamat}</td>
                  <td className="p-4">
                    <div className="flex flex-col gap-1 items-start">
                      {p.kategoriLangganan === 'Hotspot' ? (
                        <span className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-amber-50 text-amber-700 rounded text-[9px] font-bold border border-amber-100">
                          <Wifi size={10} /> Hotspot
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-sky-50 text-sky-700 rounded text-[9px] font-bold border border-sky-100">
                          <Home size={10} /> Rumahan
                        </span>
                      )}
                      {customerPaket ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-indigo-50 text-indigo-700 rounded-md font-bold text-[10px] border border-indigo-100/50" title={customerPaket.deskripsi}>
                          📦 {customerPaket.nama} ({customerPaket.kecepatan})
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-slate-100 text-slate-650 rounded-md font-medium text-[10px] border border-slate-205">
                          Tarif Manual
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="p-4 font-bold font-mono text-slate-800">{formatRupiah(p.tarif)}</td>
                  <td className="p-4 text-center font-semibold text-slate-650 font-mono">{formatTanggalIndo(p.jatuhTempo)}</td>
                  <td className="p-4 text-center font-bold text-slate-600">
                    <span className="inline-flex items-center gap-1 px-2 py-1 bg-slate-100 text-slate-700 rounded-lg text-[10px] border">
                      <UserCheck size={11} className="text-indigo-600 animate-pulse" />
                      {assignedCollector ? assignedCollector.nama : 'Admin Sendiri'}
                    </span>
                  </td>
                  <td className="p-4 text-center">
                    <button
                      onClick={() => handleToggleStatus(p)}
                      title="Klik untuk mengubah status"
                      className="inline-flex mx-auto hover:scale-105 transition active:scale-95 cursor-pointer"
                    >
                      {p.statusAktif ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-50 text-emerald-700 rounded-full font-bold text-[10px] border border-emerald-100">
                          🟢 AKTIF
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-rose-50 text-rose-700 rounded-full font-bold text-[10px] border border-rose-100">
                          🔴 ISOLIR / MATI
                        </span>
                      )}
                    </button>
                  </td>
                  <td className="p-4 text-right">
                    <div className="inline-flex items-center gap-1">
                      <button
                        onClick={() => openEditModal(p)}
                        className="p-1.5 hover:bg-slate-100 text-slate-500 hover:text-slate-700 rounded-lg transition cursor-pointer"
                        title="Edit Pelanggan"
                      >
                        <Edit2 size={14} />
                      </button>
                      <button
                        onClick={() => setCustomerToDelete(p)}
                        className="p-1.5 hover:bg-rose-50 text-rose-400 hover:text-rose-600 rounded-lg transition cursor-pointer"
                        title="Hapus Pelanggan"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
            {filteredList.length === 0 && (
              <tr>
                <td colSpan={9} className="p-8 text-center text-slate-400 whitespace-nowrap">
                  Tidak ada pelanggan yang cocok dengan pencarian / filter ini.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* MODAL FORM TAMBAH / EDIT PELANGGAN */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl border border-slate-150 shadow-xl w-full max-w-lg overflow-hidden animate-zoomIn">
            
            {/* Modal Header */}
            <div className="flex justify-between items-center bg-slate-50 px-6 py-4 border-b border-slate-100">
              <h4 className="font-bold text-slate-800 flex items-center gap-2 text-sm">
                <UserPlus size={18} className="text-indigo-600" />
                {editingPelanggan ? 'Sunting Data Pelanggan' : 'Pendaftaran Pelanggan Baru'}
              </h4>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 hover:bg-slate-200 text-slate-400 hover:text-slate-600 rounded-lg transition cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs text-slate-650">
              <div className="grid grid-cols-2 gap-4">
                
                <div className="col-span-2 space-y-1">
                  <label className="font-semibold text-slate-705">Nama Lengkap Pelanggan *</label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: Ahmad Subagjo"
                    className="w-full bg-slate-50 px-3 py-2.5 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-medium text-slate-800"
                    value={formData.nama}
                    onChange={(e) => setFormData({ ...formData, nama: e.target.value })}
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-slate-705">Nomor WhatsApp (Aktif) *</label>
                  <input
                    type="tel"
                    required
                    placeholder="Contoh: 08123456789"
                    className="w-full bg-slate-50 px-3 py-2.5 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-mono font-medium text-slate-800"
                    value={formData.noHp}
                    onChange={(e) => setFormData({ ...formData, noHp: e.target.value })}
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-slate-705">Tanggal Jatuh Tempo *</label>
                  <input
                    type="date"
                    required
                    className="w-full bg-slate-50 px-3 py-2.5 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-medium font-mono text-slate-800 text-xs"
                    value={formData.jatuhTempo}
                    onChange={(e) => setFormData({ ...formData, jatuhTempo: e.target.value })}
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-slate-705">Kategori Langganan *</label>
                  <select
                    className="w-full bg-slate-50 px-3 py-2.5 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-bold text-slate-800"
                    value={formData.kategoriLangganan}
                    onChange={(e) => setFormData({ ...formData, kategoriLangganan: e.target.value as any })}
                  >
                    <option value="Rumahan">Rumahan (Kabel/PPPoE)</option>
                    <option value="Hotspot">WiFi Hotspot (Voucher)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-slate-705">Ditugaskan ke Penagih *</label>
                  <select
                    className="w-full bg-slate-50 px-3 py-2.5 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-bold text-indigo-700"
                    value={formData.tukangTagihId}
                    onChange={(e) => setFormData({ ...formData, tukangTagihId: e.target.value })}
                  >
                    <option value="none">Admin Utama (Langsung)</option>
                    {collectors.map(c => (
                      <option key={c.id} value={c.id}>{c.nama} (Tukang Tagih)</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1 col-span-2">
                  <label className="font-semibold text-slate-705">Alamat Lengkap Rumah *</label>
                  <textarea
                    required
                    placeholder="Contoh: RT 003 / RW 002, Gg. Kenanga No. 14A"
                    rows={2}
                    className="w-full bg-slate-50 px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-medium text-slate-800"
                    value={formData.alamat}
                    onChange={(e) => setFormData({ ...formData, alamat: e.target.value })}
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-slate-705">Pilih Paket Terkait *</label>
                  <select
                    className="w-full bg-slate-50 px-3 py-2.5 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-bold text-slate-800 text-xs"
                    value={formData.paketId}
                    onChange={(e) => {
                      const selPaketId = e.target.value;
                      const matchedP = paket.find(pkt => pkt.id === selPaketId);
                      setFormData({
                        ...formData,
                        paketId: selPaketId,
                        tarif: matchedP ? matchedP.harga : formData.tarif
                      });
                    }}
                  >
                    <option value="manual">Tarif Kustom / Manual</option>
                    {paket.map((pkt) => (
                      <option key={pkt.id} value={pkt.id}>
                        {pkt.nama} ({pkt.kecepatan}) - {formatRupiah(pkt.harga)}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-slate-705">Jumlah Tagihan Bulanan (Tarif) *</label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-slate-400 font-bold">Rp</span>
                    <input
                      type="number"
                      required
                      className="w-full bg-slate-50 pl-8 pr-3 py-2.5 rounded-lg border border-slate-200 font-bold font-mono focus:outline-hidden focus:border-indigo-500 text-slate-800"
                      value={formData.tarif}
                      onChange={(e) => setFormData({ ...formData, tarif: parseInt(e.target.value) || 0 })}
                    />
                  </div>
                  <p className="text-[9px] text-slate-400 font-sans italic font-normal mt-0.5">Dapat diganti manual di atas untuk kustom potongan/harga khusus.</p>
                </div>

                <div className="space-y-1 col-span-2 flex items-center gap-3 bg-indigo-50/50 p-3 rounded-xl border border-indigo-100/50 mt-2">
                  <input
                    type="checkbox"
                    id="statusAktif"
                    className="w-4 h-4 text-indigo-600 rounded-sm focus:ring-indigo-500 cursor-pointer"
                    checked={formData.statusAktif}
                    onChange={(e) => setFormData({ ...formData, statusAktif: e.target.checked })}
                  />
                  <label htmlFor="statusAktif" className="font-semibold text-slate-700 cursor-pointer">
                    Aktifkan Layanan Sekarang (Status Berlangganan Aktif)
                  </label>
                </div>
              </div>

              {/* Form Actions */}
              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 hover:bg-slate-100 rounded-xl font-semibold hover:text-slate-800 transition cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition cursor-pointer shadow-sm"
                >
                  {editingPelanggan ? 'Simpan Perubahan' : 'Daftarkan Pelanggan'}
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* CUSTOM CONFIRMATION MODAL */}
      {customerToDelete && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xl w-full max-w-sm overflow-hidden p-6 space-y-4">
            <div className="flex items-center gap-3 text-rose-650">
              <div className="p-2 bg-rose-50 rounded-full text-rose-600">
                <AlertCircle size={20} />
              </div>
              <h4 className="font-bold text-slate-800 text-sm">Konfirmasi Hapus Pelanggan</h4>
            </div>
            
            <p className="text-xs text-slate-500 leading-relaxed">
              Apakah Anda yakin ingin menghapus pelanggan <strong className="text-slate-800 font-bold">{customerToDelete.nama}</strong>?
              <br className="mb-1" />
              Tindakan ini tidak dapat dibatalkan. Semua data historis tagihan terkait pelanggan ini juga tidak akan terhubung lagi.
            </p>

            <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setCustomerToDelete(null)}
                className="px-3.5 py-2 hover:bg-slate-100 text-slate-505 hover:text-slate-700 rounded-xl font-semibold text-xs transition cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeletePelanggan(customerToDelete.id);
                  setCustomerToDelete(null);
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold text-xs transition cursor-pointer shadow-xs font-sans"
              >
                Ya, Hapus
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
