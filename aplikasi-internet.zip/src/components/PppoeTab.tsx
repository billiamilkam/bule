import React, { useState } from 'react';
import { PppoeUser, MikrotikServer } from '../types';
import { Cable, Search, RefreshCw, Layers, Compass, Plus, Trash2, ShieldCheck, Play, Power, X } from 'lucide-react';

interface PppoeTabProps {
  pppoeUsers: PppoeUser[];
  servers: MikrotikServer[];
  onAddPppoe: (p: Omit<PppoeUser, 'id'>) => void;
  onUpdatePppoe: (p: PppoeUser) => void;
  onDeletePppoe: (id: string) => void;
}

export default function PppoeTab({
  pppoeUsers,
  servers,
  onAddPppoe,
  onUpdatePppoe,
  onDeletePppoe
}: PppoeTabProps) {
  const [search, setSearch] = useState('');
  const [filterServer, setFilterServer] = useState('SEMUA');
  const [filterStatus, setFilterStatus] = useState<'SEMUA' | 'ONLINE' | 'OFFLINE'>('SEMUA');

  // Add PPPoE Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    profileName: 'Paket Keluarga 10M',
    localAddress: '10.10.10.1',
    remoteAddress: '10.10.10.201',
    serverName: servers[0]?.nama || 'Mikrotik Pusat Kamal',
    status: 'ONLINE' as 'ONLINE' | 'OFFLINE'
  });

  const openAddModal = () => {
    setFormData({
      username: '',
      password: '123',
      profileName: 'Paket Keluarga 10M',
      localAddress: '10.10.10.1',
      remoteAddress: `10.10.10.${Math.floor(100 + Math.random() * 100)}`,
      serverName: servers[0]?.nama || 'Mikrotik Pusat Kamal',
      status: 'ONLINE'
    });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.username.trim() || !formData.profileName.trim()) {
      alert('Nama pengguna PPPoE dan Profile wajib diisi!');
      return;
    }

    onAddPppoe(formData);
    setIsModalOpen(false);
    alert(`Mikrotik API: Akun PPPoE ${formData.username} sukses dipasang ke server "${formData.serverName}".`);
  };

  // Toggle simulate online status
  const handleTogglePppoeStatus = (u: PppoeUser) => {
    const nextStatus = u.status === 'ONLINE' ? 'OFFLINE' : 'ONLINE';
    onUpdatePppoe({
      ...u,
      status: nextStatus,
      remoteAddress: nextStatus === 'ONLINE' ? `10.10.10.${Math.floor(100 + Math.random() * 140)}` : '-'
    });
  };

  const filteredList = pppoeUsers.filter(u => {
    const sLower = search.toLowerCase();
    const matchSearch = u.username.toLowerCase().includes(sLower) || u.profileName.toLowerCase().includes(sLower);
    const matchServer = filterServer === 'SEMUA' || u.serverName === filterServer;
    const matchStatus = filterStatus === 'SEMUA' || u.status === filterStatus;
    return matchSearch && matchServer && matchStatus;
  });

  return (
    <div id="pppoe-tab" className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Pelanggan PPPoE (Rumahan)</h2>
          <p className="text-xs text-slate-500">Kelola dial-up tunneling user (Secret PPPoE) untuk pelanggan rumahan yang dikontrol otomatis dari Mikrotik API.</p>
        </div>

        <button
          onClick={openAddModal}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-indigo-600 text-white rounded-xl font-bold text-xs hover:bg-indigo-700 transition shadow-sm cursor-pointer"
        >
          <Plus size={15} /> Registrasi Baru PPPoE Secret
        </button>
      </div>

      {/* Grid count stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        <div className="bg-slate-50 p-4 rounded-xl border border-slate-150 text-slate-700">
          <p className="text-[10px] uppercase font-bold tracking-wider text-slate-400">Total Akun PPPoE</p>
          <h3 className="text-xl font-black text-indigo-650 mt-1">{pppoeUsers.length} <span className="text-xs font-normal text-slate-400">akun</span></h3>
        </div>
        <div className="bg-slate-50 p-4 rounded-xl border border-slate-150 text-slate-700">
          <p className="text-[10px] uppercase font-bold tracking-wider text-slate-400">Status Online</p>
          <h3 className="text-xl font-black text-emerald-600 mt-1 flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-ping" />
            {pppoeUsers.filter(u => u.status === 'ONLINE').length} <span className="text-xs font-normal text-slate-400">aktif</span>
          </h3>
        </div>
        <div className="bg-slate-50 p-4 rounded-xl border border-slate-150 text-slate-700">
          <p className="text-[10px] uppercase font-bold tracking-wider text-slate-400">Offline / Terisolir</p>
          <h3 className="text-xl font-black text-rose-500 mt-1">{pppoeUsers.filter(u => u.status === 'OFFLINE').length} <span className="text-xs font-normal text-slate-400">offline</span></h3>
        </div>
      </div>

      {/* Query Filters */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex flex-wrap items-center gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <input
            type="text"
            placeholder="Cari Username PPPoE / Profile..."
            className="w-full bg-slate-50 text-xs pl-8 pr-3 py-2.5 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-sans"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <Search size={14} className="absolute left-2.5 top-3 text-slate-400" />
        </div>

        <select
          className="text-xs font-medium px-3 py-2.5 rounded-lg border border-slate-200 bg-slate-50 focus:outline-hidden"
          value={filterServer}
          onChange={(e) => setFilterServer(e.target.value)}
        >
          <option value="SEMUA">Semua Server</option>
          {servers.map((s, idx) => (
            <option key={idx} value={s.nama}>{s.nama}</option>
          ))}
        </select>

        <select
          className="text-xs font-medium px-3 py-2.5 rounded-lg border border-slate-200 bg-slate-50 focus:outline-hidden"
          value={filterStatus}
          onChange={(e) => setFilterStatus(e.target.value as any)}
        >
          <option value="SEMUA">Semua Status</option>
          <option value="ONLINE">ONLINE (Connected)</option>
          <option value="OFFLINE">OFFLINE (Disconnected)</option>
        </select>
      </div>

      {/* Connection Secret Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse font-sans text-xs">
            <thead className="bg-slate-50 border-b border-slate-100 text-slate-500 uppercase tracking-wider font-bold">
              <tr>
                <th className="p-4">Username PPPoE</th>
                <th className="p-4">Server Mikrotik</th>
                <th className="p-4">Profil Layanan</th>
                <th className="p-4">Alamat IP (Local / Remote)</th>
                <th className="p-4 text-center">Status Sesi</th>
                <th className="p-4 text-center">Tindakan</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {filteredList.map((u) => (
                <tr key={u.id} className="hover:bg-slate-50/50 transition">
                  <td className="p-4 font-mono font-bold text-slate-800 flex items-center gap-2">
                    <Cable size={14} className="text-indigo-400" /> {u.username}
                  </td>
                  <td className="p-4 text-slate-550">{u.serverName}</td>
                  <td className="p-4">
                    <span className="bg-indigo-50 text-indigo-700 px-2 py-1 rounded border border-indigo-100/50 font-bold">
                      {u.profileName}
                    </span>
                  </td>
                  <td className="p-4 font-mono text-slate-500">
                    {u.localAddress || '10.10.10.1'} &rarr; <strong className="text-slate-700">{u.remoteAddress || '-'}</strong>
                  </td>
                  <td className="p-4 text-center">
                    <button
                      onClick={() => handleTogglePppoeStatus(u)}
                      className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black tracking-wide border cursor-pointer ${
                        u.status === 'ONLINE'
                          ? 'bg-emerald-50 text-emerald-600 border-emerald-150 hover:bg-rose-50 hover:text-rose-600 hover:border-rose-150'
                          : 'bg-rose-50 text-rose-600 border-rose-150 hover:bg-emerald-50 hover:text-emerald-600 hover:border-emerald-150'
                      }`}
                      title="Klik untuk simulasi diskoneksi / hubungkan ulang"
                    >
                      {u.status === 'ONLINE' ? 'ONLINE (Kick)' : 'OFFLINE (Dial)'}
                    </button>
                  </td>
                  <td className="p-4 text-center">
                    <button
                      onClick={() => onDeletePppoe(u.id)}
                      className="p-1 px-2 bg-slate-50 text-slate-400 hover:bg-rose-50 hover:text-rose-500 rounded border border-slate-100 font-bold hover:border-rose-200 transition"
                      title="Remove secret dari Router"
                    >
                      Hapus Secret
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* CREATE SECRET DIALOG */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl shadow-xl w-full max-w-md overflow-hidden border border-slate-100">
            <div className="flex justify-between items-center bg-slate-50 px-6 py-4 border-b border-slate-100">
              <h4 className="font-extrabold text-slate-800 flex items-center gap-2 text-sm">
                <Cable size={18} className="text-indigo-600" />
                Daftarkan User PPPoE Baru (Secret)
              </h4>
              <button onClick={() => setIsModalOpen(false)} className="p-1 hover:bg-slate-200 rounded-lg text-slate-400 transition">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs font-semibold text-slate-700">
              <div className="space-y-1">
                <label>Pilih Router Mikrotik Tujuan *</label>
                <select
                  className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden"
                  value={formData.serverName}
                  onChange={(e) => setFormData({ ...formData, serverName: e.target.value })}
                >
                  {servers.map((s, i) => (
                    <option key={i} value={s.nama}>{s.nama} ({s.ipAddress})</option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label>Nama Pengguna (Secret User) *</label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: agus_rt03"
                    className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-mono"
                    value={formData.username}
                    onChange={(e) => setFormData({ ...formData, username: e.target.value.toLowerCase().trim() })}
                  />
                </div>

                <div className="space-y-1">
                  <label>Sandi (PPPoE Password) *</label>
                  <input
                    type="text"
                    required
                    className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-mono font-bold"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label>User Profile (Limitasi Limit-At/Bandwidth)</label>
                <select
                  className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden"
                  value={formData.profileName}
                  onChange={(e) => setFormData({ ...formData, profileName: e.target.value })}
                >
                  <option value="Paket Hemat 5M">Paket Hemat 5M (5000k/5000k)</option>
                  <option value="Paket Keluarga 10M">Paket Keluarga 10M (10000k/10000k)</option>
                  <option value="Paket Premium 20M">Paket Premium 20M (20000k/20000k)</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label>Alamat Lokal Gateway</label>
                  <input
                    type="text"
                    className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-mono text-center"
                    value={formData.localAddress}
                    onChange={(e) => setFormData({ ...formData, localAddress: e.target.value })}
                  />
                </div>
                <div className="space-y-1">
                  <label>Alamat IP Remote Pelanggan</label>
                  <input
                    type="text"
                    className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-mono text-center"
                    value={formData.remoteAddress}
                    onChange={(e) => setFormData({ ...formData, remoteAddress: e.target.value })}
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition cursor-pointer shadow-sm"
                >
                  Buat Secret PPPoE
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
