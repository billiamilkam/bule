import React, { useState } from 'react';
import { PesananAgen, Reseller, Paket } from '../types';
import { formatRupiah, formatTanggalIndo } from '../utils';
import { ClipboardList, Plus, Trash2, Edit3, Search, ShoppingBag, CheckCircle, Clock, Filter, X, User, Tag, HelpCircle, Save, AlertCircle } from 'lucide-react';

interface PesananAgenTabProps {
  pesanan: PesananAgen[];
  resellers: Reseller[];
  paket: Paket[];
  onAddPesanan: (p: Omit<PesananAgen, 'id'>) => void;
  onUpdatePesanan: (p: PesananAgen) => void;
  onDeletePesanan: (id: string) => void;
}

export default function PesananAgenTab({
  pesanan,
  resellers,
  paket,
  onAddPesanan,
  onUpdatePesanan,
  onDeletePesanan
}: PesananAgenTabProps) {
  const [search, setSearch] = useState('');
  const [filterMonth, setFilterMonth] = useState('SEMUA');
  const [filterStatus, setFilterStatus] = useState('SEMUA'); // "SEMUA", "LUNAS", "BELUM_LUNAS"

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingPesanan, setEditingPesanan] = useState<PesananAgen | null>(null);
  const [customStatusInput, setCustomStatusInput] = useState('');
  const [orderToDelete, setOrderToDelete] = useState<PesananAgen | null>(null);

  // Manual Order state
  const [formData, setFormData] = useState({
    resellerId: '',
    voucherCode: '',
    paketId: '',
    jumlahTagihan: 5000,
    status: 'BELUM BAYAR',
    catatan: ''
  });

  const months = Array.from(new Set(pesanan.map(p => p.bulan))).sort();

  // Handle open status edit modal
  const openEditStatusModal = (p: PesananAgen) => {
    setEditingPesanan(p);
    setCustomStatusInput(p.status);
  };

  // Submit edits
  const handleUpdateStatusSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingPesanan) return;
    onUpdatePesanan({
      ...editingPesanan,
      status: customStatusInput || 'LUNAS'
    });
    setEditingPesanan(null);
  };

  // Quick Lunasi
  const handleQuickLunas = (p: PesananAgen) => {
    onUpdatePesanan({
      ...p,
      status: 'LUNAS'
    });
  };

  // Create manual form submit
  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const agent = resellers.find(r => r.id === formData.resellerId);
    if (!agent) {
      alert('Pilih agen terlebih dahulu!');
      return;
    }
    if (!formData.voucherCode.trim()) {
      alert('Kode voucher (Nama Data Agen) harus diisi!');
      return;
    }

    const pkt = paket.find(pk => pk.id === formData.paketId);
    const currentDate = new Date().toISOString().substring(0, 10);
    const currentMonth = new Date().toISOString().substring(0, 7);

    onAddPesanan({
      resellerId: agent.id,
      resellerNama: agent.nama,
      resellerWilayah: agent.wilayah || 'Umum',
      resellerNoHp: agent.noHp,
      voucherCode: formData.voucherCode.trim(),
      paketId: formData.paketId,
      paketNama: pkt ? pkt.nama : 'Paket Custom',
      jumlahTagihan: formData.jumlahTagihan,
      status: formData.status.trim() || 'BELUM BAYAR',
      tanggalPesan: currentDate,
      bulan: currentMonth,
      catatan: formData.catatan
    });

    setIsAddModalOpen(false);
    // reset form
    setFormData({
      resellerId: '',
      voucherCode: '',
      paketId: paket[0]?.id || '',
      jumlahTagihan: paket[0]?.harga || 5000,
      status: 'BELUM BAYAR',
      catatan: ''
    });
  };

  const handlePaketChange = (pId: string) => {
    const pkt = paket.find(p => p.id === pId);
    setFormData({
      ...formData,
      paketId: pId,
      jumlahTagihan: pkt ? pkt.harga : 5000
    });
  };

  // Filter logic
  const filteredPesanan = pesanan.filter((p) => {
    const q = search.toLowerCase();
    const matchSearch =
      p.resellerNama.toLowerCase().includes(q) ||
      p.voucherCode.toLowerCase().includes(q) ||
      p.status.toLowerCase().includes(q) ||
      p.paketNama.toLowerCase().includes(q);

    const matchMonth = filterMonth === 'SEMUA' || p.bulan === filterMonth;
    
    let matchStat = true;
    if (filterStatus === 'LUNAS') {
      matchStat = p.status.toLowerCase().includes('lunas');
    } else if (filterStatus === 'BELUM_LUNAS') {
      matchStat = !p.status.toLowerCase().includes('lunas');
    }

    return matchSearch && matchMonth && matchStat;
  });

  // Calculate statistics
  const totalInvoiced = filteredPesanan.reduce((sum, item) => sum + item.jumlahTagihan, 0);
  const totalLunasItems = filteredPesanan.filter(item => item.status.toLowerCase().includes('lunas'));
  const totalBelumLunasItems = filteredPesanan.filter(item => !item.status.toLowerCase().includes('lunas'));

  const sumLunas = totalLunasItems.reduce((sum, item) => sum + item.jumlahTagihan, 0);
  const sumBelumLunas = totalBelumLunasItems.reduce((sum, item) => sum + item.jumlahTagihan, 0);

  return (
    <div id="pesanan-agen-tab" className="space-y-6">
      
      {/* Header Panel */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
            <ClipboardList className="text-indigo-600" />
            Pesanan Bulanan Agen Hotspot
          </h2>
          <p className="text-xs text-slate-500">
            Sistem pencatatan otomatis pesanan voucher hotspot manual yang dikaitkan berdasarkan nama / data agen.
          </p>
        </div>

      </div>

      {/* Info Warning Bar */}
      <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 text-xs text-amber-800 leading-relaxed flex items-start gap-2.5">
        <HelpCircle size={16} className="text-amber-600 shrink-0 mt-0.5" />
        <div>
          <strong className="font-bold">Informasi Sistem Otomasi:</strong>
          <span className="ml-1">
            Setiap kali Anda membuat voucher hotspot manual di menu <strong className="text-amber-900">"Hotspot Voucher" &rarr; "Tambah User Manual"</strong> dengan username / kode voucher yang mengandung atau sama dengan nama agen, pesanan akan secara otomatis ter-input ke tabel di bawah ini beserta tagihannya. Anda bebas mengatur kata statusnya menjadi "Lunas", "Lunas Transfer", atau kata apa pun sesuai kebutuhan Anda!
          </span>
        </div>
      </div>

      {/* Stats Counter Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-slate-50 p-4 rounded-xl border border-slate-150 text-slate-700">
          <p className="text-[10px] uppercase font-bold tracking-wider text-slate-400">Total Transaksi Pesanan</p>
          <h3 className="text-xl font-black text-slate-800 mt-1">
            {filteredPesanan.length} <span className="text-xs font-normal text-slate-400">pesanan</span>
          </h3>
        </div>
        <div className="bg-emerald-50/50 p-4 rounded-xl border border-emerald-100 text-slate-700">
          <p className="text-[10px] uppercase font-bold tracking-wider text-emerald-600">Total Dana Tertagih</p>
          <h3 className="text-xl font-black text-emerald-600 mt-1">
            {formatRupiah(sumLunas)}
          </h3>
          <p className="text-[9px] text-slate-400 mt-1">{totalLunasItems.length} transaksi berstatus Lunas</p>
        </div>
        <div className="bg-rose-50/50 p-4 rounded-xl border border-rose-100 text-slate-700">
          <p className="text-[10px] uppercase font-bold tracking-wider text-rose-600">Tunggakan Belum Lunas</p>
          <h3 className="text-xl font-black text-rose-600 mt-1">
            {formatRupiah(sumBelumLunas)}
          </h3>
          <p className="text-[9px] text-slate-400 mt-1">{totalBelumLunasItems.length} transaksi masih berstatus piutang</p>
        </div>
        <div className="bg-indigo-50/50 p-4 rounded-xl border border-indigo-100 text-slate-700">
          <p className="text-[10px] uppercase font-bold tracking-wider text-indigo-600">Total Akumulasi Nilai</p>
          <h3 className="text-xl font-black text-indigo-600 mt-1">
            {formatRupiah(totalInvoiced)}
          </h3>
          <p className="text-[9px] text-slate-400 mt-1">Semua pesanan hotspot agen yang terdaftar</p>
        </div>
      </div>

      {/* Filter and Search controls */}
      <div className="bg-slate-50 p-4 rounded-2xl border border-slate-150 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="relative max-w-md w-full">
          <Search size={16} className="absolute left-3 top-3 text-slate-400" />
          <input
            type="text"
            placeholder="Cari Agen, Kode Voucher, Status, atau Paket..."
            className="w-full bg-white text-xs pl-9 pr-3 py-2.5 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-medium placeholder:text-slate-400 text-slate-800"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Month filter */}
          <div className="flex items-center gap-1.5 bg-white border border-slate-200 py-1.5 px-3 rounded-lg text-xs">
            <Filter size={13} className="text-slate-400" />
            <span className="text-slate-400 font-bold text-[10px] uppercase mr-1">Bulan:</span>
            <select
              className="focus:outline-hidden text-slate-700 font-bold bg-transparent pr-2"
              value={filterMonth}
              onChange={(e) => setFilterMonth(e.target.value)}
            >
              <option value="SEMUA">Semua Bulan</option>
              {months.map((m, i) => (
                <option key={i} value={m}>{m}</option>
              ))}
            </select>
          </div>

          {/* Status filter */}
          <div className="flex items-center gap-1.5 bg-white border border-slate-200 py-1.5 px-3 rounded-lg text-xs">
            <Filter size={13} className="text-slate-400" />
            <span className="text-slate-400 font-bold text-[10px] uppercase mr-1">Status:</span>
            <select
              className="focus:outline-hidden text-slate-700 font-bold bg-transparent pr-2"
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
            >
              <option value="SEMUA">Semua Status</option>
              <option value="LUNAS">Sudah Lunas</option>
              <option value="BELUM_LUNAS">Belum Lunas</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Table View */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[10px] tracking-wider border-b border-slate-150">
              <tr>
                <th className="p-4">Tanggal & Periode</th>
                <th className="p-4">Data Agen (Pemesan)</th>
                <th className="p-4">Hotspot User Manual</th>
                <th className="p-4">Paket / Layanan</th>
                <th className="p-4 text-right">Jumlah Tagihan</th>
                <th className="p-4 text-center">Status Pembayaran</th>
                <th className="p-4 text-center">Aksi Operasi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-150 text-slate-650 font-medium font-sans">
              {filteredPesanan.map((p) => {
                const isLunas = p.status.toLowerCase().includes('lunas');
                return (
                  <tr key={p.id} className="hover:bg-slate-50/50">
                    <td className="p-4">
                      <div className="font-bold text-slate-800">{formatTanggalIndo(p.tanggalPesan)}</div>
                      <div className="text-[10px] text-slate-400 font-mono mt-0.5">Periode: {p.bulan}</div>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-full bg-slate-100 flex items-center justify-center text-slate-500 font-bold text-[10px]">
                          <User size={13} />
                        </div>
                        <div>
                          <div className="font-bold text-slate-800-snug">{p.resellerNama}</div>
                          <div className="text-[10px] text-slate-400">{p.resellerWilayah} | {p.resellerNoHp}</div>
                        </div>
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="inline-flex items-center gap-1.5 px-2 py-1 bg-slate-100 border border-slate-200 text-slate-800 font-mono font-bold rounded-lg uppercase">
                        <Tag size={11} className="text-indigo-500" />
                        <span>{p.voucherCode}</span>
                      </div>
                    </td>
                    <td className="p-4 font-bold text-slate-700">
                      <div>{p.paketNama}</div>
                    </td>
                    <td className="p-4 text-right font-black font-mono text-slate-850 text-sm">
                      {formatRupiah(p.jumlahTagihan)}
                    </td>
                    <td className="p-4 text-center">
                      <div className="inline-block relative">
                        <span className={`inline-flex items-center px-3 py-1 font-extrabold rounded-full text-[10px] border tracking-wider uppercase ${
                          isLunas
                            ? 'bg-emerald-50 border-emerald-200 text-emerald-700' 
                            : 'bg-amber-50 border-amber-200 text-amber-700'
                        }`}>
                          {isLunas ? '✅' : '⏳'} {p.status}
                        </span>
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center justify-center gap-1.5 text-xs">
                        {!isLunas && (
                          <button
                            onClick={() => handleQuickLunas(p)}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-black font-sans uppercase text-[9px] transition cursor-pointer"
                            title="Tandai langsung sebagai kata 'LUNAS'"
                          >
                            <CheckCircle size={12} /> Set Lunas
                          </button>
                        )}
                        <button
                          onClick={() => openEditStatusModal(p)}
                          className="p-1 px-2 text-slate-500 bg-slate-100 hover:bg-slate-200 rounded-lg border border-slate-200/60 transition cursor-pointer flex items-center gap-1"
                          title="Ubah kata status berbayar secara spesifik"
                        >
                          <Edit3 size={12} /> 
                          <span className="text-[9px] font-bold">Ubah Status</span>
                        </button>
                        <button
                          onClick={() => setOrderToDelete(p)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                          title="Hapus pencatatan"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {filteredPesanan.length === 0 && (
          <div className="text-center py-16 text-slate-500 font-medium">
            <ShoppingBag size={32} className="mx-auto text-slate-300 mb-2" />
            <p className="text-sm">Belum ada pesanan ditemukan</p>
            <p className="text-xs text-slate-400 mt-1">Gunakan form manual atau buat voucher hotspot dengan mencocokkan nama agen.</p>
          </div>
        )}
      </div>

      {/* MODAL 1: ADD PESANAN MANUAL */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl shadow-xl w-full max-w-md overflow-hidden border border-slate-100">
            <div className="flex justify-between items-center bg-slate-50 px-6 py-4 border-b border-slate-100">
              <h4 className="font-extrabold text-slate-800 flex items-center gap-2 text-sm">
                <ClipboardList size={18} className="text-indigo-600" />
                Tambah Catatan Pesanan Agen Hotspot Manual
              </h4>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1 hover:bg-slate-200 rounded-lg text-slate-400 transition"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="p-6 space-y-4 text-xs font-semibold text-slate-700">
              <div className="space-y-1">
                <label className="text-slate-600 font-bold">Pilih Agen / Reseller Pemesan *</label>
                <select
                  className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden text-slate-800"
                  value={formData.resellerId}
                  onChange={(e) => setFormData({ ...formData, resellerId: e.target.value })}
                  required
                >
                  <option value="">-- Pilih Agen --</option>
                  {resellers.map((r, i) => (
                    <option key={i} value={r.id}>🏢 {r.nama} ({r.wilayah})</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-slate-600 font-bold">Kode Voucher / Nama Data Agen *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: wifi_agen_sukses"
                  className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-bold font-mono text-slate-800 text-center uppercase"
                  value={formData.voucherCode}
                  onChange={(e) => setFormData({ ...formData, voucherCode: e.target.value })}
                />
                <p className="text-[10px] text-slate-400 font-normal mt-0.5">Kode atau User Hotspot yang diberikan kepada agen.</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-slate-600 font-bold">Layanan / Profil *</label>
                  <select
                    className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden text-slate-800 whitespace-nowrap"
                    value={formData.paketId}
                    onChange={(e) => handlePaketChange(e.target.value)}
                    required
                  >
                    <option value="">-- Hubungkan Profil --</option>
                    {paket.map((p, idx) => (
                      <option key={idx} value={p.id}>{p.nama} ({p.kecepatan})</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-slate-600 font-bold">Kata Status (Default) *</label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: BELUM BAYAR"
                    className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-bold text-slate-800 font-mono text-center"
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-slate-600 font-bold">Jumlah Tagihan (Rupiah) *</label>
                <input
                  type="number"
                  required
                  min={0}
                  className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-bold font-mono text-slate-800 text-sm"
                  value={formData.jumlahTagihan}
                  onChange={(e) => setFormData({ ...formData, jumlahTagihan: parseInt(e.target.value) || 0 })}
                />
              </div>

              <div className="space-y-1">
                <label className="text-slate-600 font-bold">Catatan Kecil</label>
                <textarea
                  rows={2}
                  placeholder="Memo tambahan jika ada (misal: pembayaran via gopay)"
                  className="w-full bg-slate-50 p-2 rounded-lg border border-slate-200 focus:outline-hidden text-slate-800 font-medium"
                  value={formData.catatan}
                  onChange={(e) => setFormData({ ...formData, catatan: e.target.value })}
                />
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl font-bold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition cursor-pointer shadow-sm"
                >
                  Simpan Pesanan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL 2: EDIT CUSTOM PAYMENT STATUS WORDS */}
      {editingPesanan && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl shadow-xl w-full max-w-sm overflow-hidden border border-slate-100">
            <div className="flex justify-between items-center bg-slate-50 px-6 py-4 border-b border-slate-100">
              <h4 className="font-extrabold text-slate-800 flex items-center gap-1.5 text-xs uppercase tracking-wider">
                <Edit3 size={15} className="text-indigo-600" />
                Ubah Kata Status Pembayaran
              </h4>
              <button
                onClick={() => setEditingPesanan(null)}
                className="p-1 hover:bg-slate-200 rounded-lg text-slate-400 transition"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleUpdateStatusSubmit} className="p-6 space-y-4 text-xs font-semibold text-slate-700">
              <div className="bg-slate-50 p-3 rounded-2xl border border-slate-150 leading-normal mb-1">
                <p className="text-[10px] text-slate-400 font-bold uppercase">Agen Pemesan</p>
                <p className="font-bold text-slate-800 text-sm mt-0.5">{editingPesanan.resellerNama}</p>
                <p className="text-[10px] text-slate-500 font-mono mt-1">Layanan {editingPesanan.paketNama} ({formatRupiah(editingPesanan.jumlahTagihan)})</p>
              </div>

              <div className="space-y-1">
                <label className="text-slate-600 font-bold">Status Berbayar (Sandi Bebas) *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: LUNAS, lunas transfer bca, bayar cash"
                  className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-bold font-mono text-slate-800 text-center uppercase"
                  value={customStatusInput}
                  onChange={(e) => setCustomStatusInput(e.target.value)}
                />
                <p className="text-[10px] text-slate-400 font-normal mt-1 leading-normal">
                  Sesuai pesanan Anda, jika kata status mengandung unsur kata <strong className="text-indigo-600">"LUNAS"</strong> (e.g. "Lunas", "Sudah Lunas Transfer"), sistem akan menganggapnya lunas dan memberi tanda centang hijau secara dinamis!
                </p>
              </div>

              {/* Suggestions */}
              <div className="space-y-1.5">
                <span className="text-[9px] uppercase text-slate-400 tracking-wider block font-bold">Rekomendasi Cepat:</span>
                <div className="flex flex-wrap gap-1.5">
                  {['LUNAS', 'LUNAS (TRANSFER BCA)', 'LUNAS (TUNAI / CASH)', 'BELUM BAYAR', 'PIUTANG AGEN'].map((word, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setCustomStatusInput(word)}
                      className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-650 rounded text-[10px] font-bold border border-slate-200 transition cursor-pointer"
                    >
                      {word}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditingPesanan(null)}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 rounded-lg font-bold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-indigo-600 text-white rounded-lg font-bold hover:bg-indigo-700 transition cursor-pointer shadow-sm flex items-center gap-1"
                >
                  <Save size={13} /> Simpan Perubahan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CUSTOM CONFIRMATION MODAL FOR DELETING MONTHLY ORDER */}
      {orderToDelete && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xl w-full max-w-sm overflow-hidden p-6 space-y-4">
            <div className="flex items-center gap-3 text-rose-650">
              <div className="p-2 bg-rose-50 rounded-full text-rose-600">
                <AlertCircle size={20} />
              </div>
              <h4 className="font-bold text-slate-800 text-sm">Konfirmasi Hapus Pesanan</h4>
            </div>
            
            <div className="text-xs text-slate-500 leading-relaxed space-y-2">
              <p>Apakah Anda yakin ingin menghapus pencatatan pesanan ini?</p>
              <div className="p-2.5 bg-slate-55/75 border border-slate-150 rounded-xl font-mono text-[10px] text-slate-700 leading-normal space-y-0.5">
                <div>💥 <strong>Agen:</strong> {orderToDelete.resellerNama}</div>
                <div>🏷️ <strong>Kode:</strong> {orderToDelete.voucherCode}</div>
                <div>💰 <strong>Tagihan:</strong> {formatRupiah(orderToDelete.jumlahTagihan)}</div>
              </div>
              <p className="text-[10px] text-rose-500">
                *Tindakan ini permanen dan tidak dapat dibatalkan.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setOrderToDelete(null)}
                className="px-3.5 py-2 hover:bg-slate-100 text-slate-500 hover:text-slate-700 rounded-xl font-semibold text-xs transition cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeletePesanan(orderToDelete.id);
                  setOrderToDelete(null);
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold text-xs transition cursor-pointer shadow-xs font-sans"
              >
                Ya, Hapus
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
