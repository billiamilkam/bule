import React, { useState } from 'react';
import { Paket, Pelanggan } from '../types';
import { formatRupiah } from '../utils';
import { Wifi, Plus, Edit2, Trash2, X, AlertTriangle } from 'lucide-react';

interface PaketTabProps {
  paket: Paket[];
  pelanggan: Pelanggan[];
  onAddPaket: (p: Omit<Paket, 'id'>) => void;
  onUpdatePaket: (p: Paket) => void;
  onDeletePaket: (id: string) => void;
}

export default function PaketTab({
  paket,
  pelanggan,
  onAddPaket,
  onUpdatePaket,
  onDeletePaket
}: PaketTabProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingPaket, setEditingPaket] = useState<Paket | null>(null);

  const [formData, setFormData] = useState({
    nama: '',
    kecepatan: '',
    harga: 50000,
    deskripsi: '',
    mikrotikProfile: ''
  });

  // Open modal for Adding
  const openAddModal = () => {
    setFormData({
      nama: '',
      kecepatan: '',
      harga: 100000,
      deskripsi: '',
      mikrotikProfile: 'hs-paket-baru'
    });
    setEditingPaket(null);
    setIsModalOpen(true);
  };

  // Open modal for Editing
  const openEditModal = (pkt: Paket) => {
    setEditingPaket(pkt);
    setFormData({
      nama: pkt.nama,
      kecepatan: pkt.kecepatan,
      harga: pkt.harga,
      deskripsi: pkt.deskripsi,
      mikrotikProfile: pkt.mikrotikProfile || ''
    });
    setIsModalOpen(true);
  };

  // Submit Handler
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.nama.trim() || !formData.kecepatan.trim() || !formData.harga) {
      alert('Nama, Kecepatan, dan Harga harus diisi!');
      return;
    }

    if (editingPaket) {
      onUpdatePaket({
        ...editingPaket,
        ...formData
      });
    } else {
      onAddPaket(formData);
    }

    setIsModalOpen(false);
  };

  return (
    <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm space-y-6">
      
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-lg font-bold text-slate-800">📶 Paket Layanan RT RW Net</h3>
          <p className="text-xs text-slate-500">Sesuaikan profil bandwidth kecepatan dan penetapan tarif dasar pelanggan Anda.</p>
        </div>
        <button
          onClick={openAddModal}
          className="inline-flex items-center gap-1 px-4 py-2 bg-indigo-600 text-white rounded-xl font-semibold text-sm hover:bg-indigo-700 transition cursor-pointer shadow-sm"
        >
          <Plus size={16} /> Tambah Paket
        </button>
      </div>

      {/* Grid List of Packets */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {paket.map((pkt) => {
          // Count subscriber using this package
          const listSubscribers = pelanggan.filter((p) => p.paketId === pkt.id);
          const activeSubs = listSubscribers.filter(p => p.statusAktif).length;
          
          return (
            <div 
              key={pkt.id} 
              className="bg-slate-50/50 p-5 rounded-2xl border border-slate-150/60 shadow-xs flex flex-col justify-between hover:border-indigo-200 transition duration-300 relative group"
            >
              <div>
                {/* Visual Icon and Tag */}
                <div className="flex items-center justify-between mb-4">
                  <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
                    <Wifi size={18} />
                  </div>
                  <span className="text-[10px] font-bold font-mono text-slate-400">ID: {pkt.id}</span>
                </div>

                {/* Packet Name & Speed */}
                <div>
                  <h4 className="font-bold text-slate-800 text-base">{pkt.nama}</h4>
                  <p className="text-2xl font-black text-indigo-600 mt-1 font-sans">
                    {pkt.kecepatan}
                  </p>
                </div>

                {/* Description */}
                <p className="text-xs text-slate-500 mt-3 leading-relaxed">
                  {pkt.deskripsi || 'Tidak ada deskripsi layanan.'}
                </p>
              </div>

              {/* Pricing, counts & actions */}
              <div className="mt-6 pt-4 border-t border-slate-100 flex flex-col gap-3">
                <div className="flex justify-between items-baseline">
                  <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400">Tarif Bulanan</span>
                  <span className="text-lg font-extrabold text-slate-800 font-sans">{formatRupiah(pkt.harga)}</span>
                </div>

                <div className="flex justify-between items-center bg-white px-3 py-1.5 rounded-lg border border-slate-100 text-[11px]">
                  <span className="text-slate-500 font-medium">Pelanggan Aktif:</span>
                  <span className="font-bold text-slate-800">{activeSubs} dari {listSubscribers.length} User</span>
                </div>

                <div className="flex justify-between items-center bg-indigo-50/50 px-3 py-1.5 rounded-lg border border-indigo-100 text-[11px]">
                  <span className="text-indigo-700 font-medium font-sans flex items-center gap-1">🌐 Hotspot User Profile:</span>
                  <span className="font-bold font-mono text-indigo-800 bg-white px-1.5 py-0.5 rounded border border-indigo-100 text-[10px] truncate max-w-[150px]">
                    {pkt.mikrotikProfile || 'tidak_set'}
                  </span>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center gap-2 mt-1">
                  <button
                    onClick={() => openEditModal(pkt)}
                    className="flex-1 inline-flex items-center justify-center gap-1 px-3 py-1.5 bg-white border border-slate-200 hover:border-slate-300 hover:bg-slate-100 text-slate-600 rounded-lg text-xs font-semibold transition cursor-pointer"
                  >
                    <Edit2 size={12} /> Sunting
                  </button>
                  <button
                    onClick={() => {
                      if (listSubscribers.length > 0) {
                        alert(`Gagal menghapus! Paket ini masih digunakan oleh ${listSubscribers.length} pelanggan. Silakan ubah paket pelanggan tersebut terlebih dahulu.`);
                        return;
                      }
                      if (confirm(`Yakin ingin menghapus paket "${pkt.nama}"?`)) {
                        onDeletePaket(pkt.id);
                      }
                    }}
                    className="p-1.5 bg-white hover:bg-rose-50 border border-slate-200 hover:border-rose-100 text-rose-400 hover:text-rose-600 rounded-lg transition cursor-pointer"
                    title="Hapus Paket"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* CRUD MODAL FOR PACKET */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xl w-full max-w-md overflow-hidden animate-zoomIn">
            
            {/* Modal Header */}
            <div className="flex justify-between items-center bg-slate-50 px-6 py-4 border-b border-slate-100">
              <h4 className="font-bold text-slate-800 flex items-center gap-2 text-sm">
                <Wifi size={18} className="text-indigo-600" />
                {editingPaket ? 'Sunting Paket Kecepatan' : 'Tambah Paket Internet Baru'}
              </h4>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 hover:bg-slate-200 text-slate-400 hover:text-slate-600 rounded-lg transition cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal Form */}
            <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs text-slate-600">
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Nama Paket *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Paket Keluarga Super, Paket Hemat"
                  className="w-full bg-slate-50 px-3 py-2.5 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-medium"
                  value={formData.nama}
                  onChange={(e) => setFormData({ ...formData, nama: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="font-semibold text-slate-700">Bandwidth / Kecepatan *</label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: 10 Mbps, 50 Mbps"
                    className="w-full bg-slate-50 px-3 py-2.5 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-medium font-mono"
                    value={formData.kecepatan}
                    onChange={(e) => setFormData({ ...formData, kecepatan: e.target.value })}
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-slate-700">Harga per Bulan *</label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-slate-400 font-bold">Rp</span>
                    <input
                      type="number"
                      required
                      min={0}
                      className="w-full bg-slate-50 pl-8 pr-3 py-2.5 rounded-lg border border-slate-200 font-bold font-mono focus:outline-hidden focus:border-indigo-500"
                      value={formData.harga}
                      onChange={(e) => setFormData({ ...formData, harga: parseInt(e.target.value) || 0 })}
                    />
                  </div>
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Deskripsi Paket Layanan</label>
                <textarea
                  placeholder="Keterangan singkat limitasi peranti atau sasaran paket..."
                  rows={2}
                  className="w-full bg-slate-50 px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-medium"
                  value={formData.deskripsi}
                  onChange={(e) => setFormData({ ...formData, deskripsi: e.target.value })}
                />
              </div>

              <div className="space-y-1.5 bg-indigo-50/40 p-3 rounded-xl border border-indigo-100/50">
                <div className="flex justify-between items-center">
                  <label className="font-bold text-indigo-900 flex items-center gap-1">
                    🌐 MikroTik Hotspot User Profile *
                  </label>
                  <span className="text-[9px] text-indigo-600 bg-white px-1.5 py-0.5 rounded-xl border border-indigo-150 font-extrabold tracking-wide uppercase">Terintegrasi</span>
                </div>
                <input
                  type="text"
                  required
                  placeholder="Sandi nama profile di router (contoh: hs-hemat-5M)"
                  className="w-full bg-white px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-bold font-mono text-indigo-800 text-[11px]"
                  value={formData.mikrotikProfile}
                  onChange={(e) => {
                    const sanitized = e.target.value.replace(/\s+/g, '-');
                    setFormData({ ...formData, mikrotikProfile: sanitized });
                  }}
                />
                <p className="text-[10px] text-slate-400 font-normal leading-relaxed mt-0.5">
                  Profil nama wajib sama persis dengan di MikroTik (<code className="bg-slate-100/80 px-1 py-0.2 rounded font-mono text-slate-600">/ip hotspot user profile</code>) agar limitasi kecepatan, masa aktif, dan share-users router sinkron.
                </p>
              </div>

              <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 hover:bg-slate-100 rounded-xl font-semibold hover:text-slate-800 transition cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition cursor-pointer shadow-sm"
                >
                  {editingPaket ? 'Simpan' : 'Simpan Paket'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}
