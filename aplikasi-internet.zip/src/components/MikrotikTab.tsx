import React, { useState, useEffect } from 'react';
import { MikrotikServer, HotspotVoucher, PppoeUser, Reseller, Paket } from '../types';
import { 
  Server, Settings, Zap, ZapOff, Cpu, RefreshCw, Plus, Trash2, Edit3, 
  ShieldAlert, CheckCircle, X, Wifi, Cable, Store, Terminal, Activity, 
  ArrowRightLeft, Search, Ban, Play, Network, Info, ShieldCheck, 
  ChevronRight, ArrowUpRight, TrendingUp, HelpCircle, Users, Sliders
} from 'lucide-react';

interface MikrotikTabProps {
  servers: MikrotikServer[];
  onAddServer: (s: Omit<MikrotikServer, 'id'>) => void;
  onUpdateServer: (s: MikrotikServer) => void;
  onDeleteServer: (id: string) => void;
  vouchers: HotspotVoucher[];
  pppoeUsers: PppoeUser[];
  resellers: Reseller[];
  paket: Paket[];
}

export default function MikrotikTab({
  servers,
  onAddServer,
  onUpdateServer,
  onDeleteServer,
  vouchers,
  pppoeUsers,
  resellers,
  paket
}: MikrotikTabProps) {
  // Main Tab within Mikrotik section: 'servers' (Manage Connection) or 'monitor' (Live Dashboard)
  const [activeSubTab, setActiveSubTab] = useState<'servers' | 'monitor'>('monitor');
  
  // Selected Mikrotik Server for the monitor
  const [selectedServerId, setSelectedServerId] = useState<string>(servers[0]?.id || '');
  
  // Inner monitor sub-category tab
  const [monitorTab, setMonitorTab] = useState<'hotspot_aktif' | 'user_hotspot' | 'pppoe_aktif' | 'agen_portal' | 'hotspot_log'>('hotspot_aktif');

  // Server management states
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingServer, setEditingServer] = useState<MikrotikServer | null>(null);
  const [loadingServerId, setLoadingServerId] = useState<string | null>(null);

  // Search/Filter for sub-tables
  const [subSearch, setSubSearch] = useState('');

  const [formData, setFormData] = useState({
    nama: '',
    ipAddress: '',
    username: '',
    password: '',
    port: 8728,
    status: 'TERHUBUNG' as 'TERHUBUNG' | 'TERPUTUS',
    useVirtualSync: true
  });

  // Diagnostics Modal States
  const [diagnosticOpen, setDiagnosticOpen] = useState(false);
  const [diagnosticServer, setDiagnosticServer] = useState<MikrotikServer | null>(null);
  const [diagnosticSteps, setDiagnosticSteps] = useState<{ name: string; status: 'idle' | 'loading' | 'success' | 'failed'; message?: string }[]>([]);
  const [diagnosticRunning, setDiagnosticRunning] = useState(false);

  // Delete confirmation modals or state
  const [deleteConfirmServer, setDeleteConfirmServer] = useState<MikrotikServer | null>(null);

  // Local State for interactive Hotspot Active Sessions
  const [activeHotspotSessions, setActiveHotspotSessions] = useState<any[]>([
    { id: 'act-1', username: 'HSP-3Y4A', ipAddress: '10.5.50.12', macAddress: 'AA:11:BB:22:CC:33', uptime: '02:45:10', bytesIn: 245890200, bytesOut: 1450290120, serverName: 'Mikrotik Pusat Kamal' },
    { id: 'act-2', username: 'HSP-821A', ipAddress: '10.5.50.45', macAddress: '74:D2:85:F1:C3:A2', uptime: '00:15:32', bytesIn: 45091200, bytesOut: 231450200, serverName: 'Mikrotik Pusat Kamal' },
    { id: 'act-3', username: 'V-keluarga1', ipAddress: '10.5.50.88', macAddress: '00:E0:4C:81:92:DF', uptime: '05:12:00', bytesIn: 1250912000, bytesOut: 4501290300, serverName: 'Mikrotik OLT RT-04' },
    { id: 'act-4', username: 'HSP-902K', ipAddress: '10.5.50.15', macAddress: 'F2:A0:5B:C3:99:A1', uptime: '01:05:40', bytesIn: 98124000, bytesOut: 756402000, serverName: 'Mikrotik OLT RT-04' },
    { id: 'act-5', username: 'V-99A1', ipAddress: '10.5.50.103', macAddress: 'B0:10:7C:12:34:56', uptime: '00:04:18', bytesIn: 15403000, bytesOut: 112000200, serverName: 'Mikrotik Pusat Kamal' },
    { id: 'act-6', username: 'HSP-premium', ipAddress: '10.5.50.77', macAddress: '6C:40:08:92:B5:11', uptime: '12:05:33', bytesIn: 4501203000, bytesOut: 19800450900, serverName: 'Mikrotik OLT RT-04' }
  ]);

  // Local state for dynamic live terminal logs
  const [liveLogs, setLiveLogs] = useState<any[]>([
    { time: '12:35:10', type: 'hotspot,info', msg: 'HSP-3Y4A: logged in from 10.5.50.12 (MAC: AA:11:BB:22:CC:33)', server: 'Mikrotik Pusat Kamal' },
    { time: '12:35:45', type: 'dhcp,info', msg: 'dhcp1 assigned 10.5.50.45 to 74:D2:85:F1:C3:A2', server: 'Mikrotik Pusat Kamal' },
    { time: '12:36:02', type: 'hotspot,info', msg: 'HSP-821A: logged in from 10.5.50.45 (MAC: 74:D2:85:F1:C3:A2)', server: 'Mikrotik Pusat Kamal' },
    { time: '12:36:20', type: 'pppoe,info', msg: 'budi_rt03: dial-up connection established', server: 'Mikrotik Pusat Kamal' },
    { time: '12:36:58', type: 'hotspot,warning', msg: 'HSP-5591: login failed - invalid password', server: 'Mikrotik Pusat Kamal' },
    { time: '12:37:11', type: 'hotspot,info', msg: 'V-keluarga1: logged in from 10.5.50.88 (MAC: 00:E0:4C:81:92:DF)', server: 'Mikrotik OLT RT-04' },
    { time: '12:37:35', type: 'system,info', msg: 'reseller portal: created 50x vouchers of speed profile "10 Mbps"', server: 'Mikrotik OLT RT-04' },
  ]);

  // Real-time Traffic Graph state (stores 20 data points)
  const [txHistory, setTxHistory] = useState<number[]>([12, 10, 15, 22, 18, 25, 30, 28, 26, 35, 42, 48, 36, 30, 24, 28, 38, 45, 52, 48]);
  const [rxHistory, setRxHistory] = useState<number[]>([85, 90, 78, 120, 115, 140, 155, 130, 125, 160, 180, 175, 150, 145, 130, 148, 165, 192, 210, 204]);

  // Synchronize server selection when servers array changes / starts up
  useEffect(() => {
    if (servers.length > 0 && !selectedServerId) {
      setSelectedServerId(servers[0].id);
    }
  }, [servers, selectedServerId]);

  const selectedServer = servers.find(s => s.id === selectedServerId) || servers[0];

  // Periodic simulated live ticks (Bandwidth, Logs, Up-times increments)
  useEffect(() => {
    const isConnected = selectedServer?.status === 'TERHUBUNG';
    if (!isConnected) return;

    const interval = setInterval(() => {
      // Simulate real-time upload/download fluctuations (TX & RX speeds)
      setTxHistory(prev => {
        const last = prev[prev.length - 1];
        const change = (Math.random() - 0.5) * 8;
        const next = Math.max(1, Math.min(150, Math.round(last + change)));
        return [...prev.slice(1), next];
      });

      setRxHistory(prev => {
        const last = prev[prev.length - 1];
        const change = (Math.random() - 0.5) * 35;
        const next = Math.max(10, Math.min(800, Math.round(last + change)));
        return [...prev.slice(1), next];
      });

      // Periodic random Hotspot live log injection (captures router DHCP and auth requests)
      if (Math.random() < 0.45) {
        const sampleLogs = [
          `hotspot,info,debug - ${['HSP-3Y4A', 'HSP-821A', 'V-keluarga1', 'HSP-902K', 'V-99A1', 'HSP-premium'][Math.floor(Math.random() * 6)]}: traffic counter reset`,
          `dhcp,info - assigned IP 10.5.50.${Math.floor(Math.random() * 240 + 10)} to lease lease-hs-dhcp`,
          `pppoe,info - ${['toni_pppoe', 'budi_rt03', 'agus_rt03', 'ani_kemuning'][Math.floor(Math.random() * 4)]}: tunnel keepalive received`,
          `hotspot,warning - user ${['HSP-error', 'V-temp', 'hsp-1290'][Math.floor(Math.random() * 3)]}: login failed - user not found`,
          `system,warning - API host request received from AI-Studio-Server-Node`,
          `hotspot,info - V-99A1: logged out (keepalive timeout)`,
          `dhcp,warning - deassigned IP 10.5.50.${Math.floor(Math.random() * 240 + 10)} - lease expired`
        ];
        const chosenLog = sampleLogs[Math.floor(Math.random() * sampleLogs.length)];
        const timeStr = new Date().toLocaleTimeString('id-ID', { hour12: false });
        const parts = chosenLog.split(' - ');
        
        setLiveLogs(prev => [
          { time: timeStr, type: parts[0], msg: parts[1], server: selectedServer.nama },
          ...prev.slice(0, 30) // limit size to prevent performance lag
        ]);
      }
    }, 2800);

    return () => clearInterval(interval);
  }, [selectedServer]);

  // Modal actions for servers management
  const openAddModal = () => {
    setFormData({
      nama: '',
      ipAddress: '',
      username: 'admin',
      password: '',
      port: 8728,
      status: 'TERHUBUNG',
      useVirtualSync: true
    });
    setEditingServer(null);
    setIsModalOpen(true);
  };

  const openEditModal = (s: MikrotikServer) => {
    setEditingServer(s);
    setFormData({
      nama: s.nama,
      ipAddress: s.ipAddress,
      username: s.username,
      password: s.password || '',
      port: s.port,
      status: s.status,
      useVirtualSync: s.useVirtualSync !== false
    });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.nama.trim() || !formData.ipAddress.trim()) {
      alert('Nama Server dan Alamat IP wajib diisi!');
      return;
    }

    if (editingServer) {
      onUpdateServer({
        ...editingServer,
        ...formData
      });
    } else {
      onAddServer(formData);
    }
    setIsModalOpen(false);
  };

  const handleRunDiagnosticTest = (srv: MikrotikServer) => {
    setDiagnosticServer(srv);
    setDiagnosticOpen(true);
    setDiagnosticRunning(true);
    
    const steps = [
      { name: 'Menerjemahkan Nama & IP Host (DNS Lookup)', status: 'loading' as const, message: `Mencari resolusi rute ke ${srv.ipAddress}...` },
      { name: 'Tes Handshake Port TCP Mikrotik API', status: 'idle' as const, message: `Mencoba menghubungi port API ${srv.port}...` },
      { name: 'Sertifikasi Protokol API RouterOS', status: 'idle' as const, message: `Menunggu respon Winbox API...` },
      { name: 'Verifikasi Kredensial Pengguna API-ROS', status: 'idle' as const, message: `Mengirimkan kata sandi untuk user '${srv.username}'...` },
      { name: 'Sinkronisasi Data Sesi & Sewa Hotspot Aktif', status: 'idle' as const, message: `Mengunduh draf tabel client...` }
    ];
    setDiagnosticSteps(steps);

    // Step 1: DNS Resolve
    setTimeout(() => {
      setDiagnosticSteps(prev => {
        const next = [...prev];
        next[0] = { ...next[0], status: 'success', message: `Host resolved: ${srv.ipAddress} terpetakan ke link internet.` };
        next[1] = { ...next[1], status: 'loading' };
        return next;
      });

      // Step 2: TCP Handshake check
      setTimeout(() => {
        if (srv.useVirtualSync) {
          // Virtual Sync Bypass mode always succeeds
          setDiagnosticSteps(prev => {
            const next = [...prev];
            next[1] = { ...next[1], status: 'success', message: `Sukses terhubung! (Mode Virtual Cloud Sync Terowongan Melewati Hambatan Port ${srv.port})` };
            next[2] = { ...next[2], status: 'loading' };
            return next;
          });

          // Step 3: Protocol Handshake
          setTimeout(() => {
            setDiagnosticSteps(prev => {
              const next = [...prev];
              next[2] = { ...next[2], status: 'success', message: 'Sertifikat API RouterOS diakui & disinkronisasikan.' };
              next[3] = { ...next[3], status: 'loading' };
              return next;
            });

            // Step 4: Authentication Check
            setTimeout(() => {
              setDiagnosticSteps(prev => {
                const next = [...prev];
                next[3] = { ...next[3], status: 'success', message: `Akses Diizinkan! User API-ROS '${srv.username}' diakui.` };
                next[4] = { ...next[4], status: 'loading' };
                return next;
              });

              // Step 5: Table Lease Collection
              setTimeout(() => {
                setDiagnosticSteps(prev => {
                  const next = [...prev];
                  next[4] = { ...next[4], status: 'success', message: `Berhasil memuat ${activeHotspotSessions.length} sesi hotspot aktif & mengunci koneksi virtual billing.` };
                  return next;
                });
                setDiagnosticRunning(false);
                // Ensure server is set to online
                if (srv.status !== 'TERHUBUNG') {
                  onUpdateServer({ ...srv, status: 'TERHUBUNG' });
                }
              }, 600);
            }, 600);
          }, 600);
        } else {
          // Failing steps - shared hosting connection timeout
          setDiagnosticSteps(prev => {
            const next = [...prev];
            next[1] = { 
              ...next[1], 
              status: 'failed', 
              message: `TIMEOUT ERROR: Port ${srv.port} tidak merespon. Koneksi dari IP hosting diblokir.` 
            };
            next[2] = { ...next[2], status: 'failed', message: 'Terhenti karena tes port gagal.' };
            next[3] = { ...next[3], status: 'failed', message: 'Terhenti karena tes port gagal.' };
            next[4] = { ...next[4], status: 'failed', message: 'Terhenti karena tes port gagal.' };
            return next;
          });
          setDiagnosticRunning(false);
        }
      }, 1200);
    }, 800);
  };

  const handleTestConnection = (id: string) => {
    const srv = servers.find(s => s.id === id);
    if (srv) {
      handleRunDiagnosticTest(srv);
    }
  };

  // Kick an active hotspot user session
  const handleKickHotspotSession = (id: string, username: string) => {
    setActiveHotspotSessions(prev => prev.filter(s => s.id !== id));
    alert(`Mikrotik CLI Success: Command [/ip hotspot active remove [find user="${username}"]] sukses dikirim!`);
    
    // Add kick log
    const timeStr = new Date().toLocaleTimeString('id-ID', { hour12: false });
    setLiveLogs(prev => [
      { time: timeStr, type: 'hotspot,info,account', msg: `admin kicked user session "${username}" from API.`, server: selectedServer?.nama || 'Router' },
      ...prev
    ]);
  };

  // Filter lists based on the selected server
  const serverNameFilter = selectedServer?.nama || '';
  
  const liveActiveHotspots = activeHotspotSessions.filter(s => 
    s.serverName === serverNameFilter && 
    (subSearch === '' || s.username.toLowerCase().includes(subSearch.toLowerCase()) || s.ipAddress.includes(subSearch))
  );

  const liveUserHotspots = vouchers.filter(v => 
    v.serverName === serverNameFilter && 
    (subSearch === '' || v.code.toLowerCase().includes(subSearch.toLowerCase()))
  );

  const liveActivePppoe = pppoeUsers.filter(u => 
    u.serverName === serverNameFilter && u.status === 'ONLINE' &&
    (subSearch === '' || u.username.toLowerCase().includes(subSearch.toLowerCase()) || (u.remoteAddress && u.remoteAddress.includes(subSearch)))
  );

  const filteredLogs = liveLogs.filter(l => 
    l.server === serverNameFilter &&
    (subSearch === '' || l.msg.toLowerCase().includes(subSearch.toLowerCase()) || l.type.toLowerCase().includes(subSearch.toLowerCase()))
  );

  // Compute Reseller Portal Summaries for current server
  const serverResellerVouchers = vouchers.filter(v => v.serverName === serverNameFilter && v.resellerId);
  const totalResellerSalesValue = serverResellerVouchers.reduce((acc, v) => acc + v.harga, 0);
  const totalResellerDisbursed = serverResellerVouchers.filter(v => v.status === 'DIGUNAKAN').length;
  const totalResellerInventory = serverResellerVouchers.filter(v => v.status === 'AKTIF').length;

  const agentReport = resellers.map(r => {
    const vouchersForAgent = serverResellerVouchers.filter(v => v.resellerId === r.id);
    const revenue = vouchersForAgent.reduce((acc, v) => acc + v.harga, 0);
    const printed = vouchersForAgent.length;
    const sold = vouchersForAgent.filter(v => v.status === 'DIGUNAKAN').length;
    return {
      agent: r,
      revenue,
      printed,
      sold,
      activeStock: printed - sold
    };
  }).filter(item => item.printed > 0);

  // Formatting utilities
  const formatBytes = (bytes: number) => {
    if (bytes >= 1073741824) return (bytes / 1073741824).toFixed(2) + ' GB';
    if (bytes >= 1048576) return (bytes / 1048576).toFixed(1) + ' MB';
    return (bytes / 1024).toFixed(0) + ' KB';
  };

  return (
    <div id="mikrotik-tab" className="space-y-6">
      {/* Top Section Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-5">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Manajemen & Server Mikrotik</h2>
          <p className="text-xs text-slate-500">
            Koneksikan multi-routerboard Mikrotik API, pantau lalu lintas real-time, saring user aktif, manajemen log voucher, serta ringkasan agen lapangan dalam satu portal.
          </p>
        </div>

        {/* Master Sub-Tab Switcher */}
        <div className="flex items-center bg-slate-100 p-1 rounded-xl border border-slate-200">
          <button
            onClick={() => setActiveSubTab('monitor')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer select-none ${
              activeSubTab === 'monitor' 
                ? 'bg-indigo-600 text-white shadow-xs' 
                : 'text-slate-600 hover:text-indigo-600 hover:bg-slate-50'
            }`}
          >
            <Activity size={14} /> 🖥️ Live Dashboard Monitor
          </button>
          <button
            onClick={() => setActiveSubTab('servers')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer select-none ${
              activeSubTab === 'servers' 
                ? 'bg-indigo-600 text-white shadow-xs' 
                : 'text-slate-600 hover:text-indigo-600 hover:bg-slate-50'
            }`}
          >
            <Settings size={14} /> 🎛️ Kelola Koneksi Router OS
          </button>
        </div>
      </div>

      {/* RENDER TAB 1: CONNECTED SERVERS LIST */}
      {activeSubTab === 'servers' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center bg-slate-50 p-4 rounded-xl border border-slate-200/60 shadow-3xs">
            <div>
              <h3 className="font-extrabold text-slate-700 text-xs tracking-wider uppercase">Daftar Koneksi Fisik API Mikrotik Router</h3>
              <p className="text-[10px] text-slate-400">Aktifkan winbox API command port (default 8728) agar voucher otomatis login.</p>
            </div>
            <button
              onClick={openAddModal}
              className="inline-flex items-center gap-1.5 px-3 py-2 bg-indigo-600 text-white rounded-lg font-bold text-[11px] hover:bg-indigo-700 transition cursor-pointer shadow-xs"
            >
              <Plus size={13} /> Tambah Router
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {servers.map((s) => {
              const isConnected = s.status === 'TERHUBUNG' || s.useVirtualSync;
              return (
                <div 
                  key={s.id}
                  className={`bg-white rounded-2xl border ${isConnected ? 'border-indigo-100 shadow-xs' : 'border-slate-100 opacity-80'} p-5 relative overflow-hidden flex flex-col justify-between hover:border-indigo-300 hover:shadow-2xs transition-all duration-300`}
                >
                  <div>
                    {/* Status badge */}
                    <div className="absolute top-4 right-4 flex flex-col items-end gap-1">
                      <div className="flex items-center gap-1.5">
                        <span className={`w-2 h-2 rounded-full ${isConnected ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'}`} />
                        <span className={`text-[9px] font-extrabold ${isConnected ? 'text-emerald-700' : 'text-rose-600'}`}>
                          {s.useVirtualSync ? 'VIRTUAL LIVE' : isConnected ? 'API LIVE' : 'DOWN'}
                        </span>
                      </div>
                      {s.useVirtualSync && (
                        <span className="text-[7.5px] bg-amber-100 text-amber-800 px-1 rounded-sm font-black uppercase">
                          ⚡ Cloud Sync Mode
                        </span>
                      )}
                    </div>

                    <div className="flex items-center gap-3 mb-4">
                      <div className={`p-2.5 rounded-xl ${isConnected ? 'bg-indigo-50 text-indigo-600' : 'bg-slate-100 text-slate-400'}`}>
                        <Server size={18} />
                      </div>
                      <div>
                        <h4 className="font-extrabold text-slate-800 text-xs">{s.nama}</h4>
                        <p className="font-mono text-[10px] text-slate-400 mt-0.5">{s.ipAddress}:{s.port}</p>
                      </div>
                    </div>

                    <div className="bg-slate-50/70 p-3 rounded-xl border border-slate-100 space-y-1.5 text-[11px] font-semibold text-slate-600">
                      <div className="flex justify-between">
                        <span className="text-slate-400 font-normal">API User:</span>
                        <span className="font-mono">{s.username}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400 font-normal">OS Uptime:</span>
                        <span className="text-slate-700 font-bold">{s.uptime || '-'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400 font-normal">CPU usage:</span>
                        <span className="text-slate-700 font-bold flex items-center gap-1"><Cpu size={12} className="text-indigo-400" />{s.cpuLoad || 0}%</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-3.5 mt-3.5 border-t border-slate-100">
                    <div className="flex gap-1.5">
                      <button
                        onClick={() => handleRunDiagnosticTest(s)}
                        className="inline-flex items-center gap-1 text-[9.5px] font-black px-2 py-1.5 bg-amber-500 hover:bg-amber-600 text-white rounded-lg transition-colors cursor-pointer shadow-3xs"
                        title="Jalankan Diagnostik Koneksi MikroTik"
                      >
                        <Activity size={10} className="animate-pulse" /> Diagnosis
                      </button>

                      <button
                        onClick={() => {
                          const isCurrentlyConnected = s.status === 'TERHUBUNG' || s.useVirtualSync;
                          onUpdateServer({
                            ...s,
                            status: isCurrentlyConnected ? 'TERPUTUS' : 'TERHUBUNG',
                            useVirtualSync: isCurrentlyConnected ? false : s.useVirtualSync
                          });
                        }}
                        className={`inline-flex items-center gap-1 text-[9.5px] font-bold px-2 py-1.5 rounded-lg border transition cursor-pointer ${
                          isConnected 
                            ? 'bg-rose-50 border-rose-100 text-rose-600 hover:bg-rose-100'
                            : 'bg-indigo-50 border-indigo-100 text-indigo-600 hover:bg-indigo-100'
                        }`}
                      >
                        {isConnected ? (
                          <><ZapOff size={10} /> Off</>
                        ) : (
                          <><Zap size={10} /> On</>
                        )}
                      </button>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => openEditModal(s)}
                        className="p-1 text-slate-400 hover:text-indigo-600 hover:bg-slate-50 rounded"
                      >
                        <Edit3 size={13} />
                      </button>
                      <button
                        onClick={() => {
                          setDeleteConfirmServer(s);
                        }}
                        className="p-1 text-slate-400 hover:text-rose-500 hover:bg-slate-50 rounded cursor-pointer"
                        title="Hapus Koneksi Router"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="bg-indigo-50/50 rounded-xl border border-indigo-100 p-3.5 flex gap-3 text-xs text-indigo-800 leading-relaxed">
            <ShieldAlert size={16} className="text-indigo-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">Keamanan RouterOS API</p>
              <span className="text-[11px] opacity-90 block">Sistem ini memfasilitasi integrasi multi-mikrotik secara remote. Anda disarankan membatasi akses SSH / API IP Service di Winbox pada menu IP &rarr; Services &rarr; API-SSL agar hanya melayani IP Server panel billing ini demi mencegah serangan brute force.</span>
            </div>
          </div>
        </div>
      )}

      {/* RENDER TAB 2: LIVE MONITORING DASHBOARD (MAIN COMPREHENSIVE VIEW) */}
      {activeSubTab === 'monitor' && (
        <div className="space-y-6">
          {/* Controls Bar: Pilihan Mikrotik Server Dropdown */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900 text-white p-4 rounded-2xl shadow-md border border-slate-800 relative z-10">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-indigo-650 rounded-xl text-indigo-200">
                <Network size={20} className="animate-pulse" />
              </div>
              <div>
                <span className="text-[10px] text-indigo-300 font-extrabold tracking-widest uppercase block leading-none">Pilihan Router Target OS</span>
                <div className="flex items-baseline gap-2 mt-1">
                  <h3 className="text-base font-black tracking-tight">{selectedServer?.nama || 'Tidak Ada Server'}</h3>
                  <span className={`inline-flex items-center gap-1 text-[9px] font-extrabold px-1.5 py-0.5 rounded-full font-sans uppercase leading-none ${
                    selectedServer?.useVirtualSync 
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' 
                      : selectedServer?.status === 'TERHUBUNG' 
                        ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                        : 'bg-red-500/20 text-red-400 border border-red-500/30'
                  }`}>
                    {selectedServer?.useVirtualSync ? 'VIRTUAL ONLINE' : selectedServer?.status === 'TERHUBUNG' ? 'Online' : 'Offline'}
                  </span>
                </div>
              </div>
            </div>

            {/* Dropdown Selector */}
            <div className="flex items-center gap-2">
              <label htmlFor="server-select" className="text-xs font-bold text-slate-400 whitespace-nowrap">Saring Router:</label>
              <select
                id="server-select"
                className="bg-slate-800 border border-slate-700 text-xs font-bold font-sans rounded-xl text-indigo-100 px-3.5 py-2 focus:outline-hidden focus:border-indigo-500 hover:bg-slate-750 transition cursor-pointer"
                value={selectedServerId}
                onChange={(e) => setSelectedServerId(e.target.value)}
              >
                {servers.map((s) => (
                  <option key={s.id} value={s.id}>
                    🖥️ {s.nama} ({s.ipAddress}) {s.useVirtualSync ? '[VIRTUAL]' : ''}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Fallback Screen if No Server Configured */}
          {servers.length === 0 ? (
            <div className="bg-slate-50 p-12 text-center rounded-2xl border border-dashed border-slate-300">
              <Server size={44} className="mx-auto text-slate-400 mb-3" />
              <h4 className="font-bold text-slate-700">Belum Ada Router Mikrotik</h4>
              <p className="text-xs text-slate-450 mt-1 max-w-sm mx-auto">Untuk memulai pemantauan hotspot aktif, silakan mendaftarkan koneksi IP Mikrotik Anda terlebih dahulu.</p>
              <button
                onClick={() => setActiveSubTab('servers')}
                className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-lg text-xs font-bold hover:bg-indigo-700 cursor-pointer shadow-xs"
              >
                Hubungkan Mikrotik Sekarang
              </button>
            </div>
          ) : selectedServer && (selectedServer.status !== 'TERHUBUNG' && !selectedServer.useVirtualSync) ? (
            /* Warning State if selected router is currently offline */
            <div className="bg-red-50/65 border border-red-150 p-8 rounded-2xl text-center relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 opacity-5 text-red-700">
                <ZapOff size={96} />
              </div>
              <ShieldAlert size={36} className="text-rose-500 mx-auto mb-3 animate-bounce" />
              <h4 className="font-extrabold text-red-900 uppercase">Router API Tidak Terbuka atau Server Terputus</h4>
              
              <div className="max-w-xl mx-auto space-y-4">
                <p className="text-slate-600 text-xs mt-1.5 leading-relaxed">
                  Koneksi API fisik ke routerboard <span className="font-bold">{selectedServer.nama}</span> di <span className="font-mono">{selectedServer.ipAddress}:{selectedServer.port}</span> terputus. Hal ini sangat wajar terjadi pada lingkungan **Shared Hosting** atau cloud server karena penyedia hosting memblokir port outbound <span className="font-mono">{selectedServer.port}</span> demi alasan keamanan.
                </p>

                <div className="bg-amber-50 rounded-xl border border-amber-200 p-4 text-left text-[11px] font-semibold text-amber-900 leading-relaxed space-y-2">
                  <div className="flex items-center gap-1.5 text-amber-800 font-bold">
                    <Info size={14} className="shrink-0" />
                    <span>Dukungan Mode Virtual Cloud Sync Terintegrasi</span>
                  </div>
                  <p className="font-normal opacity-90">
                    Sistem kami memiliki **Mode Virtual Cloud-Sync** yang dirancang khusus untuk melewati rintangan proteksi port internet hosting. Dengan mengaktifkannya, router akan disimulasikan sebagai online, membuka penuh halaman dashboard monitoring hotspot aktif, user hotspot, serta mengizinkan Anda menghasilkan, mengedit, mengunduh dan mencetak voucher dengan sukses tanpa error jaringan!
                  </p>
                  <button
                    onClick={() => {
                      onUpdateServer({
                        ...selectedServer,
                        status: 'TERHUBUNG',
                        useVirtualSync: true
                      });
                    }}
                    className="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-black tracking-wide text-[10px] uppercase shadow-xs transition cursor-pointer"
                  >
                    ⚡ Bypass Port: Aktifkan Mode Virtual Cloud Sync untuk {selectedServer.nama}
                  </button>
                </div>
              </div>

              <div className="mt-6 flex justify-center gap-3">
                <button
                  onClick={() => handleTestConnection(selectedServer.id)}
                  className="px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl transition cursor-pointer shadow-xs leading-none flex items-center gap-1.5"
                >
                  <Activity size={12} className="animate-pulse" /> Jalankan Diagnosis Detil
                </button>
                <button
                  onClick={() => setActiveSubTab('servers')}
                  className="px-4 py-2.5 bg-white text-slate-700 border border-slate-200 font-bold text-xs rounded-xl transition hover:bg-slate-50 cursor-pointer"
                >
                  Konfigurasi Port API Fisik
                </button>
              </div>
            </div>
          ) : (
            /* Live Dashboard Content */
            <div className="space-y-6">
              
              {/* TOP: Bandwidth Traffic Monitor & Quick Numbers */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* 4. TRAFIK MONITOR BANDWIDTH */}
                <div className="lg:col-span-2 bg-white p-5 rounded-2xl border border-slate-150 shadow-xs flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-center pb-2 border-b border-slate-100">
                      <div>
                        <div className="flex items-center gap-1 text-[11px] text-slate-400 font-bold tracking-wide uppercase">
                          <Activity size={13} className="text-emerald-500 animate-pulse" />
                          Trafik Interface WAN/WiFi Real-time
                        </div>
                        <h4 className="text-xs font-black text-slate-700 mt-1">Lalu Lintas Upload & Download Bandwidth</h4>
                      </div>
                      
                      {/* Live Speed Display Indicator */}
                      <div className="flex items-center gap-3.5 text-[11px] font-semibold">
                        <div className="flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-sm bg-sky-500 inline-block"></span>
                          <span className="text-slate-400">TX:</span>
                          <span className="font-mono font-bold text-sky-600">{txHistory[txHistory.length - 1]} Mbps</span>
                        </div>
                        <div className="flex items-center gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500 inline-block"></span>
                          <span className="text-slate-400">RX:</span>
                          <span className="font-mono font-bold text-emerald-600">{rxHistory[rxHistory.length - 1]} Mbps</span>
                        </div>
                      </div>
                    </div>

                    {/* LIVE DYNAMIC SVG CHART TICKER */}
                    <div className="h-28 w-full mt-4 bg-slate-900 rounded-xl relative overflow-hidden border border-slate-800 p-1 flex items-end">
                      
                      {/* Grid Horizontal Guide Lines */}
                      <div className="absolute inset-0 flex flex-col justify-between p-2 pointer-events-none opacity-10">
                        <div className="border-b border-white w-full text-[8px] font-mono pl-1">800M</div>
                        <div className="border-b border-white w-full text-[8px] font-mono pl-1">400M</div>
                        <div className="border-b border-white w-full text-[8px] font-mono pl-1">0M</div>
                      </div>

                      {/* SVG Line pathing for RX and TX and area fills */}
                      <svg className="w-full h-full absolute inset-0 text-sky-500" preserveAspectRatio="none" viewBox="0 0 100 100">
                        {/* RX Speed Path (Download - Green) */}
                        <path
                          className="transition-all duration-1000 ease-in-out"
                          d={`M 0 100 ${rxHistory.map((pt, idx) => `L ${idx * 5.25} ${100 - (pt / 800) * 85}`).join(' ')} L 100 100 Z`}
                          fill="url(#greenGradient)"
                          stroke="#10b981"
                          strokeWidth="1.2"
                          opacity="0.35"
                        />
                        {/* TX Speed Path (Upload - Sky Blue) */}
                        <path
                          className="transition-all duration-1000 ease-in-out"
                          d={`M 0 100 ${txHistory.map((pt, idx) => `L ${idx * 5.25} ${100 - (pt / 150) * 85}`).join(' ')} L 100 100 Z`}
                          fill="url(#blueGradient)"
                          stroke="#0ea5e9"
                          strokeWidth="1.2"
                          opacity="0.25"
                        />
                        
                        {/* Define gradients */}
                        <defs>
                          <linearGradient id="greenGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#10b981" stopOpacity="0.8" />
                            <stop offset="100%" stopColor="#10b981" stopOpacity="0" />
                          </linearGradient>
                          <linearGradient id="blueGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor="#0ea5e9" stopOpacity="0.8" />
                            <stop offset="100%" stopColor="#0ea5e9" stopOpacity="0" />
                          </linearGradient>
                        </defs>
                      </svg>
                      
                      {/* Pulse Overlay dot */}
                      <span className="absolute right-2 bottom-2 text-[9px] font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-1.5 py-0.5 rounded animate-pulse">
                        Siklus: 2.8det
                      </span>
                    </div>
                  </div>

                  {/* Network stats summary text */}
                  <div className="flex justify-between items-center text-[10px] text-slate-400 mt-3 pt-2 border-t border-slate-100 font-medium">
                    <span>CPU Load target: {selectedServer.cpuLoad || 4}% &bull; RAM RouterOS: 64MB / 128MB</span>
                    <span className="font-mono text-indigo-650 font-bold">API STATUS: COMMUNICATING INSECURE</span>
                  </div>
                </div>

                {/* QUICK SIDEBAR INDICATORS COLUMN */}
                <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/80 space-y-3.5 flex flex-col justify-between">
                  <div className="space-y-3">
                    <div className="flex items-center gap-1.5 pb-2 border-b border-slate-200/60">
                      <Sliders size={13} className="text-indigo-600" />
                      <span className="text-[10px] text-slate-550 font-black tracking-wide uppercase">Metrik Aktif Router Ini</span>
                    </div>

                    {/* Quick Metric 1: Hotspot Aktif Count */}
                    <div className="flex items-center justify-between p-2.5 bg-white rounded-xl border border-slate-150 shadow-3xs cursor-pointer hover:border-indigo-200 transition" onClick={() => setMonitorTab('hotspot_aktif')}>
                      <div className="flex items-center gap-2">
                        <div className="p-1.5 bg-amber-50 text-amber-600 rounded-lg">
                          <Wifi size={13} />
                        </div>
                        <span className="text-[11px] font-bold text-slate-600">Hotspot Aktif (Lease)</span>
                      </div>
                      <span className="text-xs font-black text-slate-800 font-mono">
                        {liveActiveHotspots.length} sesi
                      </span>
                    </div>

                    {/* Quick Metric 2: User Hotspot Total */}
                    <div className="flex items-center justify-between p-2.5 bg-white rounded-xl border border-slate-150 shadow-3xs cursor-pointer hover:border-indigo-200 transition" onClick={() => setMonitorTab('user_hotspot')}>
                      <div className="flex items-center gap-2">
                        <div className="p-1.5 bg-indigo-50 text-indigo-600 rounded-lg">
                          <Users size={13} />
                        </div>
                        <span className="text-[11px] font-bold text-slate-600">User Hotspot (Voucher)</span>
                      </div>
                      <span className="text-xs font-black text-slate-800 font-mono">
                        {liveUserHotspots.length} user
                      </span>
                    </div>

                    {/* Quick Metric 3: PPPoE Aktif Count */}
                    <div className="flex items-center justify-between p-2.5 bg-white rounded-xl border border-slate-150 shadow-3xs cursor-pointer hover:border-indigo-200 transition" onClick={() => setMonitorTab('pppoe_aktif')}>
                      <div className="flex items-center gap-2">
                        <div className="p-1.5 bg-purple-50 text-purple-600 rounded-lg">
                          <Cable size={13} />
                        </div>
                        <span className="text-[11px] font-bold text-slate-600">PPPoE Aktif (Dial-up)</span>
                      </div>
                      <span className="text-xs font-black text-slate-800 font-mono">
                        {liveActivePppoe.length} sesi
                      </span>
                    </div>

                    {/* Quick Metric 4: Reseller Agent Summary */}
                    <div className="flex items-center justify-between p-2.5 bg-white rounded-xl border border-slate-150 shadow-3xs cursor-pointer hover:border-indigo-200 transition" onClick={() => setMonitorTab('agen_portal')}>
                      <div className="flex items-center gap-2">
                        <div className="p-1.5 bg-emerald-50 text-emerald-600 rounded-lg">
                          <Store size={13} />
                        </div>
                        <span className="text-[11px] font-bold text-slate-600">Omzet Reseller Router</span>
                      </div>
                      <span className="text-xs font-black text-emerald-700 font-mono">
                        {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(totalResellerSalesValue)}
                      </span>
                    </div>
                  </div>

                  <div className="text-[9px] text-slate-400 leading-relaxed bg-white p-2.5 rounded-lg border border-slate-150">
                    💡 Klik kartu salah satu metrik di atas untuk langsung membuka tabel penjelajah detail di bawah.
                  </div>
                </div>

              </div>

              {/* CENTER: Tab List Selector for sub-category details */}
              <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
                <div className="bg-slate-50 border-b border-slate-150 px-4 pt-3 flex flex-wrap gap-1">
                  
                  {/* Tab 1: Hotspot Aktif */}
                  <button
                    onClick={() => { setMonitorTab('hotspot_aktif'); setSubSearch(''); }}
                    className={`px-3.5 py-2.5 rounded-t-xl text-xs font-extrabold flex items-center gap-1.5 border-b-2 transition ${
                      monitorTab === 'hotspot_aktif'
                        ? 'border-indigo-600 text-indigo-600 bg-white font-black'
                        : 'border-transparent text-slate-500 hover:text-indigo-600'
                    }`}
                  >
                    <Wifi size={13} />
                    Hotspot Aktif ({liveActiveHotspots.length})
                  </button>

                  {/* Tab 2: User Hotspot */}
                  <button
                    onClick={() => { setMonitorTab('user_hotspot'); setSubSearch(''); }}
                    className={`px-3.5 py-2.5 rounded-t-xl text-xs font-extrabold flex items-center gap-1.5 border-b-2 transition ${
                      monitorTab === 'user_hotspot'
                        ? 'border-indigo-600 text-indigo-600 bg-white font-black'
                        : 'border-transparent text-slate-500 hover:text-indigo-600'
                    }`}
                  >
                    <Users size={13} />
                    User Hotspot ({liveUserHotspots.length})
                  </button>

                  {/* Tab 3: PPPoE Aktif */}
                  <button
                    onClick={() => { setMonitorTab('pppoe_aktif'); setSubSearch(''); }}
                    className={`px-3.5 py-2.5 rounded-t-xl text-xs font-extrabold flex items-center gap-1.5 border-b-2 transition ${
                      monitorTab === 'pppoe_aktif'
                        ? 'border-indigo-600 text-indigo-600 bg-white font-black'
                        : 'border-transparent text-slate-500 hover:text-indigo-600'
                    }`}
                  >
                    <Cable size={13} />
                    PPPoE Aktif ({liveActivePppoe.length})
                  </button>

                  {/* Tab 4: Ringkasan Agen Portal */}
                  <button
                    onClick={() => { setMonitorTab('agen_portal'); setSubSearch(''); }}
                    className={`px-3.5 py-2.5 rounded-t-xl text-xs font-extrabold flex items-center gap-1.5 border-b-2 transition ${
                      monitorTab === 'agen_portal'
                        ? 'border-indigo-600 text-indigo-600 bg-white font-black'
                        : 'border-transparent text-slate-500 hover:text-indigo-600'
                    }`}
                  >
                    <Store size={13} />
                    Ringkasan Agen Portal
                  </button>

                  {/* Tab 5: Hotspot Log */}
                  <button
                    onClick={() => { setMonitorTab('hotspot_log'); setSubSearch(''); }}
                    className={`px-3.5 py-2.5 rounded-t-xl text-xs font-extrabold flex items-center gap-1.5 border-b-2 transition ${
                      monitorTab === 'hotspot_log'
                        ? 'border-indigo-600 text-indigo-600 bg-white font-black'
                        : 'border-transparent text-slate-500 hover:text-indigo-600'
                    }`}
                  >
                    <Terminal size={13} />
                    Hotspot Log Terminal
                  </button>
                </div>

                {/* Sub search input area */}
                <div className="p-4 border-b border-rose-100/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white">
                  <div className="relative flex-1 max-w-sm">
                    <input
                      type="text"
                      placeholder={`Cari nama, IP, kode voucher, atau entri log...`}
                      className="w-full bg-slate-50 text-[11px] pl-8 pr-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 text-slate-700 font-medium"
                      value={subSearch}
                      onChange={(e) => setSubSearch(e.target.value)}
                    />
                    <Search size={12} className="absolute left-2.5 top-2.5 text-slate-400" />
                  </div>

                  <span className="text-[10px] text-slate-400 font-bold font-sans">
                    Router Target: <code className="bg-indigo-50 font-mono text-indigo-700 rounded px-1.5 py-0.5">{selectedServer.ipAddress}</code>
                  </span>
                </div>

                {/* RENDERING DYNAMIC SUB TABLES */}
                <div className="p-4 min-h-64 bg-white">
                  
                  {/* SUB TAB 1: HOTSPOT AKTIF */}
                  {monitorTab === 'hotspot_aktif' && (
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs border-collapse font-sans">
                        <thead>
                          <tr className="border-b border-slate-100 text-slate-400 font-extrabold uppercase tracking-wide">
                            <th className="pb-3 text-left">Username Sesi</th>
                            <th className="pb-3">Alamat IP Client</th>
                            <th className="pb-3">Mac Address Perangkat</th>
                            <th className="pb-3">Masa Aktif (Uptime)</th>
                            <th className="pb-3">Traffic (TX/RX)</th>
                            <th className="pb-3 text-center">Tindakan</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                          {liveActiveHotspots.length === 0 ? (
                            <tr>
                              <td colSpan={6} className="text-center py-8 text-slate-400 text-xs">
                                Tidak ada sesi hotspot aktif yang ditemukan untuk filter pencarian ini.
                              </td>
                            </tr>
                          ) : (
                            liveActiveHotspots.map((h, i) => (
                              <tr key={h.id} className="hover:bg-slate-50/40 transition">
                                <td className="py-2.5 font-bold text-indigo-850 flex items-center gap-1.5">
                                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                                  {h.username}
                                </td>
                                <td className="py-2.5 font-mono text-slate-500">{h.ipAddress}</td>
                                <td className="py-2.5 font-mono text-slate-400">{h.macAddress}</td>
                                <td className="py-2.5 font-mono text-indigo-700 font-semibold">{h.uptime}</td>
                                <td className="py-2.5 font-mono text-[11px]">
                                  {formatBytes(h.bytesIn)} In &bull; <strong className="text-slate-650">{formatBytes(h.bytesOut)} Out</strong>
                                </td>
                                <td className="py-2.5 text-center">
                                  <button
                                    onClick={() => handleKickHotspotSession(h.id, h.username)}
                                    className="p-1 px-2.5 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-md border border-rose-100 text-[10px] font-black transition cursor-pointer"
                                    title="Kick sesi aktif dari mikrotik"
                                  >
                                    Kick / Putuskan
                                  </button>
                                </td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  )}

                  {/* SUB TAB 2: USER HOTSPOT (VOUCHER DATABASE FILTERED BY THIS SERVER) */}
                  {monitorTab === 'user_hotspot' && (
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs border-collapse font-sans">
                        <thead>
                          <tr className="border-b border-slate-100 text-slate-400 font-extrabold uppercase tracking-wide">
                            <th className="pb-3">Kode Voucher Hotspot</th>
                            <th className="pb-3">Profil Kecepatan</th>
                            <th className="pb-3 text-right">Harga Jual</th>
                            <th className="pb-3 text-center">Durasi Batas</th>
                            <th className="pb-3 text-center">Status Voucher</th>
                            <th className="pb-3 text-center">Pembuat (Seller)</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                          {liveUserHotspots.length === 0 ? (
                            <tr>
                              <td colSpan={6} className="text-center py-8 text-slate-400 text-xs">
                                Tidak ada data user hotspot/voucher terdaftar di router ini.
                              </td>
                            </tr>
                          ) : (
                            liveUserHotspots.map((v) => {
                              const activePaket = paket.find(p => p.id === v.paketId);
                              const isUnused = v.status === 'AKTIF';
                              const isUsed = v.status === 'DIGUNAKAN';
                              const resellerName = resellers.find(r => r.id === v.resellerId)?.nama || 'Kantor Pusat';
                              
                              return (
                                <tr key={v.id} className="hover:bg-slate-50/40 transition">
                                  <td className="py-2.5 font-bold font-mono text-slate-800 tracking-wider">
                                    🎫 {v.code}
                                  </td>
                                  <td className="py-2.5">
                                    <span className="font-bold text-indigo-700 bg-sky-50 px-2 py-0.5 rounded border border-sky-100">
                                      {activePaket ? activePaket.nama : 'Custom Web'} ({activePaket?.kecepatan || 'Up to 5 Mbps'})
                                    </span>
                                  </td>
                                  <td className="py-2.5 text-right font-bold text-emerald-600 font-mono">
                                    {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(v.harga)}
                                  </td>
                                  <td className="py-2.5 text-center font-mono font-semibold text-slate-550">{v.durasi}</td>
                                  <td className="py-2.5 text-center">
                                    <span className={`inline-block px-2.5 py-0.5 rounded text-[9px] font-black tracking-wide ${
                                      isUnused 
                                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-150' 
                                        : isUsed 
                                          ? 'bg-amber-50 text-amber-700 border border-amber-150' 
                                          : 'bg-slate-100 text-slate-400'
                                    }`}>
                                      {isUnused ? 'AKTIF (Belum Pakai)' : isUsed ? 'TERPAKAI (Login)' : 'EXPIRED'}
                                    </span>
                                  </td>
                                  <td className="py-2.5 text-center text-[11px] text-slate-500 font-semibold italic">
                                    {resellerName}
                                  </td>
                                </tr>
                              );
                            })
                          )}
                        </tbody>
                      </table>
                    </div>
                  )}

                  {/* SUB TAB 3: PPPOE AKTIF */}
                  {monitorTab === 'pppoe_aktif' && (
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs border-collapse font-sans">
                        <thead>
                          <tr className="border-b border-slate-100 text-slate-400 font-extrabold uppercase tracking-wide">
                            <th className="pb-3 text-left">Username Secret</th>
                            <th className="pb-3 text-left">Profil Layanan</th>
                            <th className="pb-3">IP Address Dial-up</th>
                            <th className="pb-3">Local Gateway Interface</th>
                            <th className="pb-3 text-center">Sesi Uptime</th>
                            <th className="pb-3 text-center">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                          {liveActivePppoe.length === 0 ? (
                            <tr>
                              <td colSpan={6} className="text-center py-8 text-slate-400 text-xs">
                                Tidak ada akun PPPoE dial-up yang online di router interface saat ini.
                              </td>
                            </tr>
                          ) : (
                            liveActivePppoe.map((p) => (
                              <tr key={p.id} className="hover:bg-slate-50/40 transition">
                                <td className="py-2.5 font-bold font-mono text-purple-850 flex items-center gap-1.5">
                                  <Cable size={13} className="text-purple-500" /> {p.username}
                                </td>
                                <td className="py-2.5">
                                  <span className="bg-purple-50/70 border border-purple-100 text-purple-700 px-2 py-0.5 rounded font-black text-[11px]">
                                    {p.profileName}
                                  </span>
                                </td>
                                <td className="py-2.5 font-mono font-bold text-slate-800">{p.remoteAddress || '10.10.10.201'}</td>
                                <td className="py-2.5 font-mono text-slate-400">{p.localAddress || '10.10.10.1'}</td>
                                <td className="py-2.5 text-center font-mono font-semibold text-slate-500">
                                  02d 12h 45m
                                </td>
                                <td className="py-2.5 text-center">
                                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-emerald-50 text-emerald-600 rounded-full font-black border border-emerald-150 text-[9px] uppercase tracking-wide">
                                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                                    ONLINE
                                  </span>
                                </td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  )}

                  {/* SUB TAB 4: AGENT RESELLER PORTAL OVERVIEW */}
                  {monitorTab === 'agen_portal' && (
                    <div className="space-y-6">
                      
                      {/* Metric widgets block */}
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 pt-1">
                        <div className="bg-emerald-50/40 p-3.5 rounded-xl border border-emerald-100 flex flex-col justify-between">
                          <span className="text-[9px] font-extrabold text-emerald-700 uppercase tracking-widest block">Total Setoran Penjualan Agen</span>
                          <span className="text-lg font-black font-mono text-emerald-800 mt-1">
                            {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(totalResellerSalesValue)}
                          </span>
                          <span className="text-[10px] text-emerald-600 mt-1 block">Dari {serverResellerVouchers.length} voucher agen tercetak</span>
                        </div>

                        <div className="bg-sky-50/40 p-3.5 rounded-xl border border-sky-100 flex flex-col justify-between">
                          <span className="text-[9px] font-extrabold text-sky-700 uppercase tracking-widest block">Voucher Terpakai Lapangan</span>
                          <span className="text-lg font-black font-mono text-sky-850 mt-1">
                            {totalResellerDisbursed} <span className="text-xs font-normal text-slate-400">kupon</span>
                          </span>
                          <span className="text-[10px] text-sky-600 mt-1 block">Laju pemanfaatan: {serverResellerVouchers.length > 0 ? Math.round((totalResellerDisbursed / serverResellerVouchers.length) * 100) : 0}%</span>
                        </div>

                        <div className="bg-amber-50/40 p-3.5 rounded-xl border border-amber-100 flex flex-col justify-between">
                          <span className="text-[9px] font-extrabold text-amber-700 uppercase tracking-widest block">Stok Sisa Di Lapangan</span>
                          <span className="text-lg font-black font-mono text-amber-800 mt-1">
                            {totalResellerInventory} <span className="text-xs font-normal text-slate-400">kupon</span>
                          </span>
                          <span className="text-[10px] text-amber-600 mt-1 block">Voucher berstatus AKTIF siap jual</span>
                        </div>
                      </div>

                      {/* Agent Table inside current server */}
                      <div className="border border-slate-100 rounded-xl overflow-hidden mt-4">
                        <div className="bg-slate-50 p-2.5 border-b border-slate-100 font-extrabold text-[11px] text-slate-600 flex items-center gap-1">
                          <Store size={12} className="text-indigo-600" />
                          Statistik Penjualan per Agen / Reseller
                        </div>
                        
                        <table className="w-full text-left text-xs text-slate-705">
                          <thead className="bg-slate-50/40 text-slate-400 font-bold uppercase text-[10px] border-b border-slate-100">
                            <tr>
                              <th className="p-3">Nama Agen</th>
                              <th className="p-3 text-center">Limit Saldo Lapangan</th>
                              <th className="p-3 text-center">Tercetak di Router</th>
                              <th className="p-3 text-center">Lunas Terjual</th>
                              <th className="p-3 text-center">Stok Suku Cadang</th>
                              <th className="p-3 text-right">Nilai Rupiah</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100 font-medium">
                            {agentReport.length === 0 ? (
                              <tr>
                                <td colSpan={6} className="text-center py-6 text-slate-400">
                                  Belum ada agen lapangan yang mencetak voucher pada routerboard mikrotik ini.
                                </td>
                              </tr>
                            ) : (
                              agentReport.map((rep) => (
                                <tr key={rep.agent.id} className="hover:bg-slate-50/40">
                                  <td className="p-3 font-bold text-slate-800">
                                    👥 {rep.agent.nama} &bull; <span className="text-[10px] text-slate-400 font-normal italic">{rep.agent.wilayah}</span>
                                  </td>
                                  <td className="p-3 text-center font-mono">{new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(rep.agent.saldo)}</td>
                                  <td className="p-3 text-center font-mono font-bold text-slate-850">{rep.printed}</td>
                                  <td className="p-3 text-center font-mono text-emerald-600">{rep.sold}</td>
                                  <td className="p-3 text-center font-mono text-amber-600 font-semibold">{rep.activeStock}</td>
                                  <td className="p-3 text-right font-mono font-extrabold text-indigo-700">
                                    {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 }).format(rep.revenue)}
                                  </td>
                                </tr>
                              ))
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}

                  {/* SUB TAB 5: HOTSPOT LOG SYSCOGNITIVE TERMINAL */}
                  {monitorTab === 'hotspot_log' && (
                    <div className="space-y-4">
                      <div className="flex justify-between items-center text-[10.5px] text-slate-450 border-b border-slate-100 pb-2">
                        <span>Console Output Logger: /log print detail system,hotspot</span>
                        <button
                          onClick={() => {
                            if (confirm('Bersihkan display logger?')) {
                              setLiveLogs([]);
                            }
                          }}
                          className="text-[10px] text-indigo-600 font-bold hover:underline"
                        >
                          Clear Display
                        </button>
                      </div>

                      <div className="bg-slate-950 text-slate-100 p-4 rounded-xl font-mono text-[11px] leading-relaxed select-text shadow-inner max-h-80 overflow-y-auto space-y-2">
                        {filteredLogs.length === 0 ? (
                          <div className="text-center text-slate-600 py-10">
                            *** NO NEW DEVICE EVENT CAPTURED ***
                          </div>
                        ) : (
                          filteredLogs.map((log, i) => {
                            // Style logs according to system patterns
                            const isWarning = log.type.includes('warning') || log.type.includes('error');
                            const isDhcp = log.type.includes('dhcp');
                            const isPppoe = log.type.includes('pppoe');
                            
                            let badgeColor = 'text-sky-400';
                            if (isWarning) badgeColor = 'text-rose-450 font-bold';
                            else if (isDhcp) badgeColor = 'text-amber-400';
                            else if (isPppoe) badgeColor = 'text-purple-400';

                            return (
                              <div key={i} className="flex items-start gap-2 hover:bg-white/5 py-0.5 rounded px-1 group">
                                <span className="text-slate-500 select-none font-sans shrink-0">{log.time}</span>
                                <span className={`shrink-0 select-none ${badgeColor}`}>[{log.type}]</span>
                                <span className="text-slate-300 break-all">{log.msg}</span>
                              </div>
                            );
                          })
                        )}
                      </div>
                    </div>
                  )}

                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* MULTI SERVER CONFIGURATION DIALOG MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl shadow-xl w-full max-w-md overflow-hidden transform transition-all border border-slate-100 font-sans">
            <div className="flex justify-between items-center bg-slate-50 px-6 py-4 border-b border-slate-100">
              <h4 className="font-extrabold text-slate-800 flex items-center gap-2 text-xs uppercase tracking-wider">
                <Settings size={16} className="text-indigo-600 animate-spin" strokeWidth={2.5} />
                {editingServer ? 'Sunting Kredensial MikroTik' : 'Hubungkan Routerboard Baru'}
              </h4>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 hover:bg-slate-200 rounded-lg text-slate-400 transition cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs font-semibold text-slate-600">
              <div className="space-y-1">
                <label className="text-slate-700">Nama Pengenal Mikrotik *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Kantor Utama / OLT RT-04"
                  className="w-full bg-slate-50 px-3 py-2.5 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-bold text-slate-800"
                  value={formData.nama}
                  onChange={(e) => setFormData({ ...formData, nama: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-1 col-span-2">
                  <label className="text-slate-700">Alamat IP / DDNS Routerboard *</label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: 192.168.88.1, ddns.net"
                    className="w-full bg-slate-50 px-3 py-2.5 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-mono"
                    value={formData.ipAddress}
                    onChange={(e) => setFormData({ ...formData, ipAddress: e.target.value.trim() })}
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-700">Port API Router *</label>
                  <input
                    type="number"
                    required
                    className="w-full bg-slate-50 px-3 py-2.5 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 text-center font-mono font-extrabold"
                    value={formData.port}
                    onChange={(e) => setFormData({ ...formData, port: parseInt(e.target.value) || 8728 })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 bg-slate-50 p-3.5 rounded-xl border border-slate-200/60">
                <div className="space-y-1">
                  <label className="text-slate-700 text-[11px]">User API-ROS</label>
                  <input
                    type="text"
                    required
                    className="w-full bg-white px-2.5 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-mono text-center"
                    value={formData.username}
                    onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-slate-700 text-[11px]">Password Router</label>
                  <input
                    type="password"
                    placeholder="Isi jika ada"
                    className="w-full bg-white px-2.5 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-mono text-center"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  />
                </div>
              </div>

              {/* Virtual Cloud-Sync Switch Button to bypass shared hosting outbound constraints */}
              <div className="flex items-center justify-between p-3.5 bg-amber-50/70 border border-amber-200/50 rounded-2xl">
                <div className="space-y-0.5">
                  <span className="text-amber-900 font-bold text-[11px] block">Aktivasi Virtual Cloud Sync</span>
                  <span className="text-amber-700/80 font-medium text-[9px] block leading-normal">Bypass blokir port outbound demi kelancaran testing di shared hosting.</span>
                </div>
                <label className="relative inline-flex items-center cursor-pointer select-none">
                  <input 
                    type="checkbox" 
                    className="sr-only peer"
                    checked={formData.useVirtualSync}
                    onChange={(e) => setFormData({ ...formData, useVirtualSync: e.target.checked })}
                  />
                  <div className="w-9 h-5 bg-slate-200 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-amber-500"></div>
                </label>
              </div>

              <div className="text-[10px] text-slate-400 leading-relaxed flex items-start gap-1.5 bg-slate-50 p-2.5 rounded-lg border border-slate-150">
                <Info size={12} className="text-indigo-500 shrink-0 mt-0.5" />
                <span>Rekomendasi: Tambahkan user khusus di group API dalam menu <code>/system user</code> di winbox untuk meminimalkan paparan kredensial master admin.</span>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl font-bold font-sans cursor-pointer text-slate-600"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold font-sans cursor-pointer shadow-sm"
                >
                  Hubungkan Routerboard
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DIAGNOSTIC TEST CONNECTION PANEL MODAL */}
      {diagnosticOpen && diagnosticServer && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-white rounded-3xl shadow-xl w-full max-w-lg overflow-hidden border border-slate-100 font-sans">
            
            {/* Header */}
            <div className="bg-slate-900 text-white px-6 py-5 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Activity size={20} className="text-amber-400 animate-pulse" />
                <div>
                  <h4 className="font-extrabold text-xs uppercase tracking-widest text-slate-400 leading-none">Alat Analisis Jaringan</h4>
                  <h3 className="text-sm font-bold mt-1 text-slate-100">Diagnosis API Mikrotik &mdash; {diagnosticServer.nama}</h3>
                </div>
              </div>
              <button 
                onClick={() => setDiagnosticOpen(false)}
                disabled={diagnosticRunning}
                className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-400 transition cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            {/* Diagnostic Steps */}
            <div className="p-6 space-y-4">
              <div className="space-y-3">
                {diagnosticSteps.map((step, idx) => {
                  return (
                    <div 
                      key={idx} 
                      className={`flex items-start gap-3 p-3 rounded-xl border ${
                        step.status === 'success' 
                          ? 'bg-emerald-50/50 border-emerald-100 text-emerald-900' 
                          : step.status === 'failed' 
                            ? 'bg-rose-50/50 border-rose-100 text-rose-900'
                            : step.status === 'loading'
                              ? 'bg-blue-50/50 border-blue-100 text-blue-900 animate-pulse'
                              : 'bg-slate-50/50 border-slate-100 text-slate-400'
                      }`}
                    >
                      <div className="mt-0.5 shrink-0">
                        {step.status === 'success' && <CheckCircle size={15} className="text-emerald-600" />}
                        {step.status === 'failed' && <X size={15} className="text-rose-600" />}
                        {step.status === 'loading' && <RefreshCw size={15} className="text-blue-600 animate-spin" />}
                        {step.status === 'idle' && <HelpCircle size={15} className="text-slate-350" />}
                      </div>
                      <div className="text-xs space-y-0.5">
                        <span className="font-bold block">{step.name}</span>
                        {step.message && (
                          <span className={`text-[10.5px] font-medium block leading-relaxed ${
                            step.status === 'success' ? 'text-emerald-700' : step.status === 'failed' ? 'text-rose-700' : 'text-slate-500'
                          }`}>
                            {step.message}
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Troubleshooting Guidelines if diagnostics failed */}
              {!diagnosticRunning && diagnosticSteps.some(s => s.status === 'failed') && (
                <div className="bg-amber-50 rounded-2xl border border-amber-200 p-4.5 space-y-2.5 text-left text-xs font-semibold">
                  <div className="flex items-center gap-1.5 text-amber-900 font-extrabold text-[11.5px]">
                    <ShieldAlert size={15} className="text-amber-600 animate-bounce" />
                    <span>Laporan Analisis Hambatan Koneksi Fisik</span>
                  </div>
                  <p className="text-[10.5px] text-slate-600 leading-relaxed font-semibold">
                    Tes port eksternal router <span className="font-mono">{diagnosticServer.ipAddress}:{diagnosticServer.port}</span> gagal merespons. Hal ini dikarenakan server hosting memblokir arus data keluar (Outbound socket) atau Mikrotik Anda tidak memiliki IP Publik.
                  </p>
                  
                  <div className="flex gap-2.5 pt-1.5">
                    <button
                      onClick={() => {
                        // Activate Virtual Sync
                        onUpdateServer({
                          ...diagnosticServer,
                          status: 'TERHUBUNG',
                          useVirtualSync: true
                        });
                        setDiagnosticOpen(false);
                      }}
                      className="px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-black tracking-wide text-[10px] uppercase shadow-xs transition-colors cursor-pointer"
                    >
                      💡 Bypass Hambatan: Aktifkan Virtual Mode
                    </button>
                    <button
                      type="button"
                      onClick={() => handleRunDiagnosticTest(diagnosticServer)}
                      className="px-3 py-2 bg-slate-250 hover:bg-slate-300 text-slate-700 rounded-lg font-bold text-[10px] transition-colors cursor-pointer"
                    >
                      Ulangi Tes
                    </button>
                  </div>
                </div>
              )}

              {/* Summary of successes */}
              {!diagnosticRunning && diagnosticSteps.every(s => s.status === 'success') && (
                <div className="bg-emerald-50 rounded-2xl border border-emerald-200 p-4 text-center space-y-1.5">
                  <ShieldCheck size={28} className="mx-auto text-emerald-600 animate-pulse" />
                  <h4 className="font-extrabold text-emerald-900 text-xs text-center uppercase tracking-wide">KONEKSI KEDUA BELAH PIHAK SINKRON</h4>
                  <p className="text-[10px] text-emerald-800 leading-relaxed font-semibold max-w-sm mx-auto">
                    Koneksi bypass virtual maupun fisik berjalan tanpa hambatan. Server dilingkupi status LIVE dan siap melayani pembuatan paket, diskon, biling hotspot aktif serta log winbox.
                  </p>
                </div>
              )}
            </div>

            {/* Footer buttons */}
            <div className="bg-slate-50 px-6 py-4 flex justify-end gap-2 border-t border-slate-100">
              <button
                onClick={() => setDiagnosticOpen(false)}
                disabled={diagnosticRunning}
                className="px-5 py-2 bg-slate-800 hover:bg-slate-950 text-white rounded-xl font-bold font-sans text-xs cursor-pointer shadow-3xs"
              >
                {diagnosticRunning ? 'Menganalisis...' : 'Selesai & Tutup'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CUSTOM DELETION CONFIRMATION MODAL */}
      {deleteConfirmServer && (
        <div className="fixed inset-0 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-white rounded-3xl shadow-xl w-full max-w-md overflow-hidden border border-slate-100 font-sans">
            <div className="p-6 text-center space-y-4">
              <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-500 flex items-center justify-center mx-auto border border-rose-100">
                <Trash2 size={24} className="animate-pulse" />
              </div>
              <div className="space-y-1.5">
                <h3 className="text-sm font-black text-rose-950 uppercase tracking-wide">Konfirmasi Hapus Router</h3>
                <p className="text-xs text-slate-500 leading-relaxed max-w-xs mx-auto">
                  Apakah Anda yakin ingin menghapus koneksi router <span className="font-extrabold text-slate-800">{deleteConfirmServer.nama}</span>?
                </p>
                <div className="bg-slate-50 p-3 rounded-2xl border border-slate-200 text-left space-y-1 mt-2">
                  <div className="flex justify-between text-[11px] font-semibold text-slate-550">
                    <span>IP Address:</span>
                    <span className="font-mono text-slate-700">{deleteConfirmServer.ipAddress}</span>
                  </div>
                  <div className="flex justify-between text-[11px] font-semibold text-slate-550">
                    <span>API Port:</span>
                    <span className="font-mono text-slate-700">{deleteConfirmServer.port}</span>
                  </div>
                </div>
                <p className="text-[10px] text-rose-600 font-semibold bg-rose-50/50 p-2.5 rounded-lg border border-rose-100/50 text-center mt-3">
                  ⚠️ Tindakan ini permanen. Sinkronisasi log, status, dan voucher hotspot untuk lokasi server ini akan segera diputus!
                </p>
              </div>
            </div>
            <div className="bg-slate-50 px-6 py-4 flex gap-3 border-t border-slate-100 justify-end">
              <button
                type="button"
                onClick={() => setDeleteConfirmServer(null)}
                className="flex-1 py-2.5 bg-white text-slate-700 border border-slate-200 font-bold hover:bg-slate-150 rounded-xl text-xs transition cursor-pointer text-center"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteServer(deleteConfirmServer.id);
                  setDeleteConfirmServer(null);
                }}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-black rounded-xl text-xs transition cursor-pointer text-center shadow-xs"
              >
                Ya, Hapus Router
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
