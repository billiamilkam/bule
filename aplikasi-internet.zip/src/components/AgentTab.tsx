import React, { useState } from 'react';
import { Reseller, Paket, MikrotikServer } from '../types';
import { formatRupiah } from '../utils';
import { 
  Store, User, Plus, Phone, DollarSign, Wallet, Percent, MapPin, Tag, 
  RefreshCw, X, Edit2, Shield, CheckSquare, Square, Key, Server, AlertCircle 
} from 'lucide-react';

interface AgentTabProps {
  resellers: Reseller[];
  paket: Paket[];
  servers: MikrotikServer[];
  onAddReseller: (r: Omit<Reseller, 'id'>) => void;
  onUpdateReseller: (r: Reseller) => void;
  onDeleteReseller: (id: string) => void;
  onUpdatePaket?: (p: Paket) => void;
}

const ALLOWED_RESELLER_MENUS = [
  { id: 'create_manual', label: 'Bisa Cetak Manual (Tunggal)' },
  { id: 'create_bulk', label: 'Bisa Cetak Massal (Bulk)' },
  { id: 'topup_simulation', label: 'Bisa Mengajukan Top-Up / Simulator' },
  { id: 'vouchers_history', label: 'Bisa Melihat Riwayat Cetak' }
];

export default function AgentTab({
  resellers,
  paket,
  servers,
  onAddReseller,
  onUpdateReseller,
  onDeleteReseller,
  onUpdatePaket
}: AgentTabProps) {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingReseller, setEditingReseller] = useState<Reseller | null>(null);
  const [resellerToDelete, setResellerToDelete] = useState<Reseller | null>(null);
  const [formData, setFormData] = useState({
    nama: '',
    wilayah: '',
    noHp: '',
    saldo: 0,
    komisiPercent: 10,
    statusAktif: true,
    username: '',
    password: '123',
    allowedMenus: [] as string[],
    allowedPaketIds: [] as string[],
    allowedServerIds: [] as string[],
    paketCustomPrices: {} as Record<string, { hargaModal: number; hargaJual: number }>
  });

  // Top Up Simulator State
  const [isTopUpOpen, setIsTopUpOpen] = useState(false);
  const [topUpTarget, setTopUpTarget] = useState<Reseller | null>(null);
  const [topUpAmount, setTopUpAmount] = useState(100000);
  const [balanceAction, setBalanceAction] = useState<'ADD' | 'SUBTRACT'>('ADD');

  const openAddModal = () => {
    setEditingReseller(null);
    
    // Auto populate default custom prices
    const initialPrices: Record<string, { hargaModal: number; hargaJual: number }> = {};
    paket.forEach(p => {
      const defaultValue = p.harga > 50000 ? Math.round(p.harga / 10) : p.harga;
      initialPrices[p.id] = {
        hargaModal: Math.round(defaultValue * 0.9), // 10% discount default
        hargaJual: defaultValue
      };
    });

    setFormData({
      nama: '',
      wilayah: '',
      noHp: '08',
      saldo: 0,
      komisiPercent: 10,
      statusAktif: true,
      username: '',
      password: '123',
      allowedMenus: ['create_manual', 'create_bulk', 'topup_simulation', 'vouchers_history'],
      allowedPaketIds: paket.map(p => p.id),
      allowedServerIds: servers.map(s => s.id),
      paketCustomPrices: initialPrices
    });
    setIsModalOpen(true);
  };

  const openEditModal = (r: Reseller) => {
    setEditingReseller(r);
    
    // Auto backfill prices if reseller database doesn't have custom pricing yet
    const loadedPrices = { ...(r.paketCustomPrices || {}) };
    paket.forEach(p => {
      if (!loadedPrices[p.id]) {
        const defaultValue = p.harga > 50000 ? Math.round(p.harga / 10) : p.harga;
        const commFactor = (100 - (r.komisiPercent || 10)) / 100;
        loadedPrices[p.id] = {
          hargaModal: Math.round(defaultValue * commFactor),
          hargaJual: defaultValue
        };
      }
    });

    setFormData({
      nama: r.nama,
      wilayah: r.wilayah,
      noHp: r.noHp,
      saldo: r.saldo,
      komisiPercent: r.komisiPercent || 10,
      statusAktif: r.statusAktif,
      username: r.username || '',
      password: r.password || '123',
      allowedMenus: r.allowedMenus || ['create_manual', 'create_bulk', 'topup_simulation', 'vouchers_history'],
      allowedPaketIds: r.allowedPaketIds || paket.map(p => p.id),
      allowedServerIds: r.allowedServerIds || servers.map(s => s.id),
      paketCustomPrices: loadedPrices
    });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.nama.trim() || !formData.noHp.trim()) {
      alert('Nama Toko/Agen dan No HP harus diisi!');
      return;
    }

    if (editingReseller) {
      onUpdateReseller({
        ...editingReseller,
        ...formData
      });
    } else {
      onAddReseller(formData);
    }
    setIsModalOpen(false);
  };

  const handleTopUpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!topUpTarget) return;

    let newSaldo = topUpTarget.saldo;
    if (balanceAction === 'ADD') {
      newSaldo += topUpAmount;
    } else {
      if (topUpTarget.saldo < topUpAmount) {
        if (!confirm(`Peringatan: Saldo agen saat ini (${formatRupiah(topUpTarget.saldo)}) lebih kecil dari nominal penarikan (${formatRupiah(topUpAmount)}). Saldo akan menjadi negatif atau nol. Lanjutkan?`)) {
          return;
        }
      }
      newSaldo = Math.max(0, topUpTarget.saldo - topUpAmount);
    }

    onUpdateReseller({
      ...topUpTarget,
      saldo: newSaldo
    });
    setIsTopUpOpen(false);
    if (balanceAction === 'ADD') {
      alert(`Top Up Sukses: Ditambahkan ${formatRupiah(topUpAmount)} ke saldo Agen "${topUpTarget.nama}". Saldo akhir: ${formatRupiah(newSaldo)}`);
    } else {
      alert(`Sukses Mengambil Saldo: Dikurangi ${formatRupiah(topUpAmount)} dari saldo Agen "${topUpTarget.nama}". Saldo akhir: ${formatRupiah(newSaldo)}`);
    }
  };

  return (
    <div id="agent-tab" className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Keagenan & Reseller Voucher</h2>
          <p className="text-xs text-slate-500">Kelola agen warung/toko lokal yang mendistribusikan voucher WiFi koin prabayar Anda di lapangan.</p>
        </div>

        <button
          onClick={openAddModal}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-indigo-600 text-white rounded-xl font-bold text-xs hover:bg-indigo-700 transition shadow-sm cursor-pointer"
        >
          <Plus size={15} /> Daftarkan Agen Baru
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {resellers.map((r) => {
          const enabledMenus = r.allowedMenus || ['create_manual', 'create_bulk', 'topup_simulation', 'vouchers_history'];
          const enabledPackages = r.allowedPaketIds || paket.map(p => p.id);
          
          return (
            <div 
              key={r.id}
              className={`bg-white rounded-2xl border ${r.statusAktif ? 'border-slate-200' : 'border-slate-100 opacity-65'} p-5 relative overflow-hidden flex flex-col justify-between hover:border-indigo-150 transition-all duration-300 shadow-xs`}
            >
              <div>
                <div className="absolute top-4 right-4 flex items-center gap-1.5">
                  <span className={`w-2 h-2 rounded-full ${r.statusAktif ? 'bg-emerald-500 animate-pulse' : 'bg-slate-300'}`} />
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    {r.statusAktif ? 'Aktif' : 'Macet'}
                  </span>
                </div>

                <div className="flex items-center gap-3.5 mb-4">
                  <div className={`p-3 rounded-xl ${r.statusAktif ? 'bg-indigo-50 text-indigo-600' : 'bg-slate-100'}`}>
                    <Store size={20} />
                  </div>
                  <div>
                    <h4 className="font-extrabold text-slate-800 text-sm leading-tight">{r.nama}</h4>
                    <p className="text-[10px] text-slate-400 mt-1 uppercase font-bold tracking-wider">ID: {r.id}</p>
                  </div>
                </div>

                <div className="space-y-2 text-xs text-slate-600 pt-3 border-t border-slate-100 font-sans">
                  <div className="flex items-center gap-2">
                    <MapPin size={14} className="text-slate-400" />
                    <span>{r.wilayah}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone size={14} className="text-slate-400" />
                    <span>{r.noHp}</span>
                  </div>
                  <div className="flex items-center gap-2 bg-slate-50 px-2 py-1.5 rounded-lg border border-slate-100 font-mono text-[10px] mt-1 text-slate-500">
                    <span className="font-bold text-indigo-600">Login ID:</span> {r.username || 'belum_set'} 
                    <span className="mx-1">|</span> 
                    <span className="font-bold text-indigo-600">Sandi:</span> {r.password || '123'}
                  </div>
                  <div className="flex items-center justify-between bg-emerald-50/50 p-2.5 rounded-lg border border-emerald-100/40 mt-3">
                    <div className="flex items-center gap-1.5 text-emerald-800">
                      <Wallet size={14} />
                      <span className="font-bold">Sisa Deposit:</span>
                    </div>
                    <span className="font-mono font-black text-emerald-700 text-sm">{formatRupiah(r.saldo)}</span>
                  </div>
                  <div className="flex flex-col gap-1 text-[11px] pt-1">
                    <span className="text-slate-500 font-bold block">Tarif Modal / Jual & Profit</span>
                    <div className="bg-slate-50 p-2 rounded-xl border border-slate-150 max-h-32 overflow-y-auto text-[10px] space-y-1 mt-0.5">
                      {enabledPackages.map(pid => {
                        const pName = paket.find(p => p.id === pid)?.nama || pid;
                        const cPrice = r.paketCustomPrices?.[pid] || {
                          hargaModal: Math.round((paket.find(p => p.id === pid)?.harga || 0) > 50000 ? ((paket.find(p => p.id === pid)?.harga || 50000) / 10) * 0.9 : (paket.find(p => p.id === pid)?.harga || 5000) * 0.9),
                          hargaJual: Math.round((paket.find(p => p.id === pid)?.harga || 0) > 50000 ? (paket.find(p => p.id === pid)?.harga || 50000) / 10 : (paket.find(p => p.id === pid)?.harga || 5000))
                        };
                        const profit = cPrice.hargaJual - cPrice.hargaModal;
                        return (
                          <div key={pid} className="flex justify-between items-center bg-white px-2 py-1 rounded-lg border border-slate-250">
                            <span className="font-semibold text-slate-705 truncate max-w-[100px]">📦 {pName}:</span>
                            <span className="font-mono text-slate-500">
                              {formatRupiah(cPrice.hargaModal)}/{formatRupiah(cPrice.hargaJual)} <span className="text-emerald-600 font-bold">(+{formatRupiah(profit)})</span>
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  
                  {/* Visual indication of limits */}
                  <div className="pt-2 border-t border-slate-100 space-y-1">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wide">Akses Hak Menu, Profil & Router</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      <span className="text-[9px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-medium">
                        🔑 {enabledMenus.length} Menu Diizinkan
                      </span>
                      <span className="text-[9px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-medium">
                        📶 {enabledPackages.length} Paket Diizinkan
                      </span>
                      <span className="text-[9px] bg-indigo-50 text-indigo-700 px-1.5 py-0.5 rounded font-medium">
                        📡 {(r.allowedServerIds || []).length === 0 ? servers.length : (r.allowedServerIds || []).length} Router Centang
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between border-t border-slate-100 pt-4 mt-4">
                <div className="flex gap-1.5">
                  <button
                    onClick={() => {
                      setTopUpTarget(r);
                      setBalanceAction('ADD');
                      setTopUpAmount(100000);
                      setIsTopUpOpen(true);
                    }}
                    className="px-2.5 py-1.5 bg-indigo-50 hover:bg-indigo-600 text-indigo-700 hover:text-white rounded-lg font-bold text-[11px] border border-indigo-100 flex items-center gap-1 transition shadow-xs cursor-pointer"
                  >
                    <DollarSign size={13} /> Top Up
                  </button>

                  <button
                    onClick={() => openEditModal(r)}
                    className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg font-bold text-[11px] border border-slate-200 flex items-center gap-1 transition cursor-pointer"
                  >
                    <Edit2 size={13} /> Akses
                  </button>
                </div>

                <button
                  onClick={() => setResellerToDelete(r)}
                  className="text-xs text-slate-400 hover:text-rose-500 hover:underline transition cursor-pointer"
                >
                  Hapus
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* REGISTER / EDIT RESELLER MODAL */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl shadow-xl w-full max-w-lg overflow-hidden border border-slate-100">
            <div className="flex justify-between items-center bg-slate-50 px-6 py-4 border-b border-slate-100">
              <h4 className="font-extrabold text-slate-800 flex items-center gap-2 text-sm">
                <Store size={18} className="text-indigo-600" />
                {editingReseller ? `Sunting Data & Akses: ${editingReseller.nama}` : 'Registrasikan Reseller Kemitraan Baru'}
              </h4>
              <button onClick={() => setIsModalOpen(false)} className="p-1 hover:bg-slate-200 rounded-lg text-slate-400 transition">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto text-xs font-semibold text-slate-705">
              <div className="space-y-1">
                <label>Nama Toko / Nama Agen *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Kios Kelontong Bu Erna"
                  className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-medium text-slate-800"
                  value={formData.nama}
                  onChange={(e) => setFormData({ ...formData, nama: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label>Nomor WhatsApp *</label>
                  <input
                    type="tel"
                    required
                    placeholder="Contoh: 0812XXXXXXXX"
                    className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-mono"
                    value={formData.noHp}
                    onChange={(e) => setFormData({ ...formData, noHp: e.target.value })}
                  />
                </div>

                <div className="space-y-1">
                  <label>Wilayah Distribusi Kampus/Sektor *</label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: RT 03 Barat"
                    className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden"
                    value={formData.wilayah}
                    onChange={(e) => setFormData({ ...formData, wilayah: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label>Username Login Reseller</label>
                  <input
                    type="text"
                    placeholder="sri_warung"
                    className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden text-slate-800 font-mono"
                    value={formData.username}
                    onChange={(e) => setFormData({ ...formData, username: e.target.value.toLowerCase().replace(/\s+/g, '') })}
                  />
                </div>

                <div className="space-y-1">
                  <label>Sandi Login Reseller</label>
                  <input
                    type="text"
                    placeholder="123"
                    className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden text-slate-800 font-mono"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label>Deposit Saldo (Rp) *</label>
                <input
                  type="number"
                  className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-mono font-bold"
                  value={formData.saldo}
                  onChange={(e) => setFormData({ ...formData, saldo: parseInt(e.target.value) || 0 })}
                />
              </div>

              {/* PERMISSION CONTROLS: MENUS/FEATURES */}
              <div className="space-y-2 border-t border-slate-100 pt-4">
                <div className="flex items-center gap-1.5 text-indigo-700 mb-1.5">
                  <Shield size={14} />
                  <span className="font-bold text-slate-800 text-xs">Atur Akses Menu / Fitur Agen</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 bg-slate-50 p-3 rounded-2xl border border-slate-150">
                  {ALLOWED_RESELLER_MENUS.map((m) => {
                    const checked = formData.allowedMenus.includes(m.id);
                    return (
                      <label key={m.id} className="flex items-center gap-2 text-[11px] text-slate-650 cursor-pointer font-medium hover:text-indigo-600 transition select-none">
                        <input
                          type="checkbox"
                          className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer shrink-0"
                          checked={checked}
                          onChange={(e) => {
                            const updated = e.target.checked
                              ? [...formData.allowedMenus, m.id]
                              : formData.allowedMenus.filter(id => id !== m.id);
                            setFormData({ ...formData, allowedMenus: updated });
                          }}
                        />
                        <span>{m.label}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* PERMISSION CONTROLS: MIKROTIK USER PROFILES (PAKET) */}
              <div className="space-y-2 border-t border-slate-100 pt-4">
                <div className="flex items-center gap-1.5 text-indigo-700 mb-1.5">
                  <Tag size={14} />
                  <span className="font-bold text-slate-800 text-xs">Pilih User Profile MikroTik yang Boleh Dijual Agen</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 bg-slate-50 p-3 rounded-2xl border border-slate-150 max-h-56 overflow-y-auto">
                  {paket.map((p) => {
                    const checked = formData.allowedPaketIds.includes(p.id);
                    return (
                      <div key={p.id} className="flex items-center justify-between gap-1 bg-white p-2.5 rounded-xl border border-slate-200/80 hover:border-indigo-150 hover:shadow-xs transition">
                        <label className="flex items-center gap-2 text-[11px] text-slate-650 cursor-pointer font-medium hover:text-indigo-600 select-none flex-1 truncate">
                          <input
                            type="checkbox"
                            className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer shrink-0"
                            checked={checked}
                            onChange={(e) => {
                              const updated = e.target.checked
                                ? [...formData.allowedPaketIds, p.id]
                                : formData.allowedPaketIds.filter(id => id !== p.id);
                              setFormData({ ...formData, allowedPaketIds: updated });
                            }}
                          />
                          <span className="truncate block leading-tight">
                            <span className="font-bold text-slate-800 text-[11px] block truncate">📦 {p.nama}</span>
                            <span className="text-[10px] text-slate-400 block">Speed: {p.kecepatan}</span>
                            <span className="font-mono text-[9px] text-indigo-700 bg-indigo-50/70 border border-indigo-100/40 px-1 py-0.2 rounded font-semibold inline-block mt-0.5 truncate max-w-[140px]">
                              MTRik: {p.mikrotikProfile || 'tidak_set'}
                            </span>
                          </span>
                        </label>
                        
                        <button
                          type="button"
                          onClick={() => {
                            const newProfileName = prompt(
                              `Edit Nama User Profile MikroTik untuk "${p.nama}":\n(Masa aktif, limitasi kecepatan, & share-user dari profile ini akan disinkronkan otomatis koin/voucher)`,
                              p.mikrotikProfile || ''
                            );
                            if (newProfileName !== null && onUpdatePaket) {
                              const sanitized = newProfileName.trim().replace(/\s+/g, '-');
                              onUpdatePaket({
                                ...p,
                                mikrotikProfile: sanitized
                              });
                            }
                          }}
                          className="p-1 px-1.5 hover:bg-indigo-50 text-indigo-500 hover:text-indigo-700 rounded-md transition shrink-0 cursor-pointer border border-indigo-100/50 flex items-center justify-center bg-indigo-50/20"
                          title="Sunting Nama User Profile"
                        >
                          <Edit2 size={10} />
                        </button>
                      </div>
                    );
                  })}
                </div>
                <p className="text-[10px] text-slate-400 font-normal">Centang paket kecepatan MikroTik khusus yang diperbolehkan dicetak menjadi voucher oleh agen ini.</p>
              </div>

              {/* CUSTOM PRICING FOR CHECKED PACKAGES */}
              {formData.allowedPaketIds.length > 0 && (
                <div className="space-y-3.5 border-t border-slate-100 pt-4">
                  <div className="flex items-center gap-1.5 text-indigo-700 mb-1">
                    <DollarSign size={14} />
                    <span className="font-extrabold text-slate-800 text-xs">Atur Harga Modal & Harga Jual Agen</span>
                  </div>
                  <div className="space-y-2.5 max-h-56 overflow-y-auto pr-1 bg-slate-50 p-3 rounded-2xl border border-slate-150">
                    {paket.filter(p => formData.allowedPaketIds.includes(p.id)).map((p) => {
                      const currentPrices = formData.paketCustomPrices?.[p.id] || {
                        hargaModal: p.harga > 50000 ? Math.round((p.harga / 10) * 0.9) : Math.round(p.harga * 0.9),
                        hargaJual: p.harga > 50000 ? Math.round(p.harga / 10) : p.harga
                      };
                      return (
                        <div key={p.id} className="text-[11px] p-2.5 bg-white rounded-xl border border-slate-200 shadow-3xs space-y-2">
                          <div className="flex justify-between items-center font-bold text-slate-700 border-b border-slate-100 pb-1.5">
                            <span>📦 {p.nama} ({p.kecepatan})</span>
                            <span className="text-slate-400 text-[10px]">Tarif Asli: {formatRupiah(p.harga)}</span>
                          </div>
                          <div className="grid grid-cols-2 gap-2">
                            <div className="space-y-1">
                              <span className="text-slate-500 font-medium font-mono text-[10px]">Harga Modal Agen</span>
                              <input
                                type="number"
                                className="w-full bg-slate-50 px-2 py-1.5 rounded-md border border-slate-200 font-bold font-mono focus:outline-hidden"
                                value={currentPrices.hargaModal}
                                onChange={(e) => {
                                  const val = parseInt(e.target.value) || 0;
                                  const updatedPrices = {
                                    ...formData.paketCustomPrices,
                                    [p.id]: { ...currentPrices, hargaModal: val }
                                  };
                                  setFormData({ ...formData, paketCustomPrices: updatedPrices });
                                }}
                              />
                            </div>
                            <div className="space-y-1">
                              <span className="text-slate-500 font-medium font-mono text-[10px]">Harga Jual Ke User</span>
                              <input
                                type="number"
                                className="w-full bg-slate-50 px-2 py-1.5 rounded-md border border-slate-200 font-bold font-mono focus:outline-hidden"
                                value={currentPrices.hargaJual}
                                onChange={(e) => {
                                  const val = parseInt(e.target.value) || 0;
                                  const updatedPrices = {
                                    ...formData.paketCustomPrices,
                                    [p.id]: { ...currentPrices, hargaJual: val }
                                  };
                                  setFormData({ ...formData, paketCustomPrices: updatedPrices });
                                }}
                              />
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                  <p className="text-[10px] text-slate-400 font-normal">Harga Modal Agen memotong saldo deposit agen setiap cetak voucher. Harga Jual adalah tarif eceran fisik voucher.</p>
                </div>
              )}

              {/* PERMISSION CONTROLS: AUTHORIZED MIKROTIK ROUTERS */}
              <div className="space-y-2 border-t border-slate-100 pt-4">
                <div className="flex items-center gap-1.5 text-indigo-700 mb-1.5">
                  <Server size={14} />
                  <span className="font-bold text-slate-800 text-xs">Pilih Router MikroTik yang Boleh Diakses Agen</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 bg-slate-50 p-3 rounded-2xl border border-slate-150 max-h-32 overflow-y-auto">
                  {servers.map((s) => {
                    const checked = formData.allowedServerIds.includes(s.id);
                    return (
                      <label key={s.id} className="flex items-center gap-2 text-[11px] text-slate-650 cursor-pointer font-medium hover:text-indigo-600 transition select-none">
                        <input
                          type="checkbox"
                          className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer shrink-0"
                          checked={checked}
                          onChange={(e) => {
                            const updated = e.target.checked
                              ? [...formData.allowedServerIds, s.id]
                              : formData.allowedServerIds.filter(id => id !== s.id);
                            setFormData({ ...formData, allowedServerIds: updated });
                          }}
                        />
                        <span>📡 {s.nama} ({s.status})</span>
                      </label>
                    );
                  })}
                </div>
                <p className="text-[10px] text-slate-400 font-normal">Centang router MikroTik operasional yang diperbolehkan diakses agen untuk mencetak voucher WiFi.</p>
              </div>

              {/* Form Buttons */}
              <div className="flex justify-end gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-650 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition cursor-pointer shadow-sm"
                >
                  {editingReseller ? 'Simpan Perubahan' : 'Registrasikan Agen'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* TOP UP / REDUCE BALANCE DIALOG */}
      {isTopUpOpen && topUpTarget && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl shadow-xl w-full max-w-sm overflow-hidden border border-slate-100">
            <div className="flex justify-between items-center bg-slate-50 px-5 py-3.5 border-b border-slate-100">
              <h4 className="font-extrabold text-slate-800 flex items-center gap-1.5 text-xs">
                <Wallet size={16} className={balanceAction === 'ADD' ? "text-emerald-600" : "text-rose-600"} />
                {balanceAction === 'ADD' ? 'Isi Ulang Saldo Deposit Agen' : 'Ambil / Kurangi Saldo Deposit Agen'}
              </h4>
              <button onClick={() => setIsTopUpOpen(false)} className="p-1 hover:bg-slate-200 rounded-lg text-slate-400 transition">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleTopUpSubmit} className="p-5 space-y-4 text-xs font-semibold text-slate-600">
              <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200/50">
                <p className="text-[10px] text-slate-400 font-bold uppercase">Nama Toko Agen</p>
                <h4 className="text-slate-800 font-extrabold text-sm mt-0.5">{topUpTarget.nama}</h4>
                <p className="text-xs text-emerald-700 font-bold mt-1 font-mono">Saldo Saat Ini: {formatRupiah(topUpTarget.saldo)}</p>
              </div>

              {/* Action Selector Toggle */}
              <div className="space-y-1.5">
                <label className="text-slate-550 font-bold">Pilih Tindakan Saldo *</label>
                <div className="flex gap-1.5 bg-slate-100 p-1 rounded-xl">
                  <button
                    type="button"
                    onClick={() => setBalanceAction('ADD')}
                    className={`flex-1 py-2 text-center rounded-lg text-[11px] font-bold transition select-none cursor-pointer ${
                      balanceAction === 'ADD'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-slate-500 hover:text-slate-700'
                    }`}
                  >
                    Setor / Tambah
                  </button>
                  <button
                    type="button"
                    onClick={() => setBalanceAction('SUBTRACT')}
                    className={`flex-1 py-2 text-center rounded-lg text-[11px] font-bold transition select-none cursor-pointer ${
                      balanceAction === 'SUBTRACT'
                        ? 'bg-rose-600 text-white shadow-xs'
                        : 'text-slate-500 hover:text-slate-700'
                    }`}
                  >
                    Tarik / Kurangi
                  </button>
                </div>
              </div>

              <div className="space-y-1">
                <label>
                  {balanceAction === 'ADD' ? 'Nominal Tambah Saldo (IDR) *' : 'Nominal Pengurangan Saldo (IDR) *'}
                </label>
                <input
                  type="number"
                  required
                  min={1000}
                  className="w-full bg-slate-50 p-3 rounded-lg border border-slate-200 focus:outline-hidden font-mono font-black text-slate-800 text-base"
                  value={topUpAmount}
                  onChange={(e) => setTopUpAmount(parseInt(e.target.value) || 0)}
                />
              </div>

              <div className="grid grid-cols-2 gap-2 text-center text-[10px] font-bold">
                <button
                  type="button"
                  onClick={() => setTopUpAmount(100000)}
                  className="p-2 border border-slate-200 rounded-lg hover:bg-slate-100 text-slate-700 cursor-pointer"
                >
                  + 100 Ribu
                </button>
                <button
                  type="button"
                  onClick={() => setTopUpAmount(500000)}
                  className="p-2 border border-slate-200 rounded-lg hover:bg-slate-100 text-slate-700 cursor-pointer"
                >
                  + 500 Ribu
                </button>
              </div>

              <div className="flex justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsTopUpOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 rounded-xl"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className={`px-5 py-2 text-white rounded-xl font-bold transition cursor-pointer shadow-sm ${
                    balanceAction === 'ADD' 
                      ? 'bg-emerald-600 hover:bg-emerald-700' 
                      : 'bg-rose-600 hover:bg-rose-700'
                  }`}
                >
                  {balanceAction === 'ADD' ? 'Proses Setor Dana' : 'Proses Kurangi Saldo'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CUSTOM CONFIRMATION MODAL FOR DELETING AGENT/RESELLER */}
      {resellerToDelete && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50 animate-fadeIn">
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xl w-full max-w-sm overflow-hidden p-6 space-y-4">
            <div className="flex items-center gap-3 text-rose-650">
              <div className="p-2 bg-rose-50 rounded-full text-rose-600">
                <AlertCircle size={20} />
              </div>
              <h4 className="font-bold text-slate-800 text-sm">Konfirmasi Hapus Kemitraan</h4>
            </div>
            
            <p className="text-xs text-slate-500 leading-relaxed">
              Apakah Anda yakin ingin menghapus kemitraan agen <strong className="text-slate-800 font-bold">{resellerToDelete.nama}</strong>?
              <br className="mb-1" />
              Tindakan ini tidak dapat dibatalkan. Kemitraan dan sisa deposit saldo akan ditutup sepenuhnya.
            </p>

            <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setResellerToDelete(null)}
                className="px-3.5 py-2 hover:bg-slate-100 text-slate-500 hover:text-slate-700 rounded-xl font-semibold text-xs transition cursor-pointer"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={() => {
                  onDeleteReseller(resellerToDelete.id);
                  setResellerToDelete(null);
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl font-bold text-xs transition cursor-pointer shadow-xs font-sans"
              >
                Ya, Hapus
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
