import React, { useState } from 'react';
import { Teknisi, Paket, HotspotVoucher, MikrotikServer, PortalActivityLog } from '../types';
import { formatRupiah } from '../utils';
import { 
  LogOut, Plus, Wifi, Layers, Tag, Printer, Trash2, Search, 
  RefreshCw, ShieldCheck, Cpu, HardDrive, Globe, ChevronDown, CheckCircle, Smartphone, ShieldAlert,
  ClipboardList
} from 'lucide-react';

interface TeknisiPortalProps {
  teknisi: Teknisi;
  paket: Paket[];
  vouchers: HotspotVoucher[];
  servers: MikrotikServer[];
  onLogout: () => void;
  onAddVoucher: (v: Omit<HotspotVoucher, 'id'>) => void;
  onDeleteVoucher: (id: string) => void;
  onBulkGenerate?: (payload: { count: number; paketId: string; harga: number; durasi: string; serverName: string; prefix?: string; credMode?: 'UP' | 'U_P'; charLength?: number }) => void;
  portalLogs: PortalActivityLog[];
  onAddPortalLog: (log: Omit<PortalActivityLog, 'id' | 'timestamp'>) => void;
}

export default function TeknisiPortal({
  teknisi,
  paket,
  vouchers,
  servers,
  onLogout,
  onAddVoucher,
  onDeleteVoucher,
  onBulkGenerate,
  portalLogs,
  onAddPortalLog
}: TeknisiPortalProps) {
  // Filter servers allowed for this technician
  const allowedServers = servers.filter(s => 
    !teknisi.allowedServerIds || 
    teknisi.allowedServerIds.length === 0 || 
    teknisi.allowedServerIds.includes(s.id)
  );

  // Filter packages allowed for this technician
  const allowedPakets = paket.filter(p => 
    !teknisi.allowedPaketIds || 
    teknisi.allowedPaketIds.length === 0 || 
    teknisi.allowedPaketIds.includes(p.id)
  );

  // Selected Server State (for monitoring & selective generation / viewing)
  const [selectedServerId, setSelectedServerId] = useState<string>(allowedServers[0]?.id || '');
  const [searchQuery, setSearchQuery] = useState('');
  
  // Log filtering states
  const [logSearch, setLogSearch] = useState('');
  const [logTypeFilter, setLogTypeFilter] = useState<'ALL' | 'LOGIN' | 'CETAK_VOUCHER'>('ALL');
  
  const allowedMenus = teknisi.allowedMenus || ['create_manual', 'create_bulk'];
  const hasManual = allowedMenus.includes('create_manual');
  const hasBulk = allowedMenus.includes('create_bulk');

  // Generation mode switcher: manual vs bulk
  const [generationMode, setGenerationMode] = useState<'manual' | 'bulk'>(() => {
    if (!hasManual && hasBulk) return 'bulk';
    return 'manual';
  });
  const [bulkCount, setBulkCount] = useState(10);

  // Create Manual Voucher form states
  const [voucherCode, setVoucherCode] = useState('');
  const [voucherPassword, setVoucherPassword] = useState('');
  const [selectedPaketId, setSelectedPaketId] = useState(allowedPakets[0]?.id || '');
  const [voucherDurasi, setVoucherDurasi] = useState('1 Bulan (FUP 50GB)');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Find active server object
  const currentSelectedServer = allowedServers.find(s => s.id === selectedServerId);

  // Direct Vouchers list filtered by selected server (if filtered to one)
  const filteredVouchers = vouchers.filter(v => {
    // If we have a selected server, match by name or show all if none selected
    const matchesServer = currentSelectedServer ? v.serverName === currentSelectedServer.nama : true;
    const matchesSearch = v.code.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          v.durasi.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesServer && matchesSearch;
  });

  const handleCreateVoucherSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentSelectedServer) {
      alert('Pilih router MikroTik operasional terlebih dahulu!');
      return;
    }
    if (!voucherCode.trim()) {
      alert('Kode Voucher / Username Hotspot harus diisi!');
      return;
    }

    const pkt = allowedPakets.find(p => p.id === selectedPaketId) || allowedPakets[0];
    if (!pkt) {
      alert('Mohon pilih profil paket yang diizinkan!');
      return;
    }

    setIsSubmitting(true);

    // Simulate MikroTik API delay (200ms)
    setTimeout(() => {
      onAddVoucher({
        code: voucherCode.trim().toUpperCase(),
        password: voucherPassword.trim() || undefined,
        paketId: pkt.id,
        harga: pkt.harga / 10,  // Standard retail pricing
        durasi: voucherDurasi,
        serverName: currentSelectedServer.nama,
        status: 'AKTIF'
      });

      // Clear code form
      setVoucherCode('');
      setVoucherPassword('');
      setIsSubmitting(false);

      alert(`[Mikrotik API - SUCCESS]: Berhasil mendaftarkan hotspot user "${voucherCode.trim().toUpperCase()}" langsung di router "${currentSelectedServer.nama}"!`);
    }, 200);
  };

  const handleBulkGenerateSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentSelectedServer) {
      alert('Pilih router MikroTik operasional terlebih dahulu!');
      return;
    }
    if (!onBulkGenerate) {
      alert('Fitur generasi masal dinonaktifkan.');
      return;
    }

    const pkt = allowedPakets.find(p => p.id === selectedPaketId) || allowedPakets[0];
    if (!pkt) {
      alert('Mohon pilih profil paket yang diizinkan!');
      return;
    }

    setIsSubmitting(true);

    setTimeout(() => {
      onBulkGenerate({
        count: bulkCount,
        paketId: pkt.id,
        harga: pkt.harga / 10,
        durasi: voucherDurasi,
        serverName: currentSelectedServer.nama
      });
      setIsSubmitting(false);
      alert(`[Mikrotik API - SUCCESS]: Berhasil menghasilkan ${bulkCount} voucher secara massal langsung di router "${currentSelectedServer.nama}"!`);
    }, 200);
  };

  const selectedPaketObj = allowedPakets.find(p => p.id === selectedPaketId);

  return (
    <div id="teknisi-portal-root" className="min-h-screen bg-slate-900 text-slate-100 font-sans">
      
      {/* Top Professional Header for Technician Portal */}
      <header className="bg-slate-950 border-b border-slate-800 sticky top-0 z-40 px-4 py-3.5">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400">
              <ShieldCheck size={22} className="animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-black tracking-widest text-indigo-400 uppercase bg-indigo-950 px-2 py-0.5 rounded-md border border-indigo-500/20">Portal Teknisi Lapangan</span>
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
              </div>
              <h1 className="text-sm font-extrabold text-white mt-0.5">{teknisi.nama}</h1>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="hidden sm:flex items-center gap-1.5 text-xs text-slate-400">
              <Smartphone size={14} className="text-slate-500" />
              <span>{teknisi.noHp}</span>
            </div>
            <button
              onClick={onLogout}
              className="inline-flex items-center gap-2 px-3 py-1.5 bg-rose-500/15 border border-rose-500/30 hover:bg-rose-500/25 text-rose-300 rounded-xl text-xs font-bold transition cursor-pointer"
            >
              <LogOut size={14} /> Log Out
            </button>
          </div>
        </div>
      </header>

      {/* Main Grid Workspace */}
      <main className="max-w-7xl mx-auto p-4 lg:p-6 space-y-6">
        
        {/* Router Selector Widget & Live Monitoring (Multi-MikroTik capability) */}
        <section className="bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden shadow-xl p-5 space-y-4">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
            <div>
              <h2 className="text-sm font-bold text-slate-350 flex items-center gap-1.5">
                <Globe size={16} className="text-indigo-400" />
                Daftar Koneksi & Saringan Multi-MikroTik Anda
              </h2>
              <p className="text-[11px] text-slate-500 mt-0.5">
                Pilih mikrotik aktif untuk menyaring log voucher hotspot serta melakukan pencetakan user manual di router terkait.
              </p>
            </div>

            {/* Selector Dropdown */}
            <div className="relative">
              <select
                className="appearance-none bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 pr-10 text-xs text-slate-200 font-bold focus:outline-hidden focus:border-indigo-500 cursor-pointer w-full md:w-64"
                value={selectedServerId}
                onChange={(e) => setSelectedServerId(e.target.value)}
              >
                {allowedServers.map((s, i) => (
                  <option key={i} value={s.id}>📡 {s.nama} ({s.ipAddress})</option>
                ))}
              </select>
              <ChevronDown size={14} className="absolute right-3.5 top-3.5 text-slate-400 pointer-events-none" />
            </div>
          </div>

          {/* Active Router Info Dashboard */}
          {currentSelectedServer ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-1 text-slate-300">
              <div className="bg-slate-900/50 p-4.5 rounded-xl border border-slate-800 flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400">
                  <Globe size={16} />
                </div>
                <div>
                  <div className="text-[9px] uppercase font-bold tracking-wider text-slate-500">Router IP Address</div>
                  <div className="text-xs font-mono font-bold mt-0.5 text-slate-200">{currentSelectedServer.ipAddress}:{currentSelectedServer.port}</div>
                </div>
              </div>

              <div className="bg-slate-900/50 p-4.5 rounded-xl border border-slate-800 flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-400">
                  <Cpu size={16} />
                </div>
                <div>
                  <div className="text-[9px] uppercase font-bold tracking-wider text-slate-500">Uptime Router</div>
                  <div className="text-xs font-medium mt-0.5 text-slate-200">{currentSelectedServer.uptime || '1d 5h 11m'}</div>
                </div>
              </div>

              <div className="bg-slate-900/50 p-4.5 rounded-xl border border-slate-800 flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-400">
                  <HardDrive size={16} />
                </div>
                <div>
                  <div className="text-[9px] uppercase font-bold tracking-wider text-slate-500">CPU Load Router</div>
                  <div className="text-xs font-black mt-0.5 text-slate-200 font-mono">{currentSelectedServer.cpuLoad || 3}% Load</div>
                </div>
              </div>

              <div className="bg-slate-900/50 p-4.5 rounded-xl border border-slate-800 flex items-center gap-3">
                <div className="w-9 h-9 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400">
                  <CheckCircle size={16} />
                </div>
                <div>
                  <div className="text-[9px] uppercase font-bold tracking-wider text-slate-500">Status API Link</div>
                  <div className="text-xs font-extrabold mt-0.5 text-emerald-400 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                    ONLINE (TERHUBUNG)
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <p className="text-xs text-amber-500 font-bold italic">⚠️ Tidak ada server/router divalidasi kepada akun teknisi Anda.</p>
          )}
        </section>

        {/* Portal Two Columns Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
          
          {/* COLUMN 1: MANUAL & BULK HOTSPOT USER GENERATION */}
          <section className="lg:col-span-1 bg-slate-950 rounded-2xl border border-slate-800 p-5 space-y-4 shadow-xl">
            {!hasManual && !hasBulk ? (
              <div className="p-5 bg-rose-955/20 border border-rose-900/30 text-rose-400 rounded-xl text-center text-xs space-y-3 py-10">
                <ShieldAlert size={36} className="mx-auto text-rose-500" />
                <p className="font-extrabold text-white text-sm uppercase tracking-wider">Akses Cetak Voucher Dibatasi</p>
                <p className="text-[11px] text-slate-400 leading-relaxed font-semibold">Kebijakan administrator membatasi akun Anda sehingga tidak diperkenankan mencetak voucher tunggal maupun voucher massal.</p>
              </div>
            ) : (
              <>
                {/* Mode Switcher */}
                {hasManual && hasBulk && (
                  <div className="flex gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800">
                    <button
                      type="button"
                      onClick={() => setGenerationMode('manual')}
                      className={`flex-1 py-1.5 rounded-lg text-center text-xs font-bold transition cursor-pointer ${
                        generationMode === 'manual'
                          ? 'bg-indigo-600 text-white shadow-xs'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      Cetak Tunggal
                    </button>
                    <button
                      type="button"
                      onClick={() => setGenerationMode('bulk')}
                      className={`flex-1 py-1.5 rounded-lg text-center text-xs font-bold transition cursor-pointer ${
                        generationMode === 'bulk'
                          ? 'bg-indigo-600 text-white shadow-xs'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      Cetak Massal
                    </button>
                  </div>
                )}

                <div>
                  <h3 className="text-sm font-bold text-slate-350 flex items-center gap-1.5">
                    {generationMode === 'manual' ? (
                      <>
                        <Plus size={16} className="text-indigo-400" />
                        Registrasi Hotspot User Manual
                      </>
                    ) : (
                      <>
                        <Layers size={16} className="text-indigo-400" />
                        Generator Voucher Massal
                      </>
                    )}
                  </h3>
                  <p className="text-[10px] text-slate-500 mt-0.5">
                    {generationMode === 'manual'
                      ? 'Ketik dan kirim data user hotspot baru langsung ke database API router MikroTik terpilih.'
                      : 'Cetak beberapa voucher acak sekaligus langsung dikirim ke API router MikroTik.'}
                  </p>
                </div>

                {generationMode === 'manual' ? (
                  <form onSubmit={handleCreateVoucherSubmit} className="space-y-4 text-xs font-semibold text-slate-300">
                    {/* MikroTik Destination Status */}
                    <div className="bg-slate-900 border border-slate-800 p-3 rounded-xl">
                      <span className="text-[10px] uppercase font-bold text-slate-500 block mb-0.5">Router Tujuan:</span>
                      <span className="text-xs font-black text-indigo-400 font-mono">📡 {currentSelectedServer ? currentSelectedServer.nama : 'Silakan pilih router'}</span>
                    </div>

                    {/* User Code */}
                    <div className="space-y-1">
                      <label className="text-slate-400 font-bold">Hotspot Username / Code *</label>
                      <input
                        type="text"
                        required
                        placeholder="Contoh: AGENS_WIFI"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-100 font-bold font-mono focus:outline-hidden focus:border-indigo-500 uppercase text-center text-sm"
                        value={voucherCode}
                        onChange={(e) => setVoucherCode(e.target.value)}
                      />
                    </div>

                    {/* User Password */}
                    <div className="space-y-1">
                      <label className="text-slate-400 font-bold flex justify-between items-center">
                        <span>Hotspot Password (Opsional)</span>
                        <span className="text-[9px] text-slate-500 font-normal">Kosongkan jika username saja</span>
                      </label>
                      <input
                        type="text"
                        placeholder="Masukkan password jika ada"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-100 font-bold font-mono focus:outline-hidden focus:border-indigo-500"
                        value={voucherPassword}
                        onChange={(e) => setVoucherPassword(e.target.value)}
                      />
                    </div>

                    {/* Select allowed package profile */}
                    <div className="space-y-1">
                      <label className="text-slate-400 font-bold">Pilih Profil Kecepatan (Paket) *</label>
                      <select
                        required
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-200 font-bold focus:outline-hidden focus:border-indigo-500 cursor-pointer"
                        value={selectedPaketId}
                        onChange={(e) => setSelectedPaketId(e.target.value)}
                      >
                        {allowedPakets.map((p, i) => (
                          <option key={i} value={p.id}>🎯 {p.nama} ({p.kecepatan})</option>
                        ))}
                      </select>
                    </div>

                    {/* Retail price calculation guide */}
                    {selectedPaketObj && (
                      <div className="bg-indigo-950/20 border border-indigo-900/30 p-3 rounded-xl flex items-center justify-between text-[11px] leading-relaxed">
                        <span className="text-slate-400 font-medium">Estimasi Nilai Eceran/Harga:</span>
                        <strong className="text-indigo-400 font-mono font-black text-xs">{formatRupiah(selectedPaketObj.harga / 10)}</strong>
                      </div>
                    )}

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full inline-flex items-center justify-center gap-2 px-4 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold font-sans transition text-xs shadow-md cursor-pointer disabled:opacity-50"
                    >
                      {isSubmitting ? (
                        <>
                          <RefreshCw className="animate-spin" size={14} /> Memproses MikroTik API...
                        </>
                      ) : (
                        <>
                          <Wifi size={14} /> Cetak & Daftarkan Voucher
                        </>
                      )}
                    </button>
                  </form>
                ) : (
                  <form onSubmit={handleBulkGenerateSubmit} className="space-y-4 text-xs font-semibold text-slate-300">
                    {/* MikroTik Destination Status */}
                    <div className="bg-slate-900 border border-slate-800 p-3 rounded-xl">
                      <span className="text-[10px] uppercase font-bold text-slate-500 block mb-0.5">Router Tujuan:</span>
                      <span className="text-xs font-black text-indigo-400 font-mono">📡 {currentSelectedServer ? currentSelectedServer.nama : 'Silakan pilih router'}</span>
                    </div>

                    {/* Number of Vouchers */}
                    <div className="space-y-1">
                      <label className="text-slate-400 font-bold">Jumlah Voucher (Lembar) *</label>
                      <select
                        required
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-200 font-bold focus:outline-hidden focus:border-indigo-500 cursor-pointer"
                        value={bulkCount}
                        onChange={(e) => setBulkCount(Number(e.target.value))}
                      >
                        {[5, 10, 20, 50, 100].map((num) => (
                          <option key={num} value={num}>⚙️ {num} Lembar Voucher</option>
                        ))}
                      </select>
                    </div>

                    {/* Select allowed package profile */}
                    <div className="space-y-1">
                      <label className="text-slate-400 font-bold">Pilih Profil Kecepatan (Paket) *</label>
                      <select
                        required
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-200 font-bold focus:outline-hidden focus:border-indigo-500 cursor-pointer"
                        value={selectedPaketId}
                        onChange={(e) => setSelectedPaketId(e.target.value)}
                      >
                        {allowedPakets.map((p, i) => (
                          <option key={i} value={p.id}>🎯 {p.nama} ({p.kecepatan})</option>
                        ))}
                      </select>
                    </div>

                    {/* Durasi FUP placeholder/input */}
                    <div className="space-y-1">
                      <label className="text-slate-400 font-bold">Masa Aktif & FUP</label>
                      <input
                        type="text"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-slate-100 font-bold font-mono focus:outline-hidden focus:border-indigo-500"
                        placeholder="Contoh: 1 Hari (FUP 2GB)"
                        value={voucherDurasi}
                        onChange={(e) => setVoucherDurasi(e.target.value)}
                      />
                    </div>

                    {/* Retail price calculation guide */}
                    {selectedPaketObj && (
                      <div className="space-y-2 bg-indigo-950/20 border border-indigo-900/30 p-3 rounded-xl text-[11px] leading-relaxed">
                        <div className="flex items-center justify-between">
                          <span className="text-slate-400">Harga Eceran per pcs:</span>
                          <strong className="text-indigo-400 font-mono font-bold">{formatRupiah(selectedPaketObj.harga / 10)}</strong>
                        </div>
                        <div className="flex items-center justify-between border-t border-indigo-900/30 pt-1.5">
                          <span className="text-slate-400 font-medium">Total Estimasi Harga Massal:</span>
                          <strong className="text-indigo-400 font-mono font-black text-xs">{formatRupiah((selectedPaketObj.harga / 10) * bulkCount)}</strong>
                        </div>
                      </div>
                    )}

                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full inline-flex items-center justify-center gap-2 px-4 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold font-sans transition text-xs shadow-md cursor-pointer disabled:opacity-50"
                    >
                      {isSubmitting ? (
                        <>
                          <RefreshCw className="animate-spin" size={14} /> Memproses MikroTik API...
                        </>
                      ) : (
                        <>
                          <Layers size={14} /> Generate Voucher Massal
                        </>
                      )}
                    </button>
                  </form>
                )}
              </>
            )}
          </section>

          {/* COLUMN 2: WORKSPACE TABLE VIEW (Vouchers on current selected Mikrotik) */}
          <section className="lg:col-span-2 bg-slate-950 rounded-2xl border border-slate-800 shadow-xl overflow-hidden flex flex-col justify-between">
            <div className="p-5 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-sm font-bold text-slate-350 flex items-center gap-1.5">
                  <Tag size={16} className="text-indigo-400" />
                  Daftar Voucher Terdaftar di Router
                </h3>
                <p className="text-[10px] text-slate-500 mt-0.5">
                  Menampilkan database cache hotspot vouchers pada MikroTik terkomunikasi.
                </p>
              </div>

              {/* Search Within Table */}
              <div className="relative">
                <Search size={14} className="absolute left-3 top-2.5 text-slate-500" />
                <input
                  type="text"
                  placeholder="Cari kode voucher..."
                  className="bg-slate-900 border border-slate-700 rounded-lg pl-8 pr-3 py-1.5 text-slate-200 text-xs focus:outline-hidden focus:border-indigo-500 placeholder:text-slate-500 font-medium w-full sm:w-48"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>

            {/* Vouchers Table wrapper */}
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead className="bg-slate-900 text-slate-500 font-bold uppercase text-[9px] tracking-wider border-b border-slate-800">
                  <tr>
                    <th className="p-3.5">Kode Hotspot / Password</th>
                    <th className="p-3.5">Router Server</th>
                    <th className="p-3.5">Masa Aktif (Durasi)</th>
                    <th className="p-3.5 text-right">Nilai Rupiah</th>
                    <th className="p-3.5 text-center">Status</th>
                    <th className="p-3.5 text-center">Operasi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-400 font-medium font-mono">
                  {filteredVouchers.map((v) => {
                    const pktObj = paket.find(p => p.id === v.paketId);
                    return (
                      <tr key={v.id} className="hover:bg-slate-900/40 text-xs">
                        <td className="p-3.5">
                          <div className="font-bold text-slate-200 text-xs tracking-wider uppercase flex items-center gap-1.5">
                            <span className="px-1.5 py-0.5 bg-indigo-950/50 border border-indigo-900/40 rounded text-indigo-400 text-[10px] font-black">{v.code}</span>
                          </div>
                          {v.password && <div className="text-[10px] text-slate-550 mt-0.5">Sandi: {v.password}</div>}
                        </td>
                        <td className="p-3.5 font-sans">
                          <span className="text-[10px] bg-slate-900 border border-slate-800 text-slate-450 px-1.5 py-0.5 rounded">📡 {v.serverName}</span>
                        </td>
                        <td className="p-3.5 font-sans text-slate-350">
                          <div>{v.durasi}</div>
                          <div className="text-[9px] text-slate-550 mt-0.5">Profile: {pktObj ? pktObj.nama : 'Custom'}</div>
                        </td>
                        <td className="p-3.5 text-right text-slate-200 font-bold">
                          {formatRupiah(v.harga)}
                        </td>
                        <td className="p-3.5 text-center">
                          <span className={`inline-block px-2 py-0.5 rounded text-[9px] font-black tracking-widest border font-sans ${
                            v.status === 'AKTIF' 
                              ? 'bg-emerald-950/50 border-emerald-900 text-emerald-400' 
                              : v.status === 'DIGUNAKAN'
                                ? 'bg-indigo-950/50 border-indigo-900 text-indigo-400'
                                : 'bg-slate-900 border-slate-800 text-slate-500'
                          }`}>
                            {v.status}
                          </span>
                        </td>
                        <td className="p-3.5 text-center font-sans">
                          <button
                            onClick={() => {
                              if (confirm('Yakin ingin menghapus voucher hotspot ini dari database router?')) {
                                onDeleteVoucher(v.id);
                              }
                            }}
                            className="p-1 px-1.5 bg-rose-500/10 border border-rose-500/20 text-rose-400 hover:bg-rose-500/20 rounded-md transition cursor-pointer"
                            title="Format/Hapus Hotspot User"
                          >
                            <Trash2 size={12} />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>

              {filteredVouchers.length === 0 && (
                <div className="text-center py-12 text-slate-500 font-sans">
                  📡
                  <p className="text-xs font-bold mt-1">Tidak ada voucher terdeteksi pada router ini</p>
                  <p className="text-[10px] text-slate-600 mt-0.5">Silakan tambahkan data dengan mengisi formulir cetak manual di sebelah kiri.</p>
                </div>
              )}
            </div>

            {/* Footer Workspace guidelines */}
            <div className="bg-slate-900/40 p-4 border-t border-slate-800 font-sans leading-relaxed text-[10px] text-slate-500">
              💡 <strong>Tips Operasional:</strong> Tiket voucher yang Anda cetak diatas akan otomatis tersinkronisasi ke table database dashboard admin utama secara instan.
            </div>
          </section>

          {/* FULL-WIDTH SECTION: MONITOR ANTARMUKA API & LOGS */}
          <section className="col-span-full bg-slate-950 border border-slate-800 rounded-3xl p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="font-extrabold text-sm text-slate-200 flex items-center gap-2">
                  <ClipboardList size={16} className="text-indigo-400" />
                  Monitor Antarmuka API & Audit Log Router
                </h3>
                <p className="text-[10px] text-slate-500 mt-0.5">Semua entri aktivitas API MikroTik, pendaftaran user baru, login, dan bulk-voucher oleh akun Anda.</p>
              </div>

              <div className="flex items-center gap-2">
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Saring detail log..."
                    className="bg-slate-900 border border-slate-750 rounded-lg pl-8 pr-3 py-1.5 text-slate-200 text-xs focus:outline-hidden focus:border-indigo-500 placeholder:text-slate-500 font-sans"
                    value={logSearch}
                    onChange={(e) => setLogSearch(e.target.value)}
                  />
                  <Search size={13} className="absolute left-2.5 top-2.5 text-slate-505" />
                </div>

                <select
                  value={logTypeFilter}
                  onChange={(e: any) => setLogTypeFilter(e.target.value)}
                  className="bg-slate-900 border border-slate-750 text-slate-300 text-[11px] py-1.5 px-2.5 rounded-lg font-sans"
                >
                  <option value="ALL">Semua Tipe</option>
                  <option value="LOGIN">Masuk Portal</option>
                  <option value="CETAK_VOUCHER">Operasi API</option>
                </select>
              </div>
            </div>

            {/* Logs List Table */}
            <div className="border border-slate-800 rounded-2xl overflow-hidden font-sans">
              <div className="overflow-y-auto max-h-72">
                <table className="w-full text-left text-xs border-collapse">
                  <thead className="bg-slate-900/80 text-slate-400 uppercase tracking-wider font-extrabold text-[10px] border-b border-slate-850 sticky top-0 z-10">
                    <tr>
                      <th className="p-3">Waktu</th>
                      <th className="p-3">Tipe/Aksi</th>
                      <th className="p-3">Modul / Interface</th>
                      <th className="p-3 text-left">Deskripsi Kejadian API</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-850 font-semibold text-slate-300">
                    {(portalLogs || [])
                      .filter(log => log.portalType === 'TEKNISI' && log.operatorId === teknisi.id)
                      .filter(log => logTypeFilter === 'ALL' || log.aktifitasType === logTypeFilter)
                      .filter(log => logSearch === '' || log.detail.toLowerCase().includes(logSearch.toLowerCase()) || log.fiturLabel.toLowerCase().includes(logSearch.toLowerCase()))
                      .length === 0 ? (
                      <tr>
                        <td colSpan={4} className="p-8 text-center text-slate-500 font-normal italic">
                          Belum ada baris riwayat koneksi API Router Mikrotik.
                        </td>
                      </tr>
                    ) : (
                      (portalLogs || [])
                        .filter(log => log.portalType === 'TEKNISI' && log.operatorId === teknisi.id)
                        .filter(log => logTypeFilter === 'ALL' || log.aktifitasType === logTypeFilter)
                        .filter(log => logSearch === '' || log.detail.toLowerCase().includes(logSearch.toLowerCase()) || log.fiturLabel.toLowerCase().includes(logSearch.toLowerCase()))
                        .map(log => (
                          <tr key={log.id} className="hover:bg-slate-900/40 transition">
                            <td className="p-3 text-slate-500 text-[10px] font-mono whitespace-nowrap">
                              {log.timestamp.substring(0, 10)} {log.timestamp.substring(11, 16)}
                            </td>
                            <td className="p-3">
                              <span className={`px-2 py-0.5 rounded text-[9px] uppercase tracking-wider font-black ${
                                log.aktifitasType === 'LOGIN' ? 'bg-blue-950 text-blue-400 border border-blue-900' :
                                log.aktifitasType === 'CETAK_VOUCHER' ? 'bg-purple-950 text-purple-400 border border-purple-900' :
                                'bg-slate-905 text-slate-400 border border-slate-800'
                              }`}>
                                {log.aktifitasType.replace('_', ' ')}
                              </span>
                            </td>
                            <td className="p-3 text-[11px] text-white whitespace-nowrap">
                              ⚡ {log.fiturLabel}
                            </td>
                            <td className="p-3 text-slate-400 text-[11px] font-sans leading-relaxed">
                              {log.detail}
                            </td>
                          </tr>
                        ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          </section>

        </div>
      </main>

    </div>
  );
}
