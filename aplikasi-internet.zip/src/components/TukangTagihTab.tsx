import React, { useState } from 'react';
import { TukangTagih, Pelanggan, Paket } from '../types';
import { User, MapPin, Phone, Shield, Lock, Trash2, Edit2, Plus, X, Search } from 'lucide-react';

interface TukangTagihTabProps {
  collectors: TukangTagih[];
  pelanggan: Pelanggan[];
  paket: Paket[];
  onAddCollector: (c: Omit<TukangTagih, 'id'>) => void;
  onUpdateCollector: (c: TukangTagih) => void;
  onDeleteCollector: (id: string) => void;
}

const ALLOWED_COLLECTOR_MENUS = [
  { id: 'beranda', label: 'Dashboard / Ringkasan' },
  { id: 'tagihan', label: 'Proses & Setor Tagihan Lapangan' },
  { id: 'pelanggan', label: 'Akses Anggota Saya' },
  { id: 'tambah_pelanggan', label: 'Daftar Pelanggan Baru' }
];

export default function TukangTagihTab({
  collectors,
  pelanggan,
  paket,
  onAddCollector,
  onUpdateCollector,
  onDeleteCollector
}: TukangTagihTabProps) {
  const [search, setSearch] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCollector, setEditingCollector] = useState<TukangTagih | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    nama: '',
    alamat: '',
    noHp: '',
    username: '',
    password: '',
    statusAktif: true,
    allowedMenus: [] as string[],
    allowedPaketIds: [] as string[]
  });

  const openAddModal = () => {
    setFormData({
      nama: '',
      alamat: '',
      noHp: '08',
      username: '',
      password: '123',
      statusAktif: true,
      allowedMenus: ['beranda', 'tagihan', 'pelanggan', 'tambah_pelanggan'],
      allowedPaketIds: paket.map(p => p.id)
    });
    setEditingCollector(null);
    setErrorMsg(null);
    setIsModalOpen(true);
  };

  const openEditModal = (c: TukangTagih) => {
    setEditingCollector(c);
    setFormData({
      nama: c.nama,
      alamat: c.alamat,
      noHp: c.noHp,
      username: c.username,
      password: c.password || '',
      statusAktif: c.statusAktif,
      allowedMenus: c.allowedMenus || ['beranda', 'tagihan', 'pelanggan', 'tambah_pelanggan'],
      allowedPaketIds: c.allowedPaketIds || paket.map(p => p.id)
    });
    setErrorMsg(null);
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.nama.trim() || !formData.username.trim()) {
      setErrorMsg('Nama dan Username harus diisi!');
      return;
    }

    if (editingCollector) {
      onUpdateCollector({
        ...editingCollector,
        ...formData
      });
    } else {
      onAddCollector(formData);
    }
    setIsModalOpen(false);
    setErrorMsg(null);
  };

  // Count assigned customers
  const getAssignedCount = (id: string) => {
    return pelanggan.filter(p => p.tukangTagihId === id).length;
  };

  // Filter collectors
  const filteredCollectors = collectors.filter((c) => {
    const query = search.toLowerCase();
    return (
      c.nama.toLowerCase().includes(query) ||
      c.noHp.includes(query) ||
      c.alamat.toLowerCase().includes(query)
    );
  });

  return (
    <div id="tukang-tagih-tab" className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-800">Daftar Petugas / Tukang Tagih</h2>
          <p className="text-xs text-slate-500">Kelola kru penagih iuran bulanan berkredensial login terbatas.</p>
        </div>
        <button
          onClick={openAddModal}
          className="inline-flex items-center gap-2 px-4 py-2.5 bg-indigo-600 text-white rounded-xl font-bold text-xs hover:bg-indigo-700 transition shadow-sm cursor-pointer"
        >
          <Plus size={16} /> Tambah Tukang Tagih
        </button>
      </div>

      {/* Real-time search bar */}
      <div className="max-w-md bg-slate-50 p-3 rounded-xl border border-slate-100">
        <div className="relative">
          <Search size={16} className="absolute left-3 top-3 text-slate-400" />
          <input
            type="text"
            placeholder="Cari nama, No. WA, atau alamat petugas..."
            className="w-full bg-white text-xs pl-9 pr-3 py-2.5 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 placeholder:text-slate-400 font-medium"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCollectors.map((c) => {
          const assignedCount = getAssignedCount(c.id);
          const enabledMenus = c.allowedMenus || ['beranda', 'tagihan', 'pelanggan', 'tambah_pelanggan'];
          const enabledPackages = c.allowedPaketIds || paket.map(p => p.id);
          
          return (
            <div 
              key={c.id} 
              className={`bg-white rounded-2xl border ${c.statusAktif ? 'border-slate-200' : 'border-slate-100 opacity-65'} p-5 shadow-sm space-y-4 hover:border-indigo-100 transition-all duration-300 relative overflow-hidden flex flex-col justify-between`}
            >
              <div>
                {/* Active Badge */}
                <div className="absolute top-4 right-4 flex items-center gap-1.5">
                  <span className={`w-2 h-2 rounded-full ${c.statusAktif ? 'bg-emerald-500 animate-pulse' : 'bg-slate-300'}`} />
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                    {c.statusAktif ? 'Aktif' : 'Nonaktif'}
                  </span>
                </div>

                {/* Header profile info */}
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-600 font-extrabold text-base">
                    <User size={22} />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-800 text-sm">{c.nama}</h4>
                    <p className="text-[11px] text-indigo-600 font-bold bg-indigo-50 px-2 py-0.5 rounded-md inline-block mt-1">
                      {assignedCount} Pelanggan Ditugaskan
                    </p>
                  </div>
                </div>

                {/* Meta details */}
                <div className="space-y-1.5 text-xs text-slate-600 font-sans border-t border-slate-100 pt-3 mt-3">
                  <div className="flex items-start gap-2">
                    <MapPin size={14} className="text-slate-400 shrink-0 mt-0.5" />
                    <span className="leading-tight">{c.alamat}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone size={14} className="text-slate-400" />
                    <span>{c.noHp}</span>
                  </div>
                  <div className="flex items-center gap-2 bg-slate-50 p-2 rounded-lg border border-slate-100/70 mt-2">
                    <Lock size={12} className="text-indigo-500" />
                    <span className="font-mono text-[10px] text-slate-500">
                      Username: <strong className="text-slate-800">{c.username}</strong> | Pass: <span className="bg-slate-200/80 px-1 rounded font-bold">●●●</span>
                    </span>
                  </div>

                  {/* Visual indication of limits */}
                  <div className="pt-2.5 border-t border-slate-100 space-y-1 mt-2">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wide">Akses Hak Menu & Profil</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      <span className="text-[9px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-medium">
                        🔑 {enabledMenus.length} Menu Diizinkan
                      </span>
                      <span className="text-[9px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-medium">
                        📶 {enabledPackages.length} Paket Diizinkan
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-1.5 pt-3 border-t border-slate-100 mt-4">
                <button
                  onClick={() => openEditModal(c)}
                  className="p-2 text-slate-400 hover:text-indigo-600 hover:bg-slate-50 rounded-lg transition"
                  title="Edit data & hak akses"
                >
                  <Edit2 size={14} />
                </button>
                {deleteConfirmId === c.id ? (
                  <div className="inline-flex items-center gap-1 bg-rose-50 p-1 rounded-lg border border-rose-150 animate-fadeIn">
                    <button
                      type="button"
                      onClick={() => {
                        onDeleteCollector(c.id);
                        setDeleteConfirmId(null);
                      }}
                      className="px-2 py-1 bg-rose-600 hover:bg-rose-700 text-white rounded-md text-[10px] font-black uppercase cursor-pointer"
                    >
                      Hapus
                    </button>
                    <button
                      type="button"
                      onClick={() => setDeleteConfirmId(null)}
                      className="px-2 py-1 bg-slate-200 hover:bg-slate-350 text-slate-700 rounded-md text-[10px] font-bold uppercase cursor-pointer"
                    >
                      Batal
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setDeleteConfirmId(c.id)}
                    className="p-2 text-slate-400 hover:text-rose-500 hover:bg-slate-50 rounded-lg transition"
                    title="Hapus akun"
                  >
                    <Trash2 size={14} />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {filteredCollectors.length === 0 && (
        <div className="bg-slate-50 text-slate-500 text-center py-10 rounded-2xl border border-dashed border-slate-200">
          <p className="text-sm font-medium">Petugas tidak ditemukan</p>
          <p className="text-xs text-slate-400 mt-1">Coba masukkan nama, nomor WA, atau alamat yang berbeda.</p>
        </div>
      )}

      {/* MODAL CONSOLE */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl shadow-xl w-full max-w-lg overflow-hidden transform transition-all border border-slate-100">
            {/* Header */}
            <div className="flex justify-between items-center bg-slate-50 px-6 py-4 border-b border-slate-100">
              <h4 className="font-bold text-slate-800 flex items-center gap-2 text-sm">
                <Shield size={18} className="text-indigo-600" />
                {editingCollector ? `Sunting Akun & Akses: ${editingCollector.nama}` : 'Tambah Tukang Tagih Baru'}
              </h4>
              <button
                onClick={() => setIsModalOpen(false)}
                className="p-1 hover:bg-slate-200 rounded-lg text-slate-400 transition"
              >
                <X size={18} />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[75vh] overflow-y-auto text-xs">
              {errorMsg && (
                <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl font-bold animate-fadeIn">
                  ⚠️ {errorMsg}
                </div>
              )}
              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Nama Lengkap Petugas *</label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Danang Wijayanto"
                  className="w-full bg-slate-50 px-3 py-2.5 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-medium"
                  value={formData.nama}
                  onChange={(e) => setFormData({ ...formData, nama: e.target.value })}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="font-semibold text-slate-700">No. WhatsApp *</label>
                  <input
                    type="tel"
                    required
                    placeholder="Contoh: 081299990000"
                    className="w-full bg-slate-50 px-3 py-2.5 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-mono"
                    value={formData.noHp}
                    onChange={(e) => setFormData({ ...formData, noHp: e.target.value })}
                  />
                </div>

                <div className="space-y-1">
                  <label className="font-semibold text-slate-700">Status Petugas</label>
                  <select
                    className="w-full bg-slate-50 px-3 py-2.5 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-medium"
                    value={formData.statusAktif ? 'true' : 'false'}
                    onChange={(e) => setFormData({ ...formData, statusAktif: e.target.value === 'true' })}
                  >
                    <option value="true">Aktif (Bisa Login)</option>
                    <option value="false">Nonaktif (Blokir)</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Alamat Rumah Petugas *</label>
                <textarea
                  required
                  rows={2}
                  placeholder="Contoh: Perum Indah Permata Blok D-2"
                  className="w-full bg-slate-50 px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-medium"
                  value={formData.alamat}
                  onChange={(e) => setFormData({ ...formData, alamat: e.target.value })}
                />
              </div>

              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/50 space-y-3.5">
                <div className="flex items-center gap-1.5 border-b border-slate-200/60 pb-1.5">
                  <Lock size={13} className="text-indigo-600" />
                  <span className="font-bold text-slate-800 text-[11px]">Kredensial Akses Aplikasi</span>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="font-semibold text-slate-600">Username Login</label>
                    <input
                      type="text"
                      required
                      placeholder="username"
                      className="w-full bg-white px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-mono text-center"
                      value={formData.username}
                      onChange={(e) => setFormData({ ...formData, username: e.target.value.toLowerCase().replace(/\s+/g, '') })}
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="font-semibold text-slate-600">Password</label>
                    <input
                      type="text"
                      required
                      placeholder="Password"
                      className="w-full bg-white px-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden focus:border-indigo-500 font-mono text-center"
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    />
                  </div>
                </div>
              </div>

              {/* PERMISSION CONTROLS: MENUS/FEATURES */}
              <div className="space-y-2 border-t border-slate-100 pt-4">
                <div className="flex items-center gap-1.5 text-indigo-700 mb-1.5">
                  <Shield size={14} />
                  <span className="font-bold text-slate-800 text-xs">Atur Akses Menu / Fitur Petugas</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 bg-slate-50 p-3 rounded-2xl border border-slate-150">
                  {ALLOWED_COLLECTOR_MENUS.map((m) => {
                    const checked = formData.allowedMenus.includes(m.id);
                    return (
                      <label key={m.id} className="flex items-center gap-2 text-[11px] text-slate-650 cursor-pointer font-medium hover:text-indigo-600 transition select-none">
                        <input
                          type="checkbox"
                          className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer shrink-0"
                          checked={checked}
                          onChange={(e) => {
                            const updated = e.target.checked
                              ? [...formData.allowedMenus, m.id]
                              : formData.allowedMenus.filter(id => id !== m.id);
                            setFormData({ ...formData, allowedMenus: updated });
                          }}
                        />
                        <span>{m.label}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* PERMISSION CONTROLS: ALLOWED PAKETS */}
              <div className="space-y-2 border-t border-slate-100 pt-4">
                <div className="flex items-center gap-1.5 text-indigo-700 mb-1.5">
                  <Plus size={14} className="text-indigo-600 outline-hidden shrink-0" />
                  <span className="font-bold text-slate-800 text-xs">User Profile yang Diizinkan (Registrasi Pelanggan)</span>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 bg-slate-50 p-3 rounded-2xl border border-slate-150 max-h-32 overflow-y-auto">
                  {paket.map((p) => {
                    const checked = formData.allowedPaketIds.includes(p.id);
                    return (
                      <label key={p.id} className="flex items-center gap-2 text-[11px] text-slate-650 cursor-pointer font-medium hover:text-indigo-600 transition select-none">
                        <input
                          type="checkbox"
                          className="rounded border-slate-300 text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer shrink-0"
                          checked={checked}
                          onChange={(e) => {
                            const updated = e.target.checked
                              ? [...formData.allowedPaketIds, p.id]
                              : formData.allowedPaketIds.filter(id => id !== p.id);
                            setFormData({ ...formData, allowedPaketIds: updated });
                          }}
                        />
                        <span>📦 {p.nama} ({p.kecepatan})</span>
                      </label>
                    );
                  })}
                </div>
                <p className="text-[10px] text-slate-400 font-normal">Centang paket kecepatan / user profile yang boleh diregistrasikan oleh petugas di lapangan.</p>
              </div>

              {/* Form Buttons */}
              <div className="flex justify-end gap-2 pt-4 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-650 rounded-xl font-bold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition cursor-pointer shadow-sm"
                >
                  {editingCollector ? 'Simpan Perubahan' : 'Simpan Petugas'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
