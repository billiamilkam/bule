import React, { useState } from 'react';
import { HotspotVoucher, Paket, MikrotikServer, Reseller } from '../types';
import { Plus, Layers, ShieldCheck, Tag, User, Printer, Globe, Trash2, ExternalLink, QrCode, Server, Terminal, CheckCircle2, Play, Check, Settings, AlertCircle, Database } from 'lucide-react';

interface HotspotTabProps {
  vouchers: HotspotVoucher[];
  paket: Paket[];
  servers: MikrotikServer[];
  resellers: Reseller[];
  onAddVoucher: (v: Omit<HotspotVoucher, 'id'>) => void;
  onUpdateVoucher?: (v: HotspotVoucher) => void;
  onDeleteVoucher: (id: string) => void;
  onBulkGenerate: (payload: { count: number; paketId: string; harga: number; durasi: string; serverName: string; prefix?: string; credMode?: 'UP' | 'U_P'; charLength?: number }) => void;
}

export default function HotspotTab({
  vouchers,
  paket,
  servers,
  resellers,
  onAddVoucher,
  onDeleteVoucher,
  onBulkGenerate
}: HotspotTabProps) {
  // Navigation State between Manual additions vs Bulk generation
  const [activeMode, setActiveMode] = useState<'MANUAL' | 'BULK'>('MANUAL');

  // Mikrotik API Syncing States
  const [syncModalOpen, setSyncModalOpen] = useState(false);
  const [syncType, setSyncType] = useState<'MANUAL' | 'BULK'>('MANUAL');
  const [syncTargetRouterVal, setSyncTargetRouterVal] = useState('');
  const [syncTotalCount, setSyncTotalCount] = useState(0);
  const [syncCurrentCount, setSyncCurrentCount] = useState(0);
  const [syncSteps, setSyncSteps] = useState<{ name: string; status: 'idle' | 'loading' | 'success' | 'failed'; desc?: string }[]>([]);
  const [syncTerminalCommands, setSyncTerminalCommands] = useState<string[]>([]);

  // Search filter local state for voucher list
  const [searchQuery, setSearchQuery] = useState('');

  // Bulk Generator State
  const [genCount, setGenCount] = useState(10);
  const [genPaketId, setGenPaketId] = useState(paket[0]?.id || '');
  const [genHarga, setGenHarga] = useState(paket[0]?.harga || 5000);
  const [genServer, setGenServer] = useState(servers[0]?.nama || 'Mikrotik Pusat Kamal');
  const [genPrefix, setGenPrefix] = useState('');
  const [genCredMode, setGenCredMode] = useState<'UP' | 'U_P'>('UP');
  const [genCharLength, setGenCharLength] = useState(6);

  // Manual Generator State
  const [manualCode, setManualCode] = useState('');
  const [manualPassword, setManualPassword] = useState('');
  const [manualPaketId, setManualPaketId] = useState(paket[0]?.id || '');
  const [manualHarga, setManualHarga] = useState(paket[0]?.harga || 5000);
  const [manualServer, setManualServer] = useState(servers[0]?.nama || 'Mikrotik Pusat Kamal');
  const [manualResellerId, setManualResellerId] = useState('');
  const [manualAgentPaymentStatus, setManualAgentPaymentStatus] = useState<'LUNAS' | 'BELUM BAYAR'>('BELUM_BAYAR');

  // Interactive Features State
  const [printVoucher, setPrintVoucher] = useState<HotspotVoucher | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [confirmClearAll, setConfirmClearAll] = useState(false);
  const [testLoginVoucher, setTestLoginVoucher] = useState<HotspotVoucher | null>(null);
  const [loginTestCode, setLoginTestCode] = useState('');
  const [loginTestPass, setLoginTestPass] = useState('');
  const [isConnecting, setIsConnecting] = useState(false);
  const [isConnected, setIsConnected] = useState(false);

  // Helper to dynamically match duration string from packages or set standard automatics
  const getDurasiByPaketId = (id: string) => {
    const pkt = paket.find(p => p.id === id);
    if (!pkt) return 'Otomatis';
    const nameLower = pkt.nama.toLowerCase();
    if (nameLower.includes('hari') || nameLower.includes('jam') || nameLower.includes('bulan')) {
      return pkt.nama;
    }
    // Standard defaults based on price range
    if (pkt.harga >= 50000) return '30 Hari';
    if (pkt.harga >= 10000) return '7 Hari';
    return '1 Hari';
  };

  const handleManualCodeChange = (codeVal: string) => {
    setManualCode(codeVal);
    const trimmed = codeVal.trim().toLowerCase();
    if (trimmed) {
      const matched = resellers.find(r => 
        r.nama.toLowerCase().includes(trimmed) || 
        trimmed.includes(r.nama.toLowerCase()) ||
        (r.username && r.username.toLowerCase().includes(trimmed)) ||
        (r.username && trimmed.includes(r.username.toLowerCase()))
      );
      if (matched) {
        setManualResellerId(matched.id);
      }
    }
  };

  const handleManualPaketSelect = (id: string) => {
    setManualPaketId(id);
    const pkt = paket.find(p => p.id === id);
    if (pkt) {
      setManualHarga(pkt.harga > 50000 ? 5000 : pkt.harga / 10);
    }
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualCode.trim()) {
      alert('Kode / Username harus diisi!');
      return;
    }
    const derivedDurasi = getDurasiByPaketId(manualPaketId);
    const code = manualCode.trim();
    const password = manualPassword.trim() || undefined;
    const selectedPaketObj = paket.find(p => p.id === manualPaketId);
    const profileName = selectedPaketObj ? selectedPaketObj.nama.replace(/\s+/g, '_') : 'default';

    // Set states for Sync Modal
    setSyncType('MANUAL');
    setSyncTargetRouterVal(manualServer);
    setSyncTotalCount(1);
    setSyncCurrentCount(0);
    setSyncModalOpen(true);
    setSyncTerminalCommands([]);

    const steps = [
      { name: 'Membuka Soket Transmisi API-ROS', status: 'loading' as const, desc: `Menghubungi port API MikroTik di router ${manualServer}...` },
      { name: 'Otentikasi Kredensial Winbox API', status: 'idle' as const, desc: 'Mengirimkan challenge handshakes...' },
      { name: 'Pemeriksaan Profil Limitasi Bandwidth', status: 'idle' as const, desc: `Memeriksa apakah profile "${profileName}" tersemat di RouterOS...` },
      { name: 'Eksekusi CLI Hotspot User Add', status: 'idle' as const, desc: 'Menulis baris entri biling baru...' }
    ];
    setSyncSteps(steps);

    // Sequence simulating physical connection and insertion
    setTimeout(() => {
      // Step 2
      setSyncSteps(prev => {
        const next = [...prev];
        next[0] = { ...next[0], status: 'success', desc: 'Port 8728 merespon sukses!' };
        next[1] = { ...next[1], status: 'loading', desc: 'Sertifikasi kredensial biling...' };
        return next;
      });
      setSyncTerminalCommands(prev => [...prev, `>>> CONNECT ${manualServer} API PORT 8728...`, `<<< RouterOS v7 Welcome Prompt challenge=0a2b5c7d`]);

      setTimeout(() => {
        // Step 3
        setSyncSteps(prev => {
          const next = [...prev];
          next[1] = { ...next[1], status: 'success', desc: 'Akses diizinkan (Group API-Full)!' };
          next[2] = { ...next[2], status: 'loading', desc: `Mencari /ip hotspot user profile print where name="${profileName}"` };
          return next;
        });
        setSyncTerminalCommands(prev => [...prev, `>>> /login username="admin" hash="0a2b5c7d..."`, `<<< !done`]);

        setTimeout(() => {
          // Step 4
          setSyncSteps(prev => {
            const next = [...prev];
            next[2] = { ...next[2], status: 'success', desc: `Profile "${profileName}" ditemukan dan sedia.` };
            next[3] = { ...next[3], status: 'loading', desc: `Melakukan insert /ip hotspot user add...` };
            return next;
          });
          setSyncTerminalCommands(prev => [
            ...prev,
            `>>> /ip/hotspot/user/profile/print`,
            `<<< !re .id=*1 name="${profileName}" rate-limit="${selectedPaketObj?.kecepatan || '5M/5M'}"`,
            `<<< !done`,
            `>>> /ip/hotspot/user/add name="${code}" password="${password || code}" profile="${profileName}" limit-uptime="${derivedDurasi}" comment="API_BILLING_${new Date().toISOString().substring(0,10)}"`
          ]);

          setTimeout(() => {
            setSyncSteps(prev => {
              const next = [...prev];
              next[3] = { ...next[3], status: 'success', desc: `Sukses terdaftar! ID Router: *hs_user_${Math.floor(Math.random() * 10000)}` };
              return next;
            });
            setSyncTerminalCommands(prev => [
              ...prev,
              `<<< !done .id=*hs_user_${Math.floor(Math.random() * 10000)}`
            ]);
            setSyncCurrentCount(1);

            // Execute the action in main state
            onAddVoucher({
              code,
              password,
              paketId: manualPaketId,
              harga: manualHarga,
              durasi: derivedDurasi,
              serverName: manualServer,
              status: 'AKTIF',
              resellerId: manualResellerId || undefined,
              agentPaymentStatus: manualResellerId ? manualAgentPaymentStatus : undefined
            });

            // Clean up States
            setManualCode('');
            setManualPassword('');
            setManualResellerId('');
            setManualAgentPaymentStatus('BELUM_BAYAR');
          }, 800);
        }, 850);
      }, 700);
    }, 600);
  };

  const handlePaketSelect = (id: string) => {
    setGenPaketId(id);
    const pkt = paket.find(p => p.id === id);
    if (pkt) {
      setGenHarga(pkt.harga > 50000 ? 5000 : pkt.harga / 10);
    }
  };

  const handleRunGenerator = (e: React.FormEvent) => {
    e.preventDefault();
    const derivedDurasi = getDurasiByPaketId(genPaketId);
    const selectedPaketObj = paket.find(p => p.id === genPaketId);
    const profileName = selectedPaketObj ? selectedPaketObj.nama.replace(/\s+/g, '_') : 'default';

    setSyncType('BULK');
    setSyncTargetRouterVal(genServer);
    setSyncTotalCount(genCount);
    setSyncCurrentCount(0);
    setSyncModalOpen(true);
    setSyncTerminalCommands([]);

    const steps = [
      { name: 'Membuka Jalur Soket API MikroTik', status: 'loading' as const, desc: `Membuka port API 8728 ke ${genServer}...` },
      { name: 'Otentikasi Kredensial Winbox API', status: 'idle' as const, desc: 'Mengirimkan challenge handshakes...' },
      { name: 'Bulk Queue Synchronizer Pool', status: 'idle' as const, desc: `Menyiapkan ${genCount} entri voucher...` }
    ];
    setSyncSteps(steps);

    // Sequence Simulation
    setTimeout(() => {
      setSyncSteps(prev => {
        const next = [...prev];
        next[0] = { ...next[0], status: 'success', desc: 'Port 8728 terhubung stabil!' };
        next[1] = { ...next[1], status: 'loading', desc: 'Melakukan autentikasi API...' };
        return next;
      });
      setSyncTerminalCommands(prev => [...prev, `>>> CONNECT ${genServer} API PORT 8728...`, `<<< Welcome Prompt challenge=hs-bulk-0ea7`]);

      setTimeout(() => {
        setSyncSteps(prev => {
          const next = [...prev];
          next[1] = { ...next[1], status: 'success', desc: 'API access authorized!' };
          next[2] = { ...next[2], status: 'loading', desc: `Mentransfer ${genCount} data voucher hotspot baru...` };
          return next;
        });
        setSyncTerminalCommands(prev => [...prev, `>>> /login username="admin" hash="hs-bulk-0ea7..."`, `<<< !done`, `>>> /ip/hotspot/user/profile/print`]);

        // Generate the random voucher batches code but do it inside an interval simulation
        const characters = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
        const numChars = '23456789';
        const len = genCharLength ? Math.max(1, Math.min(8, genCharLength)) : 6;
        
        let localCreated = 0;
        
        // Push actual items dynamically but with interactive logs
        const intervalTime = Math.min(150, Math.max(10, 800 / genCount)); 
        
        const syncInterval = setInterval(() => {
          if (localCreated >= genCount) {
            clearInterval(syncInterval);
            
            // finalize
            setSyncSteps(prev => {
              const next = [...prev];
              next[2] = { ...next[2], status: 'success', desc: `Sukses menyinkronkan seluruh ${genCount} voucher!` };
              return next;
            });
            
            // Execute onBulkGenerate state updater
            onBulkGenerate({
              count: genCount,
              paketId: genPaketId,
              harga: genHarga,
              durasi: derivedDurasi,
              serverName: genServer,
              prefix: genPrefix,
              credMode: genCredMode,
              charLength: genCharLength
            });
            return;
          }

          // Generate one voucher code
          let randomPart = '';
          for (let j = 0; j < len; j++) {
            randomPart += characters.charAt(Math.floor(Math.random() * characters.length));
          }
          const code = (genPrefix || '') + randomPart;
          let password: string | undefined = undefined;
          if (genCredMode === 'UP') {
            password = code;
          } else if (genCredMode === 'U_P') {
            password = '';
            for (let j = 0; j < len; j++) {
              password += numChars.charAt(Math.floor(Math.random() * numChars.length));
            }
          }

          // Increment count and add console log
          localCreated++;
          setSyncCurrentCount(localCreated);
          setSyncTerminalCommands(prev => [
            ...prev,
            `>>> /ip/hotspot/user/add name="${code}" password="${password || code}" profile="${profileName}" limit-uptime="${derivedDurasi}"`,
            `<<< !done .id=*hs_user_${Math.floor(Math.random() * 90000 + 10000)} (Voucher ${localCreated}/${genCount})`
          ]);
        }, intervalTime);

      }, 700);
    }, 600);
  };

  return (
    <div id="hotspot-tab" className="space-y-6">
      {/* Title Header */}
      <div>
        <h2 className="text-xl font-bold text-slate-800">Manajemen Hotspot & Voucher</h2>
        <p className="text-xs text-slate-500">Buat voucher prabayar baru secara manual atau generate masal otomatis ke router MikroTik Anda.</p>
      </div>

      {/* Sub-Tab Navigation Header */}
      <div className="flex border border-slate-200 bg-slate-50 p-1 rounded-2xl shadow-3xs gap-1 max-w-sm">
        <button
          type="button"
          onClick={() => setActiveMode('MANUAL')}
          className={`flex-1 py-2 text-center text-xs font-black rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${
            activeMode === 'MANUAL'
              ? 'bg-indigo-600 text-white shadow-xs font-bold'
              : 'text-slate-500 hover:bg-slate-100 hover:text-slate-800'
          }`}
        >
          <User size={13} /> Voucher Manual
        </button>
        <button
          type="button"
          onClick={() => setActiveMode('BULK')}
          className={`flex-1 py-2 text-center text-xs font-black rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer ${
            activeMode === 'BULK'
              ? 'bg-indigo-600 text-white shadow-xs font-bold'
              : 'text-slate-500 hover:bg-slate-100 hover:text-slate-800'
          }`}
        >
          <Layers size={13} /> Buat Masal
        </button>
      </div>

      <div className="max-w-xl animate-fadeIn">
        {/* Panel Left: Manual single voucher user */}
        {activeMode === 'MANUAL' && (
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="border-b border-slate-100 pb-3 flex items-center gap-2">
              <User size={16} className="text-indigo-600" />
              <h3 className="font-extrabold text-slate-800 text-sm">Tambah Satu Voucher Manual</h3>
            </div>

            <form onSubmit={handleManualSubmit} className="space-y-4 text-xs font-semibold text-slate-700">
              <div className="space-y-1">
                <label className="text-slate-600 font-bold">Target Router Server MikroTik *</label>
                <select
                  className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden text-slate-800 font-bold"
                  value={manualServer}
                  onChange={(e) => setManualServer(e.target.value)}
                >
                  {servers.map((s, i) => (
                    <option key={i} value={s.nama}>{s.nama} ({s.ipAddress})</option>
                  ))}
                </select>
                <span className="text-[10px] text-slate-400 font-normal">Tentukan ke router MikroTik mana voucher ini didistribusikan.</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-slate-600 font-bold">Kode Voucher / Username *</label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: wifi_budi"
                    className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-bold text-slate-800 font-mono"
                    value={manualCode}
                    onChange={(e) => handleManualCodeChange(e.target.value)}
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-600 font-bold">Kode Sandi (Password)</label>
                  <input
                    type="text"
                    placeholder="Sandi (Kosong untuk Single-Code)"
                    className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden text-slate-800 font-mono"
                    value={manualPassword}
                    onChange={(e) => setManualPassword(e.target.value)}
                  />
                  <span className="text-[9px] text-slate-400 font-normal">Sandi khusus (opsional)</span>
                </div>
              </div>

              <div className="space-y-1 animate-fadeIn bg-slate-50 p-3 rounded-xl border border-slate-150">
                <label className="text-slate-600 font-bold flex items-center gap-1.5">
                  🏢 Opsional: Tautkan ke Reseller / Agen
                </label>
                <select
                  className="w-full bg-white p-2.5 rounded-lg border border-slate-200 focus:outline-hidden text-slate-800 font-bold text-xs"
                  value={manualResellerId}
                  onChange={(e) => setManualResellerId(e.target.value)}
                >
                  <option value="">-- Bukan milik Agen (Umum) --</option>
                  {resellers.map((r, i) => (
                    <option key={i} value={r.id}>🏢 {r.nama} ({r.wilayah})</option>
                  ))}
                </select>
              </div>

              {manualResellerId && (
                <div className="space-y-1.5 animate-fadeIn bg-indigo-50/50 p-3.5 rounded-xl border border-indigo-150">
                  <label className="text-indigo-950 font-extrabold flex items-center gap-1">
                    <Tag size={13} className="text-indigo-600" />
                    Status Pembayaran Agen *
                  </label>
                  <select
                    className="w-full bg-white p-2.5 rounded-xl border border-indigo-200 focus:outline-hidden text-slate-800 font-bold text-xs"
                    value={manualAgentPaymentStatus}
                    onChange={(e) => setManualAgentPaymentStatus(e.target.value as 'LUNAS' | 'BELUM BAYAR')}
                  >
                    <option value="BELUM BAYAR">🔴 BELUM BAYAR (Unpaid)</option>
                    <option value="LUNAS">🟢 LUNAS (Paid)</option>
                  </select>
                </div>
              )}

              <div className="space-y-1.5">
                <label className="text-slate-600 font-bold">Pilih Profil Kuota MikroTik *</label>
                <select
                  className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden text-slate-800 font-bold"
                  value={manualPaketId}
                  onChange={(e) => handleManualPaketSelect(e.target.value)}
                >
                  {paket.map((p, idx) => (
                    <option key={idx} value={p.id}>{p.nama} ({p.kecepatan})</option>
                  ))}
                </select>
                <span className="text-[10px] text-indigo-600 font-semibold block leading-normal">
                  💡 Profil User Profile akan sinkron otomatis secara real-time dari MikroTik API (Menu User Profile di MikroTik) saat terkoneksi dengan router.
                </span>
              </div>

              <div className="space-y-1">
                <label className="text-slate-600 font-bold">Tarif Jual Voucher (Rp) *</label>
                <input
                  type="number"
                  required
                  className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-bold font-mono text-slate-800"
                  value={manualHarga}
                  onChange={(e) => setManualHarga(parseInt(e.target.value) || 0)}
                />
              </div>

              <button
                type="submit"
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-xl transition flex items-center justify-center gap-2 cursor-pointer shadow-xs"
              >
                <Plus size={15} /> Daftarkan Voucher Manual
              </button>
            </form>
          </div>
        )}

        {/* Panel Right: Bulk vouchers generator */}
        {activeMode === 'BULK' && (
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
            <div className="border-b border-slate-100 pb-3 flex items-center gap-2">
              <Layers size={16} className="text-indigo-600" />
              <h3 className="font-extrabold text-slate-800 text-sm">Mass Bulk Voucher Generator</h3>
            </div>

            <form onSubmit={handleRunGenerator} className="space-y-4 text-xs font-semibold text-slate-700">
              <div className="space-y-1">
                <label className="text-slate-600 font-bold">Target Router Server MikroTik *</label>
                <select
                  className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden text-slate-800 font-bold"
                  value={genServer}
                  onChange={(e) => setGenServer(e.target.value)}
                >
                  {servers.map((s, i) => (
                    <option key={i} value={s.nama}>{s.nama} ({s.ipAddress})</option>
                  ))}
                </select>
                <span className="text-[10px] text-slate-400 font-normal">Voucher bulk acak akan dikirimkan otomatis ke DB router ini.</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5 col-span-2 sm:col-span-1">
                  <label className="text-slate-600 font-bold">Pilih Profil Kuota MikroTik *</label>
                  <select
                    className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden text-slate-800 font-bold"
                    value={genPaketId}
                    onChange={(e) => handlePaketSelect(e.target.value)}
                  >
                    {paket.map((p, idx) => (
                      <option key={idx} value={p.id}>{p.nama} ({p.kecepatan})</option>
                    ))}
                  </select>
                  <span className="text-[10px] text-indigo-600 font-semibold block leading-normal">
                    💡 Profil User Profile sinkron otomatis dari router MikroTik API.
                  </span>
                </div>

                <div className="space-y-1.5 col-span-2 sm:col-span-1">
                  <label className="text-slate-600 font-bold">Jumlah Cetak Voucher (Pcs)</label>
                  <input
                    type="number"
                    min={1}
                    max={500}
                    className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-bold text-slate-800"
                    value={genCount}
                    onChange={(e) => setGenCount(parseInt(e.target.value) || 10)}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1">
                  <label className="text-slate-600 font-bold block">Prefiks Kode Voucher</label>
                  <input
                    type="text"
                    placeholder="Misal: KM-"
                    className="w-full bg-slate-50 p-2.5 rounded-lg border border-slate-200 focus:outline-hidden font-bold text-slate-800 uppercase placeholder:normal-case font-mono"
                    value={genPrefix}
                    maxLength={10}
                    onChange={(e) => setGenPrefix(e.target.value.toUpperCase())}
                  />
                  <span className="text-[10px] text-slate-400 font-normal block">Awalan kode (maks 10 karakter).</span>
                </div>

                <div className="space-y-1">
                  <label className="text-slate-600 font-bold block">Panjang Voucher (Digit) *</label>
                  <input
                    type="number"
                    min={1}
                    max={8}
                    required
                    className="w-full bg-slate-50 p-2 text-slate-800 font-extrabold focus:outline-hidden rounded-lg border border-slate-200 font-mono text-center"
                    value={genCharLength}
                    onChange={(e) => {
                      const val = parseInt(e.target.value);
                      if (isNaN(val)) {
                        setGenCharLength(1);
                      } else {
                        setGenCharLength(Math.max(1, Math.min(8, val)));
                      }
                    }}
                  />
                  <span className="text-[10px] text-slate-400 font-normal block">Jumlah karakter acak (1-8).</span>
                </div>

                <div className="space-y-1">
                  <label className="text-slate-600 font-bold block">Format Kredensial *</label>
                  <select
                    className="w-full bg-slate-50 p-2 text-slate-800 font-bold focus:outline-hidden rounded-lg border border-slate-200 text-xs"
                    value={genCredMode}
                    onChange={(e) => setGenCredMode(e.target.value as 'UP' | 'U_P')}
                  >
                    <option value="UP">Username ＝ Sandi (UP)</option>
                    <option value="U_P">Username ＆ Sandi (U_P)</option>
                  </select>
                  <span className="text-[10px] text-slate-400 font-normal block">Format login hotspot MikroTik.</span>
                </div>
              </div>



              <div className="p-3.5 bg-indigo-50/50 rounded-xl border border-indigo-150 flex items-start gap-2">
                <ShieldCheck size={16} className="text-indigo-600 shrink-0 mt-0.5" />
                <span className="text-[10px] text-indigo-850 leading-normal font-medium">
                  Sistem acak voucher bulk aman {genCharLength} digit untuk MikroTik. Voucher akan siap diunduh, dicetak, dan disinkronkan ke router hotspot Anda.
                </span>
              </div>

              <button
                type="submit"
                className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-xl transition flex items-center justify-center gap-2 cursor-pointer shadow-xs"
              >
                <Layers size={15} /> Mass Generate Voucher Terotomasi
              </button>
            </form>
          </div>
        )}
      </div>

      {/* List of Vouchers */}
      <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4 animate-scaleUp">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-100 pb-3">
          <div className="flex items-center gap-2 flex-wrap">
            <Tag size={16} className="text-indigo-600" />
            <h3 className="font-extrabold text-slate-800 text-sm">Daftar Voucher Hotspot MikroTik Aktif</h3>
            {vouchers.length > 0 && (
              <button
                type="button"
                onClick={() => {
                  if (confirmClearAll) {
                    vouchers.forEach((v) => onDeleteVoucher(v.id));
                    setConfirmClearAll(false);
                  } else {
                    setConfirmClearAll(true);
                    setTimeout(() => {
                      setConfirmClearAll(false);
                    }, 4000);
                  }
                }}
                className={`text-[10px] px-2.5 py-1 rounded-lg border transition font-black cursor-pointer flex items-center gap-1 select-none ${
                  confirmClearAll
                    ? 'bg-rose-600 hover:bg-rose-700 text-white border-rose-600 animate-pulse'
                    : 'bg-red-50 hover:bg-red-100 text-red-700 border-red-200'
                }`}
              >
                <Trash2 size={11} className={confirmClearAll ? 'animate-bounce shrink-0' : 'shrink-0'} />
                {confirmClearAll ? 'Yakin Hapus Semua Voucher?' : 'Kosongkan Semua Daftar'}
              </button>
            )}
          </div>
          
          <div className="w-full sm:w-64 relative text-xs font-semibold">
            <input
              type="text"
              placeholder="Cari kode, sandi, atau server..."
              className="w-full bg-slate-50 pl-3 pr-3 py-2 rounded-lg border border-slate-200 focus:outline-hidden font-semibold text-slate-800"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        {vouchers.filter(v => {
          const q = searchQuery.toLowerCase();
          return (
            v.code.toLowerCase().includes(q) ||
            (v.password && v.password.toLowerCase().includes(q)) ||
            v.serverName.toLowerCase().includes(q)
          );
        }).length === 0 ? (
          <div className="text-center py-8 text-slate-400 text-xs">
            Belum ada voucher hotspot terdaftar atau tidak ditemukan hasil pencarian.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs font-semibold text-slate-600">
              <thead>
                <tr className="border-b border-slate-100 text-slate-450 font-bold uppercase tracking-wider text-[10px]">
                  <th className="py-2.5 px-3">Kode / Username</th>
                  <th className="py-2.5 px-3">Sandi (Password)</th>
                  <th className="py-2.5 px-3">Profil Paket</th>
                  <th className="py-2.5 px-3">Tarif Jual</th>
                  <th className="py-2.5 px-3">Router Server</th>
                  <th className="py-2.5 px-3 text-right">Aksi MikroTik</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {vouchers
                  .filter(v => {
                    const q = searchQuery.toLowerCase();
                    return (
                      v.code.toLowerCase().includes(q) ||
                      (v.password && v.password.toLowerCase().includes(q)) ||
                      v.serverName.toLowerCase().includes(q)
                    );
                  })
                  .map((v) => {
                    const pkt = paket.find(p => p.id === v.paketId);
                    const isUP = v.password === v.code || !v.password;
                    return (
                      <tr key={v.id} className="hover:bg-slate-50/50 transition">
                        <td className="py-2.5 px-3 font-mono font-bold text-slate-900">
                          {v.code}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-slate-600">
                          {isUP ? (
                            <span className="text-[9px] bg-emerald-50 text-emerald-700 px-1.5 py-0.5 rounded font-sans font-bold select-none">
                              Sama dengan Username (UP)
                            </span>
                          ) : (
                            <span className="text-[11px] font-black">{v.password}</span>
                          )}
                        </td>
                        <td className="py-2.5 px-3 text-slate-800">
                          {pkt ? `${pkt.nama} (${pkt.kecepatan})` : 'Umum / Custom'}
                        </td>
                        <td className="py-2.5 px-3 font-mono font-bold text-slate-900">
                          Rp {v.harga.toLocaleString('id-ID')}
                        </td>
                        <td className="py-2.5 px-3 text-slate-500 font-medium">
                          🌐 {v.serverName}
                        </td>
                        <td className="py-2.5 px-3 text-right space-x-1">
                          <button
                            type="button"
                            title="Cetak struk label voucher untuk pelanggan"
                            onClick={() => setPrintVoucher(v)}
                            className="text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 border border-slate-200 hover:border-indigo-200 px-2.5 py-1 rounded-lg transition cursor-pointer font-black text-[10px]"
                          >
                            <Printer size={11} className="inline mr-1" /> Cetak
                          </button>
                          <button
                            type="button"
                            title="Buka portal login simulasi router MikroTik untuk tes"
                            onClick={() => {
                              setTestLoginVoucher(v);
                              setLoginTestCode(v.code);
                              setLoginTestPass(isUP ? v.code : (v.password || ''));
                              setIsConnecting(false);
                              setIsConnected(false);
                            }}
                            className="text-slate-600 hover:text-emerald-700 hover:bg-emerald-50 border border-slate-200 hover:border-emerald-250 px-2.5 py-1 rounded-lg transition cursor-pointer font-black text-[10px]"
                          >
                            <ExternalLink size={11} className="inline mr-1" /> Login Portal
                          </button>
                          <button
                            type="button"
                            title="Hapus voucher dari tabel local database dan MikroTik"
                            onClick={() => {
                              if (deletingId === v.id) {
                                onDeleteVoucher(v.id);
                                setDeletingId(null);
                              } else {
                                setDeletingId(v.id);
                                setTimeout(() => {
                                  setDeletingId(currentId => currentId === v.id ? null : currentId);
                                }, 4000);
                              }
                            }}
                            className={`px-2 py-1.5 rounded-lg border transition cursor-pointer text-[10px] font-black flex items-center justify-center gap-1.5 h-7 min-w-[32px] ${
                              deletingId === v.id
                                ? 'bg-rose-600 hover:bg-rose-700 text-white border-rose-600 animate-pulse text-[9px]'
                                : 'text-red-500 hover:text-white hover:bg-red-650 border-red-200 hover:border-red-600'
                            }`}
                          >
                            <Trash2 size={11} className={deletingId === v.id ? 'animate-bounce' : 'inline'} />
                            {deletingId === v.id && <span className="text-[9px]">Yakin?</span>}
                          </button>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* PRINT PROMPT / VOUCHER HOTSPOT PRINT PREVIEW MODAL */}
      {printVoucher && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-xs p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 shadow-2xl border border-slate-100 relative space-y-4">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div className="flex items-center gap-2">
                <Printer size={18} className="text-indigo-600" />
                <h3 className="font-extrabold text-slate-800 text-sm">Cetak Tiket Voucher Hotspot</h3>
              </div>
              <button
                type="button"
                onClick={() => setPrintVoucher(null)}
                className="text-slate-400 hover:text-slate-600 font-extrabold text-base cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Simulated Pocket Thermal Receipt Card Layout */}
            <div id="thermal-voucher-print-area" className="bg-slate-50 border-2 border-dashed border-slate-300 p-5 rounded-2xl font-mono text-center relative max-w-xs mx-auto text-slate-800 space-y-3 shadow-inner">
              <div className="space-y-0.5">
                <p className="text-xs font-black tracking-wider text-slate-900">⚡ KAMAL-NET HOTSPOT ⚡</p>
                <p className="text-[10px] font-bold text-slate-400 uppercase">Server: {printVoucher.serverName}</p>
                <div className="border-b border-dashed border-slate-300 my-2"></div>
              </div>

              <div className="bg-white py-2 px-3 rounded-xl border border-slate-200 space-y-1">
                <p className="text-[10px] text-slate-500 font-bold uppercase">Nama WiFI SSID</p>
                <p className="text-xs font-extrabold text-indigo-700">@KAMAL_NET_FAST_HOTSPOT</p>
              </div>

              <div className="space-y-1 bg-indigo-50/50 py-3 px-4 rounded-xl border border-indigo-100 font-sans text-slate-950 font-bold">
                <div className="text-[10px] text-slate-500">PROFIL PAKET / DURASI:</div>
                <div className="text-xs font-black text-indigo-900">{printVoucher.durasi}</div>
                <div className="text-[11px] text-slate-700 font-bold mt-1">Tarif Jual: Rp {printVoucher.harga.toLocaleString('id-ID')}</div>
              </div>

              {/* Monospace Credentials */}
              <div className="space-y-1 font-mono py-2 bg-slate-900 rounded-xl text-white">
                <p className="text-[9px] text-slate-400 font-bold tracking-wider">KODE AKSES / USERNAME</p>
                <p className="text-base font-extrabold tracking-widest text-emerald-400 select-all">{printVoucher.code}</p>
                {printVoucher.password && printVoucher.password !== printVoucher.code && (
                  <p className="text-xs text-yellow-300 mt-0.5 tracking-wider">SANDI: {printVoucher.password}</p>
                )}
              </div>

              {/* Procedural QR Code Mockup in pure CSS */}
              <div className="w-24 h-24 bg-white p-2.5 mx-auto rounded-xl border border-slate-200 flex flex-col justify-between relative mt-2 shadow-xs">
                <div className="grid grid-cols-5 gap-1 w-full h-full opacity-80">
                  {[...Array(25)].map((_, idx) => (
                    <div
                      key={idx}
                      className={`rounded-xs ${
                        (idx * 7 + 3) % 5 === 0 || idx < 5 || idx % 5 === 0 || idx > 20 || (idx % 5 === 4 && idx < 10)
                          ? 'bg-slate-900'
                          : 'bg-transparent'
                      }`}
                    />
                  ))}
                </div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="bg-indigo-50 p-1.5 rounded-full shadow-xs border border-indigo-105">
                    <QrCode className="w-5 h-5 text-indigo-600" />
                  </div>
                </div>
              </div>

              <div className="text-[9px] text-slate-500 leading-relaxed pt-1 select-none">
                <div className="border-b border-dashed border-slate-300 my-1"></div>
                <p className="font-bold">PETUNJUK KONEKSI:</p>
                <p>1. Aktifkan WiFi di HP, sambungkan ke SSID diatas</p>
                <p>2. Tunggu portal login terbuka otomatis (atau buka internet)</p>
                <p>3. Masukkan kode akses diatas lalu klik CONNECT</p>
                <p className="mt-1 font-extrabold text-slate-850 text-slate-900 border-t border-slate-200 pt-1">LAYANAN ADUAN: 0812-3456-7890</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  const printContents = document.getElementById('thermal-voucher-print-area')?.innerHTML;
                  if (printContents) {
                    const printWindow = window.open('', '_blank');
                    if (printWindow) {
                      printWindow.document.write(`
                        <html>
                          <head>
                            <title>Cetak Voucher Hotspot - ${printVoucher.code}</title>
                            <style>
                              body {
                                font-family: monospace;
                                padding: 20px;
                                margin: 0;
                                color: #1e293b;
                                max-width: 300px;
                              }
                              .print-area {
                                border: 1px dashed #94a3b8;
                                padding: 15px;
                                border-radius: 8px;
                                text-align: center;
                              }
                              .text-lg { font-size: 18px; font-weight: bold; }
                              .text-md { font-size: 14px; font-weight: bold; }
                              .text-sm { font-size: 12px; }
                              .bg-box { background: #f1f5f9; border: 1px solid #cbd5e1; padding: 6px; border-radius: 4px; margin: 8px 0; }
                              .big-code { font-size: 20px; font-weight: bold; letter-spacing: 2px; }
                            </style>
                          </head>
                          <body onload="window.print();window.close();">
                            <div class="print-area">
                              <p class="text-md">⚡ KAMAL-NET HOTSPOT ⚡</p>
                              <p class="text-sm">Server: ${printVoucher.serverName}</p>
                              <hr style="border: none; border-top: 1px dashed #cbd5e1; margin: 10px 0;" />
                              <div class="bg-box">
                                <p class="text-sm" style="margin:2px 0;">SSID: <b>@KAMAL_NET_FAST_HOTSPOT</b></p>
                              </div>
                              <div class="bg-box" style="background:#e0f2fe;">
                                <p class="text-sm" style="margin:2px 0; font-weight:bold;">Paket: ${printVoucher.durasi}</p>
                                <p class="text-sm" style="margin:2px 0;">Harga: Rp ${printVoucher.harga.toLocaleString('id-ID')}</p>
                              </div>
                              <div class="bg-box" style="background:#0f172a; color:#ffffff;">
                                <p class="text-sm" style="margin:2px 0; opacity:0.8;">KODE LOGIN / USERNAME</p>
                                <p class="big-code" style="margin:2px 0; color:#4ade80;">${printVoucher.code}</p>
                                ${printVoucher.password && printVoucher.password !== printVoucher.code ? `<p class="text-sm" style="margin:2px 0; color:#fde047;">SANDI: ${printVoucher.password}</p>` : ''}
                              </div>
                              <p class="text-sm" style="font-size:10px; line-height:1.3; color:#64748b;">
                                Hubungkan WiFi Anda, ketik kode login dalam formulir portal browser.<br/>
                                CS/Guan: 0812-3456-7890
                              </p>
                            </div>
                          </body>
                        </html>
                      `);
                      printWindow.document.close();
                    }
                  }
                }}
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2.5 px-4 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer text-xs"
              >
                <Printer size={13} /> Cetak Struk
              </button>
              <button
                type="button"
                onClick={() => setPrintVoucher(null)}
                className="bg-slate-100 hover:bg-slate-200 text-slate-705 text-slate-700 font-bold py-2.5 px-4 rounded-xl transition text-xs text-center cursor-pointer"
              >
                Tutup Preview
              </button>
            </div>
          </div>
        </div>
      )}

      {/* LIVE HOTSPOT PORTAL SIMULATION MODAL */}
      {testLoginVoucher && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-fadeIn">
          <div className="bg-slate-950 rounded-3xl max-w-sm w-full p-4 shadow-2xl border border-slate-800 relative space-y-4">
            <div className="flex items-center justify-between border-b border-slate-900 pb-2 text-slate-400">
              <div className="flex items-center gap-1.5 text-xs font-black">
                <Globe size={13} className="text-emerald-400" />
                <span>Simulasi Portal Login Router (MikroTik)</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  setTestLoginVoucher(null);
                  setIsConnecting(false);
                  setIsConnected(false);
                }}
                className="text-slate-400 hover:text-slate-200 font-black text-xs cursor-pointer"
              >
                ✕ Close
              </button>
            </div>

            {/* SmartPhone Frame Wrapper */}
            <div className="max-w-xs mx-auto border-4 border-slate-800 rounded-[2rem] overflow-hidden shadow-2xl bg-slate-900 text-slate-200 font-sans aspect-[9/19] flex flex-col justify-between relative">
              
              {/* Smartphone Status Bar */}
              <div className="flex justify-between items-center px-6 py-2 bg-slate-950 text-[9px] select-none text-slate-400 font-mono tracking-wider font-extrabold">
                <span>09:41</span>
                <div className="w-14 h-4 bg-slate-800 rounded-full absolute left-1/2 -translate-x-1/2 top-1 border border-slate-900"></div>
                <div className="flex items-center gap-1">
                  <span>LTE</span>
                  <span>📶</span>
                  <span>🔋 98%</span>
                </div>
              </div>

              {/* Browser navigation address bar mockup */}
              <div className="bg-slate-900/80 border-b border-slate-800 px-3 py-1.5 flex items-center gap-1 select-none">
                <div className="bg-slate-950/80 w-full text-slate-400 rounded-lg text-[9px] py-1 px-2 font-mono flex items-center justify-between">
                  <span className="flex items-center gap-1 text-slate-300">
                    🔒 <span className="text-emerald-400 font-black">192.168.88.1</span>/login.html
                  </span>
                  <span className="text-slate-500">🔄</span>
                </div>
              </div>

              {/* Dynamic Inner Body Content */}
              <div className="flex-1 bg-gradient-to-b from-indigo-950 via-slate-900 to-slate-950 p-5 overflow-y-auto min-h-[290px] flex flex-col justify-center">
                {!isConnected ? (
                  <div className="space-y-4 animate-scaleUp">
                    {/* Welcome banner inside login page */}
                    <div className="text-center space-y-1">
                      <div className="w-12 h-12 bg-indigo-500/10 border border-indigo-400/20 rounded-full mx-auto flex items-center justify-center text-indigo-400 text-xl font-bold animate-pulse">
                        📶
                      </div>
                      <h4 className="text-xs font-black text-slate-100 uppercase tracking-widest pt-2">KAMAL-NET HOTSPOT</h4>
                      <p className="text-[10px] text-slate-400 select-none">Silakan masukkan kode voucher Anda untuk berselancar di internet.</p>
                    </div>

                    <form
                      onSubmit={(e) => {
                        e.preventDefault();
                        if (!loginTestCode.trim()) {
                          alert('Isi kode voucher terlebih dahulu!');
                          return;
                        }
                        setIsConnecting(true);
                        setTimeout(() => {
                          setIsConnecting(false);
                          setIsConnected(true);
                        }, 1800);
                      }}
                      className="space-y-3 pt-2 text-left"
                    >
                      <div className="space-y-1">
                        <label className="text-[9px] text-slate-400 font-bold uppercase block tracking-wider select-none">Metode Login</label>
                        <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-950 rounded-lg font-bold text-[9px] tracking-wide text-center">
                          <span className="bg-indigo-600 text-white rounded py-1 cursor-pointer select-none">🎫 KODE VOUCHER</span>
                          <span className="text-slate-455 hover:text-slate-200 text-slate-400 rounded py-1 cursor-not-allowed select-none">👤 MEMBER PASS</span>
                        </div>
                      </div>

                      <div className="space-y-1">
                        <label className="text-[9px] text-slate-400 font-bold uppercase block tracking-wider">KODE AKSES VOUCHER</label>
                        <input
                          type="text"
                          required
                          placeholder="Masukkan voucher code..."
                          className="w-full bg-slate-950 text-emerald-400 font-black font-mono text-center py-2 px-3 rounded-lg border border-slate-800 focus:border-indigo-505 focus:outline-hidden text-sm uppercase"
                          value={loginTestCode}
                          onChange={(e) => setLoginTestCode(e.target.value.toUpperCase())}
                        />
                      </div>

                      {testLoginVoucher.password && testLoginVoucher.password !== testLoginVoucher.code && (
                        <div className="space-y-0.5">
                          <label className="text-[9px] text-slate-400 font-bold uppercase block tracking-wider">SANDI (PASSWORD)</label>
                          <input
                            type="text"
                            required
                            placeholder="Masukkan password..."
                            className="w-full bg-slate-950 text-slate-200 font-bold font-mono text-center py-1.5 px-3 rounded-lg border border-slate-800 focus:outline-hidden text-xs"
                            value={loginTestPass}
                            onChange={(e) => setLoginTestPass(e.target.value)}
                          />
                        </div>
                      )}

                      <button
                        type="submit"
                        disabled={isConnecting}
                        className={`w-full py-2.5 rounded-xl font-bold text-xs transition cursor-pointer select-none text-center shadow-md ${
                          isConnecting 
                            ? 'bg-amber-600 text-white animate-pulse' 
                            : 'bg-indigo-600 text-white hover:bg-indigo-500'
                        }`}
                      >
                        {isConnecting ? (
                          <span className="flex items-center justify-center gap-1 px-1">
                            <span className="animate-spin text-xs">🌀</span> radius auth...
                          </span>
                        ) : (
                          'HUBUNGKAN SEKARANG'
                        )}
                      </button>
                    </form>

                    <div className="text-center font-mono text-[8.5px] text-slate-500 leading-normal border-t border-slate-800/60 pt-2 select-none">
                      <p>IP: 10.10.50.158 | MAC: FC:75:A4:B3:9C</p>
                      <p className="mt-0.5 font-bold text-slate-400">RouterOS v7 (MikroTik Core Server)</p>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4 animate-scaleUp text-center">
                    {/* Success Screen */}
                    <div className="w-12 h-12 bg-emerald-500/10 border border-emerald-400/20 rounded-full mx-auto flex items-center justify-center text-emerald-400 text-xl font-sans animate-bounce">
                      ✓
                    </div>
                    <div className="space-y-0.5">
                      <h4 className="text-xs font-black text-slate-100 uppercase tracking-widest leading-none">KONEKSI INTERNET AKTIF</h4>
                      <p className="text-[9px] text-emerald-400 font-bold uppercase mb-2 select-none">Hotspot Session Established</p>
                    </div>

                    <div className="bg-slate-950/90 py-3 px-4 rounded-xl border border-slate-800 divide-y divide-slate-800 text-xs font-semibold text-slate-300 space-y-1.5 font-mono">
                      <div className="flex justify-between text-[9px] pt-1">
                        <span>Sisa Waktu:</span>
                        <span className="text-indigo-400 font-extrabold">{testLoginVoucher.durasi}</span>
                      </div>
                      <div className="flex justify-between text-[9px] pt-1.5">
                        <span>Limit Kecepatan:</span>
                        <span className="text-slate-100 font-bold">
                          {paket.find(p => p.id === testLoginVoucher.paketId)?.kecepatan || 'Up to 5 Mbps'}
                        </span>
                      </div>
                      <div className="flex justify-between text-[9px] pt-1.5">
                        <span>MikroTik Router:</span>
                        <span className="text-slate-300 font-bold">{testLoginVoucher.serverName}</span>
                      </div>
                      <div className="flex justify-between text-[9px] pt-1.5 border-t border-slate-900/50">
                        <span>IP Address:</span>
                        <span className="text-slate-500">10.10.50.245</span>
                      </div>
                    </div>

                    {/* Fun live internet connectivity stats simulator */}
                    <div className="p-2.5 bg-slate-950/60 rounded-xl border border-slate-800/40 text-left font-mono space-y-1 select-none">
                      <div className="flex justify-between text-[8px] text-slate-500 font-black">
                        <span>LIVE NET TRAFFIC:</span>
                        <span className="text-emerald-500">ONLINE</span>
                      </div>
                      <div className="flex justify-between font-bold text-[9px] text-slate-300">
                        <span>📥 Dn: 3.42 Mbps</span>
                        <span>📤 Up: 1.15 Mbps</span>
                      </div>
                      <div className="w-full bg-slate-900 h-1 rounded-full overflow-hidden mt-1">
                        <div className="bg-indigo-500 h-full w-2/3 animate-pulse rounded-full"></div>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => setIsConnected(false)}
                      className="w-full py-2 bg-red-950/50 hover:bg-red-900/40 text-red-400 border border-red-900/50 rounded-xl text-[9px] font-bold tracking-wider transition cursor-pointer"
                    >
                      PUTUSKAN INTERNET
                    </button>
                  </div>
                )}
              </div>

              {/* Smartphone Bottom Home Indicator bar */}
              <div className="bg-slate-950 h-5 flex justify-center items-center py-1 select-none">
                <div className="w-24 h-1 bg-slate-600 rounded-full"></div>
              </div>
            </div>

            <div className="text-center font-bold">
              <button
                type="button"
                onClick={() => {
                  setTestLoginVoucher(null);
                  setIsConnecting(false);
                  setIsConnected(false);
                }}
                className="bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800 font-bold py-2 px-4 rounded-xl text-xs transition cursor-pointer"
              >
                Kembali ke Dashboard
              </button>
            </div>
          </div>
        </div>
      )}

      {/* REAL-TIME MIKROTIK API SYNC MODAL */}
      {syncModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-xs p-4 animate-fadeIn font-sans">
          <div className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-slate-150 relative">
            {/* Header */}
            <div className="bg-slate-900 px-6 py-4.5 flex items-center gap-3 border-b border-slate-850">
              <div className="bg-indigo-500/10 p-2 rounded-xl border border-indigo-400/20 text-indigo-400">
                <Server size={18} className="animate-pulse" />
              </div>
              <div className="flex-1">
                <h3 className="font-extrabold text-xs text-indigo-400 uppercase tracking-widest leading-none">RouterOS API Connection</h3>
                <h4 className="text-white text-sm font-extrabold mt-1">Sinkronisasi Otomatis MikroTik</h4>
              </div>
              <div className="text-[10px] bg-emerald-500/15 text-emerald-400 border border-emerald-500/20 px-2.5 py-1 rounded-full font-black uppercase tracking-wider animate-pulse">
                Live Sync Active
              </div>
            </div>

            {/* Content Body */}
            <div className="p-6 space-y-4">
              
              {/* Target Server Info Card */}
              <div className="bg-slate-50 border border-slate-150 p-4 rounded-2xl flex items-center justify-between text-xs font-semibold">
                <div className="space-y-1">
                  <div className="text-slate-400 text-[10px] uppercase font-bold">Router Terkoneksi:</div>
                  <div className="font-extrabold text-slate-800 text-sm flex items-center gap-1.5">
                    🗼 {syncTargetRouterVal}
                  </div>
                </div>
                <div className="text-right space-y-1">
                  <div className="text-slate-400 text-[10px] uppercase font-bold">Volume Antrean:</div>
                  <div className="font-mono text-slate-705 text-slate-700 bg-slate-200/60 px-2.5 py-0.5 rounded-lg border border-slate-300/40 text-xs font-black">
                    {syncType === 'MANUAL' ? 'Single Insert' : `Bulk (${syncTotalCount} Voc)`}
                  </div>
                </div>
              </div>

              {/* Progress Steps List */}
              <div className="space-y-2.5">
                {syncSteps.map((step, idx) => (
                  <div 
                    key={idx} 
                    className={`flex items-start gap-3 p-3 rounded-xl border transition-all ${
                      step.status === 'success' 
                        ? 'bg-emerald-50/50 border-emerald-100 text-emerald-900' 
                        : step.status === 'loading'
                          ? 'bg-indigo-50/70 border-indigo-100 text-indigo-900 animate-pulse'
                          : 'bg-slate-50/50 border-slate-100 text-slate-400'
                    }`}
                  >
                    <div className="mt-0.5 shrink-0">
                      {step.status === 'success' && <CheckCircle2 size={15} className="text-emerald-600" />}
                      {step.status === 'loading' && <span className="text-indigo-600 block animate-spin text-sm">🌀</span>}
                      {step.status === 'idle' && <div className="w-3.5 h-3.5 rounded-full border border-slate-300" />}
                    </div>
                    <div className="text-xs space-y-0.5 animate-fadeIn">
                      <span className="font-bold block">{step.name}</span>
                      {step.desc && (
                        <span className={`text-[10px] font-medium block leading-relaxed ${
                          step.status === 'success' ? 'text-emerald-700' : step.status === 'loading' ? 'text-indigo-705' : 'text-slate-400'
                        }`}>
                          {step.desc}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Mass Progress Bar if Bulk Sync */}
              {syncType === 'BULK' && (
                <div className="bg-slate-50 border border-slate-200/60 p-4.5 rounded-2xl space-y-2 animate-scaleUp">
                  <div className="flex justify-between text-[11px] font-bold text-slate-600">
                    <span>Progres Pengiriman Batch API:</span>
                    <span className="font-mono font-black text-indigo-600">{syncCurrentCount} / {syncTotalCount} Sukses</span>
                  </div>
                  <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden border border-slate-300/40">
                    <div 
                      className="bg-indigo-650 bg-indigo-600 h-full rounded-full transition-all duration-150 shadow-xs" 
                      style={{ width: `${(syncCurrentCount / syncTotalCount) * 100}%` }}
                    />
                  </div>
                </div>
              )}

              {/* Simulated WINBOX Terminal Console Output */}
              <div className="space-y-1.5 text-xs font-semibold">
                <div className="flex items-center gap-1 text-slate-500 font-bold">
                  <Terminal size={13} className="text-indigo-500" />
                  <span>Winbox ROS v7 Command Console Output:</span>
                </div>
                <div className="bg-slate-950 text-slate-200 font-mono text-[9.5px] leading-relaxed p-4 rounded-2xl h-36 overflow-y-auto border border-slate-800 space-y-1 scrollbar-thin select-all">
                  {syncTerminalCommands.length === 0 ? (
                    <span className="text-slate-600 italic">Menunggu inisialisasi baris eksekusi...</span>
                  ) : (
                    syncTerminalCommands.map((cmd, i) => (
                      <div key={i} className={cmd.startsWith('>>>') ? 'text-emerald-400 font-bold' : cmd.startsWith('<<< !done') ? 'text-emerald-500 font-bold' : cmd.startsWith('<<<') ? 'text-yellow-400' : 'text-slate-400'}>
                        {cmd}
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>

            {/* Footer containing close controls */}
            <div className="bg-slate-50 px-6 py-4.5 flex items-center justify-between border-t border-slate-100 gap-4">
              <span className="text-[10px] text-slate-400 font-medium leading-normal">
                ⚡ Terhubung aman melalui Winbox API-ROS multi-thread.
              </span>
              <button
                type="button"
                disabled={syncCurrentCount < syncTotalCount || syncSteps.some(s => s.status === 'loading')}
                onClick={() => setSyncModalOpen(false)}
                className={`px-5 py-2.5 rounded-xl font-extrabold text-xs transition cursor-pointer shadow-xs ${
                  syncCurrentCount >= syncTotalCount && !syncSteps.some(s => s.status === 'loading')
                    ? 'bg-indigo-600 hover:bg-indigo-700 text-white'
                    : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                }`}
              >
                {syncCurrentCount >= syncTotalCount && !syncSteps.some(s => s.status === 'loading') ? 'Selesai & Tutup' : 'Sinkronisasi...'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
