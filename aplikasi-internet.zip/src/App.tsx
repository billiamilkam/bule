import React, { useState, useEffect } from 'react';
import { 
  Pelanggan, Paket, Tagihan, WhatsAppLog, AppSettings, 
  MikrotikServer, TukangTagih, Reseller, HotspotVoucher, PppoeUser, VoucherPageSettings, PesananAgen, Teknisi, PortalActivityLog
} from './types';
import { 
  DEFAULT_PELANGGAN, DEFAULT_PAKET, DEFAULT_TAGIHAN, 
  DEFAULT_WA_LOGS, DEFAULT_SETTINGS, DEFAULT_MIKROTIK,
  DEFAULT_TUKANG_TAGIH, DEFAULT_RESELLER, DEFAULT_VOUCHERS, DEFAULT_PPPOE, DEFAULT_PESANAN_AGEN, DEFAULT_TEKNISI, DEFAULT_PORTAL_LOGS
} from './mockData';
import { 
  formatRupiah, formatBulanIndo, generateInvoiceId, 
  replaceTemplates, isPastDue 
} from './utils';

// Import our modular components
import DashboardStats from './components/DashboardStats';
import PelangganTab from './components/PelangganTab';
import PaketTab from './components/PaketTab';
import TagihanTab from './components/TagihanTab';
import NotifikasiTab from './components/NotifikasiTab'; // Serving as "WA Gateway"
import MikrotikTab from './components/MikrotikTab';
import TukangTagihTab from './components/TukangTagihTab';
import HotspotTab from './components/HotspotTab';
import PppoeTab from './components/PppoeTab';
import AgentTab from './components/AgentTab';
import PaymentGatewayTab from './components/PaymentGatewayTab';
import VoucherPortalTemplate from './components/VoucherPortalTemplate';
import CollectorPortal from './components/CollectorPortal';
import ResellerPortal from './components/ResellerPortal';
import PesananAgenTab from './components/PesananAgenTab';
import TeknisiTab from './components/TeknisiTab';
import TeknisiPortal from './components/TeknisiPortal';
import PengaturanTab from './components/PengaturanTab';

import { 
  LayoutDashboard, Users, Wifi, CreditCard, 
  MessageSquareShare, Settings, Download, Upload, 
  RefreshCcw, Layout, Menu, X, Landmark, User, ShieldCheck,
  Server, UserCheck, Store, Lock, KeyRound, Eye, EyeOff, LogOut, ClipboardList,
  Sliders, Settings2, Search, Sun, Moon, Wallet, LogIn, TrendingUp
} from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    return localStorage.getItem('rtrw_dark_mode') === 'true';
  });

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem('rtrw_dark_mode', String(darkMode));
  }, [darkMode]);

  const [selectedBulan, setSelectedBulan] = useState<string>('2026-06');
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);

  // Admin unified activity log filter states
  const [adminLogSearch, setAdminLogSearch] = useState<string>('');
  const [adminLogPortalFilter, setAdminLogPortalFilter] = useState<'ALL' | 'ADMIN' | 'AGEN/RESELLER' | 'TUKANG_TAGIH' | 'TEKNISI'>('ALL');
  const [adminLogActionFilter, setAdminLogActionFilter] = useState<'ALL' | 'LOGIN' | 'CETAK_VOUCHER' | 'TRANSAKSI_BAYAR' | 'TOPUP'>('ALL');
  const [adminLogStartDate, setAdminLogStartDate] = useState<string>('');
  const [adminLogEndDate, setAdminLogEndDate] = useState<string>('');
  const [adminLogShowOverdueOnly, setAdminLogShowOverdueOnly] = useState<boolean>(false);

  // Core login & simulation states
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(true);
  const [currentUserRole, setCurrentUserRole] = useState<'admin' | 'collector' | 'reseller' | 'teknisi'>('admin');
  const [activeCollector, setActiveCollector] = useState<TukangTagih | null>(null);
  const [activeReseller, setActiveReseller] = useState<Reseller | null>(null);
  const [activeTeknisi, setActiveTeknisi] = useState<Teknisi | null>(null);

  // New simulated Login inputs
  const [loginRole, setLoginRole] = useState<'admin' | 'collector' | 'reseller' | 'teknisi'>('admin');
  const [loginUsername, setLoginUsername] = useState<string>('');
  const [loginPassword, setLoginPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);

  // Core database states
  const [pelanggan, setPelanggan] = useState<Pelanggan[]>([]);
  const [paket, setPaket] = useState<Paket[]>([]);
  const [tagihan, setTagihan] = useState<Tagihan[]>([]);
  const [logs, setLogs] = useState<WhatsAppLog[]>([]);
  const [settings, setSettings] = useState<AppSettings | null>(null);

  // New database tables
  const [servers, setServers] = useState<MikrotikServer[]>([]);
  const [collectors, setCollectors] = useState<TukangTagih[]>([]);
  const [resellers, setResellers] = useState<Reseller[]>([]);
  const [vouchers, setVouchers] = useState<HotspotVoucher[]>([]);
  const [pppoeUsers, setPppoeUsers] = useState<PppoeUser[]>([]);
  const [pesananAgen, setPesananAgen] = useState<PesananAgen[]>([]);
  const [teknisiList, setTeknisiList] = useState<Teknisi[]>([]);
  const [portalLogs, setPortalLogs] = useState<PortalActivityLog[]>([]);

  const addPortalLog = (log: Omit<PortalActivityLog, 'id' | 'timestamp'>) => {
    const newLog: PortalActivityLog = {
      ...log,
      id: `plog-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: new Date().toISOString()
    };
    setPortalLogs(prev => [newLog, ...prev]);
  };

  // Real-time WhatsApp Bulk sender state
  const [isBroadcasting, setIsBroadcasting] = useState<boolean>(false);
  const [broadcastQueue, setBroadcastQueue] = useState<Tagihan[]>([]);

  const SYSTEM_DATE = '2026-06-14';

  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [mysqlStatus, setMysqlStatus] = useState<'connected' | 'offline'>('offline');

  // Trigger data upload to backend and MySQL server
  const triggerCloudSync = async (customPayload?: any) => {
    setIsSyncing(true);
    const payload = customPayload || {
      pelanggan,
      paket,
      tagihan,
      logs,
      settings,
      servers,
      collectors,
      resellers,
      vouchers,
      pppoeUsers,
      pesananAgen,
      teknisiList,
      portalLogs
    };

    try {
      const res = await fetch('/api/db/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const result = await res.json();
      if (result.success) {
        if (result.source === 'mysql') {
          setMysqlStatus('connected');
        } else {
          setMysqlStatus('offline');
        }
      }
    } catch (err) {
      console.error('Unified cloud DB sync failed:', err);
      setMysqlStatus('offline');
    } finally {
      setIsSyncing(false);
    }
  };

  // 1. Initial Load from Express API with fallback to LocalStorage
  useEffect(() => {
    const loadData = async () => {
      try {
        const res = await fetch('/api/db/load');
        const result = await res.json();
        
        if (result && result.data && (result.source === 'mysql' || result.source === 'json_fallback' || result.source === 'json_fallback_on_error')) {
          const d = result.data;
          if (d.pelanggan) setPelanggan(d.pelanggan); else setPelanggan(DEFAULT_PELANGGAN);
          if (d.paket) setPaket(d.paket); else setPaket(DEFAULT_PAKET);
          if (d.tagihan) setTagihan(d.tagihan); else setTagihan(DEFAULT_TAGIHAN);
          if (d.logs) setLogs(d.logs); else setLogs(DEFAULT_WA_LOGS);
          if (d.settings) setSettings(d.settings); else setSettings(DEFAULT_SETTINGS);
          if (d.servers) setServers(d.servers); else setServers(DEFAULT_MIKROTIK);
          if (d.collectors) setCollectors(d.collectors); else setCollectors(DEFAULT_TUKANG_TAGIH);
          if (d.resellers) setResellers(d.resellers); else setResellers(DEFAULT_RESELLER);
          if (d.vouchers) setVouchers(d.vouchers); else setVouchers(DEFAULT_VOUCHERS);
          if (d.pppoeUsers) setPppoeUsers(d.pppoeUsers); else setPppoeUsers(DEFAULT_PPPOE);
          if (d.pesananAgen) setPesananAgen(d.pesananAgen); else setPesananAgen(DEFAULT_PESANAN_AGEN);
          if (d.teknisiList) setTeknisiList(d.teknisiList); else setTeknisiList(DEFAULT_TEKNISI);
          if (d.portalLogs) setPortalLogs(d.portalLogs); else setPortalLogs(DEFAULT_PORTAL_LOGS);
          
          if (result.source === 'mysql') {
            setMysqlStatus('connected');
          } else {
            setMysqlStatus('offline');
          }
          return;
        }
      } catch (err) {
        console.error('Express database API error. Checking LocalStorage fallback...', err);
      }

      // LocalStorage Fallback if server is not fully loaded or returns empty
      const savedPelanggan = localStorage.getItem('rtrw_pelanggan');
      const savedPaket = localStorage.getItem('rtrw_paket');
      const savedTagihan = localStorage.getItem('rtrw_tagihan');
      const savedLogs = localStorage.getItem('rtrw_logs');
      const savedSettings = localStorage.getItem('rtrw_settings');
      const savedServers = localStorage.getItem('rtrw_servers');
      const savedCollectors = localStorage.getItem('rtrw_collectors');
      const savedResellers = localStorage.getItem('rtrw_resellers');
      const savedVouchers = localStorage.getItem('rtrw_vouchers');
      const savedPppoe = localStorage.getItem('rtrw_pppoe');
      const savedPesananAgen = localStorage.getItem('rtrw_pesanan_agen');
      const savedTeknisi = localStorage.getItem('rtrw_teknisi');
      const savedPortalLogs = localStorage.getItem('rtrw_portal_logs');

      setPelanggan(savedPelanggan ? JSON.parse(savedPelanggan) : DEFAULT_PELANGGAN);
      setPaket(savedPaket ? JSON.parse(savedPaket) : DEFAULT_PAKET);
      setTagihan(savedTagihan ? JSON.parse(savedTagihan) : DEFAULT_TAGIHAN);
      setLogs(savedLogs ? JSON.parse(savedLogs) : DEFAULT_WA_LOGS);
      setSettings(savedSettings ? JSON.parse(savedSettings) : DEFAULT_SETTINGS);
      setServers(savedServers ? JSON.parse(savedServers) : DEFAULT_MIKROTIK);
      setCollectors(savedCollectors ? JSON.parse(savedCollectors) : DEFAULT_TUKANG_TAGIH);
      setResellers(savedResellers ? JSON.parse(savedResellers) : DEFAULT_RESELLER);
      setVouchers(savedVouchers ? JSON.parse(savedVouchers) : DEFAULT_VOUCHERS);
      setPppoeUsers(savedPppoe ? JSON.parse(savedPppoe) : DEFAULT_PPPOE);
      setPesananAgen(savedPesananAgen ? JSON.parse(savedPesananAgen) : DEFAULT_PESANAN_AGEN);
      setTeknisiList(savedTeknisi ? JSON.parse(savedTeknisi) : DEFAULT_TEKNISI);
      setPortalLogs(savedPortalLogs ? JSON.parse(savedPortalLogs) : DEFAULT_PORTAL_LOGS);
      setMysqlStatus('offline');
    };
    
    loadData();
  }, []);

  // 2. Debounced LocalStorage and Cloud Database Sync Side-Effects
  useEffect(() => {
    // Avoid double syncing empty initial states on very first mount
    if (!settings) return;

    const syncHandler = setTimeout(() => {
      localStorage.setItem('rtrw_pelanggan', JSON.stringify(pelanggan));
      localStorage.setItem('rtrw_paket', JSON.stringify(paket));
      localStorage.setItem('rtrw_tagihan', JSON.stringify(tagihan));
      localStorage.setItem('rtrw_logs', JSON.stringify(logs));
      if (settings) localStorage.setItem('rtrw_settings', JSON.stringify(settings));
      localStorage.setItem('rtrw_servers', JSON.stringify(servers));
      localStorage.setItem('rtrw_collectors', JSON.stringify(collectors));
      localStorage.setItem('rtrw_resellers', JSON.stringify(resellers));
      localStorage.setItem('rtrw_vouchers', JSON.stringify(vouchers));
      localStorage.setItem('rtrw_pppoe', JSON.stringify(pppoeUsers));
      localStorage.setItem('rtrw_pesanan_agen', JSON.stringify(pesananAgen));
      localStorage.setItem('rtrw_teknisi', JSON.stringify(teknisiList));
      localStorage.setItem('rtrw_portal_logs', JSON.stringify(portalLogs));

      // Auto write to background full-stack database
      triggerCloudSync();
    }, 1200);

    return () => clearTimeout(syncHandler);
  }, [pelanggan, paket, tagihan, logs, settings, servers, collectors, resellers, vouchers, pppoeUsers, pesananAgen, teknisiList, portalLogs]);


  if (!settings) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center font-sans">
        <div className="text-center p-6 space-y-3 bg-white border border-slate-100 rounded-2xl shadow-xs">
          <RefreshCcw className="w-8 h-8 text-indigo-600 animate-spin mx-auto" />
          <p className="text-sm font-semibold text-slate-500">Menyiapkan Database RT RW Net...</p>
        </div>
      </div>
    );
  }

  // --- CRUD CUSTOMERS (PELANGGAN) OPERATIONS ---
  const handleAddPelanggan = (p: Omit<Pelanggan, 'id' | 'tanggalDaftar'>) => {
    const customId = `plg-${Math.floor(100 + Math.random() * 900)}-${Date.now().toString().substring(10)}`;
    const newRecord: Pelanggan = {
      ...p,
      id: customId,
      tanggalDaftar: SYSTEM_DATE
    };
    setPelanggan([newRecord, ...pelanggan]);

    // Automatically generate a monthly invoice for this new customer for the currently selected month
    const currentDueDay = p.jatuhTempo ? p.jatuhTempo.slice(-2) : '10';
    const numDueDay = isNaN(Number(currentDueDay)) ? 10 : Number(currentDueDay);
    const paddedDueDay = numDueDay < 10 ? `0${numDueDay}` : `${numDueDay}`;

    const newBill: Tagihan = {
      id: `INV-${Date.now().toString().slice(-5)}-${Math.floor(100 + Math.random() * 900)}`,
      pelangganId: customId,
      pelangganNama: p.nama,
      pelangganNoHp: p.noHp,
      bulan: selectedBulan,
      jumlah: p.tarif,
      tanggalJatuhTempo: `${selectedBulan}-${paddedDueDay}`,
      status: 'BELUM_BAYAR',
      waSent: false,
      pelangganAlamat: p.alamat,
      pelangganKategori: p.kategoriLangganan
    };

    setTagihan(prev => [newBill, ...prev]);
  };

  const handleUpdatePelanggan = (p: Pelanggan) => {
    setPelanggan(pelanggan.map((item) => (item.id === p.id ? p : item)));
    
    // Auto sync updated customer names and mobile numbers on existing UNPAID invoices!
    setTagihan(tagihan.map((t) => {
      if (t.pelangganId === p.id && t.status !== 'LUNAS') {
        return {
          ...t,
          pelangganNama: p.nama,
          pelangganNoHp: p.noHp,
          jumlah: p.tarif
        };
      }
      return t;
    }));
  };

  const handleDeletePelanggan = (id: string) => {
    setPelanggan(pelanggan.filter((item) => item.id !== id));
    setTagihan(tagihan.filter((t) => t.pelangganId !== id));
  };

  // --- CRUD PACKAGES (PAKET) OPERATIONS ---
  const handleAddPaket = (pkt: Omit<Paket, 'id'>) => {
    const customId = `pkt-${paket.length + 1}`;
    const newRecord: Paket = {
      ...pkt,
      id: customId
    };
    setPaket([...paket, newRecord]);
  };

  const handleUpdatePaket = (pkt: Paket) => {
    setPaket(paket.map((item) => (item.id === pkt.id ? pkt : item)));
    
    setPelanggan(pelanggan.map((p) => {
      if (p.paketId === pkt.id) {
        return {
          ...p,
          tarif: pkt.harga
        };
      }
      return p;
    }));
  };

  const handleDeletePaket = (id: string) => {
    setPaket(paket.filter((item) => item.id !== id));
  };

  // --- MONTHLY BILL GENERATION OPERATIONS ---
  const handleGenerateTagihan = (
    bulan: string,
    kategori?: 'SEMUA' | 'HOTSPOT' | 'RUMAHAN',
    customPelangganId?: string,
    customTarif?: number
  ) => {
    if (customPelangganId) {
      // Manual single bill generation
      const p = pelanggan.find(item => item.id === customPelangganId);
      if (!p) return;

      const invoiceId = generateInvoiceId(p.id, bulan);
      
      // Check if invoice already exists
      const alreadyExists = tagihan.some(t => t.id === invoiceId);
      if (alreadyExists) {
        alert(`Tagihan dengan kode invoice ${invoiceId} sudah pernah dibuat!`);
        return;
      }

      let dueDayStr = "10";
      if (p.jatuhTempo && p.jatuhTempo.includes('-')) {
        dueDayStr = p.jatuhTempo.split('-')[2] || "10";
      } else {
        dueDayStr = p.jatuhTempo.toString().padStart(2, '0');
      }
      const tanggalJatuhTempo = `${bulan}-${dueDayStr}`;

      const newInvoice: Tagihan = {
        id: invoiceId,
        pelangganId: p.id,
        pelangganNama: p.nama,
        pelangganNoHp: p.noHp,
        bulan: bulan,
        jumlah: customTarif ?? p.tarif,
        tanggalJatuhTempo,
        status: 'BELUM_BAYAR',
        waSent: false
      };

      setTagihan([newInvoice, ...tagihan]);
      alert(`Sukses membuat tagihan mandiri untuk ${p.nama} (${formatBulanIndo(bulan)}) senilai ${formatRupiah(customTarif ?? p.tarif)}`);
      return;
    }

    const existingBillCustomerIds = tagihan
      .filter((t) => t.bulan === bulan)
      .map((t) => t.pelangganId);

    let activeCustomersWithoutBill = pelanggan.filter(
      (p) => p.statusAktif && !existingBillCustomerIds.includes(p.id)
    );

    if (kategori === 'HOTSPOT') {
      activeCustomersWithoutBill = activeCustomersWithoutBill.filter(p => p.kategoriLangganan === 'Hotspot');
    } else if (kategori === 'RUMAHAN') {
      activeCustomersWithoutBill = activeCustomersWithoutBill.filter(p => p.kategoriLangganan === 'Rumahan');
    }

    if (activeCustomersWithoutBill.length === 0) {
      alert(`Semua tagihan untuk kategori tersebut di bulan ini telah dibuat!`);
      return;
    }

    const newInvoices: Tagihan[] = activeCustomersWithoutBill.map((p) => {
      const invoiceId = generateInvoiceId(p.id, bulan);
      
      let dueDayStr = "10";
      if (p.jatuhTempo && p.jatuhTempo.includes('-')) {
        dueDayStr = p.jatuhTempo.split('-')[2] || "10";
      } else {
        dueDayStr = p.jatuhTempo.toString().padStart(2, '0');
      }
      const tanggalJatuhTempo = `${bulan}-${dueDayStr}`;

      return {
        id: invoiceId,
        pelangganId: p.id,
        pelangganNama: p.nama,
        pelangganNoHp: p.noHp,
        bulan: bulan,
        jumlah: p.tarif,
        tanggalJatuhTempo,
        status: 'BELUM_BAYAR',
        waSent: false
      };
    });

    setTagihan([...newInvoices, ...tagihan]);
  };

  const handleAddManualTagihan = (newInvoice: Tagihan) => {
    setTagihan([newInvoice, ...tagihan]);
  };

  const handleDeleteTagihan = (id: string) => {
    setTagihan(tagihan.filter((t) => t.id !== id));
  };

  // --- PAYMENT REGISTRATION OPERATIONS ---
  const handleRegisterPayment = (
    tagihanId: string, 
    payload: { tanggalBayar: string; metodeBayar: string; catatan: string }
  ) => {
    // Record log audit prior to updating tagihan
    const selectedBill = tagihan.find(t => t.id === tagihanId);
    if (selectedBill) {
      if (currentUserRole === 'collector' && activeCollector) {
        addPortalLog({
          portalType: 'TUKANG_TAGIH',
          operatorNama: activeCollector.nama,
          operatorId: activeCollector.id,
          aktifitasType: 'TRANSAKSI_BAYAR',
          fiturLabel: 'Kas Lapangan Terbayar',
          detail: `Mencatat penagihan tunai LUNAS dari pelanggan "${selectedBill.pelangganNama}" senilai ${formatRupiah(selectedBill.jumlah)}.`,
          status: 'SUKSES',
          amount: selectedBill.jumlah
        });
      } else if (currentUserRole === 'admin') {
        addPortalLog({
          portalType: 'TUKANG_TAGIH',
          operatorNama: 'Administrator',
          operatorId: 'admin',
          aktifitasType: 'TRANSAKSI_BAYAR',
          fiturLabel: 'Loket Kasir Pusat',
          detail: `Admin melunasi tagihan pelanggan "${selectedBill.pelangganNama}" senilai ${formatRupiah(selectedBill.jumlah)} via ${payload.metodeBayar}.`,
          status: 'INFO',
          amount: selectedBill.jumlah
        });
      }
    }

    setTagihan(tagihan.map((t) => {
      if (t.id === tagihanId) {
        return {
          ...t,
          status: 'LUNAS',
          tanggalBayar: payload.tanggalBayar,
          metodeBayar: payload.metodeBayar,
          catatan: payload.catatan
        };
      }
      return t;
    }));

    setTimeout(() => {
      const selectedBill = tagihan.find(t => t.id === tagihanId);
      if (selectedBill) {
        const cust = pelanggan.find(p => p.id === selectedBill.pelangganId);
        const pLayer = cust ? paket.find(p => p.id === cust.paketId) : null;
        
        const variables = {
          Nama: selectedBill.pelangganNama,
          NamaLayanan: pLayer ? pLayer.nama : 'Internet',
          Alamat: cust ? cust.alamat : '',
          Bulan: selectedBill.bulan,
          Tarif: formatRupiah(selectedBill.jumlah),
          JatuhTempo: selectedBill.tanggalJatuhTempo,
          NamaBank: settings.bankNama,
          NoRek: settings.bankNomorRekening,
          AtasNama: settings.bankAtasNama,
          NamaPenyedia: settings.billingNamaPenyedia,
          TanggalBayar: payload.tanggalBayar,
          MetodeBayar: payload.metodeBayar
        };

        const convertedMessage = replaceTemplates(settings.waTemplateLunasDefault, variables);
        
        const autoReceiptLog: WhatsAppLog = {
          id: `log-tr-${Date.now()}`,
          tagihanId: selectedBill.id,
          pelangganNama: selectedBill.pelangganNama,
          noHp: selectedBill.pelangganNoHp,
          pesan: convertedMessage,
          status: 'SUKSES',
          sentAt: new Date().toISOString().substring(0, 19).replace('T', ' ')
        };

        setLogs(prev => [autoReceiptLog, ...prev]);
        setTagihan(prevBills => prevBills.map(b => b.id === tagihanId ? { ...b, waSent: true, waSentAt: autoReceiptLog.sentAt } : b));
      }
    }, 500);
  };

  // --- AUTOMATED WHATSAPP NOTIFICATION TRIGGER ---
  const handleSendSingleWa = (t: Tagihan) => {
    const cust = pelanggan.find(p => p.id === t.pelangganId);
    const pLayer = cust ? paket.find(p => p.id === cust.paketId) : null;
    
    const rawTemplate = t.status === 'LUNAS' 
      ? settings.waTemplateLunasDefault 
      : settings.waTemplateTagihanDefault;

    const variables = {
      Nama: t.pelangganNama,
      NamaLayanan: pLayer ? pLayer.nama : 'Internet',
      Alamat: cust ? cust.alamat : '',
      Bulan: t.bulan,
      Tarif: formatRupiah(t.jumlah),
      JatuhTempo: t.tanggalJatuhTempo,
      NamaBank: settings.bankNama,
      NoRek: settings.bankNomorRekening,
      AtasNama: settings.bankAtasNama,
      NamaPenyedia: settings.billingNamaPenyedia,
      TanggalBayar: t.tanggalBayar,
      MetodeBayar: t.metodeBayar
    };

    const pesanFinal = replaceTemplates(rawTemplate, variables);

    const newLogItem: WhatsAppLog = {
      id: `log-${Date.now()}`,
      tagihanId: t.id,
      pelangganNama: t.pelangganNama,
      noHp: t.pelangganNoHp,
      pesan: pesanFinal,
      status: 'SUKSES',
      sentAt: new Date().toISOString().substring(0, 19).replace('T', ' ')
    };

    setLogs([newLogItem, ...logs]);
    setTagihan(tagihan.map((b) => (b.id === t.id ? { ...b, waSent: true, waSentAt: newLogItem.sentAt } : b)));
    
    alert(`Virtual Messenger: Pesan sukses terkirim ke pelanggan ${t.pelangganNama} (${t.pelangganNoHp})!`);
  };

  const handleSendSingleWaWeb = (t: Tagihan) => {
    const cust = pelanggan.find(p => p.id === t.pelangganId);
    const pLayer = cust ? paket.find(p => p.id === cust.paketId) : null;
    
    const rawTemplate = t.status === 'LUNAS' 
      ? settings.waTemplateLunasDefault 
      : settings.waTemplateTagihanDefault;

    const variables = {
      Nama: t.pelangganNama,
      NamaLayanan: pLayer ? pLayer.nama : 'Internet',
      Alamat: cust ? cust.alamat : '',
      Bulan: t.bulan,
      Tarif: formatRupiah(t.jumlah),
      JatuhTempo: t.tanggalJatuhTempo,
      NamaBank: settings.bankNama,
      NoRek: settings.bankNomorRekening,
      AtasNama: settings.bankAtasNama,
      NamaPenyedia: settings.billingNamaPenyedia,
      TanggalBayar: t.tanggalBayar,
      MetodeBayar: t.metodeBayar
    };

    const pesanFinal = replaceTemplates(rawTemplate, variables);
    const encodedText = encodeURIComponent(pesanFinal);
    
    let cleanPhone = t.pelangganNoHp.replace(/[-\s]/g, '');
    if (cleanPhone.startsWith('0')) {
      cleanPhone = '62' + cleanPhone.substring(1);
    }

    const waLink = `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encodedText}`;
    
    setTagihan(tagihan.map((b) => b.id === t.id ? { ...b, waSent: true, waSentAt: new Date().toISOString().substring(11, 16) } : b));
    window.open(waLink, '_blank');
  };

  const handleTriggerBulkBroadcast = () => {
    const unpaidList = tagihan.filter((t) => t.bulan === selectedBulan && t.status !== 'LUNAS');
    
    if (unpaidList.length === 0) {
      alert(`Tidak ada tunggakan tagihan belum bayar untuk periode ${formatBulanIndo(selectedBulan)}.`);
      return;
    }

    if (!settings.waStatusKoneksi) {
      alert('Peringatan: Antrean pengiriman otomatis hanya didukung saat Gateway status Terhubung!');
      return;
    }

    setBroadcastQueue(unpaidList);
    setIsBroadcasting(true);
    setActiveTab('notifikasi');
  };

  const handleFinishBroadcast = (newSimulatedLogs: WhatsAppLog[]) => {
    setLogs((prev) => [...newSimulatedLogs, ...prev]);
    
    const processedIds = newSimulatedLogs.map(l => l.tagihanId);
    setTagihan(prevBills => prevBills.map((b) => {
      if (processedIds.includes(b.id)) {
        const matchingLog = newSimulatedLogs.find(l => l.tagihanId === b.id);
        return {
          ...b,
          waSent: true,
          waSentAt: matchingLog ? matchingLog.sentAt : b.waSentAt
        };
      }
      return b;
    }));
  };

  // --- HANDLERS FOR MIKROTIK MULTI SERVER ---
  const handleAddServer = (s: Omit<MikrotikServer, 'id'>) => {
    setServers([...servers, { ...s, id: `srv-${Date.now()}` }]);
  };
  const handleUpdateServer = (s: MikrotikServer) => {
    setServers(servers.map(item => item.id === s.id ? s : item));
  };
  const handleDeleteServer = (id: string) => {
    setServers(servers.filter(item => item.id !== id));
  };

  // --- HANDLERS FOR COLLECORS (TUKANG TAGIH) ---
  const handleAddCollector = (c: Omit<TukangTagih, 'id'>) => {
    setCollectors([...collectors, { ...c, id: `tagih-${Date.now()}` }]);
  };
  const handleUpdateCollector = (c: TukangTagih) => {
    setCollectors(collectors.map(item => item.id === c.id ? c : item));
  };
  const handleDeleteCollector = (id: string) => {
    setCollectors(collectors.filter(item => item.id !== id));
    setPelanggan(pelanggan.map(p => p.tukangTagihId === id ? { ...p, tukangTagihId: 'none' } : p));
  };

  // --- HANDLERS FOR AGENT/RESELLERS ---
  const handleAddReseller = (r: Omit<Reseller, 'id'>) => {
    setResellers([...resellers, { ...r, id: `rsl-${Date.now()}` }]);
  };
  const handleUpdateReseller = (r: Reseller) => {
    setResellers(resellers.map(item => item.id === r.id ? r : item));
  };
  const handleDeleteReseller = (id: string) => {
    setResellers(resellers.filter(item => item.id !== id));
  };

  // --- HANDLERS FOR HOTSPOT VOUCHERS ---
  const handleAddVoucher = (v: Omit<HotspotVoucher, 'id'>) => {
    const newVoucherId = `voc-${Date.now()}`;
    const newVoucher = { ...v, id: newVoucherId };
    setVouchers([...vouchers, newVoucher]);

    // Audit logging for voucher creation
    if (currentUserRole === 'reseller' && activeReseller) {
      addPortalLog({
        portalType: 'AGEN/RESELLER',
        operatorNama: activeReseller.nama,
        operatorId: activeReseller.id,
        aktifitasType: 'CETAK_VOUCHER',
        fiturLabel: 'Cetak Manual',
        detail: `Membuat user hotspot "${v.code.toUpperCase()}" (Tarif: ${formatRupiah(v.harga)}) di Router "${v.serverName}".`,
        status: 'SUKSES',
        amount: v.harga
      });
    } else if (currentUserRole === 'teknisi' && activeTeknisi) {
      addPortalLog({
        portalType: 'TEKNISI',
        operatorNama: activeTeknisi.nama,
        operatorId: activeTeknisi.id,
        aktifitasType: 'CETAK_VOUCHER',
        fiturLabel: 'MikroTik Hotspot API',
        detail: `Mendaftarkan user hotspot "${v.code.toUpperCase()}" secara manual di Router "${v.serverName}".`,
        status: 'SUKSES'
      });
    } else if (currentUserRole === 'admin') {
      addPortalLog({
        portalType: 'AGEN/RESELLER',
        operatorNama: 'Administrator',
        operatorId: 'admin',
        aktifitasType: 'CETAK_VOUCHER',
        fiturLabel: 'Admin Panel Hotspot',
        detail: `Admin membuat user hotspot manual "${v.code.toUpperCase()}" di Router "${v.serverName}".`,
        status: 'INFO'
      });
    }

    // Check if this hotspot voucher is linked or matches an agent's data
    const codeLower = v.code.trim().toLowerCase();
    const linkedReseller = resellers.find(r => 
      r.id === v.resellerId ||
      r.nama.toLowerCase() === codeLower ||
      (r.username && r.username.toLowerCase() === codeLower) ||
      codeLower.includes(r.nama.toLowerCase()) ||
      (r.username && codeLower.includes(r.username.toLowerCase()))
    );

    if (linkedReseller) {
      const selectedPaket = paket.find(p => p.id === v.paketId);
      const newPesanan: PesananAgen = {
        id: `psn-${Date.now()}`,
        resellerId: linkedReseller.id,
        resellerNama: linkedReseller.nama,
        resellerWilayah: linkedReseller.wilayah || 'Umum',
        resellerNoHp: linkedReseller.noHp,
        voucherId: newVoucherId,
        voucherCode: v.code.trim(),
        paketId: v.paketId,
        paketNama: selectedPaket ? selectedPaket.nama : 'Paket Custom',
        jumlahTagihan: v.harga,
        status: v.agentPaymentStatus || 'BELUM BAYAR', // Dynamic or default status
        tanggalPesan: new Date().toISOString().substring(0, 10),
        bulan: new Date().toISOString().substring(0, 7)
      };
      setPesananAgen(prev => [newPesanan, ...prev]);
    }
  };
  const handleDeleteVoucher = (id: string) => {
    setVouchers(vouchers.filter(item => item.id !== id));
  };

  const handleUpdateVoucher = (v: HotspotVoucher) => {
    setVouchers(vouchers.map(item => item.id === v.id ? v : item));
  };

  // --- HANDLERS FOR PESANAN AGEN HOTSPOT ---
  const handleAddPesananAgen = (p: Omit<PesananAgen, 'id'>) => {
    setPesananAgen([...pesananAgen, { ...p, id: `psn-${Date.now()}` }]);
  };

  const handleUpdatePesananAgen = (p: PesananAgen) => {
    setPesananAgen(pesananAgen.map(item => item.id === p.id ? p : item));
  };

  const handleDeletePesananAgen = (id: string) => {
    setPesananAgen(pesananAgen.filter(item => item.id !== id));
  };

  // --- HANDLERS FOR TEKNISI (LAPANGAN) ---
  const handleAddTeknisi = (t: Omit<Teknisi, 'id'>) => {
    setTeknisiList([...teknisiList, { ...t, id: `tek-${Date.now()}` }]);
  };

  const handleUpdateTeknisi = (t: Teknisi) => {
    setTeknisiList(teknisiList.map(item => item.id === t.id ? t : item));
  };

  const handleDeleteTeknisi = (id: string) => {
    setTeknisiList(teknisiList.filter(item => item.id !== id));
  };

  const handleBulkGenerateVouchers = (p: { 
    count: number; 
    paketId: string; 
    harga: number; 
    durasi: string; 
    serverName: string; 
    resellerId?: string;
    prefix?: string;
    credMode?: 'UP' | 'U_P';
    charLength?: number;
  }) => {
    const newBatch: HotspotVoucher[] = [];
    const characters = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    const numChars = '23456789';
    const len = p.charLength ? Math.max(1, Math.min(8, p.charLength)) : 6;
    for (let i = 0; i < p.count; i++) {
      let randomPart = '';
      for (let j = 0; j < len; j++) {
        randomPart += characters.charAt(Math.floor(Math.random() * characters.length));
      }
      const code = (p.prefix || '') + randomPart;

      let password: string | undefined = undefined;
      if (p.credMode === 'UP') {
        password = code;
      } else if (p.credMode === 'U_P') {
        // Generate a distinct numerical/char password
        password = '';
        for (let j = 0; j < len; j++) {
          password += numChars.charAt(Math.floor(Math.random() * numChars.length));
        }
      }

      newBatch.push({
        id: `voc-${Date.now()}-${i}`,
        code,
        password,
        paketId: p.paketId,
        harga: p.harga,
        durasi: p.durasi,
        serverName: p.serverName,
        status: 'AKTIF',
        resellerId: p.resellerId
      });
    }
    setVouchers([...newBatch, ...vouchers]);

    // Audit logging for bulk voucher creation
    if (currentUserRole === 'reseller' && activeReseller) {
      addPortalLog({
        portalType: 'AGEN/RESELLER',
        operatorNama: activeReseller.nama,
        operatorId: activeReseller.id,
        aktifitasType: 'CETAK_VOUCHER',
        fiturLabel: 'Cetak Massal (Bulk)',
        detail: `Berhasil mencetak ${p.count} lembar voucher (Total Modal ditarik: ${formatRupiah(p.harga * p.count)}) di Router "${p.serverName}".`,
        status: 'SUKSES',
        amount: p.harga * p.count
      });
    } else if (currentUserRole === 'teknisi' && activeTeknisi) {
      addPortalLog({
        portalType: 'TEKNISI',
        operatorNama: activeTeknisi.nama,
        operatorId: activeTeknisi.id,
        aktifitasType: 'CETAK_VOUCHER',
        fiturLabel: 'Cetak Massal (Bulk) Mikrotik',
        detail: `Berhasil mendaftarkan ${p.count} tiket login WiFi acak di Router "${p.serverName}".`,
        status: 'SUKSES'
      });
    } else if (currentUserRole === 'admin') {
      addPortalLog({
        portalType: 'AGEN/RESELLER',
        operatorNama: 'Administrator',
        operatorId: 'admin',
        aktifitasType: 'CETAK_VOUCHER',
        fiturLabel: 'Cetak Massal Admin',
        detail: `Admin mencetak ${p.count} lembar voucher WiFi acak di Router "${p.serverName}".`,
        status: 'INFO'
      });
    }
  };

  // --- HANDLERS FOR PPPOE SECRETS ---
  const handleAddPppoe = (p: Omit<PppoeUser, 'id'>) => {
    setPppoeUsers([...pppoeUsers, { ...p, id: `ppp-${Date.now()}` }]);
  };
  const handleUpdatePppoe = (p: PppoeUser) => {
    setPppoeUsers(pppoeUsers.map(item => item.id === p.id ? p : item));
  };
  const handleDeletePppoe = (id: string) => {
    setPppoeUsers(pppoeUsers.filter(item => item.id !== id));
  };

  // --- PAYMENT GATEWAY CONFIG OR VOUCHER DESIGN SYNC ---
  const handleUpdateVoucherPageSettings = (vPage: VoucherPageSettings) => {
    if (settings) {
      setSettings({
        ...settings,
        voucherPage: vPage
      });
    }
  };

  const handleUpdatePaymentGatewayConfig = (payload: { paymentGatewayActive: boolean; merchantCode: string; apiKey: string; clientKey: string; provider: 'Midtrans' | 'Xendit' | 'Tripay' }) => {
    if (settings) {
      setSettings({
        ...settings,
        ...payload
      });
    }
  };

  // --- SIMULATION LOGIN MATCHER ---
  const handleProcessLoginSimulation = (e: React.FormEvent) => {
    e.preventDefault();
    if (loginRole === 'admin') {
      if (loginUsername.trim() === 'admin' && loginPassword === 'admin') {
        setCurrentUserRole('admin');
        setActiveCollector(null);
        setActiveReseller(null);
        setIsLoggedIn(true);
        setActiveTab('dashboard');
        // Clear forms
        setLoginUsername('');
        setLoginPassword('');
      } else {
        alert('Gagal: Kredensial login Admin salah! Gunakan username "admin" dan sandi "admin".');
      }
    } else if (loginRole === 'collector') {
      // Find matching active collector username & password
      const matched = collectors.find(c => c.username === loginUsername.trim().toLowerCase() && c.password === loginPassword);
      if (matched) {
        if (!matched.statusAktif) {
          alert('Gagal: Akun Tukang Tagih ini berstatus Nonaktif (Blokir). Hubungi Administrator.');
          return;
        }
        setCurrentUserRole('collector');
        setActiveCollector(matched);
        setActiveReseller(null);
        setIsLoggedIn(true);
        addPortalLog({
          portalType: 'TUKANG_TAGIH',
          operatorNama: matched.nama,
          operatorId: matched.id,
          aktifitasType: 'LOGIN',
          fiturLabel: 'Autentikasi Portal',
          detail: 'Berhasil melakukan login aman ke Portal Penagihan Lapangan.',
          status: 'INFO'
        });
        // Clear forms
        setLoginUsername('');
        setLoginPassword('');
      } else {
        alert('Gagal: Username / Sandi Tukang Tagih tidak ditemukan! Pastikan Anda memasukkan sandi default "123".');
      }
    } else if (loginRole === 'reseller') {
      // Find matching active reseller username & password
      const matched = resellers.find(r => r.username === loginUsername.trim().toLowerCase() && r.password === loginPassword);
      if (matched) {
        if (!matched.statusAktif) {
          alert('Gagal: Akun Reseller ini berstatus Nonaktif (Blokir). Hubungi Administrator.');
          return;
        }
        setCurrentUserRole('reseller');
        setActiveReseller(matched);
        setActiveCollector(null);
        setActiveTeknisi(null);
        setIsLoggedIn(true);
        addPortalLog({
          portalType: 'AGEN/RESELLER',
          operatorNama: matched.nama,
          operatorId: matched.id,
          aktifitasType: 'LOGIN',
          fiturLabel: 'Autentikasi Portal',
          detail: 'Berhasil melakukan login aman ke Portal Manajemen Kemitraan (Reseller).',
          status: 'INFO'
        });
        // Clear forms
        setLoginUsername('');
        setLoginPassword('');
      } else {
        alert('Gagal: Username / Sandi Reseller tidak ditemukan! Pastikan kredensial Anda benar.');
      }
    } else if (loginRole === 'teknisi') {
      // Find matching active technician username & password
      const matched = teknisiList.find(t => t.username === loginUsername.trim().toLowerCase() && t.password === loginPassword);
      if (matched) {
        if (!matched.statusAktif) {
          alert('Gagal: Akun Teknisi ini berstatus Nonaktif (Blokir). Hubungi Administrator.');
          return;
        }
        setCurrentUserRole('teknisi');
        setActiveTeknisi(matched);
        setActiveReseller(null);
        setActiveCollector(null);
        setIsLoggedIn(true);
        addPortalLog({
          portalType: 'TEKNISI',
          operatorNama: matched.nama,
          operatorId: matched.id,
          aktifitasType: 'LOGIN',
          fiturLabel: 'Autentikasi Portal',
          detail: 'Berhasil melakukan login ke Portal Teknisi Jaringan Lapangan.',
          status: 'INFO'
        });
        // Clear forms
        setLoginUsername('');
        setLoginPassword('');
      } else {
        alert('Gagal: Username / Sandi Teknisi tidak ditemukan! Pastikan Anda memasukkan sandi "123".');
      }
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setCurrentUserRole('admin');
    setActiveCollector(null);
    setActiveReseller(null);
    setActiveTeknisi(null);
  };

  // If logged in as collector, direct completely to limited Portal Screen View
  if (isLoggedIn && currentUserRole === 'collector' && activeCollector) {
    return (
      <div className={`min-h-screen ${darkMode ? 'dark bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-850'}`}>
        <CollectorPortal
          collector={activeCollector}
          pelanggan={pelanggan}
          tagihan={tagihan}
          paket={paket}
          selectedBulan={selectedBulan}
          onLogout={handleLogout}
          onRegisterPayment={handleRegisterPayment}
          onAddPelanggan={handleAddPelanggan}
          portalLogs={portalLogs}
          onAddPortalLog={addPortalLog}
        />
      </div>
    );
  }

  // If logged in as reseller, direct completely to limited Reseller Portal Screen View
  if (isLoggedIn && currentUserRole === 'reseller' && activeReseller) {
    return (
      <div className={`min-h-screen ${darkMode ? 'dark bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-850'}`}>
        <ResellerPortal
          reseller={activeReseller}
          paket={paket}
          vouchers={vouchers}
          servers={servers}
          onLogout={handleLogout}
          onUpdateReseller={(updated) => {
            // Check if saldo increased to log top-up
            if (activeReseller && updated.saldo > activeReseller.saldo) {
              const topupAmt = updated.saldo - activeReseller.saldo;
              addPortalLog({
                portalType: 'AGEN/RESELLER',
                operatorNama: updated.nama,
                operatorId: updated.id,
                aktifitasType: 'TOPUP',
                fiturLabel: 'Topup Saldo Kemitraan',
                detail: `Top Up saldo mandiri berhasil sebesar ${formatRupiah(topupAmt)} via E-Wallet/Bank.`,
                status: 'SUKSES',
                amount: topupAmt
              });
            }
            setResellers(resellers.map(r => r.id === updated.id ? updated : r));
            setActiveReseller(updated);
          }}
          onAddVoucher={handleAddVoucher}
          onBulkGenerate={handleBulkGenerateVouchers}
          portalLogs={portalLogs}
          onAddPortalLog={addPortalLog}
        />
      </div>
    );
  }

  // If logged in as teknisi, direct completely to limited Teknisi Portal Screen View
  if (isLoggedIn && currentUserRole === 'teknisi' && activeTeknisi) {
    return (
      <div className={`min-h-screen ${darkMode ? 'dark bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-855'}`}>
        <TeknisiPortal
          teknisi={activeTeknisi}
          paket={paket}
          vouchers={vouchers}
          servers={servers}
          onLogout={handleLogout}
          onAddVoucher={handleAddVoucher}
          onDeleteVoucher={handleDeleteVoucher}
          onBulkGenerate={handleBulkGenerateVouchers}
          portalLogs={portalLogs}
          onAddPortalLog={addPortalLog}
        />
      </div>
    );
  }

  // --- DATABASE EXPORT AND RESTORE HELPER CONTROLS ---
  const handleExportDataJson = () => {
    const databaseExport = {
      pelanggan,
      paket,
      tagihan,
      logs,
      settings,
      servers,
      collectors,
      resellers,
      vouchers,
      pppoeUsers,
      teknisiList
    };
    const fileData = JSON.stringify(databaseExport, null, 2);
    const blob = new Blob([fileData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `backup_billing_rtrwnet_${selectedBulan}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleImportDataJson = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileReader = new FileReader();
    if (e.target.files && e.target.files[0]) {
      fileReader.readAsText(e.target.files[0], "UTF-8");
      fileReader.onload = (event) => {
        try {
          const parsed = JSON.parse(event.target?.result as string);
          if (parsed.pelanggan && parsed.paket && parsed.tagihan) {
            setPelanggan(parsed.pelanggan);
            setPaket(parsed.paket);
            setTagihan(parsed.tagihan);
            if (parsed.logs) setLogs(parsed.logs);
            if (parsed.settings) setSettings(parsed.settings);
            if (parsed.servers) setServers(parsed.servers);
            if (parsed.collectors) setCollectors(parsed.collectors);
            if (parsed.resellers) setResellers(parsed.resellers);
            if (parsed.vouchers) setVouchers(parsed.vouchers);
            if (parsed.pppoeUsers) setPppoeUsers(parsed.pppoeUsers);
            if (parsed.teknisiList) setTeknisiList(parsed.teknisiList);
            alert('Pulihkan data sukses! Database RT RW Net telah diperbarui dari dokumen backup.');
          } else {
            alert('Format berkas backup JSON tidak didukung atau corrupt.');
          }
        } catch (err) {
          alert('Terjadi error dalam membaca berkas json.');
        }
      };
    }
  };

  const handleWipeDatabaseReset = () => {
    if (confirm('⚠️ PERINGATAN: Aksi ini menghapus semua data transaksi kustom dan mengembalikannya ke preset demo awal. Lanjutkan?')) {
      localStorage.clear();
      setPelanggan(DEFAULT_PELANGGAN);
      setPaket(DEFAULT_PAKET);
      setTagihan(DEFAULT_TAGIHAN);
      setLogs(DEFAULT_WA_LOGS);
      setSettings(DEFAULT_SETTINGS);
      setServers(DEFAULT_MIKROTIK);
      setCollectors(DEFAULT_TUKANG_TAGIH);
      setResellers(DEFAULT_RESELLER);
      setVouchers(DEFAULT_VOUCHERS);
      setPppoeUsers(DEFAULT_PPPOE);
      setTeknisiList(DEFAULT_TEKNISI);
      alert('Database dibersihkan kembali ke pengaturan bawaan!');
    }
  };

  return (
    <div className={`min-h-screen bg-slate-50 dark:bg-slate-950 dark:text-slate-100 flex flex-col font-sans select-none antialiased ${darkMode ? 'dark' : ''}`}>
      
      {/* AUTH SCREEN IF NOT LOGGED IN */}
      {!isLoggedIn && (
        <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 dark:border-slate-800 rounded-3xl w-full max-w-md overflow-hidden border border-slate-100 shadow-xl p-8 space-y-6">
            <div className="text-center space-y-2">
              <span className="p-3 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 rounded-2xl inline-block shadow-sm">
                <Landmark size={28} />
              </span>
              <h2 className="text-xl font-extrabold text-slate-800 dark:text-slate-100">Masuk Sistem Mikrotik Billing</h2>
              <p className="text-xs text-slate-450 dark:text-slate-400 leading-relaxed">Pilih peran dan gunakan kredensial resmi Anda untuk mengakses dasbor admin atau portal petugas.</p>
            </div>

            <form onSubmit={handleProcessLoginSimulation} className="space-y-4 text-xs font-semibold text-slate-700 dark:text-slate-300">
               {/* Role Toggle Tabs */}
              <div className="grid grid-cols-4 gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl text-[10px]">
                <button
                  type="button"
                  onClick={() => setLoginRole('admin')}
                  className={`py-2 px-0.5 rounded-lg text-center transition font-bold ${
                    loginRole === 'admin' ? 'bg-white dark:bg-slate-700 text-indigo-750 dark:text-indigo-300 shadow-xs' : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-100'
                  }`}
                >
                  Admin
                </button>
                <button
                  type="button"
                  onClick={() => setLoginRole('collector')}
                  className={`py-2 px-0.5 rounded-lg text-center transition font-bold ${
                    loginRole === 'collector' ? 'bg-white dark:bg-slate-700 text-indigo-750 dark:text-indigo-300 shadow-xs' : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-100'
                  }`}
                >
                  Kolektor
                </button>
                <button
                  type="button"
                  onClick={() => setLoginRole('reseller')}
                  className={`py-2 px-0.5 rounded-lg text-center transition font-bold ${
                    loginRole === 'reseller' ? 'bg-white dark:bg-slate-700 text-indigo-750 dark:text-indigo-300 shadow-xs' : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-100'
                  }`}
                >
                  Reseller
                </button>
                <button
                  type="button"
                  onClick={() => setLoginRole('teknisi')}
                  className={`py-2 px-0.5 rounded-lg text-center transition font-bold ${
                    loginRole === 'teknisi' ? 'bg-white dark:bg-slate-700 text-indigo-750 dark:text-indigo-300 shadow-xs' : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-100'
                  }`}
                >
                  Teknisi
                </button>
              </div>

              {/* Form Input fields */}
              <div className="space-y-1">
                <label>Username Akses</label>
                <input
                  type="text"
                  required
                  placeholder={
                    loginRole === 'admin' 
                      ? 'Masukkan "admin"' 
                      : loginRole === 'collector' 
                        ? 'Contoh: andri, maman' 
                        : loginRole === 'reseller'
                          ? 'Contoh: sri, koperasi'
                          : 'Contoh: budi, andi'
                  }
                  className="w-full bg-slate-50 dark:bg-slate-950 border dark:border-slate-800 p-3 rounded-xl focus:outline-hidden focus:border-indigo-500 font-mono text-slate-800 dark:text-slate-100"
                  value={loginUsername}
                  onChange={(e) => setLoginUsername(e.target.value)}
                />
              </div>

              <div className="space-y-1">
                <label>Sandi Pengaman (Password)</label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    placeholder={loginRole === 'admin' ? 'Masukkan "admin"' : 'Sandi default "123"'}
                    className="w-full bg-slate-50 dark:bg-slate-950 border dark:border-slate-800 p-3 rounded-xl focus:outline-hidden focus:border-indigo-500 font-mono text-slate-800 dark:text-slate-100"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3.5 top-3 text-slate-400 hover:text-slate-600 cursor-pointer"
                  >
                    {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-indigo-650 hover:bg-indigo-700 text-white font-extrabold text-xs py-3 rounded-xl transition-all shadow-md cursor-pointer"
              >
                Gedor Gerbang & Masuk
              </button>

              <div className="bg-slate-50 dark:bg-slate-950 border border-slate-150 dark:border-slate-800 p-3.5 rounded-xl text-[10px] text-slate-450 dark:text-slate-400 leading-relaxed font-normal">
                <p className="font-bold text-slate-600 dark:text-slate-300 flex items-center gap-1">📌 Petunjuk Pengujian Penguji:</p>
                <ul className="list-disc pl-4 mt-1 space-y-0.5">
                  <li><strong>Akses Admin:</strong> username <code>admin</code> & password <code>admin</code></li>
                  <li><strong>Akses Kolektor:</strong> username <code>andri</code> / <code>123</code> (Ada di menu "Tukang Tagih")</li>
                  <li><strong>Akses Reseller:</strong> username <code>sri</code> / <code>123</code> (Ada di menu "Agen / Reseller")</li>
                  <li><strong>Akses Teknisi:</strong> username <code>budi</code> atau <code>andi</code> & password <code>123</code> (Bisa filter multi-mikromik & cetak hotspot langsung di router!)</li>
                </ul>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ADMIN CONSOLE VIEW PORT */}
      {isLoggedIn && currentUserRole === 'admin' && (
        <>
          {/* Header Admin Shell */}
          <header className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-40 shrink-0">
            <div className="px-5 py-3.5 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-indigo-600 text-white rounded-lg shadow-lg shadow-indigo-500/20 font-black tracking-widest text-xs flex items-center gap-1.5 border border-indigo-400/40">
                  <Landmark size={15} /> RT-RW NET
                </div>
                <div>
                  <h1 className="text-sm font-extrabold tracking-tight font-sans text-slate-100 flex items-center gap-1">
                    {settings.billingNamaPenyedia}
                  </h1>
                  <p className="text-[10px] text-slate-400 mt-0.5 font-medium flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span> Manajemen & Penagihan WhatsApp
                  </p>
                </div>
              </div>

              <div className="hidden lg:flex items-center gap-3 text-xs">
                {/* Dark Mode Toggle Desktop */}
                <button
                  type="button"
                  onClick={() => setDarkMode(!darkMode)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 rounded-lg transition hover:text-white cursor-pointer"
                  title="Ganti Tema (Gelap/Terang)"
                >
                  {darkMode ? (
                    <>
                      <Sun size={13} className="text-amber-400 animate-pulse" />
                      <span className="font-semibold text-slate-300">Mode Terang</span>
                    </>
                  ) : (
                    <>
                      <Moon size={13} className="text-indigo-300" />
                      <span className="font-semibold text-slate-300">Mode Gelap</span>
                    </>
                  )}
                </button>

                {/* Account role toggle */}
                <button
                  onClick={handleLogout}
                  className="px-3 py-1.5 bg-rose-650/40 text-rose-300 hover:bg-rose-600 hover:text-white rounded-lg transition text-[11px] font-bold cursor-pointer"
                >
                  Keluar Admin
                </button>

                {/* Quick backup actions */}
                <button
                  onClick={handleExportDataJson}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 rounded-lg hover:text-white transition cursor-pointer"
                  title="Unduh cadangan data sistem"
                >
                  <Download size={13} /> Ekspor JSON
                </button>
                <label
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 rounded-lg hover:text-white cursor-pointer transition"
                  title="Unggah file JSON untuk memulihkan data"
                >
                  <Upload size={13} /> Impor Cadangan
                  <input type="file" accept=".json" onChange={handleImportDataJson} className="hidden" />
                </label>
                <button
                  onClick={handleWipeDatabaseReset}
                  className="p-1.5 hover:bg-slate-800 text-slate-400 hover:text-rose-500 rounded-lg transition cursor-pointer"
                  title="Reset Database Default"
                >
                  <RefreshCcw size={14} />
                </button>
              </div>

              {/* Mobile controls */}
              <div className="flex items-center gap-2 lg:hidden">
                {/* Dark Mode Toggle Mobile */}
                <button
                  type="button"
                  onClick={() => setDarkMode(!darkMode)}
                  className="p-1.5 bg-slate-800 hover:bg-slate-750 border border-slate-700 rounded-lg transition text-slate-300"
                  title="Ganti Tema (Gelap/Terang)"
                >
                  {darkMode ? <Sun size={18} className="text-amber-400" /> : <Moon size={18} className="text-slate-300" />}
                </button>

                {/* Collapsible Mobile Menu Switcher */}
                <button 
                  onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                  className="p-1.5 bg-slate-800 border border-slate-700 rounded-lg transition"
                >
                  {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
                </button>
              </div>
            </div>
          </header>

          {/* Side navigation & content viewport */}
          <div className="flex-1 flex flex-col lg:flex-row overflow-hidden">
            
            {/* Sidebar Panel Layout */}
            <aside className={`lg:w-64 bg-slate-900 text-slate-300 border-r border-slate-800 flex flex-col justify-between shrink-0 transition-transform ${
              mobileMenuOpen ? 'block' : 'hidden lg:flex'
            }`}>
              <div className="p-4 space-y-6 flex-1 overflow-y-auto">
                {/* Operator profile card summary */}
                <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800/80 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center text-slate-300 font-extrabold border border-indigo-500/20">
                      <User size={18} />
                    </div>
                    <div className="min-w-0">
                      <p className="text-[9px] uppercase font-black text-slate-400 tracking-wider">Operator</p>
                      <p className="text-xs font-bold text-slate-100 truncate mt-0.5">{settings.pjNama}</p>
                      <p className="text-[9px] text-slate-500 italic mt-0.5">Administrator</p>
                    </div>
                  </div>
                  <button 
                    onClick={handleLogout}
                    className="p-1 hover:bg-slate-800 rounded bg-indigo-950 text-indigo-400"
                    title="Ganti akun / Keluar"
                  >
                    <LogOut size={13} />
                  </button>
                </div>

                {/* Navigation Menus block */}
                <div className="space-y-1">
                  <p className="text-[10px] uppercase font-black text-slate-500 tracking-widest pl-3 mb-2.5">Menu Utama</p>
                  
                  <button
                    onClick={() => { setActiveTab('dashboard'); setMobileMenuOpen(false); }}
                    className={`w-full text-left p-3 rounded-xl font-medium text-xs flex items-center gap-3 transition cursor-pointer ${
                      activeTab === 'dashboard' ? 'bg-indigo-650/10 text-indigo-400 font-bold border-l-2 border-indigo-500' : 'hover:bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <LayoutDashboard size={16} /> Beranda (Statistik)
                  </button>

                  <button
                    onClick={() => { setActiveTab('mikrotik'); setMobileMenuOpen(false); }}
                    className={`w-full text-left p-3 rounded-xl font-medium text-xs flex items-center gap-3 transition cursor-pointer ${
                      activeTab === 'mikrotik' ? 'bg-indigo-650/10 text-indigo-400 font-bold border-l-2 border-indigo-500' : 'hover:bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <Server size={16} /> Router Mikrotik
                  </button>

                  <button
                    onClick={() => { setActiveTab('hotspot'); setMobileMenuOpen(false); }}
                    className={`w-full text-left p-3 rounded-xl font-medium text-xs flex items-center gap-3 transition cursor-pointer ${
                      activeTab === 'hotspot' ? 'bg-indigo-650/10 text-indigo-400 font-bold border-l-2 border-indigo-500' : 'hover:bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <Wifi size={16} /> Hotspot Voucher
                  </button>

                  <button
                    onClick={() => { setActiveTab('pppoe'); setMobileMenuOpen(false); }}
                    className={`w-full text-left p-3 rounded-xl font-medium text-xs flex items-center gap-3 transition cursor-pointer ${
                      activeTab === 'pppoe' ? 'bg-indigo-650/10 text-indigo-400 font-bold border-l-2 border-indigo-500' : 'hover:bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <RefreshCcw size={16} /> PPPoE/Rumahan
                  </button>

                  <button
                    onClick={() => { setActiveTab('reseller'); setMobileMenuOpen(false); }}
                    className={`w-full text-left p-3 rounded-xl font-medium text-xs flex items-center gap-3 transition cursor-pointer ${
                      activeTab === 'reseller' ? 'bg-indigo-650/10 text-indigo-400 font-bold border-l-2 border-indigo-500' : 'hover:bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <Store size={16} /> Agen / Reseller
                  </button>

                  <button
                    onClick={() => { setActiveTab('pesanan_agen'); setMobileMenuOpen(false); }}
                    className={`w-full text-left p-3 rounded-xl font-medium text-xs flex items-center gap-3 transition cursor-pointer ${
                      activeTab === 'pesanan_agen' ? 'bg-indigo-650/10 text-indigo-400 font-bold border-l-2 border-indigo-500' : 'hover:bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <ClipboardList size={16} /> Pesanan Agen Hotspot
                  </button>

                  <button
                    onClick={() => { setActiveTab('tukang_tagih'); setMobileMenuOpen(false); }}
                    className={`w-full text-left p-3 rounded-xl font-medium text-xs flex items-center gap-3 transition cursor-pointer ${
                      activeTab === 'tukang_tagih' ? 'bg-indigo-650/10 text-indigo-400 font-bold border-l-2 border-indigo-500' : 'hover:bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <UserCheck size={16} /> Tukang Tagih
                  </button>

                  <button
                    onClick={() => { setActiveTab('teknisi'); setMobileMenuOpen(false); }}
                    className={`w-full text-left p-3 rounded-xl font-medium text-xs flex items-center gap-3 transition cursor-pointer ${
                      activeTab === 'teknisi' ? 'bg-indigo-650/10 text-indigo-400 font-bold border-l-2 border-indigo-500' : 'hover:bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <UserCheck size={16} /> Akses Teknisi
                  </button>

                  <button
                    onClick={() => { setActiveTab('tagihan'); setMobileMenuOpen(false); }}
                    className={`w-full text-left p-3 rounded-xl font-medium text-xs flex items-center gap-3 transition cursor-pointer ${
                      activeTab === 'tagihan' ? 'bg-indigo-650/10 text-indigo-400 font-bold border-l-2 border-indigo-500' : 'hover:bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <CreditCard size={16} /> Tagihan Bulanan
                  </button>

                  <p className="text-[10px] uppercase font-black text-slate-500 tracking-widest pl-3 pt-4 mb-2">Integrasi Gateway</p>

                  <button
                    onClick={() => { setActiveTab('notifikasi'); setMobileMenuOpen(false); }}
                    className={`w-full text-left p-3 rounded-xl font-medium text-xs flex items-center gap-3 transition cursor-pointer ${
                      activeTab === 'notifikasi' ? 'bg-indigo-650/10 text-indigo-400 font-bold border-l-2 border-indigo-500' : 'hover:bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <MessageSquareShare size={16} /> WA Gateway API
                  </button>

                  <button
                    onClick={() => { setActiveTab('payment_gateway'); setMobileMenuOpen(false); }}
                    className={`w-full text-left p-3 rounded-xl font-medium text-xs flex items-center gap-3 transition cursor-pointer ${
                      activeTab === 'payment_gateway' ? 'bg-indigo-650/10 text-indigo-400 font-bold border-l-2 border-indigo-500' : 'hover:bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <CreditCard size={16} /> Payment Gateway
                  </button>

                  <button
                    onClick={() => { setActiveTab('voucher_look'); setMobileMenuOpen(false); }}
                    className={`w-full text-left p-3 rounded-xl font-medium text-xs flex items-center gap-3 transition cursor-pointer ${
                      activeTab === 'voucher_look' ? 'bg-indigo-650/10 text-indigo-400 font-bold border-l-2 border-indigo-500' : 'hover:bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <Settings id="sett-look" size={16} /> Portal Voucher Look
                  </button>

                  <button
                    onClick={() => { setActiveTab('pengaturan_umum'); setMobileMenuOpen(false); }}
                    className={`w-full text-left p-3 rounded-xl font-medium text-xs flex items-center gap-3 transition cursor-pointer ${
                      activeTab === 'pengaturan_umum' ? 'bg-indigo-650/10 text-indigo-400 font-bold border-l-2 border-indigo-500' : 'hover:bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <Settings size={16} /> Pengaturan Umum
                  </button>

                  <button
                    onClick={() => { setActiveTab('portal_activity_logs'); setMobileMenuOpen(false); }}
                    className={`w-full text-left p-3 rounded-xl font-medium text-xs flex items-center gap-3 transition cursor-pointer ${
                      activeTab === 'portal_activity_logs' ? 'bg-indigo-650/10 text-indigo-400 font-bold border-l-2 border-indigo-500' : 'hover:bg-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    <ClipboardList size={16} /> Audit Log Portal ({portalLogs.length})
                  </button>
                </div>
              </div>

              {/* Integrated Sleek Status Card */}
              <div className="m-4 p-4 bg-indigo-600 rounded-2xl text-white shadow-md">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] opacity-90 uppercase tracking-widest font-bold">Status Kirim WA</span>
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                </div>
                <p className="text-[11px] leading-snug opacity-95">Sistem siap memantau & mengirim pengingat tagihan bulanan pelanggan.</p>
              </div>

              {/* Sidebar bottom indicator */}
              <div className="p-4 border-t border-slate-800 bg-slate-950/40 text-[10px] text-slate-500 leading-relaxed shrink-0">
                <div className="flex items-center gap-1 font-semibold text-slate-400">
                  <ShieldCheck size={12} className="text-indigo-500" /> Ruang Uji Aman V.1
                </div>
                <p className="mt-1 font-normal text-[9px]">Dibuat khusus untuk pengurusan iuran internet RT RW Net mandiri lapor cepat.</p>
              </div>
            </aside>

            {/* Main Dashboard Viewport */}
            <main className="flex-1 overflow-y-auto p-4 md:p-6 pb-12 space-y-6">
              
              {activeTab === 'dashboard' && (
                <DashboardStats
                  pelanggan={pelanggan}
                  tagihan={tagihan}
                  paket={paket}
                  targetBulan={selectedBulan}
                  onSelectTab={setActiveTab}
                  onSendSingleWa={handleSendSingleWa}
                  currentDateStr={SYSTEM_DATE}
                  settings={settings}
                />
              )}

              {activeTab === 'mikrotik' && (
                <MikrotikTab
                  servers={servers}
                  onAddServer={handleAddServer}
                  onUpdateServer={handleUpdateServer}
                  onDeleteServer={handleDeleteServer}
                  vouchers={vouchers}
                  pppoeUsers={pppoeUsers}
                  resellers={resellers}
                  paket={paket}
                />
              )}

              {activeTab === 'hotspot' && (
                <HotspotTab
                  vouchers={vouchers}
                  paket={paket}
                  servers={servers}
                  resellers={resellers}
                  onAddVoucher={handleAddVoucher}
                  onUpdateVoucher={handleUpdateVoucher}
                  onDeleteVoucher={handleDeleteVoucher}
                  onBulkGenerate={handleBulkGenerateVouchers}
                />
              )}

              {activeTab === 'pesanan_agen' && (
                <PesananAgenTab
                  pesanan={pesananAgen}
                  resellers={resellers}
                  paket={paket}
                  onAddPesanan={handleAddPesananAgen}
                  onUpdatePesanan={handleUpdatePesananAgen}
                  onDeletePesanan={handleDeletePesananAgen}
                />
              )}

              {activeTab === 'pppoe' && (
                <PppoeTab
                  pppoeUsers={pppoeUsers}
                  servers={servers}
                  onAddPppoe={handleAddPppoe}
                  onUpdatePppoe={handleUpdatePppoe}
                  onDeletePppoe={handleDeletePppoe}
                />
              )}

              {activeTab === 'reseller' && (
                <AgentTab
                  resellers={resellers}
                  paket={paket}
                  servers={servers}
                  onAddReseller={handleAddReseller}
                  onUpdateReseller={handleUpdateReseller}
                  onDeleteReseller={handleDeleteReseller}
                  onUpdatePaket={handleUpdatePaket}
                />
              )}

              {activeTab === 'tukang_tagih' && (
                <TukangTagihTab
                  collectors={collectors}
                  pelanggan={pelanggan}
                  paket={paket}
                  onAddCollector={handleAddCollector}
                  onUpdateCollector={handleUpdateCollector}
                  onDeleteCollector={handleDeleteCollector}
                />
              )}

              {activeTab === 'teknisi' && (
                <TeknisiTab
                  teknisiList={teknisiList}
                  servers={servers}
                  paket={paket}
                  onAddTeknisi={handleAddTeknisi}
                  onUpdateTeknisi={handleUpdateTeknisi}
                  onDeleteTeknisi={handleDeleteTeknisi}
                  onLoginAsTeknisi={(t) => { 
                    setCurrentUserRole('teknisi'); 
                    setActiveTeknisi(t); 
                    setIsLoggedIn(true); 
                  }}
                />
              )}

               {activeTab === 'tagihan' && (
                <TagihanTab
                  tagihan={tagihan}
                  pelanggan={pelanggan}
                  paket={paket}
                  settings={settings}
                  selectedBulan={selectedBulan}
                  setSelectedBulan={setSelectedBulan}
                  onGenerateTagihan={handleGenerateTagihan}
                  onRegisterPayment={handleRegisterPayment}
                  onSendSingleWa={handleSendSingleWa}
                  onSendSingleWaWeb={handleSendSingleWaWeb}
                  currentDateStr={SYSTEM_DATE}
                  onKirimSemuaWa={handleTriggerBulkBroadcast}
                  collectors={collectors}
                  onAddPelanggan={handleAddPelanggan}
                  onUpdatePelanggan={handleUpdatePelanggan}
                  onDeletePelanggan={handleDeletePelanggan}
                  onAddManualTagihan={handleAddManualTagihan}
                  onDeleteTagihan={handleDeleteTagihan}
                />
              )}

              {activeTab === 'notifikasi' && (
                <NotifikasiTab
                  logs={logs}
                  settings={settings}
                  paket={paket}
                  pelanggan={pelanggan}
                  tagihan={tagihan}
                  onSaveSettings={setSettings}
                  isBroadcasting={isBroadcasting}
                  setIsBroadcasting={setIsBroadcasting}
                  broadcastQueue={broadcastQueue}
                  onFinishBroadcast={handleFinishBroadcast}
                />
              )}

              {activeTab === 'payment_gateway' && (
                <PaymentGatewayTab
                  appSettings={settings}
                  onSavePaymentSettings={handleUpdatePaymentGatewayConfig}
                />
              )}

              {activeTab === 'voucher_look' && settings && (
                <VoucherPortalTemplate
                  voucherPageSettings={settings.voucherPage || DEFAULT_SETTINGS.voucherPage}
                  servers={servers}
                  onSaveSettings={handleUpdateVoucherPageSettings}
                  onAddVoucher={handleAddVoucher}
                />
              )}

              {activeTab === 'pengaturan_umum' && (
                <PengaturanTab
                  appSettings={settings}
                  onSaveSettings={setSettings}
                  onExportDatabase={handleExportDataJson}
                  onImportDatabase={handleImportDataJson}
                  onResetDatabase={handleWipeDatabaseReset}
                  mysqlStatus={mysqlStatus}
                  isSyncing={isSyncing}
                  onSyncNow={() => triggerCloudSync()}
                />
              )}

              {activeTab === 'portal_activity_logs' && (() => {
                const filtered = portalLogs
                  .filter(log => adminLogPortalFilter === 'ALL' || log.portalType === adminLogPortalFilter)
                  .filter(log => adminLogActionFilter === 'ALL' || log.aktifitasType === adminLogActionFilter)
                  .filter(log => {
                    const logDate = log.timestamp.substring(0, 10);
                    if (adminLogStartDate && logDate < adminLogStartDate) return false;
                    if (adminLogEndDate && logDate > adminLogEndDate) return false;
                    return true;
                  })
                  .filter(log => {
                    if (adminLogSearch === '') return true;
                    const keywords = adminLogSearch.toLowerCase();
                    return (
                      log.detail.toLowerCase().includes(keywords) ||
                      log.fiturLabel.toLowerCase().includes(keywords) ||
                      log.portalType.toLowerCase().includes(keywords) ||
                      (log.operatorId && log.operatorId.toLowerCase().includes(keywords))
                    );
                  })
                  .filter(log => {
                    if (!adminLogShowOverdueOnly) return true;
                    const text = `${log.detail} ${log.fiturLabel} ${log.aktifitasType}`.toLowerCase();
                    return (
                      text.includes('terlambat') ||
                      text.includes('overdue') ||
                      text.includes('tempo') ||
                      text.includes('tunggakan') ||
                      text.includes('menunggak') ||
                      text.includes('telat') ||
                      text.includes('denda') ||
                      text.includes('pastdue') ||
                      text.includes('lewat')
                    );
                  });

                // Calculate summary card stats
                const totalLogins = filtered.filter(l => l.aktifitasType === 'LOGIN').length;
                const totalTransactions = filtered.filter(l => l.aktifitasType === 'TRANSAKSI_BAYAR').length;
                const totalUangMasuk = filtered
                  .filter(l => l.aktifitasType === 'TRANSAKSI_BAYAR')
                  .reduce((sum, l) => sum + (l.amount || 0), 0);
                const totalUangKeluarOrTopup = filtered
                  .filter(l => l.aktifitasType === 'TOPUP')
                  .reduce((sum, l) => sum + (l.amount || 0), 0);

                return (
                  <div id="portal-activity-logs-tab" className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6">
                    {/* Title Header with Counter */}
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                      <div>
                        <h2 className="text-xl font-black text-white flex items-center gap-2">
                          <ClipboardList className="text-indigo-400" size={22} />
                          Audit Log & Aktivitas Multi-Portal
                        </h2>
                        <p className="text-[11px] text-slate-400 mt-1">
                          Memantau log login, pencetakan voucher hotspot, simulasi top-up, serta catatan setoran lunas lapangan secara real-time.
                        </p>
                      </div>

                      <button
                        onClick={() => {
                          if (confirm('Yakin ingin mengosongkan semua riwayat audit log portal? Tindakan ini permanen.')) {
                            setPortalLogs([]);
                            addPortalLog({
                              portalType: 'ADMIN',
                              operatorNama: 'Master Admin',
                              status: 'SUKSES',
                              operatorId: 'system',
                              aktifitasType: 'LOGIN',
                              fiturLabel: 'SISTEM LOGS',
                              detail: 'Administrator utama mengosongkan semua baris log aktivitas multi-portal.'
                            });
                          }
                        }}
                        className="px-4 py-2 bg-rose-950/40 hover:bg-rose-900 border border-rose-900 text-rose-400 hover:text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
                      >
                        Bersihkan Log ({portalLogs.length})
                      </button>
                    </div>

                    {/* Operational filters & Search Box */}
                    <div className="bg-slate-950 p-4 border border-slate-800/80 rounded-2xl space-y-4">
                      <div className="flex flex-col lg:flex-row gap-4 items-stretch lg:items-center justify-between">
                        {/* Search Field */}
                        <div className="relative flex-1">
                          <input
                            type="text"
                            placeholder="Cari berdasarkan nama agen, warga, nomor voucher, detail, atau ID petugas..."
                            className="w-full bg-slate-900/90 text-xs border border-slate-800 focus:border-indigo-500 focus:outline-hidden pl-9 pr-4 py-2.5 rounded-xl text-slate-200 placeholder-slate-555"
                            value={adminLogSearch}
                            onChange={(e) => setAdminLogSearch(e.target.value)}
                          />
                          <Search size={14} className="absolute left-3.5 top-3.5 text-slate-500" />
                        </div>

                        {/* Filter Selects */}
                        <div className="flex flex-wrap sm:flex-nowrap items-center gap-3">
                          <div className="flex items-center gap-1.5 w-full sm:w-auto">
                            <span className="text-[10px] text-slate-500 uppercase font-bold whitespace-nowrap">Portal:</span>
                            <select
                              className="bg-slate-900 border border-slate-800 text-slate-200 text-xs py-2 px-3 rounded-xl focus:outline-hidden focus:border-indigo-500 w-full"
                              value={adminLogPortalFilter}
                              onChange={(e: any) => setAdminLogPortalFilter(e.target.value)}
                            >
                              <option value="ALL">Semua Portal</option>
                              <option value="ADMIN">Master Admin</option>
                              <option value="AGEN/RESELLER">Agen / Reseller</option>
                              <option value="TUKANG_TAGIH">Tukang Tagih</option>
                              <option value="TEKNISI">Akses Teknisi</option>
                            </select>
                          </div>

                          <div className="flex items-center gap-1.5 w-full sm:w-auto">
                            <span className="text-[10px] text-slate-500 uppercase font-bold whitespace-nowrap">Kegiatan:</span>
                            <select
                              className="bg-slate-900 border border-slate-800 text-slate-200 text-xs py-2 px-3 rounded-xl focus:outline-hidden focus:border-indigo-500 w-full"
                              value={adminLogActionFilter}
                              onChange={(e: any) => setAdminLogActionFilter(e.target.value)}
                            >
                              <option value="ALL">Semua Kegiatan</option>
                              <option value="LOGIN">Masuk Portal (Login)</option>
                              <option value="CETAK_VOUCHER">Buat / Cetak Voucher</option>
                              <option value="TRANSAKSI_BAYAR">Pembayaran Lunas</option>
                              <option value="TOPUP">Simulasi Top-Up Saldo</option>
                            </select>
                          </div>

                          <label className={`flex items-center gap-2 cursor-pointer py-2 px-3.5 rounded-xl border select-none transition-all duration-200 text-xs w-full sm:w-auto font-bold ${
                            adminLogShowOverdueOnly 
                              ? 'bg-rose-950/40 border-rose-900 text-rose-400 font-extrabold shadow-sm'
                              : 'bg-slate-900 border-slate-800 hover:border-slate-700 text-slate-400 hover:text-slate-300'
                          }`}>
                            <input
                              type="checkbox"
                              checked={adminLogShowOverdueOnly}
                              onChange={(e) => setAdminLogShowOverdueOnly(e.target.checked)}
                              className="w-3.5 h-3.5 accent-rose-600 rounded bg-slate-800 border-slate-700 cursor-pointer"
                            />
                            <span className="whitespace-nowrap">Tampilkan Overdue Saja</span>
                          </label>
                        </div>
                      </div>

                      {/* Date Period Filter Controls */}
                      <div className="border-t border-slate-950 pt-3 flex flex-wrap items-center justify-between gap-4">
                        <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] text-slate-500 uppercase font-bold whitespace-nowrap">Mulai Tanggal:</span>
                            <input
                              type="date"
                              className="bg-slate-900 border border-slate-800 text-slate-200 text-xs py-1.5 px-3 rounded-lg focus:outline-hidden focus:border-indigo-500 text-white"
                              value={adminLogStartDate}
                              onChange={(e) => setAdminLogStartDate(e.target.value)}
                            />
                          </div>

                          <div className="flex items-center gap-2">
                            <span className="text-[10px] text-slate-500 uppercase font-bold whitespace-nowrap">Sampai Tanggal:</span>
                            <input
                              type="date"
                              className="bg-slate-900 border border-slate-800 text-slate-200 text-xs py-1.5 px-3 rounded-lg focus:outline-hidden focus:border-indigo-500 text-white"
                              value={adminLogEndDate}
                              onChange={(e) => setAdminLogEndDate(e.target.value)}
                            />
                          </div>

                          {(adminLogStartDate || adminLogEndDate) && (
                            <button
                              onClick={() => {
                                setAdminLogStartDate('');
                                setAdminLogEndDate('');
                              }}
                              className="px-2.5 py-1 text-[10px] font-bold bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg transition"
                            >
                              Atur Ulang Periode
                            </button>
                          )}
                        </div>

                        {/* Quick Date Presets */}
                        <div className="flex items-center gap-2 text-[10px] text-slate-400">
                          <span className="text-slate-500 font-bold uppercase">Preset Cepat:</span>
                          <button
                            onClick={() => {
                              const todayStr = new Date().toISOString().substring(0, 10);
                              setAdminLogStartDate(todayStr);
                              setAdminLogEndDate(todayStr);
                            }}
                            className="px-2 py-1 bg-indigo-950/40 text-indigo-400 hover:bg-indigo-900/60 border border-indigo-900 rounded-md transition"
                          >
                            Hari Ini
                          </button>
                          <button
                            onClick={() => {
                              const end = new Date();
                              const start = new Date();
                              start.setDate(end.getDate() - 7);
                              setAdminLogStartDate(start.toISOString().substring(0, 10));
                              setAdminLogEndDate(end.toISOString().substring(0, 10));
                            }}
                            className="px-2 py-1 bg-indigo-950/40 text-indigo-400 hover:bg-indigo-900/60 border border-indigo-900 rounded-md transition"
                          >
                            7 Hari Terakhir
                          </button>
                          <button
                            onClick={() => {
                              const end = new Date();
                              const start = new Date();
                              start.setDate(end.getDate() - 30);
                              setAdminLogStartDate(start.toISOString().substring(0, 10));
                              setAdminLogEndDate(end.toISOString().substring(0, 10));
                            }}
                            className="px-2 py-1 bg-indigo-950/40 text-indigo-400 hover:bg-indigo-900/60 border border-indigo-900 rounded-md transition"
                          >
                            30 Hari Terakhir
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* STATS SUMMARY CARDS */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {/* CARD 1: TOTAL TRANSAKSI */}
                      <div className="bg-slate-950/55 p-4 rounded-2xl border border-slate-800/80 flex items-center justify-between">
                        <div className="space-y-1">
                          <span className="text-[10px] text-slate-500 uppercase font-bold tracking-wider block">Total Transaksi Lunas</span>
                          <span className="text-xl font-black text-emerald-400 block">{totalTransactions} <span className="text-xs font-normal text-slate-400">Setoran</span></span>
                          <span className="text-[10px] text-slate-400 block">Pembayaran tagihan warga terverifikasi</span>
                        </div>
                        <div className="p-3 bg-emerald-950/30 border border-emerald-900/55 rounded-xl">
                          <CreditCard className="text-emerald-400 animate-pulse" size={20} />
                        </div>
                      </div>

                      {/* CARD 2: TOTAL LOGIN */}
                      <div className="bg-slate-950/55 p-4 rounded-2xl border border-slate-800/80 flex items-center justify-between">
                        <div className="space-y-1">
                          <span className="text-[10px] text-slate-500 uppercase font-bold tracking-wider block">Aktivitas Login</span>
                          <span className="text-xl font-black text-indigo-400 block">{totalLogins} <span className="text-xs font-normal text-slate-400">Sesi</span></span>
                          <span className="text-[10px] text-slate-400 block">Sesi login petugas & agen</span>
                        </div>
                        <div className="p-3 bg-indigo-950/30 border border-indigo-900/55 rounded-xl">
                          <LogIn className="text-indigo-400" size={20} />
                        </div>
                      </div>

                      {/* CARD 3: TOTAL KEUANGAN (MASUK / KELUAR) */}
                      <div className="bg-slate-950/55 p-4 rounded-2xl border border-slate-800/80 flex items-center justify-between">
                        <div className="space-y-1 w-full">
                          <span className="text-[10px] text-slate-500 uppercase font-bold tracking-wider block">Arus Kas Portal</span>
                          <div className="flex items-baseline gap-2.5 mt-0.5">
                            <span className="text-sm font-semibold text-emerald-400" title="Uang Masuk tagihan lunas">
                              Masuk: <span className="font-extrabold">{formatRupiah(totalUangMasuk)}</span>
                            </span>
                          </div>
                          <div className="flex items-baseline gap-2.5">
                            <span className="text-[11px] text-amber-400 font-semibold" title="Top-up saldo agen / reseller">
                              Top-Up: <span className="font-extrabold">{formatRupiah(totalUangKeluarOrTopup)}</span>
                            </span>
                          </div>
                          <span className="text-[10px] text-slate-400 block pt-0.5 border-t border-slate-900/40">Akumulasi sesuai rentang filter</span>
                        </div>
                        <div className="p-3 bg-indigo-950/30 border border-indigo-900/55 rounded-xl self-start flex-none">
                          <Wallet className="text-indigo-400" size={20} />
                        </div>
                      </div>
                    </div>

                    {/* Real-time Logger Terminal Display */}
                    <div className="border border-slate-800 rounded-3xl overflow-hidden font-sans">
                      <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse text-xs">
                          <thead className="bg-slate-950 text-slate-400 font-bold uppercase text-[9px] tracking-wider border-b border-slate-800">
                            <tr>
                              <th className="p-4">Tanggal & Waktu</th>
                              <th className="p-4">Portal Sumber</th>
                              <th className="p-4 text-center">Kegiatan</th>
                              <th className="p-4">Fitur Modul</th>
                              <th className="p-4">Deskripsi Audit Log</th>
                              <th className="p-4 text-right">Keterlibatan Uang</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-850 bg-slate-900/50 text-slate-300 font-semibold font-sans">
                            {filtered.length === 0 ? (
                              <tr>
                                <td colSpan={6} className="p-12 text-center text-slate-500 italic">
                                  Tidak ada log aktivitas yang ditemukan untuk kriteria filter terpilih.
                                </td>
                              </tr>
                            ) : (
                              filtered.map((log) => (
                                <tr key={log.id} className="hover:bg-slate-950/40 transition">
                                  <td className="p-4 font-mono text-slate-500 text-[10px] whitespace-nowrap">
                                    {log.timestamp.substring(0, 10)} {log.timestamp.substring(11, 19)}
                                  </td>
                                  <td className="p-4">
                                    <div className="flex items-center gap-1.5 whitespace-nowrap">
                                      <span className={`px-2 py-0.5 rounded text-[9px] uppercase tracking-wider font-extrabold ${
                                        log.portalType === 'ADMIN' ? 'bg-indigo-950 text-indigo-400 border border-indigo-900' :
                                        log.portalType === 'AGEN/RESELLER' ? 'bg-amber-950 text-amber-400 border border-amber-900' :
                                        log.portalType === 'TUKANG_TAGIH' ? 'bg-emerald-950 text-emerald-400 border border-emerald-900' :
                                        'bg-purple-950 text-purple-400 border border-purple-900'
                                      }`}>
                                        {log.portalType}
                                      </span>
                                      {log.operatorId && (
                                        <span className="text-[10px] text-slate-400 font-mono">
                                          ({log.operatorId})
                                        </span>
                                      )}
                                    </div>
                                  </td>
                                  <td className="p-4 text-center">
                                    <span className={`inline-block px-2 py-0.5 rounded text-[9px] uppercase tracking-widest font-black border ${
                                      log.aktifitasType === 'LOGIN' ? 'bg-blue-950 border-blue-900 text-blue-400' :
                                      log.aktifitasType === 'CETAK_VOUCHER' ? 'bg-purple-950 border-purple-900 text-purple-400' :
                                      log.aktifitasType === 'TRANSAKSI_BAYAR' ? 'bg-emerald-950 border-emerald-900 text-emerald-400' :
                                      log.aktifitasType === 'TOPUP' ? 'bg-rose-950 border-rose-900 text-rose-400' :
                                      'bg-slate-950 border-slate-800 text-slate-400'
                                    }`}>
                                      {log.aktifitasType.replace('_', ' ')}
                                    </span>
                                  </td>
                                  <td className="p-4 text-slate-200 text-[11px] whitespace-nowrap">
                                    ⚙️ {log.fiturLabel}
                                  </td>
                                  <td className="p-4 text-slate-350 text-[11px] max-w-sm font-sans whitespace-normal leading-relaxed">
                                    {log.detail}
                                  </td>
                                  <td className="p-4 text-right font-mono text-[11px]">
                                    {log.amount ? (
                                      <span className={log.aktifitasType === 'TOPUP' || log.aktifitasType === 'TRANSAKSI_BAYAR' ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                                        {log.aktifitasType === 'TOPUP' || log.aktifitasType === 'TRANSAKSI_BAYAR' ? '+' : '-'}{formatRupiah(log.amount)}
                                      </span>
                                    ) : (
                                      <span className="text-slate-600">-</span>
                                    )}
                                  </td>
                                </tr>
                              ))
                            )}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                );
              })()}

            </main>

          </div>
        </>
      )}

    </div>
  );
}
