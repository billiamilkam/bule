export interface Pelanggan {
  id: string;
  nama: string;
  noHp: string;
  alamat: string;
  paketId: string;
  tarif: number;
  statusAktif: boolean;
  tanggalDaftar: string;
  jatuhTempo: string; // Full date format (e.g. 'YYYY-MM-DD')
  kategoriLangganan: 'Hotspot' | 'Rumahan' | 'PPPoE';
  tukangTagihId: string; // Collector ID or 'none' (admin)
}

export interface Paket {
  id: string;
  nama: string;
  kecepatan: string;
  harga: number;
  deskripsi: string;
  mikrotikProfile?: string;
}

export type TagihanStatus = 'BELUM_BAYAR' | 'LUNAS' | 'TERLAMBAT';

export interface Tagihan {
  id: string;
  pelangganId: string;
  pelangganNama: string;
  pelangganNoHp: string;
  bulan: string; // Format: 'YYYY-MM' (e.g. '2026-06')
  jumlah: number;
  tanggalJatuhTempo: string; // Format: 'YYYY-MM-DD'
  status: TagihanStatus;
  tanggalBayar?: string; // Format: 'YYYY-MM-DD' if LUNAS
  metodeBayar?: string; // Transfer Bank, Cash, E-Wallet, etc.
  waSent: boolean;
  waSentAt?: string;
  catatan?: string;
  pelangganAlamat?: string;
  pelangganKategori?: string;
}

export interface WhatsAppLog {
  id: string;
  tagihanId: string;
  pelangganNama: string;
  noHp: string;
  pesan: string;
  status: 'SUKSES' | 'PROSES' | 'GAGAL';
  sentAt: string;
}

export interface MikrotikServer {
  id: string;
  nama: string;
  ipAddress: string;
  username: string;
  password?: string;
  port: number;
  status: 'TERHUBUNG' | 'TERPUTUS';
  uptime?: string;
  cpuLoad?: number;
  useVirtualSync?: boolean;
}

export interface TukangTagih {
  id: string;
  nama: string;
  alamat: string;
  noHp: string;
  username: string;
  password?: string;
  statusAktif: boolean;
  allowedMenus?: string[]; // Allowed menus: 'beranda', 'tagihan', 'pelanggan', 'tambah_pelanggan'
  allowedPaketIds?: string[]; // Allowed Mikrotik user profiles / speed packages
}

export interface Reseller {
  id: string;
  nama: string;
  wilayah: string;
  noHp: string;
  saldo: number;
  komisiPercent: number;
  statusAktif: boolean;
  username?: string;
  password?: string;
  allowedMenus?: string[]; // Allowed menus: 'create_manual', 'create_bulk', 'topup_simulation', 'vouchers_history'
  allowedPaketIds?: string[]; // Allowed Mikrotik user profiles / speed packages
  allowedServerIds?: string[]; // Allowed Mikrotik servers authorized for this reseller
  paketCustomPrices?: Record<string, { hargaModal: number; hargaJual: number }>; // Custom buying and selling prices per package profile
}

export interface HotspotVoucher {
  id: string;
  code: string;
  password?: string; // Optional password for user-password pair vouchers
  paketId: string;
  harga: number;
  durasi: string;
  serverName: string;
  status: 'AKTIF' | 'DIGUNAKAN' | 'EXPIRED';
  resellerId?: string; // Tracks which reseller generated this voucher
  agentPaymentStatus?: 'LUNAS' | 'BELUM BAYAR';
}

export interface PppoeUser {
  id: string;
  username: string;
  password?: string;
  profileName: string;
  localAddress?: string;
  remoteAddress?: string;
  status: 'ONLINE' | 'OFFLINE';
  serverName: string;
}

export interface VoucherOffer {
  id: string;
  name: string;
  price: number;
  duration: string;
  speedLimit: string;
  fup?: string;
  serverId: string; // target Mikrotik server where this voucher pack will be displayed / sold
  status: 'AKTIF' | 'NONAKTIF';
}

export interface VoucherPageSettings {
  title: string;
  greetingText: string;
  themeColor: string; // hex or tailwind class name
  showPrice: boolean;
  contactSupport: string;
  enableMikrotikApi: boolean;
  customLogoUrl?: string;
  selectedServerId?: string; // target default server
  voucherOffers?: VoucherOffer[];
  qrisDanaBisnisNama?: string;
  qrisDanaBisnisWAGateway?: string;
  qrisDanaBisnisImage?: string;
  qrisDanaBisnisEnabled?: boolean;
}

export interface AppSettings {
  billingNamaPenyedia: string; // e.g. "RT RW Net Mandiri"
  pjNama: string; // Penanggung Jawab
  dueDayDefault: number;
  bankNama: string; // e.g. "BCA"
  bankNomorRekening: string;
  bankAtasNama: string;
  waTemplateTagihanDefault: string;
  waTemplateLunasDefault: string;
  waGatewayToken: string; // Simulated token
  waStatusKoneksi: boolean; // Is WA gateway "connected" (simulated)
  
  // Payment Gateway Config
  paymentGatewayActive: boolean;
  merchantCode: string;
  apiKey: string;
  clientKey: string;
  provider: 'Midtrans' | 'Xendit' | 'Tripay';

  // Voucher Look
  voucherPage: VoucherPageSettings;

  // Custom Quick Home Menus
  showQuickMenus?: string[];

  // AI assistant integration
  geminiApiKey?: string;
}

export interface PesananAgen {
  id: string;
  resellerId: string;
  resellerNama: string;
  resellerWilayah: string;
  resellerNoHp: string;
  voucherId?: string;
  voucherCode: string; // "Nama data agen"
  paketId: string;
  paketNama: string;
  jumlahTagihan: number;
  status: string; // e.g. "BELUM BAYAR", "LUNAS", or custom text
  tanggalPesan: string; // YYYY-MM-DD
  bulan: string; // YYYY-MM
  catatan?: string;
}

export interface Teknisi {
  id: string;
  nama: string;
  noHp: string;
  username: string;
  password?: string;
  statusAktif: boolean;
  allowedServerIds?: string[]; // IDs of MikrotikServer the technician can filter/manage
  allowedPaketIds?: string[]; // Allowed Mikrotik user profiles / speed packages to create
  allowedMenus?: string[]; // Allowed menus for technician: 'create_manual', 'create_bulk'
}

export interface PortalActivityLog {
  id: string;
  portalType: 'ADMIN' | 'AGEN/RESELLER' | 'TUKANG_TAGIH' | 'TEKNISI';
  operatorNama: string; // e.g. "Rian Reseller", "Supri Tukang Tagih", etc.
  operatorId: string; // ID of Reseller, TukangTagih, or Teknisi
  aktifitasType: 'LOGIN' | 'CETAK_VOUCHER' | 'TOPUP' | 'UBAH_DATA' | 'HAPUS_VOUCHER' | 'TRANSAKSI_BAYAR';
  fiturLabel: string; // e.g. "Cetak Voucher Massal", "Login Portal Keamanan", "Auto Topup Saldo E-Wallet", etc.
  detail: string; // "Berhasil menghasilkan 10 voucher di server Mikrotik Pusat Kamal"
  timestamp: string; // ISO datetime
  status: 'SUKSES' | 'PERINGATAN' | 'INFO';
  amount?: number; // Optional amount if topup/payment
}


