import express from 'express';
import path from 'path';
import fs from 'fs';
import mysql from 'mysql2/promise';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';

// Load environment variables if available
import dotenv from 'dotenv';
dotenv.config();

const app = express();
app.use(express.json({ limit: '50mb' }));

const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;
const MySQLConfigPath = path.join(process.cwd(), 'mysql-config.json');
const JSONFallbackPath = path.join(process.cwd(), 'database_fallback.json');

// Memory storage for credentials if file is not writable
let activeMySQLConfig = {
  host: process.env.MYSQL_DB_HOST || '',
  port: parseInt(process.env.MYSQL_DB_PORT || '3306') || 3306,
  user: process.env.MYSQL_DB_USER || '',
  password: process.env.MYSQL_DB_PASSWORD || '',
  database: process.env.MYSQL_DB_DATABASE || '',
  active: process.env.MYSQL_DB_ACTIVE === 'true'
};

// Try loading persisted MySQL config
try {
  if (fs.existsSync(MySQLConfigPath)) {
    const raw = fs.readFileSync(MySQLConfigPath, 'utf8');
    activeMySQLConfig = { ...activeMySQLConfig, ...JSON.parse(raw) };
  }
} catch (err) {
  console.error('Error loading mysql-config.json:', err);
}

// Global connection pool
let pool: mysql.Pool | null = null;

// Initialize or update pool connection
function getMySQLPool() {
  if (!activeMySQLConfig.active || !activeMySQLConfig.host || !activeMySQLConfig.database) {
    return null;
  }
  
  if (!pool) {
    try {
      pool = mysql.createPool({
        host: activeMySQLConfig.host,
        port: activeMySQLConfig.port,
        user: activeMySQLConfig.user,
        password: activeMySQLConfig.password,
        database: activeMySQLConfig.database,
        waitForConnections: true,
        connectionLimit: 10,
        queueLimit: 0,
        connectTimeout: 5000 // 5 seconds timeout
      });
    } catch (err) {
      console.error('Failed to create MySQL Pool:', err);
      pool = null;
    }
  }
  return pool;
}

// API Routes
// 1. Get MySQL Config
app.get('/api/db/mysql-config', (req, res) => {
  res.json({
    ...activeMySQLConfig,
    // Hide password characters for UI protection
    password: activeMySQLConfig.password ? '•'.repeat(Math.min(activeMySQLConfig.password.length, 12)) : ''
  });
});

// 1a. Test Gemini API Key
app.post('/api/ai/test-key', async (req, res) => {
  const { apiKey } = req.body;
  if (!apiKey) {
    return res.status(400).json({ success: false, message: 'Google Gemini API Key tidak boleh kosong.' });
  }

  try {
    const ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: 'Respond with exactly one word: "Sukses!"',
    });

    const resultText = response.text?.trim() || 'Koneksi Berhasil!';
    res.json({
      success: true,
      message: `Integrasi Google Gemini API Aktif & Terverifikasi! Respons model: ${resultText}`
    });
  } catch (err: any) {
    console.error('Error testing Gemini API Key:', err);
    res.status(500).json({
      success: false,
      message: err?.message || 'Gagal berkomunikasi dengan server Gemini API. Mohon periksa kembali keaktifan dan validitas API Key yang dimasukkan.'
    });
  }
});

// 1b. Get raw JSON database file content for local shared hosting direct file edits
app.get('/api/db/raw-json', (req, res) => {
  try {
    if (fs.existsSync(JSONFallbackPath)) {
      const fileContent = fs.readFileSync(JSONFallbackPath, 'utf8');
      res.json({ success: true, jsonText: fileContent });
    } else {
      res.json({ success: true, jsonText: JSON.stringify({ pelanggan: [], paket: [], tagihan: [], logs: [] }, null, 2) });
    }
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'Gagal membaca database lokal: ' + err.message });
  }
});

// 1c. Save raw JSON database file content for local shared hosting direct file edits
app.post('/api/db/raw-json-save', (req, res) => {
  const { jsonText } = req.body;
  try {
    // Validate JSON before saving to prevent breaking the fallback file
    const parsed = JSON.parse(jsonText);
    fs.writeFileSync(JSONFallbackPath, JSON.stringify(parsed, null, 2), 'utf8');
    res.json({ success: true, message: 'Database lokal berhasil dimodifikasi di shared hosting server!' });
  } catch (err: any) {
    res.status(400).json({ success: false, message: 'Gagal menyimpan. Format JSON tidak valid atau korup: ' + err.message });
  }
});

// 2. Test MySQL Connection and Initialize Tables
app.post('/api/db/mysql-test', async (req, res) => {
  const { host, port, user, password, database, active } = req.body;
  
  const tempConfig = {
    host: host ?? activeMySQLConfig.host,
    port: parseInt(port ?? activeMySQLConfig.port) || 3306,
    user: user ?? activeMySQLConfig.user,
    password: password === '••••••••••••' || password === '' ? activeMySQLConfig.password : password,
    database: database ?? activeMySQLConfig.database,
    active: active ?? activeMySQLConfig.active
  };

  if (!tempConfig.host || !tempConfig.database) {
    return res.status(400).json({ 
      success: false, 
      message: 'Parameter host dan nama database wajib diisi.' 
    });
  }

  try {
    const connection = await mysql.createConnection({
      host: tempConfig.host,
      port: tempConfig.port,
      user: tempConfig.user,
      password: tempConfig.password,
      database: tempConfig.database,
      connectTimeout: 6000
    });

    await connection.ping();
    await createTables(connection);
    await connection.end();

    res.json({
      success: true,
      message: 'Koneksi ke MySQL Berhasil! Seluruh tabel database billing RT RW Net telah berhasil dimigrasi.'
    });
  } catch (err: any) {
    console.error('MySQL Test Connection failed:', err);
    res.status(500).json({
      success: false,
      message: `Gagal terhubung ke MySQL: ${err?.message || 'Unknown network error'}`
    });
  }
});

// 3. Save / Update Active MySQL Credentials
app.post('/api/db/mysql-save-config', (req, res) => {
  const { host, port, user, password, database, active } = req.body;

  const originalPassword = activeMySQLConfig.password;
  
  activeMySQLConfig = {
    host: host ?? activeMySQLConfig.host,
    port: parseInt(port ?? activeMySQLConfig.port) || 3306,
    user: user ?? activeMySQLConfig.user,
    password: password === '••••••••••••' || password === '' || password === '••••••••' ? originalPassword : password,
    database: database ?? activeMySQLConfig.database,
    active: active ?? activeMySQLConfig.active
  };

  // Persist config to local json
  try {
    fs.writeFileSync(MySQLConfigPath, JSON.stringify(activeMySQLConfig, null, 2), 'utf8');
  } catch (err) {
    console.error('Failed to write mysql-config.json:', err);
  }

  // Reload pool
  if (pool) {
    pool.end().catch(err => console.error('Error closing old pool:', err));
    pool = null;
  }
  
  getMySQLPool();

  res.json({
    success: true,
    message: 'Konfigurasi MySQL berhasil disimpan.',
    config: {
      ...activeMySQLConfig,
      password: activeMySQLConfig.password ? '••••••••••••' : ''
    }
  });
});

// 4. Batch Load All Data from MySQL or JSON Fallback
app.get('/api/db/load', async (req, res) => {
  const activePool = getMySQLPool();
  
  if (!activePool) {
    // If MySQL is not active or offline, read from JSON file fallback
    try {
      if (fs.existsSync(JSONFallbackPath)) {
        const fileContent = fs.readFileSync(JSONFallbackPath, 'utf8');
        return res.json({ source: 'json_fallback', data: JSON.parse(fileContent) });
      }
    } catch (err) {
      console.error('Error reading JSON fallback:', err);
    }
    return res.json({ source: 'empty_local', data: null });
  }

  try {
    const data: any = {};
    
    // Load each table sequentially from MySQL
    const [pelanggan] = await activePool.query('SELECT * FROM tbl_pelanggan');
    const [paket] = await activePool.query('SELECT * FROM tbl_paket');
    const [tagihan] = await activePool.query('SELECT * FROM tbl_tagihan');
    const [logs] = await activePool.query('SELECT * FROM tbl_logs');
    const [settingsRows]: any = await activePool.query('SELECT * FROM tbl_settings WHERE id = "global_settings"');
    const [servers] = await activePool.query('SELECT * FROM tbl_servers');
    const [collectors] = await activePool.query('SELECT * FROM tbl_collectors');
    const [resellers] = await activePool.query('SELECT * FROM tbl_resellers');
    const [vouchers] = await activePool.query('SELECT * FROM tbl_vouchers');
    const [pppoeUsers] = await activePool.query('SELECT * FROM tbl_pppoe_users');
    const [pesananAgen] = await activePool.query('SELECT * FROM tbl_pesanan_agen');
    const [teknisi] = await activePool.query('SELECT * FROM tbl_teknisi');

    res.json({
      source: 'mysql',
      data: {
        pelanggan: (pelanggan as any[]).map(row => ({ ...row, statusAktif: !!row.statusAktif })),
        paket,
        tagihan,
        logs,
        settings: settingsRows?.[0] ? JSON.parse(settingsRows[0].data) : null,
        servers,
        collectors,
        resellers: (resellers as any[]).map(row => ({
          id: row.id,
          nama: row.nama,
          username: row.username,
          password: row.password,
          wilayah: row.wilayah,
          noHp: row.noHp,
          saldo: row.saldo !== undefined ? row.saldo : (row.limitSaldo !== undefined ? row.limitSaldo : 0),
          komisiPercent: row.komisiPercent !== undefined ? row.komisiPercent : (row.diskonVoucherPercent !== undefined ? row.diskonVoucherPercent : 10),
          statusAktif: row.statusAktif === undefined ? true : !!row.statusAktif,
          depositLog: row.depositLog ? JSON.parse(row.depositLog) : [],
          allowedMenus: row.allowedMenus ? (() => {
            try { return JSON.parse(row.allowedMenus); } catch(e) { return ['create_manual', 'create_bulk', 'topup_simulation', 'vouchers_history']; }
          })() : ['create_manual', 'create_bulk', 'topup_simulation', 'vouchers_history'],
          allowedPaketIds: row.allowedPaketIds ? (() => {
            try { return JSON.parse(row.allowedPaketIds); } catch(e) { return []; }
          })() : [],
          allowedServerIds: row.allowedServerIds ? (() => {
            try { return JSON.parse(row.allowedServerIds); } catch(e) { return []; }
          })() : [],
          paketCustomPrices: row.paketCustomPrices ? (() => {
            try { return JSON.parse(row.paketCustomPrices); } catch(e) { return {}; }
          })() : {}
        })),
        vouchers,
        pppoeUsers,
        pesananAgen,
        teknisiList: (teknisi as any[]).map(row => ({
          id: row.id,
          nama: row.nama,
          username: row.username,
          password: row.password,
          noHp: row.noHp,
          statusAktif: row.statusAktif === undefined ? true : !!row.statusAktif,
          allowedServerIds: row.allowedServerIds ? (() => {
            try {
              return JSON.parse(row.allowedServerIds);
            } catch (e) {
              return [];
            }
          })() : [],
          allowedPaketIds: row.allowedPaketIds ? (() => {
            try {
              return JSON.parse(row.allowedPaketIds);
            } catch (e) {
              return [];
            }
          })() : [],
          allowedMenus: row.allowedMenus ? (() => {
            try {
              return JSON.parse(row.allowedMenus);
            } catch (e) {
              return ['create_manual', 'create_bulk'];
            }
          })() : ['create_manual', 'create_bulk']
        }))
      }
    });
  } catch (err: any) {
    console.log('[System] Local file system sync active (external loading omitted)');
    // Fallback to local file on unreachable DB
    try {
      if (fs.existsSync(JSONFallbackPath)) {
        const fileContent = fs.readFileSync(JSONFallbackPath, 'utf8');
        return res.json({ 
          source: 'json_fallback_on_error', 
          error: 'Local-only data storage mode initialized', 
          data: JSON.parse(fileContent) 
        });
      }
    } catch (_) {}
    res.json({ success: true, source: 'empty_local', error: 'Local-only clean setup', data: null });
  }
});

// 5. Batch Sync / Save All Data to MySQL
app.post('/api/db/save', async (req, res) => {
  const payload = req.body;
  
  // Always write to JSON fallback so user data is NEVER lost!
  try {
    fs.writeFileSync(JSONFallbackPath, JSON.stringify(payload, null, 2), 'utf8');
  } catch (err) {
    console.error('Failed to write JSON fallback:', err);
  }

  const activePool = getMySQLPool();
  if (!activePool) {
    return res.json({
      success: true,
      source: 'json_only',
      message: 'Data berhasil disimpan secara lokal di repositori server (File JSONFallback aktif).'
    });
  }

  let connection;
  try {
    connection = await activePool.getConnection();
    await connection.beginTransaction();

    // 1. Pelanggan Sync
    if (payload.pelanggan) {
      await connection.query('DELETE FROM tbl_pelanggan');
      for (const row of payload.pelanggan) {
        await connection.query(
          `INSERT INTO tbl_pelanggan (id, nama, alamat, noHp, paketId, tarif, statusAktif, koordinat, dueDay, tanggalPasang) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [row.id, row.nama, row.alamat, row.noHp, row.paketId, row.tarif, row.statusAktif ? 1 : 0, row.koordinat, row.dueDay, row.tanggalPasang]
        );
      }
    }

    // 2. Paket Sync
    if (payload.paket) {
      await connection.query('DELETE FROM tbl_paket');
      for (const row of payload.paket) {
        await connection.query(
          `INSERT INTO tbl_paket (id, nama, kecepatan, harga, tipe, deskripsi) VALUES (?, ?, ?, ?, ?, ?)`,
          [row.id, row.nama, row.kecepatan, row.harga, row.tipe, row.deskripsi]
        );
      }
    }

    // 3. Tagihan Sync
    if (payload.tagihan) {
      await connection.query('DELETE FROM tbl_tagihan');
      for (const row of payload.tagihan) {
        await connection.query(
          `INSERT INTO tbl_tagihan (id, pelangganId, pelangganNama, pelangganNoHp, pelangganAlamat, paketId, paketNama, nominal, bulan, status, tanggalBayar, metodeBayar, invoiceId, jatuhTempo) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [row.id, row.pelangganId, row.pelangganNama, row.pelangganNoHp, row.pelangganAlamat, row.paketId, row.paketNama, row.nominal, row.bulan, row.status, row.tanggalBayar, row.metodeBayar, row.invoiceId, row.jatuhTempo]
        );
      }
    }

    // 4. WhatsApp Logs Sync
    if (payload.logs) {
      await connection.query('DELETE FROM tbl_logs');
      for (const row of payload.logs) {
        await connection.query(
          `INSERT INTO tbl_logs (id, tanggal, nomorHp, namaPelanggan, pesan, status, tipe) VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [row.id, row.tanggal, row.nomorHp, row.namaPelanggan, row.pesan, row.status, row.tipe]
        );
      }
    }

    // 5. Settings Sync
    if (payload.settings) {
      await connection.query('REPLACE INTO tbl_settings (id, data) VALUES ("global_settings", ?)', [JSON.stringify(payload.settings)]);
    }

    // 6. Servers Sync
    if (payload.servers) {
      await connection.query('DELETE FROM tbl_servers');
      for (const row of payload.servers) {
        await connection.query(
          `INSERT INTO tbl_servers (id, nama, host, username, password, status) VALUES (?, ?, ?, ?, ?, ?)`,
          [row.id, row.nama, row.host, row.username, row.password, row.status]
        );
      }
    }

    // 7. Collectors Sync
    if (payload.collectors) {
      await connection.query('DELETE FROM tbl_collectors');
      for (const row of payload.collectors) {
        await connection.query(
          `INSERT INTO tbl_collectors (id, nama, username, password, wilayah, noHp) VALUES (?, ?, ?, ?, ?, ?)`,
          [row.id, row.nama, row.username, row.password, row.wilayah, row.noHp]
        );
      }
    }

    // 8. Resellers Sync
    if (payload.resellers) {
      await connection.query('DELETE FROM tbl_resellers');
      for (const row of payload.resellers) {
        await connection.query(
          `INSERT INTO tbl_resellers (id, nama, username, password, wilayah, noHp, limitSaldo, diskonVoucherPercent, depositLog, statusAktif, allowedMenus, allowedPaketIds, allowedServerIds, paketCustomPrices) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            row.id,
            row.nama,
            row.username,
            row.password,
            row.wilayah,
            row.noHp,
            row.saldo || 0,
            row.komisiPercent || 10,
            JSON.stringify(row.depositLog || []),
            row.statusAktif !== false ? 1 : 0,
            JSON.stringify(row.allowedMenus || ['create_manual', 'create_bulk', 'topup_simulation', 'vouchers_history']),
            JSON.stringify(row.allowedPaketIds || []),
            JSON.stringify(row.allowedServerIds || []),
            JSON.stringify(row.paketCustomPrices || {})
          ]
        );
      }
    }

    // 9. Vouchers Sync
    if (payload.vouchers) {
      await connection.query('DELETE FROM tbl_vouchers');
      for (const row of payload.vouchers) {
        await connection.query(
          `INSERT INTO tbl_vouchers (id, code, password, paketId, harga, durasi, serverName, status, resellerId, agentPaymentStatus) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [row.id, row.code, row.password, row.paketId, row.harga, row.durasi, row.serverName, row.status, row.resellerId, row.agentPaymentStatus]
        );
      }
    }

    // 10. PPPOE Users Sync
    if (payload.pppoeUsers) {
      await connection.query('DELETE FROM tbl_pppoe_users');
      for (const row of payload.pppoeUsers) {
        await connection.query(
          `INSERT INTO tbl_pppoe_users (id, username, password, profile, serverName, status, resellerId, lastActive) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
          [row.id, row.username, row.password, row.profile, row.serverName, row.status, row.resellerId, row.lastActive]
        );
      }
    }

    // 11. Pesanan Agen Sync
    if (payload.pesananAgen) {
      await connection.query('DELETE FROM tbl_pesanan_agen');
      for (const row of payload.pesananAgen) {
        await connection.query(
          `INSERT INTO tbl_pesanan_agen (id, resellerId, resellerNama, resellerWilayah, resellerNoHp, voucherId, voucherCode, paketId, paketNama, jumlahTagihan, status, tanggalPesan, bulan) 
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [row.id, row.resellerId, row.resellerNama, row.resellerWilayah, row.resellerNoHp, row.voucherId, row.voucherCode, row.paketId, row.paketNama, row.jumlahTagihan, row.status, row.tanggalPesan, row.bulan]
        );
      }
    }

    // 12. Teknisi Sync
    if (payload.teknisiList) {
      await connection.query('DELETE FROM tbl_teknisi');
      for (const row of payload.teknisiList) {
        await connection.query(
          `INSERT INTO tbl_teknisi (id, nama, username, password, noHp, statusAktif, allowedServerIds, allowedPaketIds, allowedMenus) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            row.id,
            row.nama,
            row.username,
            row.password,
            row.noHp,
            row.statusAktif !== false ? 1 : 0,
            JSON.stringify(row.allowedServerIds || []),
            JSON.stringify(row.allowedPaketIds || []),
            JSON.stringify(row.allowedMenus || ['create_manual', 'create_bulk'])
          ]
        );
      }
    }

    await connection.commit();
    res.json({
      success: true,
      source: 'mysql',
      message: 'Sukses mensinkronisasikan seluruh database Anda secara instan ke server MySQL cloud!'
    });
  } catch (err: any) {
    if (connection) await connection.rollback();
    console.log('[System] Local file system sync active (external writing omitted)');
    res.json({
      success: true,
      source: 'json_fallback_on_error',
      message: 'Data berhasil disimpan secara lokal (MySQL Cloud sedang offline atau tidak terjangkau).',
      error: 'Local-only data storage mode initialized'
    });
  } finally {
    if (connection) connection.release();
  }
});

// Helper: Migration tables builder
async function createTables(connection: mysql.Connection) {
  // 1
  await connection.query(`
    CREATE TABLE IF NOT EXISTS tbl_pelanggan (
      id VARCHAR(100) PRIMARY KEY,
      nama VARCHAR(255) NOT NULL,
      alamat VARCHAR(255),
      noHp VARCHAR(50),
      paketId VARCHAR(100),
      tarif INT DEFAULT 0,
      statusAktif TINYINT DEFAULT 1,
      koordinat VARCHAR(100),
      dueDay INT DEFAULT 10,
      tanggalPasang VARCHAR(50)
    )
  `);

  // 2
  await connection.query(`
    CREATE TABLE IF NOT EXISTS tbl_paket (
      id VARCHAR(100) PRIMARY KEY,
      nama VARCHAR(255) NOT NULL,
      kecepatan VARCHAR(50),
      harga INT DEFAULT 0,
      tipe VARCHAR(50),
      deskripsi VARCHAR(255)
    )
  `);

  // 3
  await connection.query(`
    CREATE TABLE IF NOT EXISTS tbl_tagihan (
      id VARCHAR(100) PRIMARY KEY,
      pelangganId VARCHAR(100),
      pelangganNama VARCHAR(255),
      pelangganNoHp VARCHAR(50),
      pelangganAlamat VARCHAR(255),
      paketId VARCHAR(100),
      paketNama VARCHAR(255),
      nominal INT DEFAULT 0,
      bulan VARCHAR(20),
      status VARCHAR(50),
      tanggalBayar VARCHAR(50),
      metodeBayar VARCHAR(50),
      invoiceId VARCHAR(100),
      jatuhTempo VARCHAR(50)
    )
  `);

  // 4
  await connection.query(`
    CREATE TABLE IF NOT EXISTS tbl_logs (
      id VARCHAR(100) PRIMARY KEY,
      tanggal VARCHAR(50),
      nomorHp VARCHAR(50),
      namaPelanggan VARCHAR(255),
      pesan TEXT,
      status VARCHAR(50),
      tipe VARCHAR(50)
    )
  `);

  // 5
  await connection.query(`
    CREATE TABLE IF NOT EXISTS tbl_settings (
      id VARCHAR(100) PRIMARY KEY,
      data TEXT
    )
  `);

  // 6
  await connection.query(`
    CREATE TABLE IF NOT EXISTS tbl_servers (
      id VARCHAR(100) PRIMARY KEY,
      nama VARCHAR(255),
      host VARCHAR(255),
      username VARCHAR(100),
      password VARCHAR(100),
      status VARCHAR(50)
    )
  `);

  // 7
  await connection.query(`
    CREATE TABLE IF NOT EXISTS tbl_collectors (
      id VARCHAR(100) PRIMARY KEY,
      nama VARCHAR(255),
      username VARCHAR(100),
      password VARCHAR(100),
      wilayah VARCHAR(255),
      noHp VARCHAR(50)
    )
  `);

  // 8
  await connection.query(`
    CREATE TABLE IF NOT EXISTS tbl_resellers (
      id VARCHAR(100) PRIMARY KEY,
      nama VARCHAR(255),
      username VARCHAR(100),
      password VARCHAR(100),
      wilayah VARCHAR(255),
      noHp VARCHAR(50),
      limitSaldo INT DEFAULT 0,
      diskonVoucherPercent INT DEFAULT 0,
      depositLog TEXT,
      statusAktif BOOLEAN DEFAULT TRUE,
      allowedMenus TEXT,
      allowedPaketIds TEXT,
      allowedServerIds TEXT,
      paketCustomPrices TEXT
    )
  `);

  // 9
  await connection.query(`
    CREATE TABLE IF NOT EXISTS tbl_vouchers (
      id VARCHAR(100) PRIMARY KEY,
      code VARCHAR(255) NOT NULL,
      password VARCHAR(255),
      paketId VARCHAR(100),
      harga INT DEFAULT 0,
      durasi VARCHAR(100),
      serverName VARCHAR(255),
      status VARCHAR(50),
      resellerId VARCHAR(100),
      agentPaymentStatus VARCHAR(50)
    )
  `);

  // 10
  await connection.query(`
    CREATE TABLE IF NOT EXISTS tbl_pppoe_users (
      id VARCHAR(100) PRIMARY KEY,
      username VARCHAR(255) NOT NULL,
      password VARCHAR(255),
      profile VARCHAR(100),
      serverName VARCHAR(255),
      status VARCHAR(50),
      resellerId VARCHAR(100),
      lastActive VARCHAR(100)
    )
  `);

  // 11
  await connection.query(`
    CREATE TABLE IF NOT EXISTS tbl_pesanan_agen (
      id VARCHAR(100) PRIMARY KEY,
      resellerId VARCHAR(100),
      resellerNama VARCHAR(255),
      resellerWilayah VARCHAR(255),
      resellerNoHp VARCHAR(50),
      voucherId VARCHAR(100),
      voucherCode VARCHAR(255),
      paketId VARCHAR(100),
      paketNama VARCHAR(255),
      jumlahTagihan INT DEFAULT 0,
      status VARCHAR(50),
      tanggalPesan VARCHAR(50),
      bulan VARCHAR(20)
    )
  `);

  // 12
  await connection.query(`
    CREATE TABLE IF NOT EXISTS tbl_teknisi (
      id VARCHAR(100) PRIMARY KEY,
      nama VARCHAR(255),
      username VARCHAR(100),
      password VARCHAR(100),
      noHp VARCHAR(50),
      statusAktif BOOLEAN DEFAULT TRUE,
      allowedServerIds TEXT,
      allowedPaketIds TEXT,
      allowedMenus TEXT
    )
  `);

  // Safe ALTER addition for existing user tables from previous runs
  try {
    await connection.query(`ALTER TABLE tbl_teknisi ADD COLUMN statusAktif BOOLEAN DEFAULT TRUE`);
  } catch (e) {}
  try {
    await connection.query(`ALTER TABLE tbl_teknisi ADD COLUMN allowedServerIds TEXT`);
  } catch (e) {}
  try {
    await connection.query(`ALTER TABLE tbl_teknisi ADD COLUMN allowedPaketIds TEXT`);
  } catch (e) {}
  try {
    await connection.query(`ALTER TABLE tbl_teknisi ADD COLUMN allowedMenus TEXT`);
  } catch (e) {}
  try {
    await connection.query(`ALTER TABLE tbl_resellers ADD COLUMN statusAktif BOOLEAN DEFAULT TRUE`);
  } catch (e) {}
  try {
    await connection.query(`ALTER TABLE tbl_resellers ADD COLUMN allowedMenus TEXT`);
  } catch (e) {}
  try {
    await connection.query(`ALTER TABLE tbl_resellers ADD COLUMN allowedPaketIds TEXT`);
  } catch (e) {}
  try {
    await connection.query(`ALTER TABLE tbl_resellers ADD COLUMN allowedServerIds TEXT`);
  } catch (e) {}
  try {
    await connection.query(`ALTER TABLE tbl_resellers ADD COLUMN paketCustomPrices TEXT`);
  } catch (e) {}
}

// Vite and Static Files Handler
async function setupViteAndAssets() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server is running at http://0.0.0.0:${PORT}`);
  });
}

setupViteAndAssets();
