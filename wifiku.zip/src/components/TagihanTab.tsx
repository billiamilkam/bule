import React, { useState } from 'react';
import { Tagihan, Pelanggan, Paket, TagihanStatus, AppSettings, TukangTagih } from '../types';
import { formatRupiah, formatBulanIndo, formatTanggalIndo, isPastDue, replaceTemplates } from '../utils';
import { 
  Calendar, FilePlus2, Send, CheckSquare, Printer, 
  HelpCircle, Search, Info, Check, X, ShieldAlert, CreditCard, Users, Plus, Trash2
} from 'lucide-react';
import PelangganTab from './PelangganTab';

interface TagihanTabProps {
  tagihan: Tagihan[];
  pelanggan: Pelanggan[];
  paket: Paket[];
  settings: AppSettings;
  selectedBulan: string;
  setSelectedBulan: (bulan: string) => void;
  onGenerateTagihan: (bulan: string, kategori?: 'SEMUA' | 'HOTSPOT' | 'RUMAHAN', customPelangganId?: string, customTarif?: number) => void;
  onRegisterPayment: (tagihanId: string, payload: { tanggalBayar: string; metodeBayar: string; catatan: string }) => void;
  onSendSingleWa: (tagihan: Tagihan) => void;
  onSendSingleWaWeb: (tagihan: Tagihan) => void;
  currentDateStr: string;
  onKirimSemuaWa: () => void;
  
  // Pelanggan props
  collectors: TukangTagih[];
  onAddPelanggan: (p: Omit<Pelanggan, 'id' | 'tanggalDaftar'>) => void;
  onUpdatePelanggan: (p: Pelanggan) => void;
  onDeletePelanggan: (id: string) => void;
  onAddManualTagihan: (newInvoice: Tagihan) => void;
  onDeleteTagihan: (id: string) => void;
}

export default function TagihanTab({
  tagihan,
  pelanggan,
  paket,
  settings,
  selectedBulan,
  setSelectedBulan,
  onGenerateTagihan,
  onRegisterPayment,
  onSendSingleWa,
  onSendSingleWaWeb,
  currentDateStr,
  onKirimSemuaWa,
  collectors,
  onAddPelanggan,
  onUpdatePelanggan,
  onDeletePelanggan,
  onAddManualTagihan,
  onDeleteTagihan
}: TagihanTabProps) {
  const [search, setSearch] = useState('');
  const [activeSubTab, setActiveSubTab] = useState<'TAGIHAN' | 'PELANGGAN'>('TAGIHAN');
   const [showManualBillModal, setShowManualBillModal] = useState(false);
  const [manualBillForm, setManualBillForm] = useState({
    pelangganNama: '',
    pelangganAlamat: '',
    pelangganNoHp: '08',
    bulan: selectedBulan,
    jumlah: '',
    tanggalJatuhTempo: `${selectedBulan}-10`,
    status: 'BELUM_BAYAR' as TagihanStatus,
    pelangganKategori: 'Rumahan' as 'Rumahan' | 'Hotspot' | 'PPPoE'
  });
  const [filterStatus, setFilterStatus] = useState<'SEMUA' | 'LUNAS' | 'BELUM_BAYAR' | 'TERLAMBAT'>('SEMUA');
  const [filterKategori, setFilterKategori] = useState<'SEMUA' | 'HOTSPOT' | 'RUMAHAN'>('SEMUA');
  
  // Modals state
  const [paymentModalBill, setPaymentModalBill] = useState<Tagihan | null>(null);
  const [printReceiptBill, setPrintReceiptBill] = useState<Tagihan | null>(null);
  
  // Single manual invoice state
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Payment form states
  const [paymentForm, setPaymentForm] = useState({
    tanggalBayar: currentDateStr.substring(0, 10),
    metodeBayar: 'Transfer BCA',
    catatan: ''
  });

  // Calculate list of available months in bills to select from, or defaults
  const availableMonths = Array.from(new Set([
    '2026-05', '2026-06', '2026-07', 
    ...tagihan.map(t => t.bulan)
  ])).sort().reverse();

  // Handle billing payment submission
  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentModalBill) return;
    onRegisterPayment(paymentModalBill.id, paymentForm);
    setPaymentModalBill(null);
  };

  // Filter bills
  const filteredBills = tagihan.filter((t) => {
    if (t.bulan !== selectedBulan) return false;
    
    const isPast = isPastDue(t.tanggalJatuhTempo, currentDateStr);
    
    const matchSearch = t.pelangganNama.toLowerCase().includes(search.toLowerCase()) || t.id.toLowerCase().includes(search.toLowerCase());
    
    const matchStatus = 
      filterStatus === 'SEMUA' ||
      (filterStatus === 'LUNAS' && t.status === 'LUNAS') ||
      (filterStatus === 'BELUM_BAYAR' && t.status === 'BELUM_BAYAR' && !isPast) ||
      (filterStatus === 'TERLAMBAT' && t.status === 'BELUM_BAYAR' && isPast);

    // Resolve category from corresponding customer record
    const cust = pelanggan.find(p => p.id === t.pelangganId);
    const category = cust?.kategoriLangganan || 'Rumahan';

    const matchKategori = 
      filterKategori === 'SEMUA' ||
      (filterKategori === 'HOTSPOT' && category === 'Hotspot') ||
      (filterKategori === 'RUMAHAN' && category === 'Rumahan');

    return matchSearch && matchStatus && matchKategori;
  });

  // Calculate category aggregates for the current selected month
  const countSemua = tagihan.filter(t => t.bulan === selectedBulan).length;
  const countHotspot = tagihan.filter(t => t.bulan === selectedBulan && pelanggan.find(p => p.id === t.pelangganId)?.kategoriLangganan === 'Hotspot').length;
  const countRumahan = tagihan.filter(t => t.bulan === selectedBulan && pelanggan.find(p => p.id === t.pelangganId)?.kategoriLangganan === 'Rumahan').length;

  // Missing count: how many active customers don't have a bill generated for this month?
  const customersWithBill = tagihan.filter(t => t.bulan === selectedBulan).map(t => t.pelangganId);
  const activeCustomersCount = pelanggan.filter(p => p.statusAktif).length;
  const missingBillsCount = pelanggan.filter(p => p.statusAktif && !customersWithBill.includes(p.id)).length;
  const missingBillsHotspotCount = pelanggan.filter(p => p.statusAktif && p.kategoriLangganan === 'Hotspot' && !customersWithBill.includes(p.id)).length;
  const missingBillsRumahanCount = pelanggan.filter(p => p.statusAktif && p.kategoriLangganan === 'Rumahan' && !customersWithBill.includes(p.id)).length;

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Sub-Tab Navigation Header */}
      <div className="flex border-b border-slate-200 bg-slate-50 p-2 rounded-2xl border border-slate-100 shadow-3xs gap-1.5 max-w-md">
        <button
          type="button"
          onClick={() => setActiveSubTab('TAGIHAN')}
          className={`flex-1 py-2.5 text-center text-xs font-black rounded-xl transition flex items-center justify-center gap-2 cursor-pointer ${
            activeSubTab === 'TAGIHAN'
              ? 'bg-indigo-600 text-white shadow-xs font-bold'
              : 'text-slate-500 hover:bg-slate-100 hover:text-slate-800'
          }`}
        >
          <CreditCard size={15} /> DAFTAR TAGIHAN BULANAN
        </button>
        <button
          type="button"
          onClick={() => setActiveSubTab('PELANGGAN')}
          className={`flex-1 py-2.5 text-center text-xs font-black rounded-xl transition flex items-center justify-center gap-2 cursor-pointer ${
            activeSubTab === 'PELANGGAN'
              ? 'bg-indigo-600 text-white shadow-xs font-bold'
              : 'text-slate-500 hover:bg-slate-100 hover:text-slate-800'
          }`}
        >
          <Users size={15} /> DATABASE PELANGGAN
        </button>
      </div>

      {activeSubTab === 'TAGIHAN' ? (
        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm space-y-6">
          <div className="flex items-center gap-2 border-b border-slate-100 pb-3">
            <CreditCard className="text-indigo-600" size={20} />
            <h2 className="text-base font-black text-slate-800 uppercase">Daftar Tagihan Bulanan</h2>
          </div>
      
        {/* Month Selector & Core Actions */}
        <div className="flex flex-col xl:flex-row xl:items-center justify-between gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-100">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-700">
              <Calendar size={15} /> Pilih Bulan Tagihan:
            </div>
            <select
              className="bg-white text-xs px-3 py-2 border border-slate-200 rounded-lg focus:outline-hidden font-bold text-slate-700"
              value={selectedBulan}
              onChange={(e) => setSelectedBulan(e.target.value)}
            >
              {availableMonths.map((m) => (
                <option key={m} value={m}>{formatBulanIndo(m)}</option>
              ))}
            </select>
          </div>

          <div className="flex flex-wrap gap-2.5 items-center">
            {/* WhatsApp Broadcaster */}
            <button
              onClick={onKirimSemuaWa}
              disabled={filteredBills.filter(t => t.status !== 'LUNAS').length === 0}
              className={`inline-flex items-center gap-1.5 px-4 py-2 border rounded-xl text-xs font-bold transition cursor-pointer ${
                filteredBills.filter(t => t.status !== 'LUNAS').length > 0
                  ? 'bg-emerald-600 border-emerald-600 text-white hover:bg-emerald-700 shadow-xs'
                  : 'bg-slate-100 border-slate-250 text-slate-400 cursor-not-allowed'
              }`}
            >
              <Send size={13} /> Kirim Massal WA Tagihan ({filteredBills.filter(t => t.status !== 'LUNAS').length})
            </button>
          </div>
        </div>

      {/* Kategori Tagihan Bulanan Selector */}
      <div className="border-t border-b border-dashed border-slate-200 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-xs font-extrabold text-slate-800 flex items-center gap-1.5 uppercase tracking-wider">
            <span>📋 Kategori Tagihan Bulanan</span>
          </h3>
          <p className="text-[10px] text-slate-400 font-medium">Filter tagihan aktif berdasarkan kategori layanan pelanggan.</p>
        </div>
        
        <div className="flex bg-slate-100 p-1 rounded-xl self-start sm:self-auto border border-slate-200 shadow-3xs">
          <button
            type="button"
            onClick={() => setFilterKategori('SEMUA')}
            className={`px-3 py-1.5 rounded-lg text-[11px] font-bold transition flex items-center gap-1.5 cursor-pointer ${
              filterKategori === 'SEMUA'
                ? 'bg-slate-800 text-white shadow-xs'
                : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            📂 Semua ({countSemua})
          </button>
          <button
            type="button"
            onClick={() => setFilterKategori('HOTSPOT')}
            className={`px-3 py-1.5 rounded-lg text-[11px] font-bold transition flex items-center gap-1.5 cursor-pointer ${
              filterKategori === 'HOTSPOT'
                ? 'bg-amber-600 text-white shadow-xs'
                : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            🌐 Hotspot ({countHotspot})
          </button>
          <button
            type="button"
            onClick={() => setFilterKategori('RUMAHAN')}
            className={`px-3 py-1.5 rounded-lg text-[11px] font-bold transition flex items-center gap-1.5 cursor-pointer ${
              filterKategori === 'RUMAHAN'
                ? 'bg-indigo-650 text-white shadow-xs'
                : 'text-slate-500 hover:text-slate-700'
            }`}
          >
            🏠 Rumahan ({countRumahan})
          </button>
        </div>
      </div>

      {/* Stats of Selected Month */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-1">
        <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-100 text-center">
          <p className="text-[10px] font-bold text-slate-400 uppercase">Jumlah Invoice</p>
          <p className="text-xl font-bold font-sans text-slate-700 mt-0.5">{filteredBills.length}</p>
          <p className="text-[10px] text-slate-500 font-extrabold mt-1">
            {formatRupiah(filteredBills.reduce((acc, cr) => acc + cr.jumlah, 0))}
          </p>
        </div>
        <div className="bg-emerald-50/50 p-3.5 rounded-xl border border-emerald-100/50 text-center">
          <p className="text-[10px] font-bold text-emerald-600 uppercase">Lunas Terbayar</p>
          <p className="text-xl font-bold font-sans text-emerald-700 mt-0.5">
            {filteredBills.filter(b => b.status === 'LUNAS').length}
          </p>
          <p className="text-[10px] text-emerald-600 font-extrabold mt-1">
            {formatRupiah(filteredBills.filter(b => b.status === 'LUNAS').reduce((acc, cr) => acc + cr.jumlah, 0))}
          </p>
        </div>
        <div className="bg-amber-50/50 p-3.5 rounded-xl border border-amber-100/50 text-center">
          <p className="text-[10px] font-bold text-amber-600 uppercase">Menunggu Pembayaran</p>
          <p className="text-xl font-bold font-sans text-amber-700 mt-0.5">
            {filteredBills.filter(b => b.status === 'BELUM_BAYAR' && !isPastDue(b.tanggalJatuhTempo, currentDateStr)).length}
          </p>
          <p className="text-[10px] text-amber-650 font-extrabold mt-1">
            {formatRupiah(filteredBills.filter(b => b.status === 'BELUM_BAYAR' && !isPastDue(b.tanggalJatuhTempo, currentDateStr)).reduce((acc, cr) => acc + cr.jumlah, 0))}
          </p>
        </div>
        <div className="bg-rose-50/50 p-3.5 rounded-xl border border-rose-100/50 text-center">
          <p className="text-[10px] font-bold text-rose-600 uppercase">Menunggak (Terlambat)</p>
          <p className="text-xl font-bold font-sans text-rose-700 mt-0.5">
            {filteredBills.filter(b => b.status === 'BELUM_BAYAR' && isPastDue(b.tanggalJatuhTempo, currentDateStr)).length}
          </p>
          <p className="text-[10px] text-rose-600 font-extrabold mt-1">
            {formatRupiah(filteredBills.filter(b => b.status === 'BELUM_BAYAR' && isPastDue(b.tanggalJatuhTempo, currentDateStr)).reduce((acc, cr) => acc + cr.jumlah, 0))}
          </p>
        </div>
      </div>

      {/* Advanced Filter and Search */}
      <div className="flex flex-col sm:flex-row gap-3 bg-slate-50 p-3.5 rounded-xl border border-slate-100 text-xs">
        <div className="relative flex-1">
          <Search size={15} className="absolute left-3 top-2 text-slate-400" />
          <input
            type="text"
            placeholder="Cari Nama Pelanggan / Nomor Resi Invoice..."
            className="w-full bg-white text-xs pl-9 pr-3 py-1.5 border border-slate-200 rounded-lg focus:outline-hidden"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="flex items-center gap-1.5 overflow-x-auto">
          {(['SEMUA', 'LUNAS', 'BELUM_BAYAR', 'TERLAMBAT'] as const).map((st) => {
            const labelsMap = {
              SEMUA: 'Semua',
              LUNAS: 'Lunas',
              BELUM_BAYAR: 'Belum Bayar',
              TERLAMBAT: 'Terlambat (Lewat Jatuh Tempo)'
            };
            return (
              <button
                key={st}
                onClick={() => setFilterStatus(st)}
                className={`px-3 py-1.5 rounded-lg border text-[11px] font-semibold transition cursor-pointer shrink-0 ${
                  filterStatus === st
                    ? 'bg-indigo-600 border-indigo-600 text-white'
                    : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                }`}
              >
                {labelsMap[st]}
              </button>
            );
          })}
        </div>
      </div>

      {/* Invoices List Table */}
      <div className="overflow-x-auto rounded-xl border border-slate-100">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="bg-slate-50 font-semibold text-slate-500 border-b border-slate-100">
              <th className="p-4">No. Invoice / Nama</th>
              <th className="p-4">Bulan</th>
              <th className="p-4">Jumlah Tagihan</th>
              <th className="p-4">Jatuh Tempo</th>
              <th className="p-4 text-center">Status</th>
              <th className="p-4 text-center">Notifikasi WA</th>
              <th className="p-4 text-right">Aksi Pembayaran & Nota</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 text-slate-700">
            {filteredBills.map((b) => {
              const isPast = isPastDue(b.tanggalJatuhTempo, currentDateStr);
              // Determine Customer connection
              const cust = pelanggan.find(p => p.id === b.pelangganId);
              const customPaket = cust ? paket.find(p => p.id === cust.paketId) : null;
              
              return (
                <tr key={b.id} className="hover:bg-slate-50/50 transition">
                  <td className="p-4">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="font-bold text-slate-800 text-sm leading-tight">{b.pelangganNama}</p>
                        
                        {(b.pelangganKategori || cust?.kategoriLangganan || 'Rumahan') === 'Hotspot' ? (
                          <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 bg-amber-50 text-amber-800 text-[9px] rounded-md font-bold border border-amber-200 uppercase tracking-wide">
                            🌐 Hotspot
                          </span>
                        ) : (b.pelangganKategori || cust?.kategoriLangganan || 'Rumahan') === 'PPPoE' ? (
                          <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 bg-emerald-50 text-emerald-800 text-[9px] rounded-md font-bold border border-emerald-200 uppercase tracking-wide">
                            ⚡ PPPoE
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 bg-indigo-50 text-indigo-800 text-[9px] rounded-md font-bold border border-indigo-200 uppercase tracking-wide">
                            🏠 Rumahan
                          </span>
                        )}
                      </div>
                      
                      {(b.pelangganAlamat || cust?.alamat) && (
                        <p className="text-[10px] text-slate-500 font-semibold mt-0.5">
                          📍 {b.pelangganAlamat || cust?.alamat}
                        </p>
                      )}
                      
                      <p className="text-[10px] font-mono text-slate-400 mt-1">{b.id}</p>
                      {customPaket && (
                        <p className="text-[10px] text-indigo-500 font-semibold mt-0.5">
                          {customPaket.nama} ({customPaket.kecepatan})
                        </p>
                      )}
                    </div>
                  </td>
                  <td className="p-4 font-medium text-slate-600">
                    {formatBulanIndo(b.bulan)}
                  </td>
                  <td className="p-4 font-extrabold font-mono text-slate-800">
                    {formatRupiah(b.jumlah)}
                  </td>
                  <td className="p-4 font-semibold text-slate-500">
                    {formatTanggalIndo(b.tanggalJatuhTempo)}
                  </td>
                  <td className="p-4 text-center">
                    {b.status === 'LUNAS' ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-emerald-50 text-emerald-700 rounded-full font-bold text-[10px] border border-emerald-100">
                        🟢 LUNAS
                      </span>
                    ) : isPast ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-rose-50 text-rose-700 rounded-full font-bold text-[10px] border border-rose-100">
                        🔴 TERLAMBAT
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2.5 py-0.5 bg-amber-50 text-amber-700 rounded-full font-bold text-[10px] border border-amber-100">
                        🟡 BELUM BAYAR
                      </span>
                    )}
                  </td>
                  <td className="p-4 text-center">
                    {b.waSent ? (
                      <div className="inline-flex flex-col items-center">
                        <span className="text-[10px] font-bold text-emerald-600 flex items-center gap-0.5">
                          ✔ Terkirim
                        </span>
                        <span className="text-[9px] text-slate-400 font-mono scale-95 mt-0.5">{b.waSentAt?.split(' ')[1] || b.waSentAt}</span>
                      </div>
                    ) : (
                      <span className="text-[10px] font-semibold text-slate-400">
                        &mdash;
                      </span>
                    )}
                  </td>
                  <td className="p-4 text-right">
                    <div className="inline-flex items-center gap-1.5">
                      {/* Mark Payment Action */}
                      {b.status !== 'LUNAS' ? (
                        <button
                          onClick={() => {
                            setPaymentModalBill(b);
                            setPaymentForm({
                              tanggalBayar: currentDateStr.substring(0, 10),
                              metodeBayar: 'Transfer BCA',
                              catatan: ''
                            });
                          }}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-indigo-50 text-indigo-700 hover:bg-indigo-600 hover:text-white rounded-lg font-bold text-[10px] border border-indigo-100 transition cursor-pointer"
                          title="Registrasikan pembayaran tunai/transfer"
                        >
                          <CheckSquare size={13} /> Bayar
                        </button>
                      ) : (
                        <button
                          onClick={() => setPrintReceiptBill(b)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 bg-slate-50 text-slate-600 hover:bg-slate-200 rounded-lg font-bold text-[10px] border border-slate-200/60 transition cursor-pointer"
                          title="Cetak Kuitansi Resmi"
                        >
                          <Printer size={13} /> Kuitansi
                        </button>
                      )}

                      {/* Notification Triggers Menu */}
                      <div className="relative group/menu">
                        <button
                          className="inline-flex items-center justify-center p-1.5 bg-slate-50 hover:bg-emerald-50 text-slate-500 hover:text-emerald-700 rounded-lg border border-slate-100 transition text-[11px] font-bold cursor-pointer"
                          title="Hubungi Pelanggan via WhatsApp"
                        >
                          <Send size={13} />
                        </button>
                        
                        {/* Dropdown float */}
                        <div className="absolute right-0 top-full mt-1 w-48 bg-white border border-slate-100 rounded-xl shadow-lg p-1.5 hidden group-hover/menu:block z-20 text-left">
                          <p className="text-[9px] uppercase tracking-wider font-extrabold text-slate-400 px-2 py-1">Opsi WhatsApp</p>
                          
                          <button
                            onClick={() => onSendSingleWa(b)}
                            className="w-full text-left px-2 py-1.5 hover:bg-emerald-50 text-emerald-700 rounded-lg font-semibold flex items-center gap-1.5 transition cursor-pointer text-[10px]"
                          >
                            ⚡ Kirim Otomatis (Gateway)
                          </button>
                          
                          <button
                            onClick={() => onSendSingleWaWeb(b)}
                            className="w-full text-left px-2 py-1.5 hover:bg-slate-50 text-slate-600 rounded-lg font-semibold flex items-center gap-1.5 transition cursor-pointer text-[10px]"
                          >
                            🌐 Buka WhatsApp Web
                          </button>
                        </div>
                      </div>
                    </div>
                  </td>
                </tr>
              );
            })}
            {filteredBills.length === 0 && (
              <tr>
                <td colSpan={7} className="p-8 text-center text-slate-400 italic">
                  Belum ada laporan tagihan di bulan ini. Silakan klik "Buat Tagihan Baru" di atas untuk memproses tagihan bulan {formatBulanIndo(selectedBulan)}.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* REGISTRASI PEMBAYARAN MODAL */}
      {paymentModalBill && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xl w-full max-w-sm overflow-hidden animate-zoomIn">
            
            <div className="flex justify-between items-center bg-slate-50 px-5 py-4 border-b border-slate-100">
              <h4 className="font-bold text-slate-800 flex items-center gap-2 text-xs">
                <CreditCard size={16} className="text-indigo-600" />
                Registrasi Pelunasan Layanan
              </h4>
              <button onClick={() => setPaymentModalBill(null)} className="p-1 hover:bg-slate-200 text-slate-400 rounded-lg">
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handlePaymentSubmit} className="p-5 space-y-4 text-xs text-slate-600">
              <div className="bg-indigo-50/50 p-3 rounded-xl border border-indigo-100/30">
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Nama Pelanggan / ID</p>
                <p className="text-sm font-bold text-slate-800">{paymentModalBill.pelangganNama}</p>
                <div className="flex justify-between items-center mt-1 text-slate-600 font-bold font-sans">
                  <span>Tagihan {formatBulanIndo(paymentModalBill.bulan)}:</span>
                  <span className="text-indigo-600 text-sm font-black">{formatRupiah(paymentModalBill.jumlah)}</span>
                </div>
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Tanggal Pembayaran *</label>
                <input
                  type="date"
                  required
                  className="w-full bg-slate-50 px-3 py-2 border border-slate-200 rounded-lg font-medium focus:outline-hidden"
                  value={paymentForm.tanggalBayar}
                  onChange={(e) => setPaymentForm({ ...paymentForm, tanggalBayar: e.target.value })}
                />
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Metode Pembayaran *</label>
                <select
                  className="w-full bg-slate-50 px-3 py-2 border border-slate-200 rounded-lg font-medium focus:outline-hidden"
                  value={paymentForm.metodeBayar}
                  onChange={(e) => setPaymentForm({ ...paymentForm, metodeBayar: e.target.value })}
                >
                  <option value="Transfer BCA">Transfer BCA</option>
                  <option value="Transfer Mandiri">Transfer Mandiri</option>
                  <option value="Transfer BRI">Transfer BRI</option>
                  <option value="E-Wallet Dana">E-Wallet Dana</option>
                  <option value="E-Wallet OVO">E-Wallet OVO</option>
                  <option value="Cash / Tunai">Cash / Tunai</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="font-semibold text-slate-700">Catatan Tambahan (Opsional)</label>
                <input
                  type="text"
                  placeholder="Misal: Dibayar lunas melalui RT 03"
                  className="w-full bg-slate-50 px-3 py-2 border border-slate-200 rounded-lg font-medium focus:outline-hidden"
                  value={paymentForm.catatan}
                  onChange={(e) => setPaymentForm({ ...paymentForm, catatan: e.target.value })}
                />
              </div>

              <div className="flex justify-end gap-2.5 pt-3 border-t border-slate-150/55">
                <button
                  type="button"
                  onClick={() => setPaymentModalBill(null)}
                  className="px-3 py-1.5 hover:bg-slate-100 rounded-lg font-semibold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-indigo-600 text-white font-bold rounded-lg hover:bg-indigo-700 transition"
                >
                  Konfirmasi Lunas
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PRINT RECEIPT / KWITANSI MODAL PREVIEW */}
      {printReceiptBill && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-100 w-full max-w-lg overflow-hidden animate-zoomIn flex flex-col max-h-[90vh]">
            
            {/* Action Bar */}
            <div className="flex justify-between items-center bg-slate-800 text-white px-5 py-3.5 border-b border-slate-700">
              <h4 className="font-bold text-xs flex items-center gap-1.5">
                <Printer size={15} /> Kuitansi Pembayaran Digital
              </h4>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    const printContents = document.getElementById('kwitansi-print-area')?.innerHTML;
                    const originalContents = document.body.innerHTML;
                    if (printContents) {
                      const newWin = window.open('', '_blank');
                      newWin?.document.write(`
                        <html>
                          <head>
                            <title>Cetak Kwitansi ${printReceiptBill.id}</title>
                            <link href="https://cdn.jsdelivr.net/npm/tailwindcss@4.0.0/dist/index.min.css" rel="stylesheet">
                            <style>
                              body { font-family: 'Inter', sans-serif; padding: 40px; background: white; color: black; }
                              @media print {
                                body { padding: 0; }
                                .no-print { display: none; }
                              }
                            </style>
                          </head>
                          <body onload="window.print();window.close();">
                            ${printContents}
                          </body>
                        </html>
                      `);
                      newWin?.document.close();
                    }
                  }}
                  className="px-3 py-1 bg-indigo-600 text-white font-bold text-[10px] rounded-lg hover:bg-indigo-700 transition flex items-center gap-1 cursor-pointer"
                >
                  <Printer size={12} /> Cetak / Download PDF
                </button>
                <button 
                  onClick={() => setPrintReceiptBill(null)} 
                  className="p-1 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg transition"
                >
                  <X size={16} />
                </button>
              </div>
            </div>

            {/* Printable Area - Render Invoice Format */}
            <div id="kwitansi-print-area" className="p-6 overflow-y-auto bg-white flex-1 text-slate-800">
              <div className="border-[3px] border-double border-slate-300 p-6 rounded-xl space-y-6">
                
                {/* Invoice Header */}
                <div className="flex justify-between items-start border-b border-slate-200 pb-4">
                  <div>
                    <h3 className="text-base font-extrabold text-slate-900 tracking-tight">{settings.billingNamaPenyedia}</h3>
                    <p className="text-[10px] text-slate-500 mt-0.5">Layanan Koneksi Internet Cepat Mandiri</p>
                    <p className="text-[10px] text-slate-400 mt-1">PJ: {settings.pjNama}</p>
                  </div>
                  <div className="text-right">
                    <span className="px-2.5 py-0.5 bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-md font-bold text-[10px]">
                      KUITANSI RESMI (LUNAS)
                    </span>
                    <p className="text-[10px] font-mono text-slate-500 mt-2 font-bold">{printReceiptBill.id}</p>
                  </div>
                </div>

                {/* Details list */}
                <div className="space-y-2 text-[11px] text-slate-700">
                  <div className="grid grid-cols-3 border-b border-slate-100 pb-1.5">
                    <span className="text-slate-400">Telah Terima Dari :</span>
                    <span className="col-span-2 font-bold text-slate-800">{printReceiptBill.pelangganNama}</span>
                  </div>

                  <div className="grid grid-cols-3 border-b border-slate-100 pb-1.5">
                    <span className="text-slate-400">Alamat Pemasangan :</span>
                    <span className="col-span-2 text-slate-600">{printReceiptBill.pelangganNoHp} - {pelanggan.find(p => p.id === printReceiptBill.pelangganId)?.alamat}</span>
                  </div>

                  <div className="grid grid-cols-3 border-b border-slate-100 pb-1.5">
                    <span className="text-slate-400">Periode Tagihan :</span>
                    <span className="col-span-2 font-semibold text-slate-800">{formatBulanIndo(printReceiptBill.bulan)}</span>
                  </div>

                  <div className="grid grid-cols-3 border-b border-slate-100 pb-1.5">
                    <span className="text-slate-400">Tanggal Pelunasan :</span>
                    <span className="col-span-2 font-mono font-medium text-slate-600">{formatTanggalIndo(printReceiptBill.tanggalBayar || '')}</span>
                  </div>

                  <div className="grid grid-cols-3 border-b border-slate-100 pb-1.5">
                    <span className="text-slate-400">Metode Pembayaran :</span>
                    <span className="col-span-2 font-bold text-slate-700">{printReceiptBill.metodeBayar}</span>
                  </div>

                  {printReceiptBill.catatan && (
                    <div className="grid grid-cols-3 border-b border-slate-100 pb-1.5">
                      <span className="text-slate-400">Catatan :</span>
                      <span className="col-span-2 italic text-slate-500">{printReceiptBill.catatan}</span>
                    </div>
                  )}
                </div>

                {/* Payment Breakdown */}
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200/60 mt-4 flex items-center justify-between">
                  <div>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Jumlah Dibayar (Rupiah)</p>
                    <p className="text-xl font-black text-slate-800 font-serif mt-1">{formatRupiah(printReceiptBill.jumlah)}</p>
                  </div>
                  <div className="text-right flex flex-col items-end">
                    <span className="text-[10px] text-slate-400 font-bold">TERBILANG</span>
                    <span className="text-[10px] bg-white border border-slate-250/65 px-2.5 py-1 rounded-md mt-1 italic font-semibold text-slate-600 text-right">
                      {printReceiptBill.jumlah === 100000 && 'Seratus Ribu Rupiah'}
                      {printReceiptBill.jumlah === 150000 && 'Seratus Lima Puluh Ribu Rupiah'}
                      {printReceiptBill.jumlah === 250000 && 'Dua Ratus Lima Puluh Ribu Rupiah'}
                      {printReceiptBill.jumlah === 450000 && 'Empat Ratus Lima Puluh Ribu Rupiah'}
                      {![100000, 150000, 250000, 450000].includes(printReceiptBill.jumlah) && 'Dua Ratus Ribu Rupiah'}
                    </span>
                  </div>
                </div>

                {/* Receipt Signatures */}
                <div className="flex justify-between items-end pt-8 text-[11px]">
                  <div>
                    <p className="text-slate-400">Status Gateway WA</p>
                    <p className="text-emerald-600 font-bold mt-1">✔ TERKONFIRMASI SYSTEM</p>
                  </div>
                  <div className="text-center border-t border-slate-200 pt-2 w-36">
                    <p className="text-slate-400 text-[10px]">Penerima Kuasa / Kasir</p>
                    <p className="font-bold text-slate-800 mt-6">{settings.pjNama}</p>
                  </div>
                </div>

                <div className="text-center text-[9px] text-slate-300 font-mono pt-4 border-t border-slate-100">
                  Terima kasih atas pembayaran iuran iuran RT RW NET Mandiri demi kelancaran pembangunan fasilitas lingkungan bersama.
                </div>

              </div>
            </div>

          </div>
        </div>
      )}



      {showManualBillModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4 z-50 overflow-y-auto">
          <div className="bg-white rounded-2xl border border-slate-100 shadow-xl w-full max-w-md overflow-hidden animate-zoomIn my-8">
            <div className="flex justify-between items-center bg-slate-50 px-5 py-4 border-b border-slate-100">
              <h3 className="text-sm font-black text-slate-800 flex items-center gap-1.5 uppercase">
                <span>➕ Tambah Tagihan Manual</span>
              </h3>
              <button
                type="button"
                onClick={() => setShowManualBillModal(false)}
                className="text-slate-400 hover:text-slate-600 transition cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!manualBillForm.pelangganNama.trim()) {
                  alert('Silakan masukkan nama pelanggan!');
                  return;
                }
                if (!manualBillForm.jumlah || Number(manualBillForm.jumlah) <= 0) {
                  alert('Nilai nominal tagihan harus diisi dan valid!');
                  return;
                }

                const manualInvoice: Tagihan = {
                  id: `INV-${Date.now().toString().slice(-5)}-${Math.floor(100+Math.random()*900)}`,
                  pelangganId: `manual-cust-${Date.now()}`,
                  pelangganNama: manualBillForm.pelangganNama,
                  pelangganNoHp: manualBillForm.pelangganNoHp || '08',
                  bulan: manualBillForm.bulan,
                  jumlah: Number(manualBillForm.jumlah),
                  tanggalJatuhTempo: manualBillForm.tanggalJatuhTempo,
                  status: manualBillForm.status,
                  waSent: false,
                  pelangganAlamat: manualBillForm.pelangganAlamat,
                  pelangganKategori: manualBillForm.pelangganKategori,
                };

                onAddManualTagihan(manualInvoice);
                setShowManualBillModal(false);
                alert(`Tagihan manual untuk "${manualBillForm.pelangganNama}" berhasil dimasukkan!`);
              }}
              className="p-5 space-y-4 text-xs text-slate-600 font-medium"
            >
              {/* Nama Pelanggan */}
              <div className="space-y-1.5 text-left">
                <label className="block text-slate-500 font-bold">Nama Pelanggan *</label>
                <input
                  type="text"
                  required
                  placeholder="Masukkan nama pelanggan..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white outline-hidden focus:ring-1 focus:ring-indigo-500 font-semibold"
                  value={manualBillForm.pelangganNama}
                  onChange={(e) => setManualBillForm({ ...manualBillForm, pelangganNama: e.target.value })}
                />
              </div>

              {/* No HP */}
              <div className="space-y-1.5 text-left">
                <label className="block text-slate-500 font-bold">Nomor HP / WhatsApp (Opsional)</label>
                <input
                  type="text"
                  placeholder="08xxxxxxxxxx"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white outline-hidden focus:ring-1 focus:ring-indigo-500 font-semibold"
                  value={manualBillForm.pelangganNoHp}
                  onChange={(e) => setManualBillForm({ ...manualBillForm, pelangganNoHp: e.target.value })}
                />
              </div>

              {/* Alamat */}
              <div className="space-y-1.5 text-left">
                <label className="block text-slate-500 font-bold">Alamat Pelanggan</label>
                <input
                  type="text"
                  placeholder="Contoh: Jl. Merdeka No 12"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white outline-hidden focus:ring-1 focus:ring-indigo-500 font-semibold"
                  value={manualBillForm.pelangganAlamat}
                  onChange={(e) => setManualBillForm({ ...manualBillForm, pelangganAlamat: e.target.value })}
                />
              </div>

              {/* Kategori */}
              <div className="space-y-1.5 text-left">
                <label className="block text-slate-500 font-bold">Kategori Layanan</label>
                <select
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white outline-hidden font-bold"
                  value={manualBillForm.pelangganKategori}
                  onChange={(e) => setManualBillForm({ ...manualBillForm, pelangganKategori: e.target.value as any })}
                >
                  <option value="Rumahan">Rumahan</option>
                  <option value="PPPoE">PPPoE</option>
                  <option value="Hotspot">WiFi Hotspot</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3 text-left">
                {/* Bulan */}
                <div className="space-y-1.5">
                  <label className="block text-slate-500 font-bold">Bulan Periode</label>
                  <input
                    type="month"
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white outline-hidden font-semibold"
                    value={manualBillForm.bulan}
                    onChange={(e) => setManualBillForm({ ...manualBillForm, bulan: e.target.value })}
                  />
                </div>

                {/* Jatuh Tempo */}
                <div className="space-y-1.5">
                  <label className="block text-slate-500 font-bold">Batas Jatuh Tempo</label>
                  <input
                    type="date"
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white outline-hidden font-semibold"
                    value={manualBillForm.tanggalJatuhTempo}
                    onChange={(e) => setManualBillForm({ ...manualBillForm, tanggalJatuhTempo: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 text-left">
                {/* Jumlah Tagihan */}
                <div className="space-y-1.5">
                  <label className="block text-slate-500 font-bold">Jumlah Tagihan (Rp) *</label>
                  <input
                    type="number"
                    required
                    placeholder="Contoh: 150000"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white outline-hidden focus:ring-1 focus:ring-indigo-500 font-mono font-bold"
                    value={manualBillForm.jumlah}
                    onChange={(e) => setManualBillForm({ ...manualBillForm, jumlah: e.target.value })}
                  />
                </div>

                {/* Status Awal */}
                <div className="space-y-1.5">
                  <label className="block text-slate-500 font-bold">Status Awal</label>
                  <select
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 text-slate-800 focus:bg-white outline-hidden font-bold"
                    value={manualBillForm.status}
                    onChange={(e) => setManualBillForm({ ...manualBillForm, status: e.target.value as any })}
                  >
                    <option value="BELUM_BAYAR">Belum Bayar</option>
                    <option value="LUNAS">Sudah Lunas</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowManualBillModal(false)}
                  className="px-4 py-2 bg-slate-200 hover:bg-slate-300 rounded-xl font-bold text-slate-600 transition cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition cursor-pointer"
                >
                  Simpan Tagihan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      </div>
      ) : (
        <PelangganTab
          pelanggan={pelanggan}
          paket={paket}
          collectors={collectors}
          onAddPelanggan={onAddPelanggan}
          onUpdatePelanggan={onUpdatePelanggan}
          onDeletePelanggan={onDeletePelanggan}
        />
      )}
    </div>
  );
}
