import React from 'react';
import { Pelanggan, Tagihan, Paket, AppSettings } from '../types';
import { formatRupiah, formatBulanIndo, isPastDue } from '../utils';
import { 
  Users, CreditCard, AlertTriangle, CheckCircle, ArrowUpRight, Ban, Send, DollarSign,
  Server, Wifi, RefreshCw, Store, ClipboardList, UserCheck, MessageSquare, Settings, LayoutGrid
} from 'lucide-react';

interface DashboardStatsProps {
  pelanggan: Pelanggan[];
  tagihan: Tagihan[];
  paket: Paket[];
  targetBulan: string;
  onSelectTab: (tab: string) => void;
  onSendSingleWa: (tagihan: Tagihan) => void;
  currentDateStr: string;
  settings: AppSettings;
}

export default function DashboardStats({
  pelanggan,
  tagihan,
  paket,
  targetBulan,
  onSelectTab,
  onSendSingleWa,
  currentDateStr,
  settings
}: DashboardStatsProps) {
  // Mapping for permitted quick access menus
  const quickMenuMap: Record<string, { label: string; icon: React.ComponentType<{ size: number; className?: string }>; color: string }> = {
    mikrotik: { label: 'Router Mikrotik', icon: Server, color: 'text-sky-600 bg-sky-50' },
    pelanggan: { label: 'Data Pelanggan', icon: Users, color: 'text-indigo-600 bg-indigo-50' },
    hotspot: { label: 'Hotspot Voucher', icon: Wifi, color: 'text-amber-600 bg-amber-50' },
    pppoe: { label: 'PPPoE (Kabel)', icon: RefreshCw, color: 'text-purple-600 bg-purple-50' },
    reseller: { label: 'Agen / Reseller', icon: Store, color: 'text-emerald-600 bg-emerald-50' },
    pesanan_agen: { label: 'Pesanan Agen', icon: ClipboardList, color: 'text-rose-600 bg-rose-50' },
    tukang_tagih: { label: 'Tukang Tagih', icon: UserCheck, color: 'text-cyan-600 bg-cyan-50' },
    teknisi: { label: 'Akses Teknisi', icon: UserCheck, color: 'text-blue-600 bg-blue-50' },
    tagihan: { label: 'Tagihan Bulanan', icon: CreditCard, color: 'text-indigo-700 bg-indigo-100' },
    notifikasi: { label: 'WA Gateway API', icon: MessageSquare, color: 'text-emerald-700 bg-emerald-100' },
    payment_gateway: { label: 'Payment Gateway', icon: CreditCard, color: 'text-indigo-600 bg-indigo-50' },
    voucher_look: { label: 'Portal Voucher Look', icon: Settings, color: 'text-teal-600 bg-teal-50' },
    pengaturan_umum: { label: 'Pengaturan Umum', icon: Settings, color: 'text-slate-600 bg-slate-50' }
  };

  const showQuickMenus = settings?.showQuickMenus || ['pelanggan', 'hotspot', 'tagihan', 'pppoe', 'reseller', 'teknisi'];
  
  const selectedQuickMenus = showQuickMenus
    .map(id => {
      const info = quickMenuMap[id];
      if (!info) return null;
      return { id, ...info };
    })
    .filter(Boolean) as Array<{ id: string; label: string; icon: React.ComponentType<{ size: number; className?: string }>; color: string }>;

  // Filter bills for the selected target month
  const billsThisMonth = tagihan.filter((t) => t.bulan === targetBulan);

  // Stats Calculations
  const activePelangganCount = pelanggan.filter((p) => p.statusAktif).length;
  const inactivePelangganCount = pelanggan.filter((p) => !p.statusAktif).length;
  
  // Total potential income for this month based on active customers' tariffs
  const totalPotentialRevenue = pelanggan
    .filter((p) => p.statusAktif)
    .reduce((acc, p) => acc + p.tarif, 0);

  // Received income (LUNAS index)
  const receivedRevenue = billsThisMonth
    .filter((t) => t.status === 'LUNAS')
    .reduce((acc, t) => acc + t.jumlah, 0);

  // Outstanding/Unpaid income
  const outstandingRevenue = billsThisMonth
    .filter((t) => t.status !== 'LUNAS')
    .reduce((acc, t) => acc + t.jumlah, 0);

  // Bills count
  const paidCount = billsThisMonth.filter((t) => t.status === 'LUNAS').length;
  const unpaidCount = billsThisMonth.filter((t) => t.status === 'BELUM_BAYAR').length;
  
  // High-priority alert bills (unpaid & past due)
  const overdueBills = billsThisMonth.filter(
    (t) => t.status !== 'LUNAS' && isPastDue(t.tanggalJatuhTempo, currentDateStr)
  );

  // Chart data: Distribution of customers per Package
  const customersPerPackage = paket.map((pkt) => {
    const count = pelanggan.filter((p) => p.paketId === pkt.id && p.statusAktif).length;
    return {
      nama: pkt.nama,
      kecepatan: pkt.kecepatan,
      count,
      percentage: pelanggan.filter(p => p.statusAktif).length > 0
        ? Math.round((count / pelanggan.filter(p => p.statusAktif).length) * 100)
        : 0
    };
  });

  return (
    <div className="space-y-6">
      {/* Target Month Indicator Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-xl border border-slate-100 shadow-xs">
        <div>
          <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-wider">Laporan bulan berjalan</h2>
          <p className="text-xl font-bold font-sans text-slate-800">
            📊 Ringkasan Keuangan Periode {formatBulanIndo(targetBulan)}
          </p>
        </div>
        <div className="flex items-center gap-2 text-xs font-mono bg-slate-50 text-slate-500 px-3 py-1.5 rounded-lg border border-slate-100">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          Kalender Sistem: {formatBulanIndo(currentDateStr.substring(0, 7))} 2026
        </div>
      </div>

      {/* QUICK LAUNCH SHORTCUTS (MENU PINTASAN) */}
      {selectedQuickMenus.length > 0 && (
        <div className="bg-slate-50 p-5 rounded-2xl border border-slate-200 shadow-3xs space-y-3.5">
          <div className="flex items-center gap-2 text-indigo-700">
            <div className="p-1.5 bg-indigo-50 rounded-lg text-indigo-600">
              <LayoutGrid size={14} className="animate-pulse" />
            </div>
            <div>
              <span className="font-extrabold text-slate-800 text-[11px] tracking-wide uppercase">⚡ Menu Pintasan Lansung (Quick Access Links)</span>
              <p className="text-[9px] text-slate-400 font-normal">Pintasan navigasi cepat yang dikonfigurasikan dari Menu Pengaturan Umum.</p>
            </div>
          </div>
          
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {selectedQuickMenus.map((m) => {
              const IconComponent = m.icon;
              return (
                <button
                  key={m.id}
                  onClick={() => onSelectTab(m.id)}
                  className="flex flex-col items-center justify-center p-3.5 bg-white hover:bg-slate-50 hover:shadow-2xs border border-slate-200 hover:border-indigo-300 rounded-xl cursor-pointer font-bold text-center group transition text-xs space-y-2 select-none"
                >
                  <div className={`p-2.5 rounded-xl ${m.color} group-hover:scale-110 group-hover:rotate-3 transition shrink-0 shadow-3xs`}>
                    <IconComponent size={16} />
                  </div>
                  <span className="text-slate-700 group-hover:text-indigo-700 text-[11px] font-extrabold truncate max-w-full leading-tight">
                    {m.label}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Grid Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Pelanggan */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm relative overflow-hidden group">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-slate-400">Pelanggan Aktif</p>
              <h3 className="text-3xl font-bold text-slate-800 mt-1 font-sans">{activePelangganCount}</h3>
              <p className="text-xs text-slate-500 mt-2 flex items-center gap-1">
                <span className="inline-block w-1.5 h-1.5 rounded-full bg-red-400"></span>
                {inactivePelangganCount} Non-aktif / Isolir
              </p>
            </div>
            <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl">
              <Users size={20} />
            </div>
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-indigo-650 scale-x-0 group-hover:scale-x-100 transition-transform duration-300" />
        </div>

        {/* Card 2: Omzet Lunas */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm relative overflow-hidden group">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-slate-400">Pendapatan Diterima</p>
              <h3 className="text-2xl font-bold text-emerald-600 mt-1 font-sans">{formatRupiah(receivedRevenue)}</h3>
              <p className="text-xs text-slate-500 mt-2 flex items-center gap-1">
                <span className="text-emerald-500 font-semibold">{paidCount}</span> dari {billsThisMonth.length} Tagihan lunas
              </p>
            </div>
            <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
              <CheckCircle size={20} />
            </div>
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-emerald-500 scale-x-0 group-hover:scale-x-100 transition-transform duration-300" />
        </div>

        {/* Card 3: Tertunggak */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm relative overflow-hidden group">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-slate-400">Belum Tertagih</p>
              <h3 className="text-2xl font-bold text-amber-600 mt-1 font-sans">{formatRupiah(outstandingRevenue)}</h3>
              <p className="text-xs text-slate-500 mt-2 flex items-center gap-1">
                <span className="text-amber-500 font-semibold">{unpaidCount}</span> pelanggan belum melunasi
              </p>
            </div>
            <div className="p-3 bg-amber-50 text-amber-600 rounded-xl">
              <CreditCard size={20} />
            </div>
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-amber-500 scale-x-0 group-hover:scale-x-100 transition-transform duration-300" />
        </div>

        {/* Card 4: Jatuh Tempo */}
        <div className="bg-white p-5 rounded-2xl border border-slate-100 shadow-sm relative overflow-hidden group">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-sm font-medium text-slate-400">Tagihan Terlambat</p>
              <h3 className="text-2xl font-bold text-rose-600 mt-1 font-sans">{overdueBills.length}</h3>
              <p className="text-xs text-slate-500 mt-2 flex items-center gap-1">
                Total krisis: <span className="text-rose-600 font-semibold">{formatRupiah(overdueBills.reduce((acc, t) => acc + t.jumlah, 0))}</span>
              </p>
            </div>
            <div className="p-3 bg-rose-50 text-rose-600 rounded-xl">
              <AlertTriangle size={20} />
            </div>
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-rose-500 scale-x-0 group-hover:scale-x-100 transition-transform duration-300" />
        </div>
      </div>

      {/* Main Stats Layout Panels */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Left Side: Distribution of Active Subscribers per category */}
        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
          <div className="flex items-center justify-between mb-5">
            <h4 className="font-bold text-slate-700">📶 Kategori Pelanggan Aktif</h4>
            <button 
              onClick={() => onSelectTab('pelanggan')} 
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-700 flex items-center gap-1 hover:underline"
            >
              Lihat Pelanggan <ArrowUpRight size={14} />
            </button>
          </div>
          <div className="space-y-6 py-2">
            {(() => {
              const activeRumahan = pelanggan.filter((p) => p.kategoriLangganan === 'Rumahan' && p.statusAktif).length;
              const activeHotspot = pelanggan.filter((p) => p.kategoriLangganan === 'Hotspot' && p.statusAktif).length;
              const totalActive = activeRumahan + activeHotspot;
              const pctRumahan = totalActive > 0 ? Math.round((activeRumahan / totalActive) * 100) : 0;
              const pctHotspot = totalActive > 0 ? Math.round((activeHotspot / totalActive) * 100) : 0;

              return (
                <div className="space-y-5">
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs font-medium text-slate-600">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-sky-500" />
                        <span className="font-bold text-slate-700">Rumahan (Kabel/PPPoE)</span>
                      </div>
                      <div>
                        <span className="text-slate-800 font-bold">{activeRumahan}</span> Pelanggan ({pctRumahan}%)
                      </div>
                    </div>
                    <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                      <div 
                        className="bg-sky-500 h-full rounded-full transition-all duration-500"
                        style={{ width: `${pctRumahan}%` }}
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs font-medium text-slate-600">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                        <span className="font-bold text-slate-700">WiFi Hotspot (Voucher)</span>
                      </div>
                      <div>
                        <span className="text-slate-800 font-bold">{activeHotspot}</span> Pelanggan ({pctHotspot}%)
                      </div>
                    </div>
                    <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                      <div 
                        className="bg-amber-500 h-full rounded-full transition-all duration-500"
                        style={{ width: `${pctHotspot}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>
        </div>

        {/* Right Side: Financial Progress bar (Target vs Collected) */}
        <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm flex flex-col justify-between">
          <div>
            <h4 className="font-bold text-slate-700 mb-2">💰 Target Kolektibilitas Tagihan</h4>
            <p className="text-xs text-slate-400 mb-6">Persentasi perbandingan dana masuk dengan target omzet paket aktif bulan {formatBulanIndo(targetBulan)}</p>
            
            {/* Calculation of percent of invoice collected */}
            {(() => {
              const totalInvoiced = billsThisMonth.reduce((acc, t) => acc + t.jumlah, 0);
              const pct = totalInvoiced > 0 ? Math.round((receivedRevenue / totalInvoiced) * 100) : 0;
              return (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs text-slate-400">Total Omzet Tertagih</p>
                      <h4 className="text-xl font-bold text-slate-800 font-sans">{formatRupiah(totalInvoiced)}</h4>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-slate-400">Dana Masuk (Lunas)</p>
                      <h4 className="text-xl font-bold text-emerald-600 font-sans">{formatRupiah(receivedRevenue)} ({pct}%)</h4>
                    </div>
                  </div>

                  <div className="relative pt-1">
                    <div className="overflow-hidden h-4 text-xs flex rounded-full bg-amber-100">
                      <div 
                        style={{ width: `${pct}%` }} 
                        className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-emerald-500 transition-all duration-[800ms] rounded-full"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-xs pt-2">
                    <div className="bg-emerald-50 p-3 rounded-lg border border-emerald-100 text-emerald-800">
                      <p className="font-semibold text-emerald-600 uppercase tracking-widest text-[10px]">LUNAS</p>
                      <p className="text-base font-bold mt-1 font-sans">{formatRupiah(receivedRevenue)}</p>
                      <p className="text-[10px] mt-1">{paidCount} Pelanggan</p>
                    </div>
                    <div className="bg-amber-50 p-3 rounded-lg border border-amber-100 text-amber-800">
                      <p className="font-semibold text-amber-600 uppercase tracking-widest text-[10px]">BELUM BAYAR</p>
                      <p className="text-base font-bold mt-1 font-sans">{formatRupiah(outstandingRevenue)}</p>
                      <p className="text-[10px] mt-1">{unpaidCount} Pelanggan</p>
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>
        </div>
      </div>

      {/* Critical overdue alert with single whatsapp click */}
      {overdueBills.length > 0 && (
        <div className="bg-red-50/60 rounded-2xl border border-red-100 p-6">
          <div className="flex items-start gap-4">
            <div className="p-3 bg-red-100 text-red-600 rounded-xl mt-0.5">
              <AlertTriangle size={22} className="animate-bounce" />
            </div>
            <div className="flex-1">
              <h4 className="font-bold text-slate-800 text-lg">⚠️ Peringatan Tunggakan Jatuh Tempo</h4>
              <p className="text-sm text-slate-600 mt-1">
                Terdapat <span className="font-bold text-red-600">{overdueBills.length} pelanggan</span> yang telah melewati batas tanggal jatuh tempo pembayaran namun belum melunasi tagihannya.
              </p>
              
              <div className="mt-4 overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-600">
                  <thead>
                    <tr className="border-b border-red-200 text-slate-500">
                      <th className="pb-2 font-semibold">Nama Pelanggan</th>
                      <th className="pb-2 font-semibold">Jatuh Tempo</th>
                      <th className="pb-2 font-semibold">Jumlah Tagihan</th>
                      <th className="pb-2 font-semibold">HP / WhatsApp</th>
                      <th className="pb-2 text-right font-semibold">Kirim Notifikasi</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-red-100">
                    {Array.isArray(overdueBills) ? overdueBills.slice(0, 4).map((t, index) => (
                      <tr key={index} className="hover:bg-red-50/40">
                        <td className="py-2.5 font-semibold text-slate-800">{t.pelangganNama}</td>
                        <td className="py-2.5 text-rose-600 font-semibold">{t.tanggalJatuhTempo}</td>
                        <td className="py-2.5 font-mono">{formatRupiah(t.jumlah)}</td>
                        <td className="py-2.5 font-mono">{t.pelangganNoHp}</td>
                        <td className="py-2 text-right">
                          <button
                            onClick={() => onSendSingleWa(t)}
                            className="inline-flex items-center gap-1.5 px-3 py-1 bg-rose-600 text-white rounded-lg hover:bg-rose-700 transition font-medium cursor-pointer shadow-xs"
                          >
                            <Send size={12} /> Kirim Tagihan
                          </button>
                        </td>
                      </tr>
                    )) : null}
                  </tbody>
                </table>
              </div>
              
              {overdueBills.length > 4 && (
                <div className="mt-3 text-right">
                  <button 
                    onClick={() => onSelectTab('tagihan')}
                    className="text-xs font-semibold text-rose-700 hover:underline cursor-pointer"
                  >
                    Lihat semua {overdueBills.length} tunggakan &rarr;
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
